=== ArraySubsPro - Pro Addon for ArraySubs WooCommerce Subscription Plugin ===
Contributors: emranio
Tags: woocommerce subscription, recurring billing, subscription management, membership, store credits
Requires at least: 6.0
Tested up to: 6.9
Stable tag: 1.0.1
Requires PHP: 8.1
License: GPLv3 or later
License URI: https://www.gnu.org/licenses/gpl-3.0.html


== Changelog ==

= v1.0.1 - 10 april, 2026 =
* Fixed: "Headers already sent" error caused by output before session start.

= 1.0.0 =
* Initial release

== Support ==

For support, please visit our documentation or contact the development team at emran@arrayhash.com .

== License ==

This plugin is licensed under the GPL v3 License. See the LICENSE file for more details.
