<?php

namespace ArraySubsPro;

defined('ABSPATH') || exit;


use ArraySubsPro\Features;
use ArraySubs\Supports\Config;

class Boot
{
    public function __construct()
    {
        Config::add('proplugin.src_path', __DIR__);

        add_action('admin_enqueue_scripts', [$this, 'enqueueAdminAssets'], 10);

        add_filter('arraysubs_boot_classes', function (array $classes = []) {
            return array_merge($classes, [
                // Feature Manager (product features/entitlements)
                Features\FeatureManager\Provider::class,

                // Store Credit System
                Features\StoreCredit\Provider::class,

                // Subscription Shipping (one-time vs recurring shipping)
                Features\SubscriptionShipping\Provider::class,

                // Analytics (order type classification, WC Analytics integration)
                Features\Analytics\Provider::class,

                // Automatic Payments (gateway infrastructure)
                Features\AutomaticPayments\Provider::class,

                // Member Insight (member lookup and insight dashboard)
                Features\MemberInsight\Provider::class,

                // Redirect Product Page (per-product page redirect or 404)
                Features\RedirectProductPage\Provider::class,

                // Fixed Period Membership (fixed end dates, enrollment windows)
                Features\FixedPeriodMembership\Provider::class,

                // Audits (activity audit logs, scheduled-job visibility)
                Features\Audits\Provider::class,

                // Multi-Login Prevention (concurrent session limits)
                Features\MultiLoginPrevention\Provider::class,

                // Checkout Builder (checkout field customization)
                Features\CheckoutBuilder\Provider::class,
            ]);
        }, 10, 1);
    }

    public function enqueueAdminAssets() {}
}
