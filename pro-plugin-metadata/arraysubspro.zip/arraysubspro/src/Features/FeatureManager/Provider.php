<?php

/**
 * Feature Manager Provider
 *
 * Entry point for the Feature Manager feature.
 *
 * @package ArraySubsPro\Features\FeatureManager
 * @since 1.0.0
 */

namespace ArraySubsPro\Features\FeatureManager;

defined('ABSPATH') || exit;

use ArraySubs\Supports\Abstracts\AbstractLoader;

/**
 * Feature Manager Provider
 */
class Provider extends AbstractLoader
{
    /**
     * Constructor
     */
    public function __construct()
    {
        $this->classLoader([
            plugin_dir_path(__FILE__) . 'Services',
            plugin_dir_path(__FILE__) . 'REST',
        ]);
    }
}
