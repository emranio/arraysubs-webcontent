<?php

/**
 * Feature Manager My Account Hooks
 *
 * Integrates Feature Manager into WooCommerce My Account.
 *
 * @package ArraySubsPro\Features\FeatureManager\Services
 * @since 1.0.0
 */

namespace ArraySubsPro\Features\FeatureManager\Services;

defined('ABSPATH') || exit;

/**
 * My Account hooks class
 */
class MyAccountHooks
{
    /**
     * Enable auto-loading
     *
     * @var bool
     */
    public static $loadable = true;

    /**
     * Constructor
     */
    public function __construct()
    {
        // Check if Feature Manager is enabled and My Account display is on
        if (!$this->isEnabled() || !$this->showInMyAccount()) {
            return;
        }

        // Register endpoints
        add_action('init', [$this, 'registerEndpoints']);

        // Add menu items
        add_filter('woocommerce_account_menu_items', [$this, 'addMenuItems'], 15, 1);

        // Template content
        add_action('woocommerce_account_features_endpoint', [$this, 'featuresEndpointContent']);

        // Flush rewrite rules on activation (run once)
        if (get_option('arraysubs_features_flush_rewrite_rules') !== 'done') {
            add_action('init', function () {
                flush_rewrite_rules();
                update_option('arraysubs_features_flush_rewrite_rules', 'done');
            }, 99);
        }
    }

    /**
     * Check if Feature Manager is enabled
     *
     * @return bool
     */
    private function isEnabled(): bool
    {
        return (bool) arraysubs_get_setting('feature_manager.enabled', true);
    }

    /**
     * Check if features should show in My Account
     *
     * @return bool
     */
    private function showInMyAccount(): bool
    {
        return (bool) arraysubs_get_setting('feature_manager.show_in_my_account', true);
    }

    /**
     * Register WooCommerce endpoints
     *
     * @return void
     */
    public function registerEndpoints(): void
    {
        add_rewrite_endpoint('features', EP_ROOT | EP_PAGES);
    }

    /**
     * Add menu items to My Account
     *
     * @param array $items Menu items
     * @return array Modified menu items
     */
    public function addMenuItems(array $items): array
    {
        // Insert after subscriptions
        $new_items = [];

        foreach ($items as $key => $label) {
            $new_items[$key] = $label;

            if ($key === 'subscriptions') {
                $new_items['features'] = $this->getDefaultMenuLabel();
            }
        }

        // If subscriptions key wasn't found, add after orders
        if (!isset($new_items['features'])) {
            $new_items_with_features = [];
            foreach ($items as $key => $label) {
                $new_items_with_features[$key] = $label;
                if ($key === 'orders') {
                    $new_items_with_features['features'] = $this->getDefaultMenuLabel();
                }
            }
            $new_items = $new_items_with_features;
        }

        return $new_items;
    }

    /**
     * Get the default My Account label for the features endpoint.
     *
     * Menu label customization is handled by the My Account editor module,
     * so Feature Manager only provides its default endpoint label.
     *
     * @return string
     */
    private function getDefaultMenuLabel(): string
    {
        return \__('My Features', 'arraysubs');
    }

    /**
     * Features endpoint content
     *
     * @return void
     */
    public function featuresEndpointContent(): void
    {
        $arraysubs_customer_id = get_current_user_id();
        $arraysubs_aggregation_mode = arraysubs_get_feature_manager_aggregation_mode();
        $arraysubs_page_title = arraysubs_get_feature_manager_my_account_page_title();
        $arraysubs_show_usage_count = arraysubs_show_feature_usage_in_my_account();

        // Get all entitled features
        $arraysubs_features_data = $this->collectCustomerFeatures($arraysubs_customer_id, $arraysubs_aggregation_mode);

        include dirname(__DIR__) . '/views/my-account-features.php';
    }

    /**
     * Collect customer features based on aggregation mode
     *
     * @param int    $customer_id      Customer ID
     * @param string $aggregation_mode Aggregation mode
     * @return array
     */
    private function collectCustomerFeatures(int $customer_id, string $aggregation_mode): array
    {
        $normalized_mode = arraysubs_sanitize_feature_manager_aggregation_mode($aggregation_mode);
        $core_mode = $normalized_mode === 'combine' ? 'combine' : 'per_subscription';
        $all_features = arraysubs_get_customer_features($customer_id, $core_mode);

        if ($normalized_mode === 'per_subscription') {
            foreach ($all_features as &$feature_group) {
                $feature_group['features'] = $this->decorateFeaturesWithUsage(
                    $feature_group['features'] ?? [],
                    (int) ($feature_group['subscription_id'] ?? 0)
                );
            }

            unset($feature_group);

            return $all_features;
        }

        return $this->decorateFeaturesWithUsage($all_features, 0, $customer_id);
    }

    /**
     * Decorate features with usage data.
     *
     * @param array $features        Feature rows.
     * @param int   $subscription_id Subscription ID.
     * @param int   $customer_id     Customer ID.
     * @return array
     */
    private function decorateFeaturesWithUsage(array $features, int $subscription_id = 0, int $customer_id = 0): array
    {
        foreach ($features as &$feature) {
            $feature['usage'] = null;

            if (($feature['type'] ?? '') !== 'number' || empty($feature['name'])) {
                continue;
            }

            if ($subscription_id > 0) {
                $feature['usage'] = arraysubs_get_feature_usage($subscription_id, $feature['name']);
                continue;
            }

            if ($customer_id > 0) {
                $feature['usage'] = arraysubs_get_customer_feature_usage($customer_id, $feature['name']);
            }
        }

        unset($feature);

        return array_values($features);
    }
}
