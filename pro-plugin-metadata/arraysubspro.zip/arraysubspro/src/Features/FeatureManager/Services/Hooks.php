<?php

/**
 * Feature Manager Hooks
 *
 * Handles WordPress hooks for the Feature Manager feature.
 *
 * @package ArraySubsPro\Features\FeatureManager\Services
 * @since 1.0.0
 */

namespace ArraySubsPro\Features\FeatureManager\Services;

defined('ABSPATH') || exit;

use ArraySubs\Supports\Config;
use WC_Product;
use WC_Product_Variation;
use WP_Post;

/**
 * Hooks class
 */
class Hooks
{
    /**
     * Enable auto-loading
     *
     * @var bool
     */
    public static $loadable = true;

    /**
     * Constructor
     */
    public function __construct()
    {
        // Check if Feature Manager is enabled in settings
        if (!$this->isEnabled()) {
            return;
        }

        // Register product meta
        add_action('init', [$this, 'registerProductMeta']);

        // Add Feature Manager tab to product data
        add_filter('woocommerce_product_data_tabs', [$this, 'addProductDataTab']);
        add_action('woocommerce_product_data_panels', [$this, 'addProductDataPanel']);

        // Add Feature Manager section to variations
        add_action('woocommerce_product_after_variable_attributes', [$this, 'addVariationFields'], 10, 3);
        add_action('woocommerce_admin_process_variation_object', [$this, 'saveVariationObjectMeta'], 10, 2);
        add_action('woocommerce_save_product_variation', [$this, 'saveVariationFields'], 10, 2);

        // Save product meta
        add_action('woocommerce_admin_process_product_object', [$this, 'saveProductObjectMeta'], 10, 1);
        add_action('woocommerce_process_product_meta', [$this, 'saveProductMeta']);

        // Enqueue admin assets
        add_action('admin_enqueue_scripts', [$this, 'enqueueAssets'], 100);

        // Display features on product page (optional)
        if ($this->showOnProductPage()) {
            add_action('woocommerce_single_product_summary', [$this, 'displayProductFeatures'], 25);
        }
    }

    /**
     * Check if Feature Manager is enabled
     *
     * @return bool
     */
    private function isEnabled(): bool
    {
        return (bool) arraysubs_get_setting('feature_manager.enabled', true);
    }

    /**
     * Check if features should show on product page
     *
     * @return bool
     */
    private function showOnProductPage(): bool
    {
        return (bool) arraysubs_get_setting('feature_manager.show_on_product_page', true);
    }

    /**
     * Register product meta fields
     *
     * @return void
     */
    public function registerProductMeta(): void
    {
        // Register for simple products
        register_post_meta('product', '_arraysubs_features', [
            'type'              => 'string',
            'single'            => true,
            'show_in_rest'      => true,
            'default'           => '[]',
            'description'       => __('Product features JSON array', 'arraysubspro'),
            'sanitize_callback' => [$this, 'sanitizeFeaturesJson'],
            'auth_callback'     => function () {
                return current_user_can('edit_products');
            },
        ]);

        // Register for variations
        register_post_meta('product_variation', '_arraysubs_features', [
            'type'              => 'string',
            'single'            => true,
            'show_in_rest'      => true,
            'default'           => '[]',
            'description'       => __('Product variation features JSON array', 'arraysubspro'),
            'sanitize_callback' => [$this, 'sanitizeFeaturesJson'],
            'auth_callback'     => function () {
                return current_user_can('edit_products');
            },
        ]);
    }

    /**
     * Sanitize features JSON
     *
     * @param string $value JSON string
     * @return string Sanitized JSON string
     */
    public function sanitizeFeaturesJson($value): string
    {
        if (is_array($value)) {
            $decoded = $value;
        } else {
            $decoded = json_decode((string) $value, true);
        }

        if (!is_array($decoded)) {
            return '[]';
        }

        $sanitized = $this->sanitizeFeatures($decoded);

        return wp_json_encode($sanitized);
    }

    /**
     * Sanitize decoded feature data.
     *
     * @param array $decoded Decoded feature rows.
     * @return array<int, array<string, mixed>>
     */
    private function sanitizeFeatures(array $decoded): array
    {
        $sanitized = [];

        foreach ($decoded as $feature) {
            if (!is_array($feature)) {
                continue;
            }

            $name = sanitize_text_field($feature['name'] ?? '');
            if ('' === $name) {
                continue;
            }

            $type = in_array($feature['type'] ?? 'text', ['toggle', 'number', 'text'], true)
                ? $feature['type']
                : 'text';

            $value = sanitize_text_field($feature['value'] ?? '');
            $value = trim($value);

            if ('number' === $type) {
                if ('' === $value) {
                    continue;
                }

                if (0 === strcasecmp($value, 'unlimited')) {
                    $value = 'Unlimited';
                } elseif (!is_numeric($value)) {
                    continue;
                }
            }

            if ('toggle' !== $type && '' === $value) {
                continue;
            }

            $sanitized[] = [
                'id'      => sanitize_key($feature['id'] ?? uniqid('feature_')),
                'name'    => $name,
                'type'    => $type,
                'value'   => ('toggle' === $type && '' === $value) ? 'No' : $value,
                'enabled' => !empty($feature['enabled']),
                'order'   => absint($feature['order'] ?? 0),
            ];
        }

        return $sanitized;
    }

    /**
     * Add Feature Manager tab to product data tabs
     *
     * @param array $tabs Existing tabs
     * @return array Modified tabs
     */
    public function addProductDataTab(array $tabs): array
    {
        $tabs['arraysubs_features'] = [
            'label'    => __('Feature Manager', 'arraysubspro'),
            'target'   => 'arraysubs_features_data',
            'class'    => ['show_if_simple', 'hide_if_grouped', 'hide_if_external'],
            'priority' => 75, // Before Advanced tab (80)
        ];

        return $tabs;
    }

    /**
     * Add Feature Manager panel content
     *
     * @return void
     */
    public function addProductDataPanel(): void
    {
        global $post;

        $features = get_post_meta($post->ID, '_arraysubs_features', true);
        $features = $features ? $features : '[]';
?>
        <div id="arraysubs_features_data" class="panel woocommerce_options_panel">
            <div class="options_group arraysubspro-feature-manager-panel">
                <p class="form-field">
                    <label><?php esc_html_e('Product Features', 'arraysubspro'); ?></label>
                    <span class="description"><?php esc_html_e('Define features for this product. Customers will see these features in their My Account area.', 'arraysubspro'); ?>
                    </span>
                </p>
                <div id="arraysubspro-feature-manager-root"
                    data-product-id="<?php echo esc_attr($post->ID); ?>"
                    data-product-type="simple"
                    data-features="<?php echo esc_attr($features); ?>">
                </div>
                <input type="hidden"
                    id="arraysubs_features_data_input"
                    name="_arraysubs_features"
                    value="<?php echo esc_attr($features); ?>" />
            </div>
        </div>
    <?php
    }

    /**
     * Add Feature Manager fields to variations
     *
     * @param int     $loop           Loop index
     * @param array   $variation_data Variation data
     * @param WP_Post $variation      Variation post object
     * @return void
     */
    public function addVariationFields(int $loop, array $variation_data, WP_Post $variation): void
    {
        $features = get_post_meta($variation->ID, '_arraysubs_features', true);
        $features = $features ? $features : '[]';
    ?>
        <div class="form-row form-row-full arraysubspro-variation-features">
            <label><?php esc_html_e('Feature Manager', 'arraysubspro'); ?></label>
            <div class="arraysubspro-feature-manager-variation-root"
                data-variation-id="<?php echo esc_attr($variation->ID); ?>"
                data-loop="<?php echo esc_attr($loop); ?>"
                data-features="<?php echo esc_attr($features); ?>">
            </div>
            <input type="hidden"
                class="arraysubspro-variation-features-input"
                name="arraysubs_variation_features[<?php echo esc_attr($loop); ?>]"
                value="<?php echo esc_attr($features); ?>" />
        </div>
    <?php
    }

    /**
     * Save variation fields
     *
     * @param int $variation_id Variation ID
     * @param int $loop         Loop index
     * @return void
     */
    public function saveVariationFields(int $variation_id, int $loop): void
    {
        // phpcs:ignore WordPress.Security.NonceVerification.Missing
        if (isset($_POST['arraysubs_variation_features'][$loop]) && is_string(wp_unslash($_POST['arraysubs_variation_features'][$loop]))) {
            // phpcs:ignore WordPress.Security.NonceVerification.Missing
            $features = wp_unslash($_POST['arraysubs_variation_features'][$loop]);
            update_post_meta($variation_id, '_arraysubs_features', $this->sanitizeFeaturesJson($features));
        }
    }

    /**
     * Save variation meta through the WooCommerce CRUD object.
     *
     * @param WC_Product_Variation $variation Variation object.
     * @param int                  $loop      Loop index.
     * @return void
     */
    public function saveVariationObjectMeta(WC_Product_Variation $variation, int $loop): void
    {
        // phpcs:ignore WordPress.Security.NonceVerification.Missing
        if (!isset($_POST['arraysubs_variation_features'][$loop]) || !is_string(wp_unslash($_POST['arraysubs_variation_features'][$loop]))) {
            return;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Missing
        $features = wp_unslash($_POST['arraysubs_variation_features'][$loop]);
        $variation->update_meta_data('_arraysubs_features', $this->sanitizeFeaturesJson($features));
    }

    /**
     * Save product meta
     *
     * @param int $post_id Product ID
     * @return void
     */
    public function saveProductMeta(int $post_id): void
    {
        // phpcs:ignore WordPress.Security.NonceVerification.Missing
        if (isset($_POST['_arraysubs_features']) && is_string(wp_unslash($_POST['_arraysubs_features']))) {
            // phpcs:ignore WordPress.Security.NonceVerification.Missing
            $features = wp_unslash($_POST['_arraysubs_features']);
            update_post_meta($post_id, '_arraysubs_features', $this->sanitizeFeaturesJson($features));
        }
    }

    /**
     * Save product meta through the WooCommerce CRUD object.
     *
     * @param WC_Product $product Product object.
     * @return void
     */
    public function saveProductObjectMeta(WC_Product $product): void
    {
        // phpcs:ignore WordPress.Security.NonceVerification.Missing
        if (!isset($_POST['_arraysubs_features']) || !is_string(wp_unslash($_POST['_arraysubs_features']))) {
            return;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Missing
        $features = wp_unslash($_POST['_arraysubs_features']);
        $product->update_meta_data('_arraysubs_features', $this->sanitizeFeaturesJson($features));
    }

    /**
     * Enqueue admin assets
     *
     * @param string $hook Current admin page hook
     * @return void
     */
    public function enqueueAssets(string $hook): void
    {
        // Only load on WooCommerce product edit pages
        $screen = get_current_screen();
        if (!is_admin() || !$screen || $screen->post_type !== 'product' || $screen->base !== 'post') {
            return;
        }

        // Load dependencies from webpack asset file
        $asset_file = Config::get('proplugin.public_path') . 'build/admin/feature-manager.asset.php';
        $asset = file_exists($asset_file)
            ? require $asset_file
            : ['dependencies' => ['wp-element', 'wp-i18n'], 'version' => ARRAYSUBSPRO_VERSION];

        // Enqueue CSS
        wp_enqueue_style(
            'arraysubspro-feature-manager',
            Config::get('proplugin.public_url') . 'build/admin/feature-manager.css',
            ['woocommerce_admin_styles'],
            $asset['version']
        );

        // Enqueue JS
        wp_enqueue_script(
            'arraysubspro-feature-manager',
            Config::get('proplugin.public_url') . 'build/admin/feature-manager.js',
            $asset['dependencies'],
            $asset['version'],
            true
        );

        // Load translations for React components
        wp_set_script_translations(
            'arraysubspro-feature-manager',
            'arraysubspro',
            Config::get('proplugin.plugin_path') . 'languages'
        );

        // Localize script
        wp_localize_script('arraysubspro-feature-manager', 'arraySubsProFeatureManager', [
            'nonce'   => wp_create_nonce('wp_rest'),
            'apiUrl'  => rest_url('arraysubs/v1/'),
            'i18n'    => [
                'add_feature'       => __('Add Feature', 'arraysubspro'),
                'edit_features'     => __('Edit Features', 'arraysubspro'),
                'feature_name'      => __('Feature Name', 'arraysubspro'),
                'value_type'        => __('Value Type', 'arraysubspro'),
                'value'             => __('Value', 'arraysubspro'),
                'enabled'           => __('Enabled', 'arraysubspro'),
                'actions'           => __('Actions', 'arraysubspro'),
                'toggle'            => __('Toggle', 'arraysubspro'),
                'number'            => __('Number', 'arraysubspro'),
                'text'              => __('Text', 'arraysubspro'),
                'yes'               => __('Yes', 'arraysubspro'),
                'no'                => __('No', 'arraysubspro'),
                'save'              => __('Save', 'arraysubspro'),
                'cancel'            => __('Cancel', 'arraysubspro'),
                'delete'            => __('Delete', 'arraysubspro'),
                'confirm_delete'    => __('Are you sure you want to delete this feature?', 'arraysubspro'),
                'no_features'       => __('No features added yet.', 'arraysubspro'),
                'drag_to_reorder'   => __('Drag to reorder', 'arraysubspro'),
                /* translators: %d: number of features */
                'feature_count'     => __('%d feature(s)', 'arraysubspro'),
            ],
        ]);
    }

    /**
     * Display features on product page
     *
     * @return void
     */
    public function displayProductFeatures(): void
    {
        global $product;

        if (!$product) {
            return;
        }

        $features = [];

        // For variable products, we don't show features at product level
        // Features are shown per variation
        if ($product->is_type('variable')) {
            return;
        }

        // Get features for simple product
        $features_json = get_post_meta($product->get_id(), '_arraysubs_features', true);
        if ($features_json) {
            $features = json_decode($features_json, true);
        }

        if (empty($features)) {
            return;
        }

        // Filter to only show enabled features
        $enabled_features = array_filter($features, function ($f) {
            return !empty($f['enabled']);
        });

        if (empty($enabled_features)) {
            return;
        }

        // Sort by order
        usort($enabled_features, function ($a, $b) {
            return ($a['order'] ?? 0) - ($b['order'] ?? 0);
        });

    ?>
        <div class="arraysubspro-product-features">
            <h4><?php esc_html_e("What's Included", 'arraysubspro'); ?></h4>
            <ul class="arraysubspro-features-list">
                <?php foreach ($enabled_features as $feature) : ?>
                    <li class="arraysubspro-feature-item arraysubspro-feature-type-<?php echo esc_attr($feature['type']); ?>">
                        <span class="arraysubspro-feature-name"><?php echo esc_html($feature['name']); ?></span>
                        <span class="arraysubspro-feature-value">
                            <?php
                            if ($feature['type'] === 'toggle') {
                                $is_yes = in_array(strtolower($feature['value']), ['yes', 'true', '1', 'on'], true);
                                echo $is_yes
                                    ? '<span class="arraysubspro-feature-yes">✓</span>'
                                    : '<span class="arraysubspro-feature-no">✗</span>';
                            } else {
                                echo esc_html($feature['value']);
                            }
                            ?>
                        </span>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
<?php
    }
}
