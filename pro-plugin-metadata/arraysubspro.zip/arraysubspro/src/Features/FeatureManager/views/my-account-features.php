<?php

/**
 * My Account - Features Template
 *
 * Displays customer's entitled features from active subscriptions.
 *
 * @package ArraySubsPro
 * @var array $arraysubs_features_data Features data array
 * @var int $arraysubs_customer_id Customer ID
 * @var string $arraysubs_aggregation_mode Aggregation mode
 * @var string $arraysubs_page_title My Account page title
 * @var bool $arraysubs_show_usage_count Whether to show usage column
 */

defined('ABSPATH') || exit;

$arraysubs_table_columns = !empty($arraysubs_show_usage_count) ? 4 : 3;

$arraysubs_format_usage = static function ($arraysubs_usage): string {
    if (!is_array($arraysubs_usage)) {
        return '—';
    }

    $arraysubs_used = (string) ($arraysubs_usage['used'] ?? 0);
    $arraysubs_limit = !empty($arraysubs_usage['is_unlimited'])
        ? __('Unlimited', 'arraysubspro')
        : (string) ($arraysubs_usage['limit'] ?? 0);

    return sprintf('%1$s / %2$s', $arraysubs_used, $arraysubs_limit);
};

?>

<div class="arraysubspro-my-features">
    <h2><?php echo esc_html($arraysubs_page_title); ?></h2>

    <p class="arraysubspro-features-intro">
        <?php esc_html_e('Below are all the features included with your active subscriptions.', 'arraysubspro'); ?>
    </p>

    <?php if (empty($arraysubs_features_data)) : ?>
        <div class="woocommerce-message woocommerce-message--info woocommerce-Message woocommerce-Message--info woocommerce-info">
            <?php esc_html_e('You don\'t have any features yet. Subscribe to a plan to unlock features!', 'arraysubspro'); ?>
            <a class="woocommerce-Button button" href="<?php echo esc_url(get_permalink(wc_get_page_id('shop'))); ?>">
                <?php esc_html_e('Browse Products', 'arraysubspro'); ?>
            </a>
        </div>
    <?php elseif ($arraysubs_aggregation_mode === 'per_subscription') : ?>

        <?php foreach ($arraysubs_features_data as $arraysubs_product_features) : ?>
            <div class="arraysubspro-features-product-section">
                <?php if (!empty($arraysubs_product_features['features'])) : ?>
                    <table class="woocommerce-table woocommerce-table--features shop_table shop_table_responsive">
                        <thead>
                            <tr>
                                <th colspan="<?php echo esc_attr($arraysubs_table_columns); ?>" class="feature-group-title">
                                    <?php echo esc_html($arraysubs_product_features['product_name']); ?>
                                    <a href="<?php echo esc_url(wc_get_endpoint_url('view-subscription', $arraysubs_product_features['subscription_id'], wc_get_page_permalink('myaccount'))); ?>" class="arraysubspro-view-subscription-link">
                                        <?php
                                        /* translators: %d: subscription ID */
                                        echo esc_html(sprintf(__('Subscription #%d', 'arraysubspro'), (int) $arraysubs_product_features['subscription_id']));
                                        ?>
                                    </a>
                                </th>
                            </tr>
                            <tr>
                                <th class="feature-name"><?php esc_html_e('Feature', 'arraysubspro'); ?></th>
                                <th class="feature-type"><?php esc_html_e('Type', 'arraysubspro'); ?></th>
                                <th class="feature-value"><?php esc_html_e('Your Entitlement', 'arraysubspro'); ?></th>
                                <?php if (!empty($arraysubs_show_usage_count)) : ?>
                                    <th class="feature-usage"><?php esc_html_e('Usage', 'arraysubspro'); ?></th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($arraysubs_product_features['features'] as $arraysubs_feature) : ?>
                                <tr class="arraysubspro-feature-row type-<?php echo esc_attr($arraysubs_feature['type']); ?>">
                                    <td class="feature-name" data-title="<?php esc_attr_e('Feature', 'arraysubspro'); ?>">
                                        <?php echo esc_html($arraysubs_feature['name']); ?>
                                    </td>
                                    <td class="feature-type" data-title="<?php esc_attr_e('Type', 'arraysubspro'); ?>">
                                        <?php echo esc_html($arraysubs_feature['type']); ?>
                                    </td>
                                    <td class="feature-value" data-title="<?php esc_attr_e('Your Entitlement', 'arraysubspro'); ?>">
                                        <?php
                                        if ($arraysubs_feature['type'] === 'toggle') {
                                            $arraysubs_is_yes = in_array(strtolower($arraysubs_feature['value']), ['yes', 'true', '1', 'on'], true);
                                            if ($arraysubs_is_yes) {
                                                echo '<span class="arraysubspro-feature-yes">✓ ' . esc_html__('Yes', 'arraysubspro') . '</span>';
                                            } else {
                                                echo '<span class="arraysubspro-feature-no">✗ ' . esc_html__('No', 'arraysubspro') . '</span>';
                                            }
                                        } else {
                                            echo esc_html($arraysubs_feature['value']);
                                        }
                                        ?>
                                    </td>
                                    <?php if (!empty($arraysubs_show_usage_count)) : ?>
                                        <td class="feature-usage" data-title="<?php esc_attr_e('Usage', 'arraysubspro'); ?>">
                                            <?php echo esc_html($arraysubs_format_usage($arraysubs_feature['usage'] ?? null)); ?>
                                        </td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else : ?>
                    <p class="arraysubspro-no-features-message">
                        <?php esc_html_e('No features defined for this subscription.', 'arraysubspro'); ?>
                    </p>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>

    <?php else : ?>

        <div class="arraysubspro-features-combined-section">
            <table class="woocommerce-table woocommerce-table--features shop_table shop_table_responsive">
                <thead>
                    <tr>
                        <th colspan="<?php echo esc_attr($arraysubs_table_columns); ?>" class="feature-group-title">
                            <?php esc_html_e('Combined Features', 'arraysubspro'); ?>
                        </th>
                    </tr>
                    <tr>
                        <th class="feature-name"><?php esc_html_e('Feature', 'arraysubspro'); ?></th>
                        <th class="feature-type"><?php esc_html_e('Type', 'arraysubspro'); ?></th>
                        <th class="feature-value"><?php esc_html_e('Your Entitlement', 'arraysubspro'); ?></th>
                        <?php if (!empty($arraysubs_show_usage_count)) : ?>
                            <th class="feature-usage"><?php esc_html_e('Usage', 'arraysubspro'); ?></th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($arraysubs_features_data as $arraysubs_feature) : ?>
                        <tr class="arraysubspro-feature-row type-<?php echo esc_attr($arraysubs_feature['type']); ?>">
                            <td class="feature-name" data-title="<?php esc_attr_e('Feature', 'arraysubspro'); ?>">
                                <?php echo esc_html($arraysubs_feature['name']); ?>
                            </td>
                            <td class="feature-type" data-title="<?php esc_attr_e('Type', 'arraysubspro'); ?>">
                                <?php echo esc_html($arraysubs_feature['type']); ?>
                            </td>
                            <td class="feature-value" data-title="<?php esc_attr_e('Your Entitlement', 'arraysubspro'); ?>">
                                <?php
                                if ($arraysubs_feature['type'] === 'toggle') {
                                    $arraysubs_is_yes = in_array(strtolower($arraysubs_feature['value']), ['yes', 'true', '1', 'on'], true);
                                    if ($arraysubs_is_yes) {
                                        echo '<span class="arraysubspro-feature-yes">✓ ' . esc_html__('Yes', 'arraysubspro') . '</span>';
                                    } else {
                                        echo '<span class="arraysubspro-feature-no">✗ ' . esc_html__('No', 'arraysubspro') . '</span>';
                                    }
                                } else {
                                    echo esc_html($arraysubs_feature['value']);
                                }
                                ?>
                            </td>
                            <?php if (!empty($arraysubs_show_usage_count)) : ?>
                                <td class="feature-usage" data-title="<?php esc_attr_e('Usage', 'arraysubspro'); ?>">
                                    <?php echo esc_html($arraysubs_format_usage($arraysubs_feature['usage'] ?? null)); ?>
                                </td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

    <?php endif; ?>
</div>