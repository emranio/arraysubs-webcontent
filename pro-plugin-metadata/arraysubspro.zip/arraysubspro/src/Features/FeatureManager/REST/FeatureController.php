<?php

/**
 * Feature Manager REST Controller
 *
 * REST API endpoints for Feature Manager.
 *
 * @package ArraySubsPro\Features\FeatureManager\REST
 * @since 1.0.0
 */

namespace ArraySubsPro\Features\FeatureManager\REST;

defined('ABSPATH') || exit;

use ArraySubs\Supports\BaseRestController;
use WP_REST_Request;
use WP_REST_Response;
use WP_Error;

/**
 * Feature Manager REST controller
 */
class FeatureController extends BaseRestController
{
    /**
     * Enable auto-loading
     *
     * @var bool
     */
    public static $loadable = true;

    /**
     * Initialize controller
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Register REST routes
     *
     * @return void
     */
    public function registerRoutes(): void
    {
        // Get product features (admin)
        register_rest_route(
            $this->namespace,
            '/features/product/(?P<id>\d+)',
            [
                [
                    'methods'             => 'GET',
                    'callback'            => [$this, 'getProductFeatures'],
                    'permission_callback' => [$this, 'checkAdminPermission'],
                    'args'                => [
                        'id' => [
                            'required'          => true,
                            'type'              => 'integer',
                            'sanitize_callback' => 'absint',
                        ],
                    ],
                ],
                [
                    'methods'             => 'POST',
                    'callback'            => [$this, 'saveProductFeatures'],
                    'permission_callback' => [$this, 'checkAdminPermission'],
                    'args'                => [
                        'id' => [
                            'required'          => true,
                            'type'              => 'integer',
                            'sanitize_callback' => 'absint',
                        ],
                        'features' => [
                            'required'          => true,
                            'type'              => 'array',
                        ],
                    ],
                ],
            ]
        );

        // Get variation features (admin)
        register_rest_route(
            $this->namespace,
            '/features/variation/(?P<id>\d+)',
            [
                [
                    'methods'             => 'GET',
                    'callback'            => [$this, 'getVariationFeatures'],
                    'permission_callback' => [$this, 'checkAdminPermission'],
                    'args'                => [
                        'id' => [
                            'required'          => true,
                            'type'              => 'integer',
                            'sanitize_callback' => 'absint',
                        ],
                    ],
                ],
                [
                    'methods'             => 'POST',
                    'callback'            => [$this, 'saveVariationFeatures'],
                    'permission_callback' => [$this, 'checkAdminPermission'],
                    'args'                => [
                        'id' => [
                            'required'          => true,
                            'type'              => 'integer',
                            'sanitize_callback' => 'absint',
                        ],
                        'features' => [
                            'required'          => true,
                            'type'              => 'array',
                        ],
                    ],
                ],
            ]
        );

        // Get customer entitled features (customer)
        register_rest_route(
            $this->namespace,
            '/my-features',
            [
                'methods'             => 'GET',
                'callback'            => [$this, 'getCustomerFeatures'],
                'permission_callback' => [$this, 'checkCustomerPermission'],
            ]
        );

        // Get features for a specific subscription (customer)
        register_rest_route(
            $this->namespace,
            '/my-features/subscription/(?P<id>\d+)',
            [
                'methods'             => 'GET',
                'callback'            => [$this, 'getSubscriptionFeatures'],
                'permission_callback' => [$this, 'checkCustomerPermission'],
                'args'                => [
                    'id' => [
                        'required'          => true,
                        'type'              => 'integer',
                        'sanitize_callback' => 'absint',
                    ],
                ],
            ]
        );

        register_rest_route(
            $this->namespace,
            '/features/log',
            [
                'methods'             => 'GET',
                'callback'            => [$this, 'getAdminFeatureLog'],
                'permission_callback' => [$this, 'checkAdminPermission'],
                'args'                => [
                    'user_id' => [
                        'required'          => true,
                        'type'              => 'integer',
                        'sanitize_callback' => 'absint',
                    ],
                ],
            ]
        );

        // Get feature templates (admin)
        register_rest_route(
            $this->namespace,
            '/features/templates',
            [
                [
                    'methods'             => 'GET',
                    'callback'            => [$this, 'getTemplates'],
                    'permission_callback' => [$this, 'checkAdminPermission'],
                ],
                [
                    'methods'             => 'POST',
                    'callback'            => [$this, 'saveTemplate'],
                    'permission_callback' => [$this, 'checkAdminPermission'],
                    'args'                => [
                        'name' => [
                            'required'          => true,
                            'type'              => 'string',
                            'sanitize_callback' => 'sanitize_text_field',
                        ],
                        'features' => [
                            'required'          => true,
                            'type'              => 'array',
                        ],
                    ],
                ],
            ]
        );

        // Delete feature template (admin)
        register_rest_route(
            $this->namespace,
            '/features/templates/(?P<id>[\w-]+)',
            [
                'methods'             => 'DELETE',
                'callback'            => [$this, 'deleteTemplate'],
                'permission_callback' => [$this, 'checkAdminPermission'],
                'args'                => [
                    'id' => [
                        'required'          => true,
                        'type'              => 'string',
                        'sanitize_callback' => 'sanitize_key',
                    ],
                ],
            ]
        );
    }

    /**
     * Check admin permission
     *
     * @return bool|WP_Error
     */
    public function checkAdminPermission()
    {
        if (!current_user_can('manage_woocommerce') && !current_user_can('manage_options')) {
            return new WP_Error(
                'rest_forbidden',
                __('You do not have permission to manage product features.', 'arraysubspro'),
                ['status' => 403]
            );
        }
        return true;
    }

    /**
     * Check customer permission
     *
     * @return bool|WP_Error
     */
    public function checkCustomerPermission()
    {
        if (!is_user_logged_in()) {
            return new WP_Error(
                'rest_forbidden',
                __('You must be logged in to view your features.', 'arraysubspro'),
                ['status' => 401]
            );
        }
        return true;
    }

    /**
     * Get product features
     *
     * @param WP_REST_Request $request Request object
     * @return WP_REST_Response|WP_Error
     */
    public function getProductFeatures(WP_REST_Request $request)
    {
        $product_id = $request->get_param('id');
        $product = wc_get_product($product_id);

        if (!$product) {
            return new WP_Error(
                'product_not_found',
                __('Product not found.', 'arraysubspro'),
                ['status' => 404]
            );
        }

        $features_json = get_post_meta($product_id, '_arraysubs_features', true);
        $features = $features_json ? json_decode($features_json, true) : [];

        return arraysubs_rest_response(
            [
                'product_id' => $product_id,
                'features'   => $features,
            ],
            200,
            __('Features retrieved successfully.', 'arraysubspro')
        );
    }

    /**
     * Save product features
     *
     * @param WP_REST_Request $request Request object
     * @return WP_REST_Response|WP_Error
     */
    public function saveProductFeatures(WP_REST_Request $request)
    {
        $product_id = $request->get_param('id');
        $features = $request->get_param('features');

        $product = wc_get_product($product_id);
        if (!$product) {
            return new WP_Error(
                'product_not_found',
                __('Product not found.', 'arraysubspro'),
                ['status' => 404]
            );
        }

        // Sanitize features
        $sanitized = $this->sanitizeFeatures($features);

        update_post_meta($product_id, '_arraysubs_features', wp_json_encode($sanitized));

        return arraysubs_rest_response(
            [
                'product_id' => $product_id,
                'features'   => $sanitized,
            ],
            200,
            __('Features saved successfully.', 'arraysubspro')
        );
    }

    /**
     * Get variation features
     *
     * @param WP_REST_Request $request Request object
     * @return WP_REST_Response|WP_Error
     */
    public function getVariationFeatures(WP_REST_Request $request)
    {
        $variation_id = $request->get_param('id');
        $variation = wc_get_product($variation_id);

        if (!$variation || !$variation->is_type('variation')) {
            return new WP_Error(
                'variation_not_found',
                __('Product variation not found.', 'arraysubspro'),
                ['status' => 404]
            );
        }

        $features_json = get_post_meta($variation_id, '_arraysubs_features', true);
        $features = $features_json ? json_decode($features_json, true) : [];

        return arraysubs_rest_response(
            [
                'variation_id' => $variation_id,
                'features'     => $features,
            ],
            200,
            __('Variation features retrieved successfully.', 'arraysubspro')
        );
    }

    /**
     * Save variation features
     *
     * @param WP_REST_Request $request Request object
     * @return WP_REST_Response|WP_Error
     */
    public function saveVariationFeatures(WP_REST_Request $request)
    {
        $variation_id = $request->get_param('id');
        $features = $request->get_param('features');

        $variation = wc_get_product($variation_id);
        if (!$variation || !$variation->is_type('variation')) {
            return new WP_Error(
                'variation_not_found',
                __('Product variation not found.', 'arraysubspro'),
                ['status' => 404]
            );
        }

        $sanitized = $this->sanitizeFeatures($features);

        update_post_meta($variation_id, '_arraysubs_features', wp_json_encode($sanitized));

        return arraysubs_rest_response(
            [
                'variation_id' => $variation_id,
                'features'     => $sanitized,
            ],
            200,
            __('Variation features saved successfully.', 'arraysubspro')
        );
    }

    /**
     * Get customer entitled features
     *
     * @param WP_REST_Request $request Request object
     * @return WP_REST_Response
     */
    public function getCustomerFeatures(WP_REST_Request $request)
    {
        $customer_id = get_current_user_id();
        $aggregation_mode = arraysubs_get_feature_manager_aggregation_mode();

        // Get all active subscriptions and orders with features
        $entitled_features = $this->collectCustomerFeatures($customer_id, $aggregation_mode);

        return arraysubs_rest_response(
            [
                'customer_id' => $customer_id,
                'mode'        => $aggregation_mode,
                'features'    => $entitled_features,
            ],
            200,
            __('Features retrieved successfully.', 'arraysubspro')
        );
    }

    /**
     * Get features for a specific subscription
     *
     * @param WP_REST_Request $request Request object
     * @return WP_REST_Response|WP_Error
     */
    public function getSubscriptionFeatures(WP_REST_Request $request)
    {
        $subscription_id = $request->get_param('id');
        $customer_id = get_current_user_id();

        // Verify ownership
        $subscription = arraysubs_get_subscription($subscription_id);
        if (!$subscription instanceof \WP_Post) {
            return new WP_Error(
                'subscription_not_found',
                __('Subscription not found.', 'arraysubspro'),
                ['status' => 404]
            );
        }

        $subscription_customer_id = (int) get_post_meta($subscription_id, '_customer_id', true);
        if ($subscription_customer_id !== $customer_id) {
            return new WP_Error(
                'permission_denied',
                __('You do not have permission to view this subscription.', 'arraysubspro'),
                ['status' => 403]
            );
        }

        // Get features from subscription's product
        $features = $this->decorateFeaturesWithUsage(
            $this->getSubscriptionProductFeatures($subscription_id),
            $subscription_id
        );

        return arraysubs_rest_response(
            [
                'subscription_id' => $subscription_id,
                'features'        => $features,
            ],
            200,
            __('Subscription features retrieved successfully.', 'arraysubspro')
        );
    }

    /**
     * Get member feature log for admin views.
     *
     * @param WP_REST_Request $request Request object.
     * @return WP_REST_Response|WP_Error
     */
    public function getAdminFeatureLog(WP_REST_Request $request)
    {
        $customer_id = (int) $request->get_param('user_id');
        $customer = $customer_id > 0 ? get_userdata($customer_id) : false;

        if (!$customer) {
            return new WP_Error(
                'customer_not_found',
                __('Customer not found.', 'arraysubspro'),
                ['status' => 404]
            );
        }

        $aggregation_mode = arraysubs_get_feature_manager_aggregation_mode();
        $features_data = $this->collectCustomerFeatures($customer_id, $aggregation_mode);

        return arraysubs_rest_response(
            [
                'customer' => [
                    'id'    => $customer_id,
                    'name'  => $customer->display_name,
                    'email' => $customer->user_email,
                ],
                'aggregation_mode'   => $aggregation_mode,
                'show_usage_in_admin' => arraysubs_show_feature_usage_in_admin(),
                'features_data'      => $features_data,
            ],
            200,
            __('Feature log retrieved successfully.', 'arraysubspro')
        );
    }

    /**
     * Get feature templates
     *
     * @return WP_REST_Response
     */
    public function getTemplates()
    {
        $templates = get_option('arraysubs_feature_templates', []);

        return arraysubs_rest_response(
            ['templates' => $templates],
            200,
            __('Templates retrieved successfully.', 'arraysubspro')
        );
    }

    /**
     * Save feature template
     *
     * @param WP_REST_Request $request Request object
     * @return WP_REST_Response
     */
    public function saveTemplate(WP_REST_Request $request)
    {
        $name = $request->get_param('name');
        $features = $request->get_param('features');

        $templates = get_option('arraysubs_feature_templates', []);

        $template_id = sanitize_key(str_replace(' ', '_', $name)) . '_' . time();
        $templates[$template_id] = [
            'id'       => $template_id,
            'name'     => sanitize_text_field($name),
            'features' => $this->sanitizeFeatures($features),
            'created'  => current_time('mysql', true),
        ];

        update_option('arraysubs_feature_templates', $templates);

        return arraysubs_rest_response(
            ['template' => $templates[$template_id]],
            201,
            __('Template saved successfully.', 'arraysubspro')
        );
    }

    /**
     * Delete feature template
     *
     * @param WP_REST_Request $request Request object
     * @return WP_REST_Response|WP_Error
     */
    public function deleteTemplate(WP_REST_Request $request)
    {
        $template_id = $request->get_param('id');
        $templates = get_option('arraysubs_feature_templates', []);

        if (!isset($templates[$template_id])) {
            return new WP_Error(
                'template_not_found',
                __('Template not found.', 'arraysubspro'),
                ['status' => 404]
            );
        }

        unset($templates[$template_id]);
        update_option('arraysubs_feature_templates', $templates);

        return arraysubs_rest_response(
            [],
            200,
            __('Template deleted successfully.', 'arraysubspro')
        );
    }

    /**
     * Sanitize features array
     *
     * @param array $features Features array
     * @return array Sanitized features
     */
    private function sanitizeFeatures(array $features): array
    {
        $sanitized = [];

        foreach ($features as $index => $feature) {
            if (!isset($feature['name']) || empty($feature['name'])) {
                continue;
            }

            $type = in_array($feature['type'] ?? 'text', ['toggle', 'number', 'text'], true)
                ? $feature['type']
                : 'text';
            $value = sanitize_text_field($feature['value'] ?? '');

            if ($type === 'number' && $value !== '' && !is_numeric($value) && strtolower($value) !== 'unlimited') {
                $value = '';
            }

            $sanitized[] = [
                'id'      => sanitize_key($feature['id'] ?? uniqid('feature_')),
                'name'    => sanitize_text_field($feature['name']),
                'type'    => $type,
                'value'   => $value,
                'enabled' => !empty($feature['enabled']),
                'order'   => isset($feature['order']) ? absint($feature['order']) : $index,
            ];
        }

        return $sanitized;
    }

    /**
     * Collect customer features based on aggregation mode
     *
     * @param int    $customer_id      Customer ID
     * @param string $aggregation_mode Aggregation mode
     * @return array
     */
    private function collectCustomerFeatures(int $customer_id, string $aggregation_mode): array
    {
        $normalized_mode = arraysubs_sanitize_feature_manager_aggregation_mode($aggregation_mode);
        $core_mode = $normalized_mode === 'combine' ? 'combine' : 'per_subscription';
        $all_features = arraysubs_get_customer_features($customer_id, $core_mode);

        if ($normalized_mode === 'per_subscription') {
            foreach ($all_features as &$feature_group) {
                $feature_group['features'] = $this->decorateFeaturesWithUsage(
                    $feature_group['features'] ?? [],
                    (int) ($feature_group['subscription_id'] ?? 0)
                );
            }

            unset($feature_group);

            return $all_features;
        }

        return $this->decorateFeaturesWithUsage($all_features, 0, $customer_id);
    }

    /**
     * Get features from subscription's product
     *
     * @param int $subscription_id Subscription ID
     * @return array
     */
    private function getSubscriptionProductFeatures(int $subscription_id): array
    {
        $product_id = get_post_meta($subscription_id, '_product_id', true);
        $variation_id = get_post_meta($subscription_id, '_variation_id', true);

        // Use variation features if available, otherwise product features
        $target_id = $variation_id ?: $product_id;

        if (!$target_id) {
            return [];
        }

        $enabled = arraysubs_get_product_features((int) $target_id);

        usort($enabled, function ($a, $b) {
            return ($a['order'] ?? 0) - ($b['order'] ?? 0);
        });

        return array_values($enabled);
    }

    /**
     * Decorate features with usage data.
     *
     * @param array $features         Feature rows.
     * @param int   $subscription_id  Subscription ID.
     * @param int   $customer_id      Customer ID.
     * @return array
     */
    private function decorateFeaturesWithUsage(array $features, int $subscription_id = 0, int $customer_id = 0): array
    {
        foreach ($features as &$feature) {
            $feature['usage'] = null;

            if (($feature['type'] ?? '') !== 'number' || empty($feature['name'])) {
                continue;
            }

            if ($subscription_id > 0) {
                $feature['usage'] = arraysubs_get_feature_usage($subscription_id, $feature['name']);
                continue;
            }

            if ($customer_id > 0) {
                $feature['usage'] = arraysubs_get_customer_feature_usage($customer_id, $feature['name']);
            }
        }

        unset($feature);

        return array_values($features);
    }
}
