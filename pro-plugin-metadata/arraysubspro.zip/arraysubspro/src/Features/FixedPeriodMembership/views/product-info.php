<?php

/**
 * Fixed Period Membership - Product Page Info
 *
 * Displays the fixed end date on the single product page.
 *
 * @package ArraySubsPro\Features\FixedPeriodMembership
 */

defined('ABSPATH') || exit;

use ArraySubsPro\Features\FixedPeriodMembership\Services\EndDateCalculator;

global $product;

$arraysubs_fpm_is_variable = isset($arraysubs_fpm_is_variable) ? (bool) $arraysubs_fpm_is_variable : false;

if (!$product || !method_exists($product, 'get_id')) {
    return;
}

$arraysubs_fpm_product_id = (int) $product->get_id();

if (!$arraysubs_fpm_is_variable && !EndDateCalculator::isFixedPeriodProduct($arraysubs_fpm_product_id)) {
    return;
}

if ($arraysubs_fpm_is_variable) :
?>
    <div class="arraysubs-product-info arraysubs-fixed-period-info arraysubs-fixed-period-info--hidden" data-arraysubs-variable="yes">
        <p class="subscription-fixed-end-date">
            <strong><?php esc_html_e('Membership ends:', 'arraysubspro'); ?></strong>
            <span class="subscription-fixed-end-date-value"></span>
        </p>

        <p class="subscription-renewal-info arraysubs-fixed-period-info__section arraysubs-fixed-period-info__section--hidden">
            <small><?php esc_html_e('Auto-renews into the next membership period.', 'arraysubspro'); ?></small>
        </p>

        <p class="subscription-enrollment-window arraysubs-fixed-period-info__section arraysubs-fixed-period-info__section--hidden">
            <small></small>
        </p>
    </div>
<?php
    return;
endif;

$arraysubs_fpm_display_date = EndDateCalculator::getDisplayEndDate($arraysubs_fpm_product_id);

if (empty($arraysubs_fpm_display_date)) {
    return;
}

$arraysubs_fpm_renewal_behavior = get_post_meta($arraysubs_fpm_product_id, '_arraysubs_fixed_end_renewal', true);

// Check enrollment window
$arraysubs_fpm_win_start = get_post_meta($arraysubs_fpm_product_id, '_arraysubs_enrollment_window_start', true);
$arraysubs_fpm_win_end   = get_post_meta($arraysubs_fpm_product_id, '_arraysubs_enrollment_window_end', true);
?>

<div class="arraysubs-product-info arraysubs-fixed-period-info">
    <p class="subscription-fixed-end-date">
        <?php
        printf(
            /* translators: %s: fixed end date for the membership */
            esc_html__('Membership ends: %s', 'arraysubspro'),
            '<strong>' . esc_html($arraysubs_fpm_display_date) . '</strong>'
        );
        ?>
    </p>

    <?php if ('renew' === $arraysubs_fpm_renewal_behavior) : ?>
        <p class="subscription-renewal-info">
            <small><?php esc_html_e('Auto-renews into the next membership period.', 'arraysubspro'); ?></small>
        </p>
    <?php endif; ?>

    <?php if (!empty($arraysubs_fpm_win_start) || !empty($arraysubs_fpm_win_end)) : ?>
        <p class="subscription-enrollment-window">
            <small>
                <?php
                if (!empty($arraysubs_fpm_win_start) && !empty($arraysubs_fpm_win_end)) {
                    printf(
                        /* translators: 1: enrollment start date, 2: enrollment end date */
                        esc_html__('Enrollment window: %1$s – %2$s', 'arraysubspro'),
                        esc_html(arraysubs_format_site_local_date($arraysubs_fpm_win_start, get_option('date_format'))),
                        esc_html(arraysubs_format_site_local_date($arraysubs_fpm_win_end, get_option('date_format')))
                    );
                } elseif (!empty($arraysubs_fpm_win_start)) {
                    printf(
                        /* translators: %s: enrollment start date */
                        esc_html__('Enrollment opens: %s', 'arraysubspro'),
                        esc_html(arraysubs_format_site_local_date($arraysubs_fpm_win_start, get_option('date_format')))
                    );
                } elseif (!empty($arraysubs_fpm_win_end)) {
                    printf(
                        /* translators: %s: enrollment end/close date */
                        esc_html__('Enrollment closes: %s', 'arraysubspro'),
                        esc_html(arraysubs_format_site_local_date($arraysubs_fpm_win_end, get_option('date_format')))
                    );
                }
                ?>
            </small>
        </p>
    <?php endif; ?>
</div>
