<?php

/**
 * Fixed Period Membership - Simple Product Fields
 *
 * Renders the fixed-end-date options in the Subscription tab
 * of the WooCommerce product editor for simple products.
 *
 * @package ArraySubsPro\Features\FixedPeriodMembership
 * @var int $product_id Product post ID (from renderSimpleProductFields)
 */

defined('ABSPATH') || exit;

$arraysubs_fpm_enabled    = get_post_meta($product_id, '_arraysubs_fixed_end_date_enabled', true);
$arraysubs_fpm_type       = get_post_meta($product_id, '_arraysubs_fixed_end_date_type', true) ?: 'recurring_annual';
$arraysubs_fpm_date       = get_post_meta($product_id, '_arraysubs_fixed_end_date', true);
$arraysubs_fpm_win_start  = get_post_meta($product_id, '_arraysubs_enrollment_window_start', true);
$arraysubs_fpm_win_end    = get_post_meta($product_id, '_arraysubs_enrollment_window_end', true);
$arraysubs_fpm_renewal    = get_post_meta($product_id, '_arraysubs_fixed_end_renewal', true) ?: 'expire';

$arraysubs_fpm_is_subscription = get_post_meta($product_id, '_is_subscription', true);
?>

<div class="options_group show_if_subscription arraysubs-fixed-end-date-section<?php echo 'yes' !== $arraysubs_fpm_is_subscription ? ' arraysubs-fixed-end-date-section--hidden' : ''; ?>">
    <?php
    echo '<p class="form-field arraysubs-fixed-end-heading"><strong>' . esc_html__('Fixed Period Membership', 'arraysubspro') . '</strong>';
    echo '</p>';

    woocommerce_wp_checkbox([
        'id'          => '_arraysubs_fixed_end_date_enabled',
        'label'       => __('Use fixed end date', 'arraysubspro'),
        'description' => __('End this subscription on a fixed calendar date instead of counting billing cycles.', 'arraysubspro'),
        'desc_tip'    => true,
    ]);
    ?>

    <div class="arraysubs-fixed-end-fields<?php echo 'yes' !== $arraysubs_fpm_enabled ? ' arraysubs-fixed-end-fields--hidden' : ''; ?>">
        <?php
        woocommerce_wp_select([
            'id'      => '_arraysubs_fixed_end_date_type',
            'label'   => __('End date type', 'arraysubspro'),
            'options' => [
                'recurring_annual' => __('Recurring annual cutoff (month + day each year)', 'arraysubspro'),
                'absolute'         => __('Absolute date (specific calendar date)', 'arraysubspro'),
            ],
            'value'   => $arraysubs_fpm_type,
        ]);
        ?>

        <div class="arraysubs-fixed-end-absolute<?php echo 'absolute' !== $arraysubs_fpm_type ? ' arraysubs-fixed-end-absolute--hidden' : ''; ?>">
            <?php
            woocommerce_wp_text_input([
                'id'                => '_arraysubs_fixed_end_date',
                'label'             => __('End date', 'arraysubspro'),
                'description'       => __('The subscription ends on this exact date (YYYY-MM-DD).', 'arraysubspro'),
                'type'              => 'date',
                'value'             => 'absolute' === $arraysubs_fpm_type ? $arraysubs_fpm_date : '',
                'wrapper_class'     => 'arraysubs-fixed-end-absolute-field',
            ]);
            ?>
        </div>

        <div class="arraysubs-fixed-end-recurring<?php echo 'recurring_annual' !== $arraysubs_fpm_type ? ' arraysubs-fixed-end-recurring--hidden' : ''; ?>">
            <p class="form-field arraysubs-fixed-end-recurring-field">
                <label for="_arraysubs_fixed_end_date_recurring">
                    <?php esc_html_e('Annual cutoff (MM-DD)', 'arraysubspro'); ?>
                </label>
                <span class="wrap arraysubs-fixed-end-recurring-selects">
                    <select id="_arraysubs_fpm_month" name="_arraysubs_fpm_month" class="arraysubs-fixed-end-select">
                        <?php
                        $arraysubs_fpm_parts = explode('-', $arraysubs_fpm_date);
                        $arraysubs_fpm_saved_month = isset($arraysubs_fpm_parts[0]) && 'recurring_annual' === $arraysubs_fpm_type ? (int) $arraysubs_fpm_parts[0] : 0;
                        $arraysubs_fpm_saved_day   = isset($arraysubs_fpm_parts[1]) && 'recurring_annual' === $arraysubs_fpm_type ? (int) $arraysubs_fpm_parts[1] : 0;

                        for ($arraysubs_m = 1; $arraysubs_m <= 12; $arraysubs_m++) :
                            $arraysubs_month_name = date_i18n('F', mktime(0, 0, 0, $arraysubs_m, 1));
                        ?>
                            <option value="<?php echo esc_attr($arraysubs_m); ?>" <?php selected($arraysubs_fpm_saved_month, $arraysubs_m); ?>>
                                <?php echo esc_html($arraysubs_month_name); ?>
                            </option>
                        <?php endfor; ?>
                    </select>

                    <select id="_arraysubs_fpm_day" name="_arraysubs_fpm_day" class="arraysubs-fixed-end-select">
                        <?php for ($arraysubs_d = 1; $arraysubs_d <= 31; $arraysubs_d++) : ?>
                            <option value="<?php echo esc_attr($arraysubs_d); ?>" <?php selected($arraysubs_fpm_saved_day, $arraysubs_d); ?>>
                                <?php echo esc_html($arraysubs_d); ?>
                            </option>
                        <?php endfor; ?>
                    </select>
                </span>
                <?php echo wc_help_tip(__('The subscription will end on this month and day every year. For example, June 30 means the subscription always ends on June 30th.', 'arraysubspro')); ?>
            </p>
        </div>

        <p class="form-field arraysubs-fixed-end-heading"><strong><?php esc_html_e('Enrollment Window', 'arraysubspro'); ?></strong></p>
        <p class="form-field arraysubs-fixed-end-intro arraysubs-fixed-end-intro--compact">
            <span class="description arraysubs-fixed-end-intro__description">
                <?php esc_html_e('Optionally restrict when customers can purchase this product. Leave empty to allow purchases anytime.', 'arraysubspro'); ?>
            </span>
        </p>

        <?php
        woocommerce_wp_text_input([
            'id'    => '_arraysubs_enrollment_window_start',
            'label' => __('Enrollment opens', 'arraysubspro'),
            'type'  => 'date',
            'value' => $arraysubs_fpm_win_start,
            'wrapper_class' => 'arraysubs-fixed-end-date-field',
        ]);

        woocommerce_wp_text_input([
            'id'    => '_arraysubs_enrollment_window_end',
            'label' => __('Enrollment closes', 'arraysubspro'),
            'type'  => 'date',
            'value' => $arraysubs_fpm_win_end,
            'wrapper_class' => 'arraysubs-fixed-end-date-field',
        ]);

        woocommerce_wp_select([
            'id'          => '_arraysubs_fixed_end_renewal',
            'label'       => __('At period end', 'arraysubspro'),
            'description' => __('What happens when the fixed end date arrives.', 'arraysubspro'),
            'desc_tip'    => true,
            'wrapper_class' => 'arraysubs-fixed-end-renewal-field',
            'options'     => [
                'expire' => __('Expire — subscription ends, customer must repurchase', 'arraysubspro'),
                'renew'  => __('Renew — automatically start next period with new end date', 'arraysubspro'),
            ],
            'value'       => $arraysubs_fpm_renewal,
        ]);
        ?>
    </div>
</div>