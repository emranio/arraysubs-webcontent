<?php

/**
 * Fixed Period Membership - Variation Fields
 *
 * Renders the fixed-end-date options per variation.
 *
 * @package ArraySubsPro\Features\FixedPeriodMembership
 * @var int   $loop                   Variation loop index.
 * @var int   $arraysubs_variation_id Variation post ID.
 * @var array $variation_data         Variation data.
 */

defined('ABSPATH') || exit;

$arraysubs_fpm_v_enabled    = get_post_meta($arraysubs_variation_id, '_arraysubs_fixed_end_date_enabled', true);
$arraysubs_fpm_v_type       = get_post_meta($arraysubs_variation_id, '_arraysubs_fixed_end_date_type', true) ?: 'recurring_annual';
$arraysubs_fpm_v_date       = get_post_meta($arraysubs_variation_id, '_arraysubs_fixed_end_date', true);
$arraysubs_fpm_v_win_start  = get_post_meta($arraysubs_variation_id, '_arraysubs_enrollment_window_start', true);
$arraysubs_fpm_v_win_end    = get_post_meta($arraysubs_variation_id, '_arraysubs_enrollment_window_end', true);
$arraysubs_fpm_v_renewal    = get_post_meta($arraysubs_variation_id, '_arraysubs_fixed_end_renewal', true) ?: 'expire';

$arraysubs_fpm_v_is_subscription = get_post_meta($arraysubs_variation_id, '_is_subscription', true);

$arraysubs_fpm_v_parts = explode('-', $arraysubs_fpm_v_date);
$arraysubs_fpm_v_saved_month = isset($arraysubs_fpm_v_parts[0]) && 'recurring_annual' === $arraysubs_fpm_v_type ? (int) $arraysubs_fpm_v_parts[0] : 0;
$arraysubs_fpm_v_saved_day   = isset($arraysubs_fpm_v_parts[1]) && 'recurring_annual' === $arraysubs_fpm_v_type ? (int) $arraysubs_fpm_v_parts[1] : 0;
?>

<div class="arraysubs-variation-section arraysubs-variation-fixed-end-section show_if_variation_subscription<?php echo 'yes' !== $arraysubs_fpm_v_is_subscription ? ' arraysubs-variation-fixed-end-section--hidden' : ''; ?>">
    <div class="arraysubs-section-title">
        <?php esc_html_e('Fixed Period Membership', 'arraysubspro'); ?>
    </div>

    <div class="arraysubs-variation-row">
        <div class="arraysubs-section-title">
            <label class="arraysubs-checkbox-label">
                <input type="checkbox"
                    name="_arraysubs_fixed_end_date_enabled[<?php echo esc_attr($loop); ?>]"
                    value="yes"
                    class="checkbox arraysubs-variation-fixed-end-enabled"
                    <?php checked($arraysubs_fpm_v_enabled, 'yes'); ?> />
                <?php esc_html_e('Use fixed end date', 'arraysubspro'); ?>
            </label>
            <span class="description">
                <?php esc_html_e('End this subscription on a fixed calendar date instead of counting billing cycles.', 'arraysubspro'); ?>
            </span>
        </div>
    </div>

    <div class="arraysubs-variation-fixed-end-fields<?php echo 'yes' !== $arraysubs_fpm_v_enabled ? ' arraysubs-variation-fixed-end-fields--hidden' : ''; ?>">
        <div class="arraysubs-variation-row">
            <div class="arraysubs-variation-col arraysubs-variation-col-full">
                <label><?php esc_html_e('End date type', 'arraysubspro'); ?></label>
                <select name="_arraysubs_fixed_end_date_type[<?php echo esc_attr($loop); ?>]"
                    class="arraysubs-variation-fixed-end-type">
                    <option value="recurring_annual" <?php selected($arraysubs_fpm_v_type, 'recurring_annual'); ?>>
                        <?php esc_html_e('Recurring annual cutoff (month + day each year)', 'arraysubspro'); ?>
                    </option>
                    <option value="absolute" <?php selected($arraysubs_fpm_v_type, 'absolute'); ?>>
                        <?php esc_html_e('Absolute date (specific calendar date)', 'arraysubspro'); ?>
                    </option>
                </select>
            </div>
        </div>

        <div class="arraysubs-variation-row arraysubs-variation-fixed-end-absolute<?php echo 'absolute' !== $arraysubs_fpm_v_type ? ' arraysubs-variation-fixed-end-absolute--hidden' : ''; ?>">
            <div class="arraysubs-variation-col arraysubs-variation-col-half">
                <label><?php esc_html_e('End date', 'arraysubspro'); ?></label>
                <input type="date"
                    name="_arraysubs_fixed_end_date[<?php echo esc_attr($loop); ?>]"
                    value="<?php echo esc_attr('absolute' === $arraysubs_fpm_v_type ? $arraysubs_fpm_v_date : ''); ?>"
                    class="arraysubs-variation-fixed-end-date-input" />
                <span class="description"><?php esc_html_e('The subscription ends on this exact date.', 'arraysubspro'); ?></span>
            </div>
        </div>

        <div class="arraysubs-variation-row arraysubs-variation-fixed-end-recurring<?php echo 'recurring_annual' !== $arraysubs_fpm_v_type ? ' arraysubs-variation-fixed-end-recurring--hidden' : ''; ?>">
            <div class="arraysubs-variation-col arraysubs-variation-col-half">
                <label><?php esc_html_e('Annual cutoff', 'arraysubspro'); ?></label>
                <span class="wrap arraysubs-variation-fpm-selects">
                    <select name="_arraysubs_fpm_month[<?php echo esc_attr($loop); ?>]" class="arraysubs-variation-fpm-month arraysubs-variation-fpm-select">
                        <?php for ($arraysubs_fpm_vm = 1; $arraysubs_fpm_vm <= 12; $arraysubs_fpm_vm++) : ?>
                            <option value="<?php echo esc_attr($arraysubs_fpm_vm); ?>" <?php selected($arraysubs_fpm_v_saved_month, $arraysubs_fpm_vm); ?>>
                                <?php echo esc_html(date_i18n('F', mktime(0, 0, 0, $arraysubs_fpm_vm, 1))); ?>
                            </option>
                        <?php endfor; ?>
                    </select>
                    <select name="_arraysubs_fpm_day[<?php echo esc_attr($loop); ?>]" class="arraysubs-variation-fpm-day arraysubs-variation-fpm-select">
                        <?php for ($arraysubs_fpm_vd = 1; $arraysubs_fpm_vd <= 31; $arraysubs_fpm_vd++) : ?>
                            <option value="<?php echo esc_attr($arraysubs_fpm_vd); ?>" <?php selected($arraysubs_fpm_v_saved_day, $arraysubs_fpm_vd); ?>>
                                <?php echo esc_html($arraysubs_fpm_vd); ?>
                            </option>
                        <?php endfor; ?>
                    </select>
                </span>
                <span class="description"><?php esc_html_e('The subscription ends on this month and day every year.', 'arraysubspro'); ?></span>
            </div>
        </div>

        <div class="arraysubs-variation-row arraysubs-variation-row--intro">
            <div class="arraysubs-variation-col arraysubs-variation-col-full">
                <strong><?php esc_html_e('Enrollment Window', 'arraysubspro'); ?></strong>
                <span class="description arraysubs-variation-description"><?php esc_html_e('Optionally restrict when customers can purchase this variation. Leave empty to allow purchases anytime.', 'arraysubspro'); ?></span>
            </div>
        </div>

        <div class="arraysubs-variation-row arraysubs-variation-row--spaced">
            <div class="arraysubs-variation-col arraysubs-variation-col-half">
                <label><?php esc_html_e('Enrollment opens', 'arraysubspro'); ?></label>
                <input type="date"
                    name="_arraysubs_enrollment_window_start[<?php echo esc_attr($loop); ?>]"
                    value="<?php echo esc_attr($arraysubs_fpm_v_win_start); ?>" />
            </div>
            <div class="arraysubs-variation-col arraysubs-variation-col-half">
                <label><?php esc_html_e('Enrollment closes', 'arraysubspro'); ?></label>
                <input type="date"
                    name="_arraysubs_enrollment_window_end[<?php echo esc_attr($loop); ?>]"
                    value="<?php echo esc_attr($arraysubs_fpm_v_win_end); ?>" />
            </div>
        </div>

        <div class="arraysubs-variation-row arraysubs-variation-row--spaced">
            <div class="arraysubs-variation-col arraysubs-variation-col-full">
                <label><?php esc_html_e('At period end', 'arraysubspro'); ?></label>
                <select name="_arraysubs_fixed_end_renewal[<?php echo esc_attr($loop); ?>]">
                    <option value="expire" <?php selected($arraysubs_fpm_v_renewal, 'expire'); ?>>
                        <?php esc_html_e('Expire — subscription ends, customer must repurchase', 'arraysubspro'); ?>
                    </option>
                    <option value="renew" <?php selected($arraysubs_fpm_v_renewal, 'renew'); ?>>
                        <?php esc_html_e('Renew — automatically start next period with new end date', 'arraysubspro'); ?>
                    </option>
                </select>
            </div>
        </div>
    </div>
</div>