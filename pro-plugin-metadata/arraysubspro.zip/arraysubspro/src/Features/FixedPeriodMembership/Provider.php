<?php

/**
 * Fixed Period Membership Provider
 *
 * @package ArraySubsPro\Features\FixedPeriodMembership
 */

namespace ArraySubsPro\Features\FixedPeriodMembership;

defined('ABSPATH') || exit;

use ArraySubs\Supports\Abstracts\AbstractLoader;

/**
 * Feature entry point
 */
class Provider extends AbstractLoader
{
    /**
     * Constructor
     */
    public function __construct()
    {
        $this->classLoader([
            plugin_dir_path(__FILE__) . 'Services',
        ]);
    }
}
