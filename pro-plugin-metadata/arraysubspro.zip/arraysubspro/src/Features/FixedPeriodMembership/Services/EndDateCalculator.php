<?php

/**
 * End Date Calculator
 *
 * Computes the concrete subscription end date from fixed-period product configuration.
 *
 * @package ArraySubsPro\Features\FixedPeriodMembership\Services
 */

namespace ArraySubsPro\Features\FixedPeriodMembership\Services;

defined('ABSPATH') || exit;

/**
 * Calculates fixed end dates for subscriptions
 */
class EndDateCalculator
{
    /**
     * Calculate the concrete end date for a subscription based on product meta.
     *
     * @param int    $product_id    Product or variation ID.
     * @param string $join_date_utc MySQL datetime when the customer joins (UTC).
     * @return string|null MySQL datetime (UTC) or null if not a fixed-period product.
     */
    public static function calculate(int $product_id, string $join_date_utc = ''): ?string
    {
        if (!self::isFixedPeriodProduct($product_id)) {
            return null;
        }

        $type = get_post_meta($product_id, '_arraysubs_fixed_end_date_type', true);
        $value = get_post_meta($product_id, '_arraysubs_fixed_end_date', true);

        if (empty($value)) {
            return null;
        }

        if (empty($join_date_utc)) {
            $join_date_utc = current_time('mysql', true);
        }

        $site_tz = wp_timezone();

        if ('absolute' === $type) {
            return self::calculateAbsolute($value, $site_tz);
        }

        if ('recurring_annual' === $type) {
            // Convert UTC to site-local for calendar-based calculation.
            $join_local = new \DateTime($join_date_utc, new \DateTimeZone('UTC'));
            $join_local->setTimezone($site_tz);

            return self::calculateRecurringAnnual($value, $join_local->format('Y-m-d H:i:s'), $site_tz);
        }

        return null;
    }

    /**
     * Calculate the next-period end date for renewal into the next fixed period.
     *
     * @param int    $product_id      Product or variation ID.
     * @param string $current_end_utc Current end date (UTC MySQL datetime).
     * @return string|null Next period end date (UTC MySQL datetime) or null.
     */
    public static function calculateNextPeriod(int $product_id, string $current_end_utc): ?string
    {
        $type = get_post_meta($product_id, '_arraysubs_fixed_end_date_type', true);

        if ('recurring_annual' !== $type) {
            return null;
        }

        $value = get_post_meta($product_id, '_arraysubs_fixed_end_date', true);

        if (empty($value)) {
            return null;
        }

        $site_tz = wp_timezone();

        $current_end_local = new \DateTime($current_end_utc, new \DateTimeZone('UTC'));
        $current_end_local->setTimezone($site_tz);
        $reference_date = $current_end_local->format('Y-m-d H:i:s');

        return self::calculateRecurringAnnual($value, $reference_date, $site_tz);
    }

    /**
     * Check whether a product is a fixed-period product.
     *
     * @param int $product_id Product or variation ID.
     * @return bool
     */
    public static function isFixedPeriodProduct(int $product_id): bool
    {
        return 'yes' === get_post_meta($product_id, '_arraysubs_fixed_end_date_enabled', true)
            || 'yes' === get_post_meta($product_id, '_arraysubs_use_fixed_end_date', true);
    }

    /**
     * Get the display end date string for a product (site-local).
     *
     * @param int    $product_id Product or variation ID.
     * @param string $format     PHP date format. Defaults to site date format.
     * @return string|null Formatted date or null.
     */
    public static function getDisplayEndDate(int $product_id, string $format = ''): ?string
    {
        $end_date_utc = self::calculate($product_id);

        if (empty($end_date_utc)) {
            return null;
        }

        if (empty($format)) {
            $format = get_option('date_format');
        }

        return arraysubs_format_date_local($end_date_utc, $format);
    }

    /**
     * Calculate absolute end date (specific calendar date → UTC).
     *
     * @param string        $date_value Date in Y-m-d format.
     * @param \DateTimeZone $site_tz    Site timezone.
     * @return string|null UTC MySQL datetime.
     */
    private static function calculateAbsolute(string $date_value, \DateTimeZone $site_tz): ?string
    {
        try {
            $end = new \DateTime($date_value . ' 23:59:59', $site_tz);
            $end->setTimezone(new \DateTimeZone('UTC'));
            return $end->format('Y-m-d H:i:s');
        } catch (\Exception $e) {
            return null;
        }
    }

    /**
     * Calculate recurring annual end date.
     *
     * For a cutoff of MM-DD: if the cutoff this year has already passed relative to
     * the join date, use next year's cutoff. The end date is set to 23:59:59 site-local
     * and then converted to UTC.
     *
     * @param string        $month_day  Month-day string in MM-DD format.
     * @param string        $join_date  Site-local MySQL datetime.
     * @param \DateTimeZone $site_tz    Site timezone.
     * @return string|null UTC MySQL datetime.
     */
    private static function calculateRecurringAnnual(string $month_day, string $join_date, \DateTimeZone $site_tz): ?string
    {
        try {
            $parts = explode('-', $month_day);

            if (count($parts) < 2) {
                return null;
            }

            $month = (int) $parts[0];
            $day   = (int) $parts[1];

            if ($month < 1 || $month > 12 || $day < 1 || $day > 31) {
                return null;
            }

            $join = new \DateTime($join_date, $site_tz);
            $year = (int) $join->format('Y');

            $cutoff_str = sprintf('%04d-%02d-%02d 23:59:59', $year, $month, $day);
            $cutoff = new \DateTime($cutoff_str, $site_tz);

            if ($cutoff <= $join) {
                $cutoff->modify('+1 year');
            }

            $cutoff->setTimezone(new \DateTimeZone('UTC'));
            return $cutoff->format('Y-m-d H:i:s');
        } catch (\Exception $e) {
            return null;
        }
    }
}
