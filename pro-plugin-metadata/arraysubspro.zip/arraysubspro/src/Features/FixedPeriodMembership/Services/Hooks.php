<?php

/**
 * Fixed Period Membership Hooks
 *
 * Handles product field rendering, saving, purchasability enforcement,
 * subscription creation integration, and display hooks for the fixed-period
 * membership feature.
 *
 * @package ArraySubsPro\Features\FixedPeriodMembership\Services
 */

namespace ArraySubsPro\Features\FixedPeriodMembership\Services;

defined('ABSPATH') || exit;

use ArraySubs\Supports\ActionScheduler;
use ArraySubs\Supports\Config;
use ArraySubsPro\Features\FixedPeriodMembership\Services\EndDateCalculator;

/**
 * WordPress hooks integration for fixed-period memberships
 */
class Hooks
{
    /**
     * Enable auto-loading
     *
     * @var bool
     */
    public static $loadable = true;

    /**
     * Constructor
     */
    public function __construct()
    {
        // --- Admin: Product fields ---
        add_action('arraysubs_subscription_product_fields_before_shipping', [$this, 'renderSimpleProductFields'], 10, 1);
        add_action('arraysubs_subscription_variation_fields_before_shipping', [$this, 'renderVariationFields'], 10, 4);

        // --- Admin: Save product meta ---
        add_action('woocommerce_process_product_meta', [$this, 'saveProductMeta'], 15, 1);
        add_action('woocommerce_save_product_variation', [$this, 'saveVariationMeta'], 15, 2);

        // --- Front-end: Purchasability / enrollment window ---
        add_filter('woocommerce_is_purchasable', [$this, 'filterPurchasable'], 80, 2);
        add_filter('woocommerce_variation_is_purchasable', [$this, 'filterPurchasable'], 80, 2);

        // --- Front-end: Product page display ---
        add_action('woocommerce_single_product_summary', [$this, 'displayProductFixedEndDate'], 12);
        add_action('wp_enqueue_scripts', [$this, 'enqueueFrontendScripts'], 20);

        // --- Front-end: Cart / checkout display ---
        add_filter('woocommerce_get_item_data', [$this, 'addCartItemFixedEndDate'], 25, 2);

        // --- Checkout: subscription creation ---
        add_action('arraysubs_data_created_from_order', [$this, 'setSubscriptionEndDate'], 10, 3);

        // --- Checkout: display in order review ---
        add_action('woocommerce_review_order_after_order_total', [$this, 'displayCheckoutFixedEndDate'], 15);

        // --- Admin: Variation subscription data for frontend ---
        add_filter('woocommerce_available_variation', [$this, 'addVariationFixedEndData'], 15, 3);

        // --- Admin: Enqueue scripts for conditional field visibility ---
        add_action('admin_enqueue_scripts', [$this, 'enqueueAdminScripts'], 20);

        // --- Renewal / expiration lifecycle ---
        add_filter('arraysubs_should_generate_renewal_invoice', [$this, 'blockInvoicePastEndDate'], 10, 2);
        add_filter('arraysubs_should_expire_subscription', [$this, 'handleRenewalBehavior'], 10, 2);
        add_action('arraysubs_renewal_payment_complete', [$this, 'guardRenewalSchedulePastEndDate'], 10, 1);

        // --- Plan switching ---
        add_action('arraysubs_plan_switch_completed', [$this, 'onPlanSwitchCompleted'], 10, 4);
    }

    /**
     * Render fixed-end-date fields in the Subscription panel for simple products.
     *
     * @param int $product_id Product post ID.
     * @return void
     */
    public function renderSimpleProductFields(int $product_id = 0): void
    {
        global $post;

        if ($product_id <= 0 && $post) {
            $product_id = $post->ID;
        }

        if ($product_id <= 0) {
            return;
        }

        include dirname(__DIR__) . '/views/simple-product-fields.php';
    }

    /**
     * Render fixed-end-date fields for product variations.
     *
     * @param int      $loop                   Variation loop index.
     * @param array    $variation_data         Variation data.
     * @param \WP_Post $variation              Variation post object.
     * @param int|null $arraysubs_variation_id Variation post ID.
     * @return void
     */
    public function renderVariationFields(int $loop, array $variation_data, \WP_Post $variation, ?int $arraysubs_variation_id = null): void
    {
        $arraysubs_variation_id = $arraysubs_variation_id ?: $variation->ID;
        include dirname(__DIR__) . '/views/variation-fields.php';
    }

    /**
     * Save fixed-period meta for simple products.
     *
     * @param int $post_id Product post ID.
     * @return void
     */
    public function saveProductMeta(int $post_id): void
    {
        if (
            !isset($_POST['woocommerce_meta_nonce'])
            || !wp_verify_nonce(
                sanitize_text_field(wp_unslash($_POST['woocommerce_meta_nonce'])),
                'woocommerce_save_data'
            )
        ) {
            return;
        }

        $this->saveFixedPeriodFields($post_id);
    }

    /**
     * Save fixed-period meta for variations.
     *
     * @param int $variation_id Variation post ID.
     * @param int $loop         Loop index.
     * @return void
     */
    public function saveVariationMeta(int $variation_id, int $loop): void
    {
        $nonce_verified = false;

        if (
            isset($_POST['woocommerce_meta_nonce'])
            && wp_verify_nonce(
                sanitize_text_field(wp_unslash($_POST['woocommerce_meta_nonce'])),
                'woocommerce_save_data'
            )
        ) {
            $nonce_verified = true;
        }

        if (
            !$nonce_verified && isset($_POST['security'])
            && wp_verify_nonce(
                sanitize_text_field(wp_unslash($_POST['security'])),
                'save-variations'
            )
        ) {
            $nonce_verified = true;
        }

        if (!$nonce_verified) {
            return;
        }

        $this->saveFixedPeriodFieldsVariation($variation_id, $loop);
    }

    /**
     * Filter product purchasability based on enrollment window.
     *
     * @param bool        $purchasable Current purchasability.
     * @param \WC_Product $product     Product object.
     * @return bool
     */
    public function filterPurchasable(bool $purchasable, $product): bool
    {
        if (!$purchasable || !$product || !method_exists($product, 'get_id')) {
            return $purchasable;
        }

        $product_id = (int) $product->get_id();

        if (!EndDateCalculator::isFixedPeriodProduct($product_id)) {
            return $purchasable;
        }

        // Check absolute date hasn't passed
        $type = get_post_meta($product_id, '_arraysubs_fixed_end_date_type', true);

        if ('absolute' === $type) {
            $end_date_value = get_post_meta($product_id, '_arraysubs_fixed_end_date', true);

            if (!empty($end_date_value)) {
                $site_tz  = wp_timezone();
                $now      = new \DateTime('now', $site_tz);
                $end_date = new \DateTime($end_date_value . ' 23:59:59', $site_tz);

                if ($now > $end_date) {
                    return false;
                }
            }
        }

        // Check enrollment window
        $window_start = get_post_meta($product_id, '_arraysubs_enrollment_window_start', true);
        $window_end   = get_post_meta($product_id, '_arraysubs_enrollment_window_end', true);

        if (empty($window_start) && empty($window_end)) {
            return $purchasable;
        }

        $site_tz = wp_timezone();
        $now     = new \DateTime('now', $site_tz);

        if (!empty($window_start)) {
            $start = new \DateTime($window_start . ' 00:00:00', $site_tz);
            if ($now < $start) {
                return false;
            }
        }

        if (!empty($window_end)) {
            $end = new \DateTime($window_end . ' 23:59:59', $site_tz);
            if ($now > $end) {
                return false;
            }
        }

        return $purchasable;
    }

    /**
     * Display fixed end date on the product page.
     *
     * @return void
     */
    public function displayProductFixedEndDate(): void
    {
        global $product;

        if (!$product || !method_exists($product, 'get_id')) {
            return;
        }

        $product_id = (int) $product->get_id();

        if ($product->is_type('variable')) {
            $has_fixed_period_variation = false;

            foreach ($product->get_children() as $variation_id) {
                if (EndDateCalculator::isFixedPeriodProduct((int) $variation_id)) {
                    $has_fixed_period_variation = true;
                    break;
                }
            }

            if (!$has_fixed_period_variation) {
                return;
            }

            $arraysubs_fpm_is_variable = true;
            include dirname(__DIR__) . '/views/product-info.php';
            return;
        }

        if (!EndDateCalculator::isFixedPeriodProduct($product_id)) {
            return;
        }

        $arraysubs_fpm_is_variable = false;
        include dirname(__DIR__) . '/views/product-info.php';
    }

    /**
     * Add fixed end date info to cart item data (visible in cart / checkout).
     *
     * @param array $item_data Existing item data.
     * @param array $cart_item Cart item.
     * @return array
     */
    public function addCartItemFixedEndDate(array $item_data, array $cart_item): array
    {
        $product_id  = !empty($cart_item['variation_id']) ? (int) $cart_item['variation_id'] : (int) $cart_item['product_id'];

        if ($product_id <= 0 || !EndDateCalculator::isFixedPeriodProduct($product_id)) {
            return $item_data;
        }

        $display_date = EndDateCalculator::getDisplayEndDate($product_id);

        if (empty($display_date)) {
            return $item_data;
        }

        $item_data[] = [
            'key'   => __('Membership ends', 'arraysubspro'),
            'value' => $display_date,
        ];

        $renewal = get_post_meta($product_id, '_arraysubs_fixed_end_renewal', true);

        if ('renew' === $renewal) {
            $item_data[] = [
                'key'   => __('Renewal', 'arraysubspro'),
                'value' => __('Auto-renews into next period', 'arraysubspro'),
            ];
        }

        return $item_data;
    }

    /**
     * Set the computed fixed end date on the subscription at creation time.
     *
     * @param int   $subscription_id Subscription ID.
     * @param int   $order_id        Order ID.
     * @param mixed $item            Order item.
     * @return void
     */
    public function setSubscriptionEndDate(int $subscription_id, int $order_id, $item): void
    {
        if (!$item || !method_exists($item, 'get_product_id')) {
            return;
        }

        $variation_id = $item->get_variation_id();
        $product_id   = $variation_id > 0 ? $variation_id : $item->get_product_id();

        if (!EndDateCalculator::isFixedPeriodProduct($product_id)) {
            return;
        }

        $start_date   = get_post_meta($subscription_id, '_start_date', true);
        $end_date_utc = EndDateCalculator::calculate($product_id, $start_date);

        if (empty($end_date_utc)) {
            return;
        }

        update_post_meta($subscription_id, '_end_date', $end_date_utc);
        update_post_meta($subscription_id, '_arraysubs_fixed_end_date_enabled', 'yes');
        update_post_meta($subscription_id, '_arraysubs_fixed_end_renewal', get_post_meta($product_id, '_arraysubs_fixed_end_renewal', true));
        update_post_meta($subscription_id, '_arraysubs_fixed_end_date_type', get_post_meta($product_id, '_arraysubs_fixed_end_date_type', true));
        update_post_meta($subscription_id, '_arraysubs_fixed_end_date', get_post_meta($product_id, '_arraysubs_fixed_end_date', true));

        // Schedule the expiration action so the subscription expires at the end date
        $this->scheduleExpiration($subscription_id, $end_date_utc);
    }

    /**
     * Display fixed end date in the checkout order review table.
     *
     * @return void
     */
    public function displayCheckoutFixedEndDate(): void
    {
        if (!function_exists('WC') || !WC()->cart) {
            return;
        }

        foreach (WC()->cart->get_cart() as $cart_item) {
            $product_id = !empty($cart_item['variation_id']) ? (int) $cart_item['variation_id'] : (int) $cart_item['product_id'];

            if ($product_id <= 0 || !EndDateCalculator::isFixedPeriodProduct($product_id)) {
                continue;
            }

            $display_date = EndDateCalculator::getDisplayEndDate($product_id);

            if (empty($display_date)) {
                continue;
            }

            echo '<tr class="subscription-fixed-end-date-info">';
            echo '<th>' . esc_html__('Membership ends', 'arraysubspro') . '</th>';
            echo '<td>' . esc_html($display_date) . '</td>';
            echo '</tr>';
        }
    }

    /**
     * Add fixed-end-date data to the variation JSON for frontend rendering.
     *
     * @param array                 $data      Variation data.
     * @param \WC_Product_Variable  $product   Parent product.
     * @param \WC_Product_Variation $variation Variation.
     * @return array
     */
    public function addVariationFixedEndData(array $data, $product, $variation): array
    {
        if (!$variation || !method_exists($variation, 'get_id')) {
            return $data;
        }

        $variation_id = (int) $variation->get_id();

        if (!EndDateCalculator::isFixedPeriodProduct($variation_id)) {
            return $data;
        }

        $data['arraysubs_fixed_end_date']         = EndDateCalculator::getDisplayEndDate($variation_id);
        $data['arraysubs_fixed_end_date_renewal'] = get_post_meta($variation_id, '_arraysubs_fixed_end_renewal', true);
        $data['arraysubs_fixed_end_window_display'] = $this->getEnrollmentWindowDisplay($variation_id);

        return $data;
    }

    /**
     * Enqueue frontend behavior for variable-product fixed-period messaging.
     *
     * @return void
     */
    public function enqueueFrontendScripts(): void
    {
        if (!function_exists('is_product') || !is_product()) {
            return;
        }

        global $product;

        if (!$product || !method_exists($product, 'is_type') || !$product->is_type('variable')) {
            if (!$product || !method_exists($product, 'get_id')) {
                return;
            }

            if (!EndDateCalculator::isFixedPeriodProduct((int) $product->get_id())) {
                return;
            }

            $style_asset = $this->getAssetFile('fixed-period-membership');

            wp_enqueue_style(
                'arraysubspro-fixed-period-membership',
                Config::get('proplugin.public_url') . 'build/fixed-period-membership.css',
                [],
                $style_asset['version']
            );

            return;
        }

        $has_fixed_period_variation = false;

        foreach ($product->get_children() as $variation_id) {
            if (EndDateCalculator::isFixedPeriodProduct((int) $variation_id)) {
                $has_fixed_period_variation = true;
                break;
            }
        }

        if (!$has_fixed_period_variation) {
            return;
        }

        $asset = $this->getAssetFile('fixed-period-membership');

        wp_enqueue_style(
            'arraysubspro-fixed-period-membership',
            Config::get('proplugin.public_url') . 'build/fixed-period-membership.css',
            [],
            $asset['version']
        );

        wp_enqueue_script(
            'arraysubspro-fixed-period-membership',
            Config::get('proplugin.public_url') . 'build/fixed-period-membership.js',
            array_unique(array_merge($asset['dependencies'], ['jquery', 'wc-add-to-cart-variation'])),
            $asset['version'],
            true
        );
    }

    /**
     * Enqueue admin scripts for conditional field visibility.
     *
     * @param string $hook Current admin page hook.
     * @return void
     */
    public function enqueueAdminScripts(string $hook): void
    {
        if (!in_array($hook, ['post.php', 'post-new.php'], true)) {
            return;
        }

        $screen = get_current_screen();

        if (!$screen || 'product' !== $screen->id) {
            return;
        }

        $asset = $this->getAssetFile('admin/fixed-period-membership');

        wp_enqueue_style(
            'arraysubspro-fixed-period-membership-admin',
            Config::get('proplugin.public_url') . 'build/admin/fixed-period-membership.css',
            [],
            $asset['version']
        );

        wp_enqueue_script(
            'arraysubspro-fixed-period-membership-admin',
            Config::get('proplugin.public_url') . 'build/admin/fixed-period-membership.js',
            array_unique(array_merge($asset['dependencies'], ['jquery', 'wc-admin-product-meta-boxes'])),
            $asset['version'],
            true
        );
    }

    /**
     * Prevent renewal invoice from being generated when the fixed end date has passed
     * or the next billing cycle falls after the end date.
     *
     * @param bool     $should_generate Whether to generate the invoice.
     * @param \WP_Post $subscription    Subscription post object.
     * @return bool
     */
    public function blockInvoicePastEndDate(bool $should_generate, $subscription): bool
    {
        if (!$should_generate) {
            return $should_generate;
        }

        if (!$subscription instanceof \WP_Post) {
            return $should_generate;
        }

        $subscription_id = $subscription->ID;
        $fixed_enabled   = get_post_meta($subscription_id, '_arraysubs_fixed_end_date_enabled', true);

        if ('yes' !== $fixed_enabled) {
            return $should_generate;
        }

        $end_date = get_post_meta($subscription_id, '_end_date', true);

        if (empty($end_date) || '0000-00-00 00:00:00' === $end_date) {
            return $should_generate;
        }

        $now_utc = current_time('mysql', true);

        // End date already passed — no more invoices
        if ($now_utc >= $end_date) {
            return false;
        }

        // Next payment date is at or after the end date — skip last cycle invoice
        $next_payment = get_post_meta($subscription_id, '_next_payment_date', true);

        if (!empty($next_payment) && $next_payment >= $end_date) {
            return false;
        }

        return $should_generate;
    }

    /**
     * Intercept expiration to renew into the next period when configured.
     *
     * If the renewal behavior is "renew" (recurring annual), compute the next period
     * end date, update the subscription, and prevent expiration.
     *
     * @param bool $should_expire   Whether the subscription should expire.
     * @param int  $subscription_id Subscription ID.
     * @return bool
     */
    public function handleRenewalBehavior(bool $should_expire, int $subscription_id): bool
    {
        if (!$should_expire) {
            return $should_expire;
        }

        $fixed_enabled = get_post_meta($subscription_id, '_arraysubs_fixed_end_date_enabled', true);

        if ('yes' !== $fixed_enabled) {
            return $should_expire;
        }

        $renewal_behavior = get_post_meta($subscription_id, '_arraysubs_fixed_end_renewal', true);

        if ('renew' !== $renewal_behavior) {
            return $should_expire;
        }

        // Only recurring_annual supports automatic period renewal
        $type = get_post_meta($subscription_id, '_arraysubs_fixed_end_date_type', true);

        if ('recurring_annual' !== $type) {
            return $should_expire;
        }

        // Resolve the product ID (variation first, then parent)
        $variation_id = (int) get_post_meta($subscription_id, '_variation_id', true);
        $product_id   = $variation_id > 0 ? $variation_id : (int) get_post_meta($subscription_id, '_product_id', true);

        if ($product_id <= 0) {
            return $should_expire;
        }

        $current_end = get_post_meta($subscription_id, '_end_date', true);

        if (empty($current_end)) {
            return $should_expire;
        }

        $next_end = EndDateCalculator::calculateNextPeriod($product_id, $current_end);

        if (empty($next_end)) {
            return $should_expire;
        }

        // Update the end date to the next period
        update_post_meta($subscription_id, '_end_date', $next_end);

        // Reschedule expiration for the new end date
        $this->scheduleExpiration($subscription_id, $next_end);

        return false;
    }

    /**
     * After a renewal payment completes, unschedule the next renewal if it would
     * fall at or after the fixed end date.
     *
     * @param int $subscription_id Subscription ID.
     * @return void
     */
    public function guardRenewalSchedulePastEndDate(int $subscription_id): void
    {
        $fixed_enabled = get_post_meta($subscription_id, '_arraysubs_fixed_end_date_enabled', true);

        if ('yes' !== $fixed_enabled) {
            return;
        }

        $end_date = get_post_meta($subscription_id, '_end_date', true);

        if (empty($end_date) || '0000-00-00 00:00:00' === $end_date) {
            return;
        }

        $next_payment = get_post_meta($subscription_id, '_next_payment_date', true);

        if (empty($next_payment)) {
            return;
        }

        // If next payment date is at or past the end date, unschedule the renewal
        if ($next_payment >= $end_date) {
            \ArraySubs\Features\RecurringBilling\Services\RenewalScheduler::unschedule($subscription_id);
        }
    }

    /**
     * Save fixed-period fields for a simple product.
     *
     * @param int $post_id Product post ID.
     * @return void
     */
    private function saveFixedPeriodFields(int $post_id): void
    {
        if (
            !isset($_POST['woocommerce_meta_nonce'])
            || !wp_verify_nonce(
                sanitize_text_field(wp_unslash($_POST['woocommerce_meta_nonce'])),
                'woocommerce_save_data'
            )
        ) {
            return;
        }

        $fields = [
            '_arraysubs_fixed_end_date_enabled' => 'sanitize_text_field',
            '_arraysubs_fixed_end_date_type'    => 'sanitize_text_field',
            '_arraysubs_fixed_end_date'         => 'sanitize_text_field',
            '_arraysubs_enrollment_window_start' => 'sanitize_text_field',
            '_arraysubs_enrollment_window_end'   => 'sanitize_text_field',
            '_arraysubs_fixed_end_renewal'       => 'sanitize_text_field',
        ];

        $checkbox_fields = ['_arraysubs_fixed_end_date_enabled'];

        foreach ($fields as $key => $callback) {
            if (isset($_POST[$key])) {
                if (in_array($key, $checkbox_fields, true)) {
                    $value = 'yes';
                } else {
                    $raw = sanitize_text_field(wp_unslash($_POST[$key]));
                    $value = call_user_func($callback, $raw);
                }

                update_post_meta($post_id, $key, $value);
            } else {
                delete_post_meta($post_id, $key);
            }
        }

        // Mutual exclusivity: if fixed end date is enabled, clear subscription length
        if ('yes' === get_post_meta($post_id, '_arraysubs_fixed_end_date_enabled', true)) {
            update_post_meta($post_id, '_subscription_length', 0);
        }

        // Validate the fixed end date type
        $allowed_types = ['absolute', 'recurring_annual'];
        $saved_type    = get_post_meta($post_id, '_arraysubs_fixed_end_date_type', true);

        if (!empty($saved_type) && !in_array($saved_type, $allowed_types, true)) {
            delete_post_meta($post_id, '_arraysubs_fixed_end_date_type');
        }

        // Validate renewal behavior
        $allowed_renewal = ['renew', 'expire'];
        $saved_renewal   = get_post_meta($post_id, '_arraysubs_fixed_end_renewal', true);

        if (!empty($saved_renewal) && !in_array($saved_renewal, $allowed_renewal, true)) {
            update_post_meta($post_id, '_arraysubs_fixed_end_renewal', 'expire');
        }

        // For recurring_annual, compose MM-DD from separate month/day POST fields (server-side fallback)
        if ('recurring_annual' === get_post_meta($post_id, '_arraysubs_fixed_end_date_type', true)) {
            $month = isset($_POST['_arraysubs_fpm_month'])
                ? absint(wp_unslash($_POST['_arraysubs_fpm_month']))
                : 0;
            $day   = isset($_POST['_arraysubs_fpm_day'])
                ? absint(wp_unslash($_POST['_arraysubs_fpm_day']))
                : 0;

            if ($month >= 1 && $month <= 12 && $day >= 1 && $day <= 31) {
                $mm_dd = sprintf('%02d-%02d', $month, $day);
                update_post_meta($post_id, '_arraysubs_fixed_end_date', $mm_dd);
            }
        }
    }

    /**
     * Save fixed-period fields for a variation.
     *
     * @param int $variation_id Variation post ID.
     * @param int $loop         Loop index.
     * @return void
     */
    private function saveFixedPeriodFieldsVariation(int $variation_id, int $loop): void
    {
        $nonce_ok = false;
        if (
            isset($_POST['woocommerce_meta_nonce'])
            && wp_verify_nonce(
                sanitize_text_field(wp_unslash($_POST['woocommerce_meta_nonce'])),
                'woocommerce_save_data'
            )
        ) {
            $nonce_ok = true;
        }

        if (
            !$nonce_ok && isset($_POST['security'])
            && wp_verify_nonce(
                sanitize_text_field(wp_unslash($_POST['security'])),
                'save-variations'
            )
        ) {
            $nonce_ok = true;
        }

        if (!$nonce_ok) {
            return;
        }

        $fields = [
            '_arraysubs_fixed_end_date_enabled'  => 'sanitize_text_field',
            '_arraysubs_fixed_end_date_type'     => 'sanitize_text_field',
            '_arraysubs_fixed_end_date'          => 'sanitize_text_field',
            '_arraysubs_enrollment_window_start'  => 'sanitize_text_field',
            '_arraysubs_enrollment_window_end'    => 'sanitize_text_field',
            '_arraysubs_fixed_end_renewal'        => 'sanitize_text_field',
        ];

        $checkbox_fields = ['_arraysubs_fixed_end_date_enabled'];

        foreach ($fields as $key => $callback) {
            // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Sanitized via callback below
            if (isset($_POST[$key][$loop])) {
                if (in_array($key, $checkbox_fields, true)) {
                    $value = 'yes';
                } else {
                    // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Sanitized via callback
                    $value = call_user_func($callback, wp_unslash($_POST[$key][$loop]));
                }

                update_post_meta($variation_id, $key, $value);
            } else {
                delete_post_meta($variation_id, $key);
            }
        }

        // Mutual exclusivity: if fixed end date is enabled, clear subscription length
        if ('yes' === get_post_meta($variation_id, '_arraysubs_fixed_end_date_enabled', true)) {
            update_post_meta($variation_id, '_subscription_length', 0);
        }

        // Validate the fixed end date type
        $allowed_types = ['absolute', 'recurring_annual'];
        $saved_type    = get_post_meta($variation_id, '_arraysubs_fixed_end_date_type', true);

        if (!empty($saved_type) && !in_array($saved_type, $allowed_types, true)) {
            delete_post_meta($variation_id, '_arraysubs_fixed_end_date_type');
            $saved_type = '';
        }

        // Validate renewal behavior
        $allowed_renewal = ['renew', 'expire'];
        $saved_renewal   = get_post_meta($variation_id, '_arraysubs_fixed_end_renewal', true);

        if (!empty($saved_renewal) && !in_array($saved_renewal, $allowed_renewal, true)) {
            update_post_meta($variation_id, '_arraysubs_fixed_end_renewal', 'expire');
        }

        // For recurring_annual, compose MM-DD from separate month/day POST fields

        if ('recurring_annual' === $saved_type) {
            $month = isset($_POST['_arraysubs_fpm_month'][$loop])
                ? absint(wp_unslash($_POST['_arraysubs_fpm_month'][$loop]))
                : 0;
            $day   = isset($_POST['_arraysubs_fpm_day'][$loop])
                ? absint(wp_unslash($_POST['_arraysubs_fpm_day'][$loop]))
                : 0;

            if ($month >= 1 && $month <= 12 && $day >= 1 && $day <= 31) {
                $mm_dd = sprintf('%02d-%02d', $month, $day);
                update_post_meta($variation_id, '_arraysubs_fixed_end_date', $mm_dd);
            }
        }
    }

    /**
     * Handle plan switch: recalculate fixed end date for the new product.
     *
     * @param int    $subscription_id Subscription ID.
     * @param int    $old_product_id  Previous product ID.
     * @param int    $new_product_id  New product ID.
     * @param string $switch_type     Switch type (upgrade/downgrade/crossgrade).
     * @return void
     */
    public function onPlanSwitchCompleted(int $subscription_id, int $old_product_id, int $new_product_id, string $switch_type): void
    {
        // Clear old fixed-period meta from the subscription
        $fixed_meta_keys = [
            '_arraysubs_fixed_end_date_enabled',
            '_arraysubs_fixed_end_date_type',
            '_arraysubs_fixed_end_date',
            '_arraysubs_fixed_end_renewal',
        ];

        foreach ($fixed_meta_keys as $key) {
            delete_post_meta($subscription_id, $key);
        }

        // Unschedule any pending expiration from the old product
        if (class_exists(ActionScheduler::class)) {
            ActionScheduler::unscheduleAll(
                ActionScheduler::HOOK_EXPIRE_SUBSCRIPTION,
                [$subscription_id],
                ActionScheduler::GROUP_STATUS
            );
        }

        // If the new product is a fixed-period product, recalculate and set the new end date
        if (!EndDateCalculator::isFixedPeriodProduct($new_product_id)) {
            delete_post_meta($subscription_id, '_end_date');
            return;
        }

        $switch_date_utc = current_time('mysql', true);
        $end_date_utc    = EndDateCalculator::calculate($new_product_id, $switch_date_utc);

        if (empty($end_date_utc)) {
            return;
        }

        update_post_meta($subscription_id, '_end_date', $end_date_utc);
        update_post_meta($subscription_id, '_arraysubs_fixed_end_date_enabled', 'yes');
        update_post_meta($subscription_id, '_arraysubs_fixed_end_renewal', get_post_meta($new_product_id, '_arraysubs_fixed_end_renewal', true));
        update_post_meta($subscription_id, '_arraysubs_fixed_end_date_type', get_post_meta($new_product_id, '_arraysubs_fixed_end_date_type', true));
        update_post_meta($subscription_id, '_arraysubs_fixed_end_date', get_post_meta($new_product_id, '_arraysubs_fixed_end_date', true));

        $this->scheduleExpiration($subscription_id, $end_date_utc);
    }

    /**
     * Schedule the HOOK_EXPIRE_SUBSCRIPTION action for a subscription.
     *
     * @param int    $subscription_id Subscription ID.
     * @param string $end_date_utc    End date in UTC MySQL datetime format.
     * @return void
     */
    private function scheduleExpiration(int $subscription_id, string $end_date_utc): void
    {
        if (!class_exists(ActionScheduler::class)) {
            return;
        }

        // Unschedule any existing expiration first
        ActionScheduler::unscheduleAll(
            ActionScheduler::HOOK_EXPIRE_SUBSCRIPTION,
            [$subscription_id],
            ActionScheduler::GROUP_STATUS
        );

        $timestamp = strtotime($end_date_utc);

        if ($timestamp && $timestamp > time()) {
            ActionScheduler::scheduleSingle(
                ActionScheduler::HOOK_EXPIRE_SUBSCRIPTION,
                $timestamp,
                [$subscription_id],
                ActionScheduler::GROUP_STATUS
            );
        }
    }

    /**
     * Get formatted enrollment window text for frontend display.
     *
     * @param int $product_id Product or variation ID.
     * @return string
     */
    private function getEnrollmentWindowDisplay(int $product_id): string
    {
        $window_start = get_post_meta($product_id, '_arraysubs_enrollment_window_start', true);
        $window_end   = get_post_meta($product_id, '_arraysubs_enrollment_window_end', true);
        $date_format  = get_option('date_format');

        if (!empty($window_start) && !empty($window_end)) {
            return sprintf(
                /* translators: 1: enrollment start date, 2: enrollment end date */
                __('Enrollment window: %1$s – %2$s', 'arraysubspro'),
                arraysubs_format_site_local_date($window_start, $date_format),
                arraysubs_format_site_local_date($window_end, $date_format)
            );
        }

        if (!empty($window_start)) {
            return sprintf(
                /* translators: %s: enrollment start date */
                __('Enrollment opens: %s', 'arraysubspro'),
                arraysubs_format_site_local_date($window_start, $date_format)
            );
        }

        if (!empty($window_end)) {
            return sprintf(
                /* translators: %s: enrollment close date */
                __('Enrollment closes: %s', 'arraysubspro'),
                arraysubs_format_site_local_date($window_end, $date_format)
            );
        }

        return '';
    }

    /**
     * Get a compiled asset definition for the pro plugin.
     *
     * @param string $asset_name Asset path relative to the build directory, without the .asset.php suffix.
     * @return array{dependencies: array, version: string}
     */
    private function getAssetFile(string $asset_name): array
    {
        $asset_file = Config::get('proplugin.public_path') . 'build/' . $asset_name . '.asset.php';

        if (file_exists($asset_file)) {
            return require $asset_file;
        }

        return [
            'dependencies' => [],
            'version'      => ARRAYSUBSPRO_VERSION,
        ];
    }
}
