<?php

/**
 * RedirectProductPage Hooks
 *
 * Adds the "ArraySubs Redirect" tab to the WooCommerce product data
 * panel and handles saving / loading product redirect meta fields.
 *
 * @package ArraySubsPro\Features\RedirectProductPage\Services
 * @since 1.0.0
 */

namespace ArraySubsPro\Features\RedirectProductPage\Services;

defined('ABSPATH') || exit;

/**
 * WordPress hooks for product redirect functionality
 */
class Hooks
{
    /**
     * Enable auto-loading
     *
     * @var bool
     */
    public static $loadable = true;

    /**
     * Constructor
     */
    public function __construct()
    {
        // Product data tab and panel
        add_filter('woocommerce_product_data_tabs', [$this, 'addRedirectTab'], 40, 1);
        add_action('woocommerce_product_data_panels', [$this, 'addRedirectPanel']);

        // Save product meta
        add_action('woocommerce_process_product_meta', [$this, 'saveProductMeta'], 15, 1);

        // Admin assets for the product edit screen
        add_action('admin_enqueue_scripts', [$this, 'enqueueAdminAssets']);
    }

    /**
     * Add Redirect tab to product data tabs
     *
     * @param array $tabs Product data tabs.
     * @return array Modified tabs.
     */
    public function addRedirectTab(array $tabs): array
    {
        $tabs['arraysubs_redirect'] = [
            'label'    => __('ArraySubs Redirect', 'arraysubspro'),
            'target'   => 'arraysubs_redirect_product_data',
            'class'    => [],
            'priority' => 80,
        ];

        return $tabs;
    }

    /**
     * Render the Redirect panel content
     *
     * @return void
     */
    public function addRedirectPanel(): void
    {
        global $post;
        include dirname(__DIR__) . '/views/product-redirect-fields.php';
    }

    /**
     * Save redirect product meta
     *
     * @param int $post_id Product post ID.
     * @return void
     */
    public function saveProductMeta(int $post_id): void
    {
        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- nonce verified via sanitize_text_field
        if (
            !isset($_POST['woocommerce_meta_nonce'])
            || !wp_verify_nonce(
                sanitize_text_field(wp_unslash($_POST['woocommerce_meta_nonce'])),
                'woocommerce_save_data'
            )
        ) {
            return;
        }

        if (!current_user_can('edit_post', $post_id)) {
            return;
        }

        // Enable / disable toggle (checkbox)
        $enabled = isset($_POST['_arraysubs_product_redirect_enabled']) ? 'yes' : 'no';
        update_post_meta($post_id, '_arraysubs_product_redirect_enabled', $enabled);

        // Redirect action
        $valid_actions = ['redirect', '404'];
        $action = isset($_POST['_arraysubs_product_redirect_action'])
            ? sanitize_text_field(wp_unslash($_POST['_arraysubs_product_redirect_action']))
            : 'redirect';

        if (!in_array($action, $valid_actions, true)) {
            $action = 'redirect';
        }
        update_post_meta($post_id, '_arraysubs_product_redirect_action', $action);

        // Redirect target page
        $page_id = isset($_POST['_arraysubs_product_redirect_page'])
            ? absint(wp_unslash($_POST['_arraysubs_product_redirect_page']))
            : 0;

        // Validate the page exists and is published
        if ($page_id > 0) {
            $page = get_post($page_id);
            if (!$page || $page->post_type !== 'page' || $page->post_status !== 'publish') {
                $page_id = 0;
            }
        }
        update_post_meta($post_id, '_arraysubs_product_redirect_page', $page_id);

        clean_post_cache($post_id);

        if (function_exists('wc_delete_product_transients')) {
            wc_delete_product_transients($post_id);
        }

        /**
         * Fires after product redirect meta is saved.
         *
         * @param int    $post_id Product post ID.
         * @param string $enabled Whether redirect is enabled ('yes' or 'no').
         * @param string $action  The redirect action ('redirect' or '404').
         * @param int    $page_id The target page ID (0 if none).
         */
        do_action('arraysubspro_product_redirect_meta_saved', $post_id, $enabled, $action, $page_id);

        /**
         * Fires after redirect-related caches should be considered stale.
         *
         * Third-party caching plugins or CDNs can hook here to purge the
         * product URL or any derived cache entries.
         *
         * @param int    $post_id Product post ID.
         * @param string $enabled Whether redirect is enabled ('yes' or 'no').
         * @param string $action  The redirect action ('redirect' or '404').
         * @param int    $page_id The target page ID (0 if none).
         */
        do_action('arraysubspro_product_redirect_cache_invalidated', $post_id, $enabled, $action, $page_id);
    }

    /**
     * Enqueue admin assets for the product edit screen
     *
     * @return void
     */
    public function enqueueAdminAssets(): void
    {
        $screen = get_current_screen();
        if (!$screen || $screen->post_type !== 'product' || $screen->base !== 'post') {
            return;
        }

        // Tab icon CSS
        wp_add_inline_style(
            'woocommerce_admin_styles',
            '#woocommerce-product-data ul.wc-tabs li.arraysubs_redirect_tab a::before { font-family: dashicons; content: "\f504"; }'
        );

        // Field toggle JS
        $toggle_js = <<<'JS'
jQuery(function($){
    var $enabled   = $('#_arraysubs_product_redirect_enabled'),
        $action    = $('#_arraysubs_product_redirect_action'),
        $fields    = $('.arraysubs-redirect-conditional'),
        $pageField = $('.arraysubs-redirect-page-field'),
        $footnotes = $('.arraysubs-redirect-footnotes-group');

    function toggleRedirectFields(){
        var isEnabled = $enabled.is(':checked'),
            actionVal = $action.val();

        if(isEnabled){
            $fields.show();
            $footnotes.show();
            $pageField.toggle(actionVal === 'redirect');
        } else {
            $fields.hide();
            $footnotes.hide();
            $pageField.hide();
        }
    }

    toggleRedirectFields();
    $enabled.on('change', toggleRedirectFields);
    $action.on('change', toggleRedirectFields);
});
JS;

        wp_add_inline_script('jquery-core', $toggle_js, 'after');
    }
}
