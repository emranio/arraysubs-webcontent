<?php

/**
 * Product Redirector Service
 *
 * Handles the frontend redirect behaviour when a visitor lands on a
 * product page that has been configured to redirect or show 404.
 *
 * Also handles SEO-related filtering (sitemaps) and provides hooks
 * for third-party extensibility.
 *
 * @package ArraySubsPro\Features\RedirectProductPage\Services
 * @since 1.0.0
 */

namespace ArraySubsPro\Features\RedirectProductPage\Services;

defined('ABSPATH') || exit;

/**
 * ProductRedirector class
 */
class ProductRedirector
{
    /**
     * Enable auto-loading
     *
     * @var bool
     */
    public static $loadable = true;

    /**
     * Cached product IDs with 404 action (for sitemap filtering)
     *
     * @var int[]|null
     */
    private ?array $fourOhFourProductIds = null;

    /**
     * Constructor
     */
    public function __construct()
    {
        // Redirect at priority 5, before MembersAccess EcommerceRestriction (priority 10)
        add_action('template_redirect', [$this, 'maybeRedirect'], 5);

        // WordPress core sitemap filtering
        add_filter('wp_sitemaps_posts_query_args', [$this, 'filterSitemapQueryArgs'], 10, 2);

        // Yoast SEO sitemap compatibility
        add_filter('wpseo_exclude_from_sitemap_by_post_ids', [$this, 'filterYoastSitemapExclusions']);

        // Rank Math sitemap compatibility
        add_filter('rank_math/sitemap/entry', [$this, 'filterRankMathSitemapEntry'], 10, 3);

        // Robots meta for products with redirect (noindex)
        add_filter('wp_robots', [$this, 'filterRobotsForRedirectedProducts'], 10, 1);
    }

    /**
     * Maybe redirect the product page based on per-product meta
     *
     * @return void
     */
    public function maybeRedirect(): void
    {
        // Only act on frontend single product pages
        if (is_admin() || wp_doing_ajax() || wp_doing_cron()) {
            return;
        }

        // Skip REST API requests
        if (defined('REST_REQUEST') && REST_REQUEST) {
            return;
        }

        if (!is_singular('product')) {
            return;
        }

        // Allow add-to-cart requests to pass through
        if ($this->isAddToCartRequest()) {
            return;
        }

        global $post;
        $product_id = $post->ID ?? 0;

        if (!$product_id) {
            return;
        }

        // Check if redirect is enabled for this product
        if (!$this->isRedirectEnabled($product_id)) {
            return;
        }

        /**
         * Filter whether the product redirect should execute.
         *
         * Return false to skip the redirect for this request.
         *
         * @param bool $should_redirect Whether to redirect (default: true).
         * @param int  $product_id      Product ID.
         */
        if (!apply_filters('arraysubspro_product_redirect_should_redirect', true, $product_id)) {
            return;
        }

        /**
         * Filter capabilities that bypass the product redirect.
         *
         * By default, no capabilities are skipped. Return an array of
         * capabilities (e.g. ['manage_options']) to let certain users
         * view the product page without being redirected.
         *
         * @param string[] $capabilities Array of capability strings.
         * @param int      $product_id   Product ID.
         */
        $skip_capabilities = apply_filters('arraysubspro_product_redirect_skip_capabilities', [], $product_id);

        if (!empty($skip_capabilities) && is_array($skip_capabilities)) {
            foreach ($skip_capabilities as $cap) {
                if (current_user_can($cap)) {
                    return;
                }
            }
        }

        $action = $this->getRedirectAction($product_id);

        /**
         * Fires before the product redirect or 404 is applied.
         *
         * @param int    $product_id Product ID.
         * @param string $action     The action being performed ('redirect' or '404').
         */
        do_action('arraysubspro_before_product_redirect', $product_id, $action);

        switch ($action) {
            case 'redirect':
                $this->performRedirect($product_id);
                break;

            case '404':
                $this->perform404();
                break;
        }
    }

    /**
     * Check if redirect is enabled for a product
     *
     * @param int $product_id Product ID.
     * @return bool
     */
    public function isRedirectEnabled(int $product_id): bool
    {
        $enabled = get_post_meta($product_id, '_arraysubs_product_redirect_enabled', true) === 'yes';

        /**
         * Filter whether product redirect is enabled for a specific product.
         *
         * @param bool $enabled    Whether redirect is enabled.
         * @param int  $product_id Product ID.
         */
        return (bool) apply_filters('arraysubspro_product_redirect_enabled', $enabled, $product_id);
    }

    /**
     * Get the redirect action for a product
     *
     * @param int $product_id Product ID.
     * @return string 'redirect' or '404'
     */
    public function getRedirectAction(int $product_id): string
    {
        $action = get_post_meta($product_id, '_arraysubs_product_redirect_action', true);

        if (!in_array($action, ['redirect', '404'], true)) {
            $action = 'redirect';
        }

        /**
         * Filter the redirect action for a specific product.
         *
         * @param string $action     The redirect action ('redirect' or '404').
         * @param int    $product_id Product ID.
         */
        return apply_filters('arraysubspro_product_redirect_action', $action, $product_id);
    }

    /**
     * Get the redirect target URL for a product
     *
     * @param int $product_id Product ID.
     * @return string Target URL or empty string.
     */
    public function getRedirectTargetUrl(int $product_id): string
    {
        $page_id = absint(get_post_meta($product_id, '_arraysubs_product_redirect_page', true));
        $url = '';

        if ($page_id > 0) {
            $permalink = get_permalink($page_id);
            if ($permalink) {
                $url = $permalink;
            }
        }

        /**
         * Filter the product redirect target URL.
         *
         * @param string $url        The redirect target URL.
         * @param int    $product_id Product ID.
         * @param int    $page_id    The configured page ID (may be 0).
         */
        return apply_filters('arraysubspro_product_redirect_url', $url, $product_id, $page_id);
    }

    /**
     * Perform a 301 redirect to the target page
     *
     * @param int $product_id Product ID.
     * @return void
     */
    private function performRedirect(int $product_id): void
    {
        $url = $this->getRedirectTargetUrl($product_id);

        if (empty($url)) {
            // No valid target — fall back to shop page or home
            $shop_page_url = wc_get_page_permalink('shop');
            $url = $shop_page_url ?: home_url('/');
        }

        // Prevent redirect loops: don't redirect to the same product page
        $product_url = get_permalink($product_id);
        if ($product_url && untrailingslashit($url) === untrailingslashit($product_url)) {
            return;
        }

        wp_safe_redirect(esc_url_raw($url), 301);
        exit;
    }

    /**
     * Return a 404 response
     *
     * @return void
     */
    private function perform404(): void
    {
        global $wp_query;
        $wp_query->set_404();
        status_header(404);
        nocache_headers();
        include get_404_template();
        exit;
    }

    /**
     * Check if the current request is an add-to-cart action
     *
     * @return bool
     */
    private function isAddToCartRequest(): bool
    {
        // Standard WooCommerce add-to-cart via URL parameter (filter_input avoids direct superglobal access)
        if (filter_input(INPUT_GET, 'add-to-cart', FILTER_SANITIZE_NUMBER_INT)) {
            return true;
        }

        if (filter_input(INPUT_POST, 'add-to-cart', FILTER_SANITIZE_NUMBER_INT)) {
            return true;
        }

        // WooCommerce AJAX add-to-cart
        if (filter_input(INPUT_GET, 'wc-ajax', FILTER_SANITIZE_FULL_SPECIAL_CHARS) === 'add_to_cart') {
            return true;
        }

        return false;
    }

    // ─────────────────────────────────────────────────────────
    // Sitemap Integration
    // ─────────────────────────────────────────────────────────

    /**
     * Exclude products with 404 action from WordPress core sitemaps
     *
     * @param array  $args      WP_Query arguments for the sitemap.
     * @param string $post_type The post type.
     * @return array Modified arguments.
     */
    public function filterSitemapQueryArgs(array $args, string $post_type): array
    {
        if ($post_type !== 'product') {
            return $args;
        }

        $excluded_ids = $this->get404ProductIds();

        if (!empty($excluded_ids)) {
            $existing_exclude = $args['post__not_in'] ?? [];
            $args['post__not_in'] = array_merge($existing_exclude, $excluded_ids);
        }

        return $args;
    }

    /**
     * Exclude products with 404 action from Yoast SEO sitemaps
     *
     * @param int[] $excluded_ids Already excluded post IDs.
     * @return int[] Modified excluded IDs.
     */
    public function filterYoastSitemapExclusions($excluded_ids): array
    {
        if (!is_array($excluded_ids)) {
            $excluded_ids = [];
        }

        return array_merge($excluded_ids, $this->get404ProductIds());
    }

    /**
     * Exclude products with 404 action from Rank Math sitemaps
     *
     * @param object   $url  Sitemap entry object.
     * @param string   $type Sitemap type.
     * @param \WP_Post $post Post object.
     * @return object|false Return false to exclude.
     */
    public function filterRankMathSitemapEntry($url, $type, $post)
    {
        if ($type !== 'post' || !isset($post->ID)) {
            return $url;
        }

        if (get_post_type($post->ID) !== 'product') {
            return $url;
        }

        if (in_array($post->ID, $this->get404ProductIds(), true)) {
            return false;
        }

        return $url;
    }

    /**
     * Add noindex meta for products configured with redirect
     *
     * Products with 404 action should not be indexed. Products with
     * redirect action are already handled by the 301 redirect itself.
     *
     * @param array $robots Robots meta directives.
     * @return array Modified directives.
     */
    public function filterRobotsForRedirectedProducts(array $robots): array
    {
        if (!is_singular('product')) {
            return $robots;
        }

        global $post;
        if (!$post) {
            return $robots;
        }

        // Only add noindex for 404 action — 301 redirects handle SEO transfer themselves
        if (
            $this->isRedirectEnabled($post->ID)
            && $this->getRedirectAction($post->ID) === '404'
        ) {
            $robots['noindex'] = true;
            $robots['nofollow'] = true;
        }

        return $robots;
    }

    /**
     * Get all product IDs configured with 404 redirect action
     *
     * Results are cached per request.
     *
     * @return int[]
     */
    private function get404ProductIds(): array
    {
        if ($this->fourOhFourProductIds !== null) {
            return $this->fourOhFourProductIds;
        }

        $this->fourOhFourProductIds = get_posts([
            'post_type'   => 'product',
            'post_status' => 'publish',
            'fields'      => 'ids',
            'numberposts' => -1,
            'meta_query'  => [ // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- necessary for sitemap filtering
                'relation' => 'AND',
                [
                    'key'   => '_arraysubs_product_redirect_enabled',
                    'value' => 'yes',
                ],
                [
                    'key'   => '_arraysubs_product_redirect_action',
                    'value' => '404',
                ],
            ],
        ]);

        return $this->fourOhFourProductIds;
    }
}
