<?php

/**
 * WooCommerce Store API Integration
 *
 * Exposes product redirect data via the WooCommerce Store API so
 * headless frontends, WooCommerce Blocks, and third-party clients
 * can handle redirect behaviour client-side.
 *
 * @package ArraySubsPro\Features\RedirectProductPage\Services
 * @since 1.0.0
 */

namespace ArraySubsPro\Features\RedirectProductPage\Services;

defined('ABSPATH') || exit;

use Automattic\WooCommerce\StoreApi\Schemas\V1\ProductSchema;

/**
 * StoreApiIntegration class
 */
class StoreApiIntegration
{
    /**
     * Enable auto-loading
     *
     * @var bool
     */
    public static $loadable = true;

    /**
     * Constructor
     */
    public function __construct()
    {
        // Register Store API extension data on REST API init
        add_action('rest_api_init', [$this, 'registerProductData']);

        // Extend WooCommerce REST API product responses (v3/standard API)
        add_filter('woocommerce_rest_prepare_product_object', [$this, 'extendRestProductResponse'], 20, 3);
    }

    /**
     * Register Store API product extension data for Blocks and headless clients
     *
     * @return void
     */
    public function registerProductData(): void
    {
        if (!function_exists('woocommerce_store_api_register_endpoint_data')) {
            return;
        }

        if (!class_exists(ProductSchema::class)) {
            return;
        }

        woocommerce_store_api_register_endpoint_data(
            [
                'endpoint'        => ProductSchema::IDENTIFIER,
                'namespace'       => 'arraysubs_redirect',
                'schema_callback' => [$this, 'getProductSchema'],
                'data_callback'   => [$this, 'getProductData'],
                'schema_type'     => ARRAY_A,
            ]
        );
    }

    /**
     * Schema for the Store API product extension
     *
     * @return array
     */
    public function getProductSchema(): array
    {
        return [
            'redirect_enabled' => [
                'description' => __('Whether the product page has redirect enabled.', 'arraysubspro'),
                'type'        => 'boolean',
                'readonly'    => true,
                'context'     => ['view'],
            ],
            'redirect_action' => [
                'description' => __('The redirect action configured for this product.', 'arraysubspro'),
                'type'        => 'string',
                'enum'        => ['', 'redirect', '404'],
                'readonly'    => true,
                'context'     => ['view'],
            ],
            'redirect_url' => [
                'description' => __('The redirect target URL when action is redirect.', 'arraysubspro'),
                'type'        => 'string',
                'format'      => 'uri',
                'readonly'    => true,
                'context'     => ['view'],
            ],
        ];
    }

    /**
     * Data callback for the Store API product extension
     *
     * @param \WC_Product $product Product object.
     * @return array
     */
    public function getProductData($product): array
    {
        if (!$product instanceof \WC_Product) {
            return $this->getEmptyData();
        }

        $product_id = $product->get_id();
        $enabled = get_post_meta($product_id, '_arraysubs_product_redirect_enabled', true) === 'yes';

        if (!$enabled) {
            return $this->getEmptyData();
        }

        $action = get_post_meta($product_id, '_arraysubs_product_redirect_action', true);
        if (!in_array($action, ['redirect', '404'], true)) {
            $action = 'redirect';
        }

        $redirect_url = '';
        if ($action === 'redirect') {
            $page_id = absint(get_post_meta($product_id, '_arraysubs_product_redirect_page', true));
            if ($page_id > 0) {
                $permalink = get_permalink($page_id);
                if ($permalink) {
                    $redirect_url = $permalink;
                }
            }
        }

        return [
            'redirect_enabled' => true,
            'redirect_action'  => $action,
            'redirect_url'     => $redirect_url,
        ];
    }

    /**
     * Extend WooCommerce REST API (v3) product responses
     *
     * @param \WP_REST_Response $response Response object.
     * @param \WC_Product       $product  Product object.
     * @param \WP_REST_Request  $request  Request object.
     * @return \WP_REST_Response
     */
    public function extendRestProductResponse($response, $product, $request): \WP_REST_Response
    {
        if (!$product instanceof \WC_Product) {
            return $response;
        }

        $data = $response->get_data();
        $product_id = $product->get_id();

        $enabled = get_post_meta($product_id, '_arraysubs_product_redirect_enabled', true) === 'yes';

        $data['arraysubs_redirect'] = [
            'enabled' => $enabled,
            'action'  => $enabled ? (get_post_meta($product_id, '_arraysubs_product_redirect_action', true) ?: 'redirect') : '',
            'page_id' => $enabled ? absint(get_post_meta($product_id, '_arraysubs_product_redirect_page', true)) : 0,
        ];

        $response->set_data($data);

        return $response;
    }

    /**
     * Return empty data structure
     *
     * @return array
     */
    private function getEmptyData(): array
    {
        return [
            'redirect_enabled' => false,
            'redirect_action'  => '',
            'redirect_url'     => '',
        ];
    }
}
