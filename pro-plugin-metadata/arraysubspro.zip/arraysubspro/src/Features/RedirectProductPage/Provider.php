<?php

/**
 * RedirectProductPage Provider
 *
 * Entry point for the Redirect Product Page feature.
 * Allows merchants to redirect product pages to custom pages or return 404.
 *
 * @package ArraySubsPro\Features\RedirectProductPage
 * @since 1.0.0
 */

namespace ArraySubsPro\Features\RedirectProductPage;

defined('ABSPATH') || exit;

use ArraySubs\Supports\Abstracts\AbstractLoader;

/**
 * RedirectProductPage Feature entry point
 */
class Provider extends AbstractLoader
{
    /**
     * Constructor - Load feature classes
     */
    public function __construct()
    {
        $this->classLoader([
            plugin_dir_path(__FILE__) . 'Services',
        ]);
    }
}
