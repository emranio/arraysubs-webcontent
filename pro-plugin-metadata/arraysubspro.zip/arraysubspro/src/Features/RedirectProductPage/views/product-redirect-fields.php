<?php

/**
 * Product Redirect Fields
 *
 * Renders the "ArraySubs Redirect" product data panel fields.
 *
 * @package ArraySubsPro\Features\RedirectProductPage
 * @var \WP_Post $post Current product post object.
 */

defined('ABSPATH') || exit;

$arraysubs_rp_post_id = $post->ID ?? 0;
$arraysubs_rp_enabled = get_post_meta($arraysubs_rp_post_id, '_arraysubs_product_redirect_enabled', true);
$arraysubs_rp_action  = get_post_meta($arraysubs_rp_post_id, '_arraysubs_product_redirect_action', true) ?: 'redirect';
$arraysubs_rp_page_id = absint(get_post_meta($arraysubs_rp_post_id, '_arraysubs_product_redirect_page', true));
$arraysubs_rp_page    = $arraysubs_rp_page_id > 0 ? get_post($arraysubs_rp_page_id) : null;

$arraysubs_rp_is_enabled = $arraysubs_rp_enabled === 'yes';
?>

<div id="arraysubs_redirect_product_data" class="panel woocommerce_options_panel">

    <div class="options_group">
        <p class="form-field arraysubs-redirect-intro">
            <span class="description" style="margin-left: 0;">
                <?php esc_html_e('Control what happens when a visitor accesses this product\'s page directly. The product remains purchasable via add-to-cart links and will continue to appear in admin and REST API responses.', 'arraysubspro'); ?>
            </span>
        </p>

        <?php
        woocommerce_wp_checkbox(
            [
                'id'          => '_arraysubs_product_redirect_enabled',
                'label'       => __('Enable redirect', 'arraysubspro'),
                'description' => __('Activate page-level redirect for this product.', 'arraysubspro'),
                'value'       => $arraysubs_rp_enabled,
            ]
        );
        ?>
    </div>

    <div class="options_group arraysubs-redirect-conditional" style="<?php echo ! $arraysubs_rp_is_enabled ? 'display:none;' : ''; ?>">
        <?php
        woocommerce_wp_select(
            [
                'id'          => '_arraysubs_product_redirect_action',
                'label'       => __('Redirect action', 'arraysubspro'),
                'description' => __('Choose what happens when a visitor navigates to this product page.', 'arraysubspro'),
                'desc_tip'    => true,
                'options'     => [
                    'redirect' => __('301 Redirect to a page', 'arraysubspro'),
                    '404'      => __('Show 404 (page not found)', 'arraysubspro'),
                ],
                'value'       => $arraysubs_rp_action,
            ]
        );
        ?>

        <p class="form-field _arraysubs_product_redirect_page_field arraysubs-redirect-page-field" style="<?php echo (! $arraysubs_rp_is_enabled || $arraysubs_rp_action !== 'redirect') ? 'display:none;' : ''; ?>">
            <label for="_arraysubs_product_redirect_page"><?php esc_html_e('Redirect to page', 'arraysubspro'); ?></label>
            <?php
            $arraysubs_rp_page_label = '';

            if ($arraysubs_rp_page instanceof \WP_Post) {
                $arraysubs_rp_page_label = sprintf(
                    /* translators: 1: page title, 2: page ID */
                    __('%1$s (ID: %2$s)', 'arraysubspro'),
                    $arraysubs_rp_page->post_title,
                    $arraysubs_rp_page_id
                );
            }
            ?>
            <select
                name="_arraysubs_product_redirect_page"
                id="_arraysubs_product_redirect_page"
                class="wc-page-search"
                style="width: 50%;"
                data-placeholder="<?php esc_attr_e('Search for a page…', 'arraysubspro'); ?>"
                data-allow_clear="true"
                data-limit="5"
                data-post_status="publish"
                data-minimum_input_length="1">
                <option value=""></option>
                <?php if (!empty($arraysubs_rp_page_label)) : ?>
                    <option value="<?php echo esc_attr($arraysubs_rp_page_id); ?>" selected="selected">
                        <?php echo esc_html($arraysubs_rp_page_label); ?>
                    </option>
                <?php endif; ?>
            </select>
            <?php /* translators: tooltip text */ ?>
            <span class="woocommerce-help-tip" tabindex="0" aria-label="<?php esc_attr_e('Select the WordPress page visitors will be sent to. A 301 (permanent) redirect tells search engines to transfer ranking authority to the target page.', 'arraysubspro'); ?>" data-tip="<?php esc_attr_e('Select the WordPress page visitors will be sent to. A 301 (permanent) redirect tells search engines to transfer ranking authority to the target page.', 'arraysubspro'); ?>"></span>
        </p>
    </div>

    <div class="options_group arraysubs-redirect-footnotes-group" style="<?php echo ! $arraysubs_rp_is_enabled ? 'display:none;' : ''; ?>">
        <p class="form-field" style="padding-top: 0;">
            <label style="visibility: hidden;">&nbsp;</label>
            <span class="description" style="display: block;">
                <strong><?php esc_html_e('How it works', 'arraysubspro'); ?></strong>
            </span>
        </p>
        <div class="form-field" style="margin-left: 162px; margin-top: -10px; margin-bottom: 15px; font-size: 12px; color: #646970; line-height: 1.6;">
            <ul style="list-style: disc; margin: 4px 0 0 16px;">
                <li>
                    <?php esc_html_e('The redirect fires only for the product page itself. Direct add-to-cart links (?add-to-cart=ID), the REST API, and all backend operations continue to work normally.', 'arraysubspro'); ?>
                </li>
                <li>
                    <?php esc_html_e('Variable products: the redirect applies to the parent product page. Individual variations don\'t have their own pages, so no extra handling is needed.', 'arraysubspro'); ?>
                </li>
                <li>
                    <?php esc_html_e('Catalog visibility is a separate WooCommerce setting. To also hide this product from shop listings and search results, change its Catalog Visibility under the Publish panel.', 'arraysubspro'); ?>
                </li>
                <li>
                    <?php
                    printf(
                        /* translators: %s opening and closing <strong> tags */
                        esc_html__('Products set to %1$s301 Redirect%2$s transfer SEO authority to the target page. Products set to %1$s404%2$s are automatically excluded from XML sitemaps.', 'arraysubspro'),
                        '<strong>',
                        '</strong>'
                    );
                    ?>
                </li>
                <li>
                    <?php esc_html_e('If your site uses full-page caching (e.g. a caching plugin or CDN), clear the product URL cache after saving these changes so the new behaviour takes effect immediately.', 'arraysubspro'); ?>
                </li>
            </ul>
        </div>
    </div>

</div>