/**
 * Store Credit Refund Integration
 *
 * Handles the "Refund as Store Credit" UI on WooCommerce order edit pages.
 *
 * @package ArraySubsPro
 */

/* global jQuery, arraysubs_refund */
jQuery(function ($) {
  "use strict";

  var arraysubs_refund_data = window.arraysubs_refund || {};
  var currentBalance = parseFloat(arraysubs_refund_data.current_balance) || 0;
  var refundedAsCredit =
    parseFloat(arraysubs_refund_data.refunded_as_credit) || 0;
  var remainingRefundable =
    parseFloat(arraysubs_refund_data.refundable_amount) || 0;

  /**
   * Move the refund method selector from its PHP output position
   * (near action buttons) into the WC refund form area.
   */
  function moveRefundMethodToForm() {
    var $el = $("#arraysubspro-refund-method");
    if (!$el.length) return;

    var $refundActions = $(".wc-order-refund-items .refund-actions");
    if (!$refundActions.length) return;

    // Only move if not already inside the refund section
    if (!$el.closest(".wc-order-refund-items").length) {
      $el.detach().insertBefore($refundActions).show();
    }
  }

  // Move on page load
  moveRefundMethodToForm();

  // Re-move after WC reloads order items via AJAX
  $(document).ajaxComplete(function () {
    setTimeout(moveRefundMethodToForm, 150);
  });

  // Toggle credit info visibility
  $(document).on(
    "change",
    'input[name="arraysubs_refund_method"]',
    function () {
      if ($(this).val() === "store_credit") {
        $("#arraysubspro-credit-info").slideDown();
        updateBalanceAfter();
      } else {
        $("#arraysubspro-credit-info").slideUp();
      }
    },
  );

  // Update balance after when refund amount changes
  $(document).on("input change", "#refund_amount", function () {
    if (
      $('input[name="arraysubs_refund_method"]:checked').val() ===
      "store_credit"
    ) {
      updateBalanceAfter();
    }
    updateRefundButtonLabel();
  });

  function updateBalanceAfter() {
    var refundAmount = parseFloat($("#refund_amount").val()) || 0;
    var newBalance = currentBalance + refundAmount;
    $("#arraysubspro-balance-after").html(
      arraysubs_refund_data.balance_after_label +
        ": " +
        arraysubs_refund_data.currency_symbol +
        " " +
        newBalance.toFixed(2),
    );
  }

  function formatRefundAmount(refundAmount) {
    return (
      arraysubs_refund_data.currency_symbol + " " + refundAmount.toFixed(2)
    );
  }

  function escapeHtml(value) {
    return $("<div>").text(value === undefined || value === null ? "" : value).html();
  }

  function showAdminNotice(message, type) {
    var noticeType = type === "success" ? "success" : "error";
    var $notice = $(
      '<div class="notice notice-' +
        noticeType +
        ' is-dismissible arraysubspro-refund-admin-notice" role="alert"><p></p><button type="button" class="notice-dismiss"><span class="screen-reader-text">Dismiss this notice.</span></button></div>',
    );

    $notice.find("p").text(message);
    $notice.on("click", ".notice-dismiss", function () {
      $notice.remove();
    });

    $(".arraysubspro-refund-admin-notice").remove();

    var $headerEnd = $(".wrap .wp-header-end").first();
    if ($headerEnd.length) {
      $headerEnd.after($notice);
    } else if ($(".wrap").length) {
      $(".wrap").first().prepend($notice);
    } else {
      $("body").prepend($notice);
    }

    $("html, body").animate({ scrollTop: 0 }, 150);
  }

  function isStandardRefundBlocked() {
    return refundedAsCredit > 0 && remainingRefundable <= 0;
  }

  function blockStandardRefundControls() {
    if (!isStandardRefundBlocked()) {
      return;
    }

    var $buttons = $(".do-api-refund, .do-manual-refund");
    $buttons.prop("disabled", true).addClass("disabled").attr("aria-disabled", "true");

    var $refundActions = $(".wc-order-refund-items .refund-actions");
    if (
      $refundActions.length &&
      !$refundActions.find(".arraysubspro-credit-refund-blocked").length
    ) {
      $refundActions.prepend(
        '<p class="description arraysubspro-credit-refund-blocked"></p>',
      );
      $refundActions
        .find(".arraysubspro-credit-refund-blocked")
        .text(arraysubs_refund_data.standard_refund_blocked_message);
    }
  }

  function storeOriginalButtonLabels() {
    $(".do-api-refund, .do-manual-refund").each(function () {
      var $button = $(this);
      if ($button.data("arraysubs-original-label") !== undefined) {
        return;
      }

      $button.data(
        "arraysubs-original-label",
        $button.is("input") ? $button.val() : $button.text(),
      );
    });
  }

  function setButtonText($button, text) {
    if ($button.is("input")) {
      $button.val(text);
      return;
    }

    $button.text(text);
  }

  function setButtonLoading($button, loading, loadingText) {
    if (loading) {
      $button.data(
        "arraysubs-loading-label",
        $button.is("input") ? $button.val() : $button.html(),
      );
      $button
        .prop("disabled", true)
        .addClass("disabled arraysubspro-refund-button--loading");

      if ($button.is("input")) {
        $button.val(loadingText);
      } else {
        $button.html(
          '<span class="spinner is-active arraysubspro-refund-button__spinner" aria-hidden="true"></span><span>' +
            escapeHtml(loadingText) +
            "</span>",
        );
      }
      return;
    }

    var original = $button.data("arraysubs-loading-label");
    $button
      .prop("disabled", false)
      .removeClass("disabled arraysubspro-refund-button--loading");

    if (original !== undefined) {
      if ($button.is("input")) {
        $button.val(original);
      } else {
        $button.html(original);
      }
      $button.removeData("arraysubs-loading-label");
    }

    updateRefundButtonLabel();
  }

  function updateRefundButtonLabel() {
    storeOriginalButtonLabels();

    var selectedMethod = $(
      'input[name="arraysubs_refund_method"]:checked',
    ).val();
    var refundAmount = parseFloat($("#refund_amount").val()) || 0;
    var $buttons = $(".do-api-refund, .do-manual-refund");

    $buttons.each(function () {
      var $button = $(this);
      if ($button.hasClass("arraysubspro-refund-button--loading")) {
        return;
      }

      if (selectedMethod === "store_credit") {
        var label = arraysubs_refund_data.refund_as_credit_label;
        if (refundAmount > 0) {
          label = arraysubs_refund_data.refund_as_credit_amount_label.replace(
            "%s",
            formatRefundAmount(refundAmount),
          );
        }
        setButtonText($button, label);
        return;
      }

      var original = $button.data("arraysubs-original-label");
      if (original !== undefined) {
        setButtonText($button, original);
      }
    });
  }

  function openConfirmDialog(refundAmount) {
    var deferred = $.Deferred();
    var amount = formatRefundAmount(refundAmount);
    var message = arraysubs_refund_data.confirm_message.replace("%s", amount);
    var previousFocus = document.activeElement;
    var $modal = $(
      '<div class="arraysubspro-refund-modal" role="dialog" aria-modal="true" aria-labelledby="arraysubspro-refund-modal-title">' +
        '<div class="arraysubspro-refund-modal__backdrop"></div>' +
        '<div class="arraysubspro-refund-modal__panel">' +
        '<h2 id="arraysubspro-refund-modal-title" class="arraysubspro-refund-modal__title"></h2>' +
        '<p class="arraysubspro-refund-modal__message"></p>' +
        '<div class="arraysubspro-refund-modal__actions">' +
        '<button type="button" class="button arraysubspro-refund-modal__cancel"></button>' +
        '<button type="button" class="button button-primary arraysubspro-refund-modal__confirm"></button>' +
        "</div>" +
        "</div>" +
        "</div>",
    );

    $modal.find(".arraysubspro-refund-modal__title").text(
      arraysubs_refund_data.confirm_title,
    );
    $modal.find(".arraysubspro-refund-modal__message").text(message);
    $modal.find(".arraysubspro-refund-modal__cancel").text(
      arraysubs_refund_data.cancel_label,
    );
    $modal.find(".arraysubspro-refund-modal__confirm").text(
      arraysubs_refund_data.confirm_label,
    );

    function close(resolve) {
      $(document).off("keydown.arraysubsRefundModal");
      $modal.remove();
      $("body").removeClass("arraysubspro-refund-modal-open");
      if (previousFocus && previousFocus.focus) {
        previousFocus.focus();
      }

      if (resolve) {
        deferred.resolve();
      } else {
        deferred.reject();
      }
    }

    $modal.on(
      "click",
      ".arraysubspro-refund-modal__cancel, .arraysubspro-refund-modal__backdrop",
      function () {
        close(false);
      },
    );
    $modal.on("click", ".arraysubspro-refund-modal__confirm", function () {
      close(true);
    });
    $(document).on("keydown.arraysubsRefundModal", function (event) {
      if (event.key === "Escape") {
        close(false);
      }
    });

    $("body").append($modal).addClass("arraysubspro-refund-modal-open");
    setTimeout(function () {
      $modal.find(".arraysubspro-refund-modal__confirm").trigger("focus");
    }, 0);

    return deferred.promise();
  }

  function processStoreCreditRefund($button, refundAmount, refundReason) {
    var shouldReload = false;

    setButtonLoading(
      $button,
      true,
      arraysubs_refund_data.loading_label || "Refunding...",
    );

    $.ajax({
      url: arraysubs_refund_data.ajax_url,
      type: "POST",
      data: {
        action: "arraysubs_refund_as_credit",
        security: arraysubs_refund_data.nonce,
        order_id: arraysubs_refund_data.order_id,
        refund_amount: refundAmount,
        refund_reason: refundReason,
      },
      success: function (response) {
        if (response.success) {
          currentBalance = parseFloat(response.data.new_balance);
          showAdminNotice(arraysubs_refund_data.success_message, "success");
          shouldReload = true;
          setTimeout(function () {
            location.reload();
          }, 600);
          return;
        }

        showAdminNotice(
          (response.data && response.data.error) ||
            arraysubs_refund_data.error_generic,
          "error",
        );
      },
      error: function () {
        showAdminNotice(arraysubs_refund_data.error_generic, "error");
      },
      complete: function () {
        if (!shouldReload) {
          setButtonLoading($button, false);
        }
      },
    });
  }

  $(document).on("change", 'input[name="arraysubs_refund_method"]', function () {
    updateRefundButtonLabel();
  });

  $(document).ajaxComplete(function () {
    setTimeout(function () {
      updateRefundButtonLabel();
      blockStandardRefundControls();
    }, 150);
  });

  function handleStoreCreditRefundClick(button, event) {
    if (isStandardRefundBlocked()) {
      event.preventDefault();
      event.stopPropagation();
      if (event.stopImmediatePropagation) {
        event.stopImmediatePropagation();
      }
      showAdminNotice(
        arraysubs_refund_data.standard_refund_blocked_message,
        "error",
      );
      return true;
    }

    var selectedMethod = $(
      'input[name="arraysubs_refund_method"]:checked',
    ).val();
    if (selectedMethod !== "store_credit") {
      return false; // Let WooCommerce handle normal refund
    }

    event.preventDefault();
    event.stopPropagation();
    if (event.stopImmediatePropagation) {
      event.stopImmediatePropagation();
    }

    var $button = $(button);
    var refundAmount = parseFloat($("#refund_amount").val()) || 0;
    var refundReason = $("#refund_reason").val() || "";

    if (refundAmount <= 0) {
      showAdminNotice(arraysubs_refund_data.error_amount, "error");
      $("#refund_amount").trigger("focus");
      return;
    }

    openConfirmDialog(refundAmount).done(function () {
      processStoreCreditRefund($button, refundAmount, refundReason);
    });

    return true;
  }

  // Intercept before WooCommerce's native refund handler can open confirm().
  document.addEventListener(
    "click",
    function (event) {
      var button = event.target.closest(".do-api-refund, .do-manual-refund");
      if (!button) {
        return;
      }

      handleStoreCreditRefundClick(button, event);
    },
    true,
  );

  // Keep a jQuery fallback for synthetic click events.
  $(document).on("click", ".do-api-refund, .do-manual-refund", function (e) {
    handleStoreCreditRefundClick(this, e);
  });

  blockStandardRefundControls();
});
