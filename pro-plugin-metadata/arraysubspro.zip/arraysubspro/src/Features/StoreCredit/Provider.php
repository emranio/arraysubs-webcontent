<?php

/**
 * Store Credit Provider
 *
 * Entry point for the Store Credit feature.
 * Provides a comprehensive store credit system for customers.
 *
 * @package ArraySubsPro\Features\StoreCredit
 * @since 1.0.0
 */

namespace ArraySubsPro\Features\StoreCredit;

defined('ABSPATH') || exit;

use ArraySubs\Supports\Abstracts\AbstractLoader;

/**
 * Store Credit Feature entry point
 */
class Provider extends AbstractLoader
{
    /**
     * Constructor
     */
    public function __construct()
    {
        $this->classLoader([
            plugin_dir_path(__FILE__) . 'Services',
            plugin_dir_path(__FILE__) . 'REST',
        ]);
    }
}
