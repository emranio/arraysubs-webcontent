<?php

/**
 * Credit Expiration Service
 *
 * Handles expiration tracking and cleanup for store credits.
 * Credits can be configured to expire after a certain number of days.
 *
 * @package ArraySubsPro\Features\StoreCredit\Services
 * @since 1.0.0
 */

namespace ArraySubsPro\Features\StoreCredit\Services;

defined('ABSPATH') || exit;

use ArraySubs\Supports\ActionScheduler;

/**
 * Credit Expiration class
 */
class CreditExpiration
{
    /**
     * Enable auto-loading
     *
     * @var bool
     */
    public static $loadable = true;

    /**
     * Days before expiration to send warning email
     */
    const DAYS_BEFORE_EXPIRY_WARNING = 7;

    /**
     * Constructor
     */
    public function __construct()
    {
        // Schedule recurring expiration job
        add_action('init', [$this, 'scheduleExpirationJob']);

        // Handle expiration batch job
        add_action(ActionScheduler::HOOK_EXPIRE_STORE_CREDITS, [$this, 'processExpiredCredits']);

        // Handle credit expiring soon notification
        add_action(ActionScheduler::HOOK_SEND_CREDIT_EXPIRING, [$this, 'sendExpiringNotification'], 10, 2);

        // When credit is added, schedule expiration if needed
        add_action('arraysubs_customer_credit_added', [$this, 'onCreditAdded'], 10, 4);
        add_action('arraysubs_subscription_credit_added', [$this, 'onSubscriptionCreditAdded'], 10, 4);
    }

    /**
     * Schedule recurring expiration check job
     */
    public function scheduleExpirationJob(): void
    {
        if (!ActionScheduler::isAvailable()) {
            return;
        }

        // Skip if disabled
        $expiration_days = absint(arraysubs_get_setting('store_credit.expiration_days', 0));
        if ($expiration_days <= 0) {
            return;
        }

        // Schedule daily at 3am if not already scheduled
        ActionScheduler::scheduleRecurring(
            ActionScheduler::HOOK_EXPIRE_STORE_CREDITS,
            strtotime('tomorrow 3am'),
            DAY_IN_SECONDS,
            [],
            ActionScheduler::GROUP_MAINTENANCE
        );
    }

    /**
     * Process expired credits (batch job)
     */
    public function processExpiredCredits(): void
    {
        if (!ActionScheduler::acquireLock(ActionScheduler::HOOK_EXPIRE_STORE_CREDITS, [])) {
            return;
        }

        try {
            $this->expireCredits();
            $this->scheduleExpiringNotifications();
        } finally {
            ActionScheduler::releaseLock(ActionScheduler::HOOK_EXPIRE_STORE_CREDITS, []);
        }
    }

    /**
     * Expire all credits that have passed their expiration date
     */
    private function expireCredits(): void
    {
        $expiration_days = absint(arraysubs_get_setting('store_credit.expiration_days', 0));
        if ($expiration_days <= 0) {
            return;
        }

        // Find credits that should expire
        $args = [
            'post_type' => Hooks::CPT_CREDIT_LOG,
            'post_status' => 'publish',
            'posts_per_page' => 100,
            'meta_query' => [
                'relation' => 'AND',
                [
                    'key' => '_type',
                    'value' => CreditManager::TYPE_CREDIT,
                ],
                [
                    'key' => '_expires_at',
                    'value' => current_time('mysql', true),
                    'compare' => '<=',
                    'type' => 'DATETIME',
                ],
                [
                    'key' => '_expired',
                    'compare' => 'NOT EXISTS',
                ],
            ],
        ];

        $query = new \WP_Query($args);

        foreach ($query->posts as $credit_log) {
            $this->expireSingleCredit($credit_log);
        }
    }

    /**
     * Expire a single credit entry
     *
     * @param \WP_Post $credit_log Credit log post
     */
    private function expireSingleCredit(\WP_Post $credit_log): void
    {
        $customer_id = (int) get_post_meta($credit_log->ID, '_customer_id', true);
        $subscription_id = (int) get_post_meta($credit_log->ID, '_subscription_id', true);
        $amount = (float) get_post_meta($credit_log->ID, '_amount', true);

        if ($amount <= 0) {
            update_post_meta($credit_log->ID, '_expired', 1);
            return;
        }

        // Calculate how much of this credit is still available
        $remaining = $this->getRemainingCreditFromEntry($credit_log->ID, $customer_id, $subscription_id);

        if ($remaining <= 0) {
            update_post_meta($credit_log->ID, '_expired', 1);
            return;
        }

        // Deduct the remaining amount
        if ($subscription_id > 0) {
            CreditManager::deductSubscriptionCredit(
                $subscription_id,
                $remaining,
                CreditManager::SOURCE_EXPIRED,
                $credit_log->ID,
                __('Credit expired', 'arraysubspro')
            );
        } else {
            CreditManager::deductCustomerCredit(
                $customer_id,
                $remaining,
                CreditManager::SOURCE_EXPIRED,
                $credit_log->ID,
                __('Credit expired', 'arraysubspro')
            );
        }

        // Mark as expired
        update_post_meta($credit_log->ID, '_expired', 1);
        update_post_meta($credit_log->ID, '_expired_at', current_time('mysql', true));
        update_post_meta($credit_log->ID, '_expired_amount', $remaining);

        // Fire action for email notification
        do_action('arraysubs_credit_expired', $customer_id, $remaining, $credit_log->ID, $subscription_id);
    }

    /**
     * Get remaining credit from a specific entry
     *
     * This is simplified - in production you might want FIFO tracking
     *
     * @param int $credit_log_id Credit log ID
     * @param int $customer_id   Customer ID
     * @param int $subscription_id Subscription ID
     * @return float
     */
    private function getRemainingCreditFromEntry(int $credit_log_id, int $customer_id, int $subscription_id): float
    {
        $original_amount = (float) get_post_meta($credit_log_id, '_amount', true);

        // For simplicity, we assume the full original amount is expiring
        // A more sophisticated system would track FIFO usage
        return $original_amount;
    }

    /**
     * Schedule notifications for credits expiring soon
     */
    private function scheduleExpiringNotifications(): void
    {
        $expiration_days = absint(arraysubs_get_setting('store_credit.expiration_days', 0));
        if ($expiration_days <= 0) {
            return;
        }

        // Find credits expiring within warning period
        $warning_date = gmdate('Y-m-d H:i:s', strtotime('+' . self::DAYS_BEFORE_EXPIRY_WARNING . ' days'));

        $args = [
            'post_type' => Hooks::CPT_CREDIT_LOG,
            'post_status' => 'publish',
            'posts_per_page' => 100,
            'meta_query' => [
                'relation' => 'AND',
                [
                    'key' => '_type',
                    'value' => CreditManager::TYPE_CREDIT,
                ],
                [
                    'key' => '_expires_at',
                    'value' => $warning_date,
                    'compare' => '<=',
                    'type' => 'DATETIME',
                ],
                [
                    'key' => '_expires_at',
                    'value' => current_time('mysql', true),
                    'compare' => '>',
                    'type' => 'DATETIME',
                ],
                [
                    'key' => '_expiry_notified',
                    'compare' => 'NOT EXISTS',
                ],
                [
                    'key' => '_expired',
                    'compare' => 'NOT EXISTS',
                ],
            ],
        ];

        $query = new \WP_Query($args);

        foreach ($query->posts as $credit_log) {
            $customer_id = (int) get_post_meta($credit_log->ID, '_customer_id', true);

            // Schedule notification
            ActionScheduler::scheduleSingle(
                ActionScheduler::HOOK_SEND_CREDIT_EXPIRING,
                time() + 60, // Send within a minute
                [$customer_id, $credit_log->ID],
                ActionScheduler::GROUP_EMAILS
            );

            // Mark as notified
            update_post_meta($credit_log->ID, '_expiry_notified', 1);
        }
    }

    /**
     * Send credit expiring soon notification
     *
     * @param int $customer_id   Customer ID
     * @param int $credit_log_id Credit log ID
     */
    public function sendExpiringNotification(int $customer_id, int $credit_log_id): void
    {
        $credit_log = get_post($credit_log_id);
        if (!$credit_log || $credit_log->post_type !== Hooks::CPT_CREDIT_LOG) {
            return;
        }

        $amount = (float) get_post_meta($credit_log_id, '_amount', true);
        $expires_at = get_post_meta($credit_log_id, '_expires_at', true);

        // Fire action for email system to pick up
        do_action('arraysubs_credit_expiring_soon', $customer_id, $amount, $expires_at, $credit_log_id);
    }

    /**
     * Handle credit added - set expiration date
     *
     * @param int    $customer_id Customer ID
     * @param float  $amount      Amount added
     * @param float  $new_balance New balance
     * @param string $source      Source type
     */
    public function onCreditAdded(int $customer_id, float $amount, float $new_balance, string $source): void
    {
        $this->setExpirationOnLatestCredit($customer_id, null, $source);
    }

    /**
     * Handle subscription credit added - set expiration date
     *
     * @param int    $subscription_id Subscription ID
     * @param float  $amount          Amount added
     * @param float  $new_balance     New balance
     * @param string $source          Source type
     */
    public function onSubscriptionCreditAdded(int $subscription_id, float $amount, float $new_balance, string $source): void
    {
        $customer_id = (int) get_post_meta($subscription_id, '_customer_id', true);
        $this->setExpirationOnLatestCredit($customer_id, $subscription_id, $source);
    }

    /**
     * Set expiration date on the latest credit log entry
     *
     * @param int      $customer_id     Customer ID
     * @param int|null $subscription_id Subscription ID or null
     * @param string   $source          Source type
     */
    private function setExpirationOnLatestCredit(int $customer_id, ?int $subscription_id, string $source): void
    {
        // Don't set expiration for expired credits (they're already processed)
        if ($source === CreditManager::SOURCE_EXPIRED) {
            return;
        }

        $expiration_days = absint(arraysubs_get_setting('store_credit.expiration_days', 0));
        if ($expiration_days <= 0) {
            return;
        }

        // Find the latest credit entry for this customer
        $args = [
            'post_type' => Hooks::CPT_CREDIT_LOG,
            'post_status' => 'publish',
            'posts_per_page' => 1,
            'orderby' => 'ID',
            'order' => 'DESC',
            'meta_query' => [
                'relation' => 'AND',
                [
                    'key' => '_customer_id',
                    'value' => $customer_id,
                    'type' => 'NUMERIC',
                ],
                [
                    'key' => '_type',
                    'value' => CreditManager::TYPE_CREDIT,
                ],
            ],
        ];

        if ($subscription_id) {
            $args['meta_query'][] = [
                'key' => '_subscription_id',
                'value' => $subscription_id,
                'type' => 'NUMERIC',
            ];
        }

        $query = new \WP_Query($args);

        if ($query->have_posts()) {
            $credit_log = $query->posts[0];
            $expires_at = gmdate('Y-m-d H:i:s', strtotime('+' . $expiration_days . ' days'));
            update_post_meta($credit_log->ID, '_expires_at', $expires_at);
        }
    }

    /**
     * Get credits expiring for a customer
     *
     * @param int $customer_id Customer ID
     * @param int $days_ahead  Days ahead to check
     * @return array Array of expiring credit info
     */
    public static function getExpiringCredits(int $customer_id, int $days_ahead = 30): array
    {
        $args = [
            'post_type' => Hooks::CPT_CREDIT_LOG,
            'post_status' => 'publish',
            'posts_per_page' => 20,
            'meta_query' => [
                'relation' => 'AND',
                [
                    'key' => '_customer_id',
                    'value' => $customer_id,
                    'type' => 'NUMERIC',
                ],
                [
                    'key' => '_type',
                    'value' => CreditManager::TYPE_CREDIT,
                ],
                [
                    'key' => '_expires_at',
                    'value' => gmdate('Y-m-d H:i:s', strtotime('+' . $days_ahead . ' days')),
                    'compare' => '<=',
                    'type' => 'DATETIME',
                ],
                [
                    'key' => '_expires_at',
                    'value' => current_time('mysql', true),
                    'compare' => '>',
                    'type' => 'DATETIME',
                ],
                [
                    'key' => '_expired',
                    'compare' => 'NOT EXISTS',
                ],
            ],
            'orderby' => 'meta_value',
            'meta_key' => '_expires_at',
            'order' => 'ASC',
        ];

        $query = new \WP_Query($args);
        $expiring = [];

        foreach ($query->posts as $credit_log) {
            $expiring[] = [
                'id' => $credit_log->ID,
                'amount' => (float) get_post_meta($credit_log->ID, '_amount', true),
                'expires_at' => get_post_meta($credit_log->ID, '_expires_at', true),
                'source' => get_post_meta($credit_log->ID, '_source', true),
            ];
        }

        return $expiring;
    }

    /**
     * Get total expiring credit amount for a customer
     *
     * @param int $customer_id Customer ID
     * @param int $days_ahead  Days ahead to check
     * @return float
     */
    public static function getTotalExpiringCredit(int $customer_id, int $days_ahead = 30): float
    {
        $expiring = self::getExpiringCredits($customer_id, $days_ahead);
        $total = 0;

        foreach ($expiring as $credit) {
            $total += $credit['amount'];
        }

        return $total;
    }
}
