<?php

/**
 * Transaction Logger
 *
 * Logs all credit transactions to the CPT.
 *
 * @package ArraySubsPro\Features\StoreCredit\Services
 * @since 1.0.0
 */

namespace ArraySubsPro\Features\StoreCredit\Services;

defined('ABSPATH') || exit;

use function arraysubs_format_site_local_date;

/**
 * Transaction Logger class
 */
class TransactionLogger
{
    /**
     * Log a credit transaction
     *
     * @param array $data Transaction data
     *
     * @return int|false Post ID on success, false on failure
     */
    public static function log(array $data): int|false
    {
        $defaults = [
            'customer_id'     => 0,
            'subscription_id' => null,
            'amount'          => 0.0,
            'type'            => 'credit',
            'source'          => '',
            'source_id'       => null,
            'balance_after'   => 0.0,
            'note'            => '',
            'currency'        => get_woocommerce_currency(),
        ];

        $data = wp_parse_args($data, $defaults);

        if (!$data['customer_id'] || $data['amount'] <= 0) {
            return false;
        }

        // Get customer info for title
        $user = get_user_by('ID', $data['customer_id']);
        $customer_name = $user ? $user->display_name : __('Unknown', 'arraysubspro');

        // Generate title
        $title = sprintf(
            'Credit #%s - %s',
            uniqid(),
            $customer_name
        );

        // Create the log post
        $post_id = wp_insert_post([
            'post_type'   => Hooks::CPT_CREDIT_LOG,
            'post_title'  => $title,
            'post_status' => 'publish',
            'post_author' => get_current_user_id() ?: 1,
        ]);

        if (is_wp_error($post_id) || !$post_id) {
            return false;
        }

        // Save meta data
        update_post_meta($post_id, '_customer_id', $data['customer_id']);
        update_post_meta($post_id, '_subscription_id', $data['subscription_id'] ?: 0);
        update_post_meta($post_id, '_amount', $data['amount']);
        update_post_meta($post_id, '_type', $data['type']);
        update_post_meta($post_id, '_source', $data['source']);
        update_post_meta($post_id, '_source_id', $data['source_id'] ?: 0);
        update_post_meta($post_id, '_balance_after', $data['balance_after']);
        update_post_meta($post_id, '_note', $data['note']);
        update_post_meta($post_id, '_currency', $data['currency']);

        return $post_id;
    }

    /**
     * Get transaction history for a customer
     *
     * @param int   $customer_id Customer user ID
     * @param int   $page        Page number
     * @param int   $per_page    Items per page
     * @param array $filters     Additional filters
     *
     * @return array {items: array, total: int, pages: int}
     */
    public static function getCustomerHistory(
        int $customer_id,
        int $page = 1,
        int $per_page = 20,
        array $filters = []
    ): array {
        $meta_query = [
            [
                'key'     => '_customer_id',
                'value'   => $customer_id,
                'compare' => '=',
            ],
        ];

        // Add source filter if provided
        if (!empty($filters['source'])) {
            $meta_query[] = [
                'key'     => '_source',
                'value'   => $filters['source'],
                'compare' => '=',
            ];
        }

        // Add type filter if provided
        if (!empty($filters['type'])) {
            $meta_query[] = [
                'key'     => '_type',
                'value'   => $filters['type'],
                'compare' => '=',
            ];
        }

        $args = [
            'post_type'      => Hooks::CPT_CREDIT_LOG,
            'posts_per_page' => $per_page,
            'paged'          => $page,
            'meta_query'     => $meta_query,
            'orderby'        => 'date',
            'order'          => 'DESC',
        ];

        $query = new \WP_Query($args);

        $items = [];
        foreach ($query->posts as $post) {
            $items[] = self::formatTransaction($post);
        }

        return [
            'items'  => $items,
            'total'  => $query->found_posts,
            'pages'  => $query->max_num_pages,
        ];
    }

    /**
     * Get transaction history for a subscription
     *
     * @param int $subscription_id Subscription ID
     * @param int $page            Page number
     * @param int $per_page        Items per page
     *
     * @return array {items: array, total: int, pages: int}
     */
    public static function getSubscriptionHistory(
        int $subscription_id,
        int $page = 1,
        int $per_page = 20
    ): array {
        $args = [
            'post_type'      => Hooks::CPT_CREDIT_LOG,
            'posts_per_page' => $per_page,
            'paged'          => $page,
            'meta_query'     => [
                [
                    'key'     => '_subscription_id',
                    'value'   => $subscription_id,
                    'compare' => '=',
                ],
            ],
            'orderby'        => 'date',
            'order'          => 'DESC',
        ];

        $query = new \WP_Query($args);

        $items = [];
        foreach ($query->posts as $post) {
            $items[] = self::formatTransaction($post);
        }

        return [
            'items'  => $items,
            'total'  => $query->found_posts,
            'pages'  => $query->max_num_pages,
        ];
    }

    /**
     * Get all transactions (admin view)
     *
     * @param int   $page     Page number
     * @param int   $per_page Items per page
     * @param array $filters  Filters (source, type, customer_id)
     *
     * @return array {items: array, total: int, pages: int}
     */
    public static function getAllTransactions(
        int $page = 1,
        int $per_page = 20,
        array $filters = []
    ): array {
        $meta_query = [];

        // Add customer filter if provided
        if (!empty($filters['customer_id'])) {
            $meta_query[] = [
                'key'     => '_customer_id',
                'value'   => $filters['customer_id'],
                'compare' => '=',
            ];
        }

        // Add source filter if provided
        if (!empty($filters['source'])) {
            $meta_query[] = [
                'key'     => '_source',
                'value'   => $filters['source'],
                'compare' => '=',
            ];
        }

        // Add type filter if provided
        if (!empty($filters['type'])) {
            $meta_query[] = [
                'key'     => '_type',
                'value'   => $filters['type'],
                'compare' => '=',
            ];
        }

        $args = [
            'post_type'      => Hooks::CPT_CREDIT_LOG,
            'posts_per_page' => $per_page,
            'paged'          => $page,
            'orderby'        => 'date',
            'order'          => 'DESC',
        ];

        if (!empty($meta_query)) {
            $args['meta_query'] = $meta_query;
        }

        $query = new \WP_Query($args);

        $items = [];
        foreach ($query->posts as $post) {
            $items[] = self::formatTransaction($post);
        }

        return [
            'items'  => $items,
            'total'  => $query->found_posts,
            'pages'  => $query->max_num_pages,
        ];
    }

    /**
     * Format a transaction post for API response
     *
     * @param \WP_Post $post Transaction post
     *
     * @return array Formatted transaction
     */
    public static function formatTransaction(\WP_Post $post): array
    {
        $customer_id = (int) get_post_meta($post->ID, '_customer_id', true);
        $user = get_user_by('ID', $customer_id);

        return [
            'id'              => $post->ID,
            'date'            => $post->post_date_gmt ?: $post->post_date,
            'date_formatted'  => !empty($post->post_date_gmt) && $post->post_date_gmt !== '0000-00-00 00:00:00'
                ? arraysubs_format_date_local($post->post_date_gmt)
                : arraysubs_format_site_local_date($post->post_date),
            'customer_id'     => $customer_id,
            'customer_name'   => $user ? $user->display_name : __('Unknown', 'arraysubspro'),
            'customer_email'  => $user ? $user->user_email : '',
            'subscription_id' => (int) get_post_meta($post->ID, '_subscription_id', true),
            'amount'          => (float) get_post_meta($post->ID, '_amount', true),
            'type'            => get_post_meta($post->ID, '_type', true),
            'source'          => get_post_meta($post->ID, '_source', true),
            'source_label'    => self::getSourceLabel(get_post_meta($post->ID, '_source', true)),
            'source_id'       => (int) get_post_meta($post->ID, '_source_id', true),
            'balance_after'   => (float) get_post_meta($post->ID, '_balance_after', true),
            'note'            => get_post_meta($post->ID, '_note', true),
            'currency'        => get_post_meta($post->ID, '_currency', true),
        ];
    }

    /**
     * Get human-readable source label
     *
     * @param string $source Source type
     *
     * @return string Source label
     */
    public static function getSourceLabel(string $source): string
    {
        $labels = [
            CreditManager::SOURCE_DOWNGRADE   => __('Plan Downgrade', 'arraysubspro'),
            CreditManager::SOURCE_REFUND      => __('Refund', 'arraysubspro'),
            CreditManager::SOURCE_ADMIN       => __('Admin Adjustment', 'arraysubspro'),
            CreditManager::SOURCE_PROMOTIONAL => __('Promotional Credit', 'arraysubspro'),
            CreditManager::SOURCE_PURCHASE    => __('Credit Purchase', 'arraysubspro'),
            CreditManager::SOURCE_RENEWAL     => __('Applied to Renewal', 'arraysubspro'),
            CreditManager::SOURCE_ORDER       => __('Applied to Order', 'arraysubspro'),
            CreditManager::SOURCE_EXPIRED     => __('Expired', 'arraysubspro'),
        ];

        return $labels[$source] ?? $source;
    }

    /**
     * Delete a transaction log entry
     *
     * @param int $log_id Log post ID
     *
     * @return bool True on success
     */
    public static function deleteLog(int $log_id): bool
    {
        $post = get_post($log_id);

        if (!$post || $post->post_type !== Hooks::CPT_CREDIT_LOG) {
            return false;
        }

        $result = wp_delete_post($log_id, true);

        return $result !== false && $result !== null;
    }

    /**
     * Get a single transaction
     *
     * @param int $log_id Log post ID
     *
     * @return array|null Formatted transaction or null
     */
    public static function getTransaction(int $log_id): ?array
    {
        $post = get_post($log_id);

        if (!$post || $post->post_type !== Hooks::CPT_CREDIT_LOG) {
            return null;
        }

        return self::formatTransaction($post);
    }
}
