<?php

/**
 * Store Credit Email Manager
 *
 * Registers store credit emails with WooCommerce.
 *
 * @package ArraySubsPro\Features\StoreCredit\Services
 * @since 1.0.0
 */

namespace ArraySubsPro\Features\StoreCredit\Services;

defined('ABSPATH') || exit;

use ArraySubsPro\Features\StoreCredit\Emails\CreditAddedEmail;
use ArraySubsPro\Features\StoreCredit\Emails\CreditUsedEmail;
use ArraySubsPro\Features\StoreCredit\Emails\CreditExpiringEmail;
use ArraySubsPro\Features\StoreCredit\Emails\CreditExpiredEmail;

/**
 * Email Manager class
 */
class EmailManager
{
    /**
     * Enable auto-loading
     *
     * @var bool
     */
    public static bool $loadable = true;

    /**
     * Constructor
     */
    public function __construct()
    {
        add_filter('woocommerce_email_classes', [$this, 'registerEmailClasses']);
        add_filter('woocommerce_email_actions', [$this, 'registerEmailActions']);
    }

    /**
     * Register email classes with WooCommerce
     *
     * @param array $emails Existing email classes
     * @return array
     */
    public function registerEmailClasses(array $emails): array
    {
        $emails['ArraySubsPro_Credit_Added_Email'] = new CreditAddedEmail();
        $emails['ArraySubsPro_Credit_Used_Email'] = new CreditUsedEmail();
        $emails['ArraySubsPro_Credit_Expiring_Email'] = new CreditExpiringEmail();
        $emails['ArraySubsPro_Credit_Expired_Email'] = new CreditExpiredEmail();

        return $emails;
    }

    /**
     * Register email actions
     *
     * @param array $actions Existing email actions
     * @return array
     */
    public function registerEmailActions(array $actions): array
    {
        // Credit added triggers
        $actions[] = 'arraysubs_customer_credit_added';
        $actions[] = 'arraysubs_subscription_credit_added';

        // Credit used triggers
        $actions[] = 'arraysubs_credits_applied_to_order';

        // Expiration triggers
        $actions[] = 'arraysubs_credit_expiring_soon';
        $actions[] = 'arraysubs_credit_expired';

        return $actions;
    }
}
