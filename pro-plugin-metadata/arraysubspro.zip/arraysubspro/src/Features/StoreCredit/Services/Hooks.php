<?php

/**
 * Store Credit Hooks
 *
 * WordPress hooks, CPT registration, and integration points.
 *
 * @package ArraySubsPro\Features\StoreCredit\Services
 * @since 1.0.0
 */

namespace ArraySubsPro\Features\StoreCredit\Services;

defined('ABSPATH') || exit;

/**
 * Store Credit Hooks class
 */
class Hooks
{
    /**
     * Enable auto-loading
     *
     * @var bool
     */
    public static $loadable = true;

    /**
     * CPT slug for credit log
     */
    const CPT_CREDIT_LOG = 'arraysubs_credit';

    /**
     * Constructor
     */
    public function __construct()
    {
        // Register CPT on init
        add_action('init', [$this, 'registerCreditLogCPT']);
        add_action('init', [$this, 'registerCreditLogMeta']);

        // Hook into downgrade credit creation
        add_action('arraysubs_downgrade_credit_created', [$this, 'onDowngradeCreditCreated'], 10, 3);

        // Hook into renewal invoice creation to apply credits
        add_action('arraysubs_renewal_invoice_created', [$this, 'onRenewalInvoiceCreated'], 10, 2);

        // Reverse credit application when the renewal payment fails so the
        // customer's credit balance is restored. Without this, a failed
        // Stripe charge silently consumes the credit and the customer can
        // never claim its value.
        add_action('arraysubs_renewal_payment_failed', [$this, 'onRenewalPaymentFailed'], 10, 3);

        // Hook into WooCommerce checkout to apply credits (optional)
        add_action('woocommerce_cart_calculate_fees', [$this, 'applyCheckoutCreditsToCart'], 20, 1);
        add_action('woocommerce_checkout_order_processed', [$this, 'onCheckoutOrderProcessed'], 10, 3);
        add_action('woocommerce_store_api_checkout_order_processed', [$this, 'onStoreApiCheckoutOrderProcessed'], 10, 1);
    }

    /**
     * Reverse a previous credit application when the renewal payment fails.
     *
     * Hook signature: arraysubs_renewal_payment_failed ($subscription_id, $order_id, $error_message)
     *
     * @param int    $subscription_id Subscription ID.
     * @param int    $order_id        Order ID.
     * @param string $error_message   Failure message.
     * @return void
     */
    public function onRenewalPaymentFailed(int $subscription_id, int $order_id, string $error_message = ''): void
    {
        unset($error_message);

        $order = wc_get_order($order_id);
        if (! $order instanceof \WC_Order) {
            return;
        }

        CreditManager::reverseCreditsForOrder($order, $subscription_id);
    }

    /**
     * Register Credit Log CPT
     */
    public function registerCreditLogCPT(): void
    {
        $labels = [
            'name'               => __('Credit Transactions', 'arraysubspro'),
            'singular_name'      => __('Credit Transaction', 'arraysubspro'),
            'menu_name'          => __('Store Credits', 'arraysubspro'),
            'all_items'          => __('All Transactions', 'arraysubspro'),
            'view_item'          => __('View Transaction', 'arraysubspro'),
            'search_items'       => __('Search Transactions', 'arraysubspro'),
            'not_found'          => __('No credit transactions found', 'arraysubspro'),
            'not_found_in_trash' => __('No credit transactions found in trash', 'arraysubspro'),
        ];

        $args = [
            'labels'              => $labels,
            'public'              => false,
            'publicly_queryable'  => false,
            'show_ui'             => false,
            'show_in_menu'        => false,
            'query_var'           => false,
            'rewrite'             => false,
            'capability_type'     => 'post',
            'has_archive'         => false,
            'hierarchical'        => false,
            'show_in_rest'        => true,
            'rest_base'           => 'credit-transactions',
            'supports'            => ['title'],
        ];

        register_post_type(self::CPT_CREDIT_LOG, $args);
    }

    /**
     * Register meta fields for Credit Log CPT
     */
    public function registerCreditLogMeta(): void
    {
        $meta_fields = [
            '_customer_id' => [
                'type'              => 'integer',
                'default'           => 0,
                'sanitize_callback' => 'absint',
            ],
            '_subscription_id' => [
                'type'              => 'integer',
                'default'           => 0,
                'sanitize_callback' => 'absint',
            ],
            '_amount' => [
                'type'              => 'number',
                'default'           => 0,
                'sanitize_callback' => [$this, 'sanitizeFloat'],
            ],
            '_type' => [
                'type'              => 'string',
                'default'           => 'credit',
                'sanitize_callback' => 'sanitize_text_field',
            ],
            '_source' => [
                'type'              => 'string',
                'default'           => '',
                'sanitize_callback' => 'sanitize_text_field',
            ],
            '_source_id' => [
                'type'              => 'integer',
                'default'           => 0,
                'sanitize_callback' => 'absint',
            ],
            '_balance_after' => [
                'type'              => 'number',
                'default'           => 0,
                'sanitize_callback' => [$this, 'sanitizeFloat'],
            ],
            '_note' => [
                'type'              => 'string',
                'default'           => '',
                'sanitize_callback' => 'sanitize_textarea_field',
            ],
            '_currency' => [
                'type'              => 'string',
                'default'           => 'USD',
                'sanitize_callback' => 'sanitize_text_field',
            ],
        ];

        foreach ($meta_fields as $key => $config) {
            register_post_meta(self::CPT_CREDIT_LOG, $key, [
                'type'              => $config['type'],
                'single'            => true,
                'show_in_rest'      => true,
                'default'           => $config['default'],
                'sanitize_callback' => $config['sanitize_callback'],
                'auth_callback'     => fn() => current_user_can('manage_woocommerce'),
            ]);
        }
    }

    /**
     * Handle downgrade credit creation
     *
     * @param int    $subscription_id Subscription ID
     * @param float  $amount          Credit amount
     * @param string $currency        Currency code
     */
    public function onDowngradeCreditCreated(int $subscription_id, float $amount, string $currency): void
    {
        $subscription = get_post($subscription_id);
        if (!$subscription) {
            return;
        }

        $customer_id = (int) get_post_meta($subscription_id, '_customer_id', true);
        if (!$customer_id) {
            return;
        }

        // Log the credit transaction
        CreditManager::addSubscriptionCredit(
            $subscription_id,
            $amount,
            'downgrade',
            $subscription_id,
            __('Credit from plan downgrade', 'arraysubspro'),
            $currency
        );
    }

    /**
     * Handle renewal invoice created - apply credits
     *
     * @param int $subscription_id Subscription ID
     * @param int $order_id        Order ID
     */
    public function onRenewalInvoiceCreated(int $subscription_id, int $order_id): void
    {
        // Check if auto-apply is enabled
        $settings = arraysubs_get_settings();
        $auto_apply = $settings['store_credit']['auto_apply_to_renewals'] ?? true;

        if (!$auto_apply) {
            return;
        }

        $order = wc_get_order($order_id);
        if (!$order) {
            return;
        }

        $min_order_amount = (float) ($settings['store_credit']['min_order_amount'] ?? 0);
        $order_total = (float) $order->get_total();
        $available_credit = CreditManager::getTotalAvailableCredit($subscription_id);

        if (
            $min_order_amount > 0
            && (
                $order_total < $min_order_amount
                || (float) ($available_credit['total'] ?? 0) < $min_order_amount
            )
        ) {
            return;
        }

        CreditManager::applyCreditsToOrder($order, $subscription_id);
    }

    /**
     * Handle checkout order processed - apply credits (optional)
     *
     * @param int       $order_id  Order ID
     * @param array     $posted_data Posted data
     * @param \WC_Order $order     Order object
     */
    public function onCheckoutOrderProcessed(int $order_id, array $posted_data, \WC_Order $order): void
    {
        unset($order_id, $posted_data);

        $this->captureCheckoutCreditForOrder($order);
    }

    /**
     * Capture checkout credit after Block Checkout creates the order.
     *
     * @param \WC_Order $order Order object.
     * @return void
     */
    public function onStoreApiCheckoutOrderProcessed(\WC_Order $order): void
    {
        $this->captureCheckoutCreditForOrder($order);
    }

    /**
     * Capture checkout-applied credit for eligible subscription orders.
     *
     * @param \WC_Order $order Order object.
     * @return void
     */
    private function captureCheckoutCreditForOrder(\WC_Order $order): void
    {
        // Check if apply at checkout is enabled
        $settings = arraysubs_get_settings();
        $apply_at_checkout = $settings['store_credit']['apply_at_checkout'] ?? false;

        if (!$apply_at_checkout) {
            return;
        }

        if (!function_exists('arraysubs_is_subscription_product')) {
            return;
        }

        // Only apply to subscription orders
        $has_subscription = false;
        foreach ($order->get_items() as $item) {
            $product_ids = [
                (int) $item->get_variation_id(),
                (int) $item->get_product_id(),
            ];

            $product = $item->get_product();
            if ($product instanceof \WC_Product) {
                $product_ids[] = (int) $product->get_id();
            }

            foreach (array_filter(array_unique($product_ids)) as $product_id) {
                if (!arraysubs_is_subscription_product($product_id)) {
                    continue;
                }

                $has_subscription = true;
                break;
            }

            if ($has_subscription) {
                break;
            }
        }

        if (!$has_subscription) {
            return;
        }

        CreditManager::captureAppliedCheckoutCredit($order);
    }

    /**
     * Display checkout credit as a cart fee before the order is placed.
     *
     * @param \WC_Cart $cart Cart object.
     * @return void
     */
    public function applyCheckoutCreditsToCart(\WC_Cart $cart): void
    {
        if (is_admin() && !defined('DOING_AJAX')) {
            return;
        }

        if (!is_user_logged_in()) {
            return;
        }

        $settings = arraysubs_get_settings();
        if (empty($settings['store_credit']['apply_at_checkout'])) {
            return;
        }

        $has_subscription = false;
        foreach ($cart->get_cart() as $cart_item) {
            $product_id = (int) ($cart_item['product_id'] ?? 0);
            if ($product_id && arraysubs_is_subscription_product($product_id)) {
                $has_subscription = true;
                break;
            }
        }

        if (!$has_subscription) {
            return;
        }

        $eligible_total = max(0.0, (float) $cart->get_subtotal() - (float) $cart->get_discount_total());
        $min_order_amount = (float) ($settings['store_credit']['min_order_amount'] ?? 0);

        if ($eligible_total <= 0 || $eligible_total < $min_order_amount) {
            return;
        }

        $customer_credit = CreditManager::getCustomerCredit(get_current_user_id());
        if ($customer_credit <= 0) {
            return;
        }

        $credit_to_apply = min($customer_credit, $eligible_total);
        if ($credit_to_apply <= 0) {
            return;
        }

        $cart->add_fee(__('Store Credit Applied', 'arraysubspro'), -$credit_to_apply, false);
    }

    /**
     * Sanitize float value for meta fields
     * WordPress sanitize_meta passes 4 arguments, but floatval only accepts 1
     *
     * @param mixed $value The value to sanitize
     * @return float
     */
    public function sanitizeFloat($value): float
    {
        return (float) $value;
    }
}
