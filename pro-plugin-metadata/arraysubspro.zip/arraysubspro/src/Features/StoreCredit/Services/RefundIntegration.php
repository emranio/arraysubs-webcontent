<?php

/**
 * Store Credit Refund Integration
 *
 * Integrates store credit refund option into WooCommerce order edit page.
 *
 * @package ArraySubsPro\Features\StoreCredit\Services
 */

namespace ArraySubsPro\Features\StoreCredit\Services;

defined('ABSPATH') || exit;

use ArraySubs\Supports\Config;

/**
 * RefundIntegration class
 *
 * Handles integration of "Refund as Store Credit" option into WooCommerce's
 * native refund interface on order edit pages.
 */
class RefundIntegration
{
    /**
     * Enable auto-loading via AbstractLoader
     *
     * @var bool
     */
    public static $loadable = true;

    /**
     * Constructor - register WordPress hooks
     */
    public function __construct()
    {
        // Add refund method option to WooCommerce refund UI
        add_action('woocommerce_order_item_add_action_buttons', [$this, 'addRefundMethodOption'], 10, 1);

        // Show store credit refund history in order items
        add_action('woocommerce_admin_order_items_after_refunds', [$this, 'showCreditRefundHistory'], 10, 1);
        add_action('woocommerce_order_details_after_order_table', [$this, 'showCustomerCreditRefundHistory'], 10, 1);

        // Enqueue scripts on order edit page
        add_action('admin_enqueue_scripts', [$this, 'enqueueAssets']);

        // Handle AJAX refund as store credit
        add_action('wp_ajax_arraysubs_refund_as_credit', [$this, 'handleRefundAsCredit']);
        add_action('wp_ajax_woocommerce_refund_line_items', [$this, 'blockStandardRefundWhenCreditRefunded'], 0);
    }

    /**
     * Enqueue assets on order edit page
     *
     * @param string $hook Current admin page hook.
     */
    public function enqueueAssets(string $hook): void
    {
        // Only load on order edit page
        if (!in_array($hook, ['post.php', 'woocommerce_page_wc-orders'], true)) {
            return;
        }

        $screen = get_current_screen();
        if (!$screen) {
            return;
        }

        // Check for both legacy orders and HPOS
        $is_order_screen = (
            ('shop_order' === $screen->post_type && 'post' === $screen->base) ||
            ('woocommerce_page_wc-orders' === $screen->id)
        );

        if (!$is_order_screen) {
            return;
        }

        // Get the order ID
        $order_id = $this->getOrderIdFromRequest();
        if (!$order_id) {
            return;
        }

        $order = wc_get_order($order_id);
        if (!$order) {
            return;
        }

        $customer_id = $order->get_customer_id();
        $current_balance = $customer_id ? CreditManager::getCustomerCredit($customer_id) : 0;
        $refundable = $this->getRefundableAmount($order);

        $assets_url = plugin_dir_url(__DIR__) . 'assets/';
        $assets_path = dirname(__DIR__) . '/assets/';
        $asset_version = static function (string $filename) use ($assets_path): string {
            $path = $assets_path . $filename;

            return file_exists($path) ? (string) filemtime($path) : ARRAYSUBSPRO_VERSION;
        };

        // Enqueue refund integration styles
        wp_enqueue_style(
            'arraysubspro-refund-integration',
            $assets_url . 'refund-integration.css',
            ['woocommerce_admin_styles'],
            $asset_version('refund-integration.css')
        );

        // Enqueue refund integration script
        wp_enqueue_script(
            'arraysubspro-refund-integration',
            $assets_url . 'refund-integration.js',
            ['jquery'],
            $asset_version('refund-integration.js'),
            true
        );

        // Localize data for the script
        wp_localize_script('arraysubspro-refund-integration', 'arraysubs_refund', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('order-item'),
            'order_id' => $order_id,
            'current_balance' => $current_balance,
            'refundable_amount' => $refundable,
            'refunded_as_credit' => (float) $order->get_meta('_refunded_as_credit'),
            'currency_symbol' => get_woocommerce_currency_symbol(),
            'balance_after_label' => __('Balance After', 'arraysubspro'),
            'success_message' => __('Refund issued as store credit successfully!', 'arraysubspro'),
            'error_amount' => __('Please enter a valid refund amount.', 'arraysubspro'),
            'error_generic' => __('An error occurred. Please try again.', 'arraysubspro'),
            'standard_refund_blocked_message' => __('This order has already been fully refunded as store credit. No further gateway or manual refund is available.', 'arraysubspro'),
            'confirm_title' => __('Refund as Store Credit', 'arraysubspro'),
            'confirm_message' => __('Refund %s as store credit?', 'arraysubspro'),
            'confirm_label' => __('Refund as Store Credit', 'arraysubspro'),
            'cancel_label' => __('Cancel', 'arraysubspro'),
            'loading_label' => __('Refunding...', 'arraysubspro'),
            'refund_as_credit_label' => __('Refund as Store Credit', 'arraysubspro'),
            'refund_as_credit_amount_label' => __('Refund %s as Store Credit', 'arraysubspro'),
        ]);
    }

    /**
     * Block WooCommerce standard refunds when store-credit refunds consume the refundable total.
     *
     * @return void
     */
    public function blockStandardRefundWhenCreditRefunded(): void
    {
        if (!current_user_can('edit_shop_orders')) {
            return;
        }

        if (!check_ajax_referer('order-item', 'security', false)) {
            return;
        }

        $order_id = absint($_POST['order_id'] ?? 0);
        if (!$order_id) {
            return;
        }

        $order = wc_get_order($order_id);
        if (!$order) {
            return;
        }

        $refunded_as_credit = (float) $order->get_meta('_refunded_as_credit');
        if ($refunded_as_credit <= 0) {
            return;
        }

        $credit_aware_refundable = CreditManager::getRefundableAmountForOrder($order);
        $requested_amount = abs((float) wc_format_decimal(wp_unslash($_POST['refund_amount'] ?? 0)));

        if ($credit_aware_refundable <= 0 || $requested_amount > $credit_aware_refundable) {
            wp_send_json_error([
                'error' => sprintf(
                    /* translators: %s: remaining refundable amount */
                    __('Refund blocked because store-credit refunds already consumed this order. Remaining refundable amount: %s.', 'arraysubspro'),
                    wc_price($credit_aware_refundable, ['currency' => $order->get_currency()])
                ),
            ]);
        }
    }



    /**
     * Add "Refund as Store Credit" option to WooCommerce refund modal
     *
     * @param \WC_Order $order Current order being edited.
     */
    public function addRefundMethodOption($order): void
    {
        // Check if store credit refund is enabled
        if (!arraysubs_get_setting('store_credit.enabled', true)) {
            return;
        }

        $customer_id = $order->get_customer_id();
        if (!$customer_id) {
            // Guest orders can't receive store credit
            echo '<p class="arraysubspro-refund-notice" style="color: #999; font-style: italic; margin-top: 10px;">';
            esc_html_e('Store credit refund not available for guest orders.', 'arraysubspro');
            echo '</p>';
            return;
        }

        $current_balance = CreditManager::getCustomerCredit($customer_id);
        $customer = get_user_by('id', $customer_id);
        $refundable = $this->getRefundableAmount($order);

        if ($refundable <= 0) {
            return; // Nothing to refund
        }
?>
        <div id="arraysubspro-refund-method" class="arraysubspro-refund-method-wrapper" style="display:none;">
            <p class="arraysubspro-refund-title"><?php esc_html_e('Refund Method:', 'arraysubspro'); ?></p>
            <label>
                <input type="radio" name="arraysubs_refund_method" value="gateway" checked>
                <?php esc_html_e('Refund via Payment Gateway (or manual)', 'arraysubspro'); ?>
            </label>
            <label>
                <input type="radio" name="arraysubs_refund_method" value="store_credit">
                <?php esc_html_e('Refund as Store Credit', 'arraysubspro'); ?>
            </label>
            <div id="arraysubspro-credit-info" style="display: none;">
                <div class="arraysubspro-customer-email">
                    <?php
                    /* translators: %s: Customer email */
                    echo esc_html(sprintf(__('Customer: %s', 'arraysubspro'), $customer->user_email));
                    ?>
                </div>
                <div class="arraysubspro-balance-current">
                    <?php
                    /* translators: %s: Current balance formatted as price */
                    echo wp_kses_post(sprintf(__('Current Balance: %s', 'arraysubspro'), wc_price($current_balance)));
                    ?>
                </div>
                <div class="arraysubspro-balance-after" id="arraysubspro-balance-after">
                    <?php
                    /* translators: %s: Balance after refund formatted as price */
                    echo wp_kses_post(sprintf(__('Balance After: %s', 'arraysubspro'), wc_price($current_balance)));
                    ?>
                </div>
                <div class="arraysubspro-refundable">
                    <?php
                    /* translators: %s: Maximum refundable amount formatted as price */
                    echo wp_kses_post(sprintf(__('Max Refundable: %s', 'arraysubspro'), wc_price($refundable)));
                    ?>
                </div>
            </div>
        </div>
        <?php
    }

    /**
     * Show store credit refunds in order items area
     *
     * @param int $order_id Order ID.
     */
    public function showCreditRefundHistory($order_id): void
    {
        $order = wc_get_order($order_id);
        if (!$order) {
            return;
        }

        $refunded_as_credit = (float) $order->get_meta('_refunded_as_credit');

        if ($refunded_as_credit > 0) {
        ?>
            <tr class="arraysubspro-credit-refund-row">
                <td class="thumb">
                    <div></div>
                </td>
                <td colspan="5" style="color: #b26200; font-weight: 500;">
                    <?php
                    echo wp_kses_post(sprintf(
                        /* translators: %s: Amount refunded as credit formatted as price */
                        __('Refunded as Store Credit: %s', 'arraysubspro'),
                        '<strong>' . wc_price($refunded_as_credit) . '</strong>'
                    ));
                    ?>
                </td>
            </tr>
<?php
        }
    }

    /**
     * Show store credit refunds on the customer order detail page.
     *
     * @param \WC_Order|mixed $order Order object.
     * @return void
     */
    public function showCustomerCreditRefundHistory($order): void
    {
        if (! $order instanceof \WC_Order) {
            return;
        }

        $credit_refunds = $order->get_meta('_arraysubs_credit_refunds') ?: [];
        $credit_refunds = is_array($credit_refunds) ? $credit_refunds : [];
        $refunded_as_credit = (float) $order->get_meta('_refunded_as_credit');

        if ($refunded_as_credit <= 0 && empty($credit_refunds)) {
            return;
        }

        ?>
        <section class="woocommerce-order-details arraysubspro-credit-refund-summary">
            <h2 class="woocommerce-order-details__title">
                <?php esc_html_e('Store Credit Refund', 'arraysubspro'); ?>
            </h2>
            <p>
                <?php
                echo wp_kses_post(sprintf(
                    /* translators: %s: amount refunded as store credit */
                    __('Refunded as store credit: %s', 'arraysubspro'),
                    '<strong>' . wc_price($refunded_as_credit, ['currency' => $order->get_currency()]) . '</strong>'
                ));
                ?>
            </p>
            <?php if (! empty($credit_refunds)) : ?>
                <table class="woocommerce-table shop_table shop_table_responsive">
                    <thead>
                        <tr>
                            <th><?php esc_html_e('Date', 'arraysubspro'); ?></th>
                            <th><?php esc_html_e('Amount', 'arraysubspro'); ?></th>
                            <th><?php esc_html_e('Reason', 'arraysubspro'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($credit_refunds as $credit_refund) : ?>
                            <tr>
                                <td data-title="<?php esc_attr_e('Date', 'arraysubspro'); ?>">
                                    <?php echo esc_html($credit_refund['date'] ?? ''); ?>
                                </td>
                                <td data-title="<?php esc_attr_e('Amount', 'arraysubspro'); ?>">
                                    <?php echo wp_kses_post(wc_price((float) ($credit_refund['amount'] ?? 0), ['currency' => $order->get_currency()])); ?>
                                </td>
                                <td data-title="<?php esc_attr_e('Reason', 'arraysubspro'); ?>">
                                    <?php echo esc_html($credit_refund['reason'] ?? __('Store credit refund', 'arraysubspro')); ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </section>
        <?php
    }

    /**
     * Handle AJAX refund as store credit
     */
    public function handleRefundAsCredit(): void
    {
        check_ajax_referer('order-item', 'security');

        if (!current_user_can('edit_shop_orders')) {
            wp_send_json_error(['error' => __('Permission denied.', 'arraysubspro')]);
        }

        $order_id = absint($_POST['order_id'] ?? 0);
        $amount = floatval($_POST['refund_amount'] ?? 0);
        $reason = sanitize_textarea_field(wp_unslash($_POST['refund_reason'] ?? ''));

        if (!$order_id || $amount <= 0) {
            wp_send_json_error(['error' => __('Invalid order or amount.', 'arraysubspro')]);
        }

        $order = wc_get_order($order_id);
        if (!$order) {
            wp_send_json_error(['error' => __('Order not found.', 'arraysubspro')]);
        }

        $customer_id = $order->get_customer_id();
        if (!$customer_id) {
            wp_send_json_error(['error' => __('Order has no customer account.', 'arraysubspro')]);
        }

        // Validate refundable amount
        $refundable = $this->getRefundableAmount($order);
        if ($amount > $refundable) {
            wp_send_json_error([
                'error' => sprintf(
                    /* translators: %s: Maximum refundable amount */
                    __('Amount exceeds maximum refundable (%s).', 'arraysubspro'),
                    wc_price($refundable)
                ),
            ]);
        }

        $result = CreditManager::processRefundAsCredit($order_id, $amount, $reason);

        if (empty($result['success'])) {
            wp_send_json_error([
                'error' => $result['error'] ?? __('Failed to process refund as store credit.', 'arraysubspro'),
            ]);
        }

        wp_send_json_success([
            'amount_refunded' => $amount,
            'refund_id' => $result['refund_id'],
            'new_balance' => $result['new_balance'],
            'remaining_refundable' => $result['remaining_refundable'],
        ]);
    }

    /**
     * Get order ID from request (supports both legacy orders and HPOS)
     *
     * @return int Order ID or 0.
     */
    private function getOrderIdFromRequest(): int
    {
        // HPOS format
        $id = filter_input(INPUT_GET, 'id', FILTER_SANITIZE_NUMBER_INT);
        if ($id) {
            return absint($id);
        }

        // Legacy format
        $post = filter_input(INPUT_GET, 'post', FILTER_SANITIZE_NUMBER_INT);
        if ($post) {
            return absint($post);
        }

        return 0;
    }

    /**
     * Get maximum refundable amount for an order
     *
     * Considers both gateway refunds and store credit refunds already issued.
     *
     * @param \WC_Order $order Order object.
     * @return float Maximum refundable amount.
     */
    private function getRefundableAmount(\WC_Order $order): float
    {
        return CreditManager::getRefundableAmountForOrder($order);
    }
}
