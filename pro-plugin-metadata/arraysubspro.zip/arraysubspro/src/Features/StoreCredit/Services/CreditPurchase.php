<?php

/**
 * Credit Purchase Service
 *
 * Handles WooCommerce integration for purchasing store credits.
 * Creates a virtual product type and processes credit orders.
 *
 * @package ArraySubsPro\Features\StoreCredit\Services
 * @since 1.0.0
 */

namespace ArraySubsPro\Features\StoreCredit\Services;

defined('ABSPATH') || exit;

/**
 * WooCommerce product class for Store Credit products.
 */
class StoreCreditProduct extends \WC_Product_Simple
{
    /**
     * Return the custom product type so WooCommerce admin reloads select it.
     *
     * @return string
     */
    public function get_type()
    {
        return 'arraysubs_store_credit';
    }

    /**
     * Store credit products can be purchasable even when custom pricing leaves
     * the stored product price empty.
     *
     * @return bool
     */
    public function is_purchasable()
    {
        return $this->exists()
            && ('publish' === $this->get_status() || current_user_can('edit_post', $this->get_id()));
    }
}

/**
 * Credit Purchase class
 */
class CreditPurchase
{
    /**
     * Enable auto-loading
     *
     * @var bool
     */
    public static $loadable = true;

    /**
     * Product meta key to identify credit products
     */
    const CREDIT_PRODUCT_META = '_arraysubs_credit_product';

    /**
     * Order meta key to track processed credit orders
     */
    const ORDER_PROCESSED_META = '_arraysubs_credit_purchase_processed';

    /**
     * Constructor
     */
    public function __construct()
    {
        // Only load if feature is enabled
        if (!$this->isEnabled()) {
            return;
        }

        // Add product type option
        add_filter('product_type_selector', [$this, 'addProductType']);

        // Register product type class
        add_filter('woocommerce_product_class', [$this, 'productClass'], 10, 2);

        // Hide tabs for credit products
        add_filter('woocommerce_product_data_tabs', [$this, 'filterProductDataTabs']);

        // Add product data fields to General tab
        add_action('woocommerce_product_options_general_product_data', [$this, 'addProductDataFields']);

        // Save product meta
        add_action('woocommerce_process_product_meta', [$this, 'saveProductMeta']);

        // Make credit products virtual and downloadable
        add_filter('woocommerce_product_is_virtual', [$this, 'forceVirtual'], 10, 2);
        add_filter('woocommerce_product_needs_shipping', [$this, 'disableShipping'], 10, 2);

        // Process credit on order completion (multiple hooks for different payment flows)
        add_action('woocommerce_payment_complete', [$this, 'processCreditPurchase'], 10, 1);
        add_action('woocommerce_order_status_completed', [$this, 'processCreditPurchase'], 10, 1);
        add_action('woocommerce_order_status_processing', [$this, 'processCreditPurchase'], 10, 1);

        // Display credit amount on product page
        add_action('woocommerce_single_product_summary', [$this, 'displayCreditInfo'], 15);

        // Render the single-product add-to-cart form for the custom product type
        add_action('woocommerce_arraysubs_store_credit_add_to_cart', [$this, 'renderSingleAddToCartForm']);

        // Customize add to cart button text
        add_filter('woocommerce_product_single_add_to_cart_text', [$this, 'addToCartText'], 10, 2);
        add_filter('woocommerce_product_add_to_cart_text', [$this, 'addToCartText'], 10, 2);

        // Treat store credit purchases like subscription items for checkout behavior.
        add_filter('arraysubs_is_subscription_checkout_product', [$this, 'markCreditProductAsSubscriptionCheckoutItem'], 10, 2);

        // Add credit amount to cart item
        add_filter('woocommerce_add_cart_item_data', [$this, 'addCartItemData'], 10, 3);

        // Set custom price for cart item
        add_action('woocommerce_before_calculate_totals', [$this, 'setCustomCartItemPrice'], 10, 1);

        // Display credit in cart
        add_filter('woocommerce_get_item_data', [$this, 'displayCartItemData'], 10, 2);

        // Save credit amount to order item
        add_action('woocommerce_checkout_create_order_line_item', [$this, 'saveOrderItemMeta'], 10, 4);

        // Validate custom credit nonce
        add_filter('woocommerce_add_to_cart_validation', [$this, 'validateCustomCreditAmount'], 10, 3);

        // Register shortcode for credit purchase form
        add_shortcode('arraysubs_buy_credits', [$this, 'buyCreditsShortcode']);
        add_filter('arraysubs_shortcode_registry', [$this, 'addShortcodeRegistry']);
    }

    /**
     * Add Store Credit shortcodes to the shared registry.
     *
     * @param array $shortcodes Existing shortcode registry.
     * @return array
     */
    public function addShortcodeRegistry(array $shortcodes): array
    {
        $shortcodes[] = [
            'tag' => 'arraysubs_buy_credits',
            'title' => __('Buy Store Credits', 'arraysubspro'),
            'description' => __('Render a storefront purchase form for buying customer store credits.', 'arraysubspro'),
            'availability' => 'pro',
            'group' => __('Store Credit', 'arraysubspro'),
            'usage' => '[arraysubs_buy_credits product_id="123"]',
            'examples' => [
                '[arraysubs_buy_credits]',
                '[arraysubs_buy_credits product_id="123"]',
            ],
            'attributes' => [
                ['name' => 'product_id', 'description' => __('Optional store credit product ID to render directly. If omitted, the available purchase form or product list is shown.', 'arraysubspro')],
            ],
        ];

        return $shortcodes;
    }

    /**
     * Check if credit purchase is enabled
     *
     * @return bool
     */
    private function isEnabled(): bool
    {
        $settings = get_option('arraysubs_settings', []);
        $store_credit = $settings['store_credit'] ?? [];

        return !empty($store_credit['enabled']) && !empty($store_credit['enable_purchase']);
    }

    /**
     * Get purchase settings
     *
     * @return array
     */
    public static function getSettings(): array
    {
        $settings = get_option('arraysubs_settings', []);
        $store_credit = $settings['store_credit'] ?? [];

        return [
            'enabled'        => !empty($store_credit['enabled']) && !empty($store_credit['enable_purchase']),
            'min_amount'     => (float) ($store_credit['min_purchase_amount'] ?? 10),
            'max_amount'     => (float) ($store_credit['max_purchase_amount'] ?? 1000),
            'default_amount' => (float) ($store_credit['default_purchase_amount'] ?? 50),
        ];
    }

    /**
     * Add store credit product type
     *
     * @param array $types Product types
     * @return array
     */
    public function addProductType(array $types): array
    {
        $types['arraysubs_store_credit'] = __('Store Credit', 'arraysubspro');
        return $types;
    }

    /**
     * Register product class for store credit type
     *
     * @param string $classname Product class name
     * @param string $product_type Product type
     * @return string
     */
    public function productClass(string $classname, string $product_type): string
    {
        if ($product_type === 'arraysubs_store_credit') {
            return StoreCreditProduct::class;
        }
        return $classname;
    }

    /**
     * Filter product data tabs - hide irrelevant tabs for credit products
     *
     * @param array $tabs Product data tabs
     * @return array
     */
    public function filterProductDataTabs(array $tabs): array
    {
        // Add hide class to tabs that shouldn't show for credit products
        if (isset($tabs['attribute'])) {
            $tabs['attribute']['class'][] = 'hide_if_arraysubs_store_credit';
        }
        if (isset($tabs['linked_product'])) {
            $tabs['linked_product']['class'][] = 'hide_if_arraysubs_store_credit';
        }
        if (isset($tabs['shipping'])) {
            $tabs['shipping']['class'][] = 'hide_if_arraysubs_store_credit';
        }
        if (isset($tabs['inventory'])) {
            $tabs['inventory']['class'][] = 'hide_if_arraysubs_store_credit';
        }

        return $tabs;
    }

    /**
     * Add product data fields to General tab
     */
    public function addProductDataFields(): void
    {
        global $post;

        $settings = self::getSettings();

        echo '<div class="options_group show_if_arraysubs_store_credit">';

        // Credit amount type (removed "price" option as it's redundant with fixed)
        woocommerce_wp_select([
            'id'          => '_arraysubs_credit_amount_type',
            'label'       => __('Credit Amount Type', 'arraysubspro'),
            'description' => __('How should the credit amount be determined?', 'arraysubspro'),
            'desc_tip'    => true,
            'options'     => [
                'fixed'    => __('Fixed Amount', 'arraysubspro'),
                'custom'   => __('Customer Enters Amount', 'arraysubspro'),
            ],
        ]);

        // Fixed credit amount
        woocommerce_wp_text_input([
            'id'                => '_arraysubs_credit_amount',
            'label'             => __('Credit Amount', 'arraysubspro') . ' (' . get_woocommerce_currency_symbol() . ')',
            'description'       => __('Fixed credit amount to add when purchased.', 'arraysubspro'),
            'desc_tip'          => true,
            'type'              => 'number',
            'custom_attributes' => [
                'step' => '0.01',
                'min'  => '0',
            ],
        ]);

        // Bonus credit percentage
        woocommerce_wp_text_input([
            'id'                => '_arraysubs_bonus_percentage',
            'label'             => __('Bonus Credit (%)', 'arraysubspro'),
            'description'       => __('Optional bonus percentage. E.g., 10 means customer gets 10% extra credit.', 'arraysubspro'),
            'desc_tip'          => true,
            'type'              => 'number',
            'custom_attributes' => [
                'step' => '0.01',
                'min'  => '0',
                'max'  => '100',
            ],
        ]);

        // Info box
        echo '<p class="form-field">';
        echo '<span style="margin-left: 150px; display: block; background: #f0f6fc; padding: 10px; border-left: 4px solid #2271b1;">';
        printf(
            /* translators: %1$s: min amount, %2$s: max amount */
            esc_html__('Purchase limits: Min %1$s - Max %2$s (configured in ArraySubsPro Settings)', 'arraysubspro'),
            wp_kses_post(wc_price($settings['min_amount'])),
            wp_kses_post(wc_price($settings['max_amount']))
        );
        echo '</span>';
        echo '</p>';

        // Mark as credit product
        echo '<input type="hidden" name="' . esc_attr(self::CREDIT_PRODUCT_META) . '" value="yes">';

        echo '</div>';
    }

    /**
     * Save product meta
     *
     * @param int $post_id Product ID
     */
    public function saveProductMeta(int $post_id): void
    {
        // Verify WooCommerce nonce
        if (
            !isset($_POST['woocommerce_meta_nonce'])
            || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['woocommerce_meta_nonce'])), 'woocommerce_save_data')
        ) {
            return;
        }

        // Check if it's a credit product
        $product_type = isset($_POST['product-type']) ? sanitize_text_field(wp_unslash($_POST['product-type'])) : '';

        if ($product_type === 'arraysubs_store_credit') {
            update_post_meta($post_id, self::CREDIT_PRODUCT_META, 'yes');
            update_post_meta($post_id, '_virtual', 'yes');
            update_post_meta($post_id, '_sold_individually', 'yes');

            // Save credit settings
            if (isset($_POST['_arraysubs_credit_amount_type'])) {
                update_post_meta($post_id, '_arraysubs_credit_amount_type', sanitize_text_field(wp_unslash($_POST['_arraysubs_credit_amount_type'])));
            }

            if (isset($_POST['_arraysubs_credit_amount'])) {
                update_post_meta($post_id, '_arraysubs_credit_amount', wc_format_decimal(sanitize_text_field(wp_unslash($_POST['_arraysubs_credit_amount']))));
            }

            if (isset($_POST['_arraysubs_bonus_percentage'])) {
                update_post_meta($post_id, '_arraysubs_bonus_percentage', wc_format_decimal(sanitize_text_field(wp_unslash($_POST['_arraysubs_bonus_percentage']))));
            }
        } else {
            delete_post_meta($post_id, self::CREDIT_PRODUCT_META);
        }
    }

    /**
     * Force credit products to be virtual
     *
     * @param bool       $virtual Is virtual
     * @param WC_Product $product Product
     * @return bool
     */
    public function forceVirtual($virtual, $product): bool
    {
        if ($this->isCreditProduct($product)) {
            return true;
        }
        return $virtual;
    }

    /**
     * Disable shipping for credit products
     *
     * @param bool       $needs_shipping Needs shipping
     * @param WC_Product $product        Product
     * @return bool
     */
    public function disableShipping($needs_shipping, $product): bool
    {
        if ($this->isCreditProduct($product)) {
            return false;
        }
        return $needs_shipping;
    }

    /**
     * Check if product is a credit product
     *
     * @param WC_Product|int $product Product or ID
     * @return bool
     */
    public function isCreditProduct($product): bool
    {
        if (is_numeric($product)) {
            $product = wc_get_product($product);
        }

        if (!$product) {
            return false;
        }

        return get_post_meta($product->get_id(), self::CREDIT_PRODUCT_META, true) === 'yes';
    }

    /**
     * Process credit purchase on order completion
     *
     * @param int $order_id Order ID
     */
    public function processCreditPurchase(int $order_id): void
    {
        $order = wc_get_order($order_id);

        if (!$order) {
            return;
        }

        // Check if already processed
        if ($order->get_meta(self::ORDER_PROCESSED_META) === 'yes') {
            return;
        }

        $customer_id = $order->get_customer_id();

        if (!$customer_id) {
            return;
        }

        $total_credit = 0;
        $has_credit_items = false;

        foreach ($order->get_items() as $item) {
            $product_id = $item->get_product_id();

            // Check if this is a credit product (from order item meta or product meta)
            $is_credit_item = $item->get_meta('_arraysubs_is_credit_product') === 'yes';
            $is_credit_product = $this->isCreditProduct($product_id);

            if (!$is_credit_item && !$is_credit_product) {
                continue;
            }

            $has_credit_items = true;

            // Get credit amount from order item meta first
            $credit_amount = (float) $item->get_meta('_arraysubs_credit_amount');

            // If not in order item meta, calculate from product settings
            if (!$credit_amount || $credit_amount <= 0) {
                $credit_amount = $this->calculateCreditAmount($product_id, $item);
            }

            if ($credit_amount > 0) {
                // Get bonus percentage from order item meta or product meta
                $bonus_percentage = (float) $item->get_meta('_arraysubs_bonus_percentage');
                if (!$bonus_percentage) {
                    $bonus_percentage = (float) get_post_meta($product_id, '_arraysubs_bonus_percentage', true);
                }

                if ($bonus_percentage > 0) {
                    $bonus = $credit_amount * ($bonus_percentage / 100);
                    $credit_amount += $bonus;
                }

                $total_credit += $credit_amount;
            }
        }

        // Only mark as processed if we had credit items
        if (!$has_credit_items) {
            return;
        }

        if ($total_credit > 0) {
            // Add credit to customer
            $log_id = CreditManager::addCustomerCredit(
                $customer_id,
                $total_credit,
                CreditManager::SOURCE_PURCHASE,
                $order_id,
                sprintf(
                    /* translators: %d: order ID */
                    __('Store credit purchase from Order #%d', 'arraysubspro'),
                    $order_id
                )
            );

            if ($log_id) {
                // Add order note
                $order->add_order_note(
                    sprintf(
                        /* translators: %s: credit amount */
                        __('Store credit of %s added to customer account.', 'arraysubspro'),
                        wc_price($total_credit)
                    )
                );

                // Trigger email
                do_action('arraysubs_credit_purchased', $customer_id, $total_credit, $order_id);
            }
        }

        // Mark as processed
        $order->update_meta_data(self::ORDER_PROCESSED_META, 'yes');
        $order->save();
    }

    /**
     * Calculate credit amount for order item
     *
     * @param int           $product_id Product ID
     * @param WC_Order_Item $item       Order item
     * @return float
     */
    private function calculateCreditAmount(int $product_id, $item): float
    {
        $amount_type = get_post_meta($product_id, '_arraysubs_credit_amount_type', true);

        switch ($amount_type) {
            case 'fixed':
                $fixed_amount = (float) get_post_meta($product_id, '_arraysubs_credit_amount', true);
                // Fall back to item total if fixed amount not set
                return $fixed_amount > 0 ? $fixed_amount : (float) $item->get_total();

            case 'custom':
                // For custom, check order item meta first, then fall back to total
                $custom_amount = (float) $item->get_meta('_arraysubs_custom_credit_amount');
                return $custom_amount > 0 ? $custom_amount : (float) $item->get_total();

            default:
                // Default to the item total (price paid)
                return (float) $item->get_total();
        }
    }

    /**
     * Display credit info on single product page
     */
    public function displayCreditInfo(): void
    {
        global $product;

        if (!$this->isCreditProduct($product)) {
            return;
        }

        $amount_type = get_post_meta($product->get_id(), '_arraysubs_credit_amount_type', true);
        $bonus_percentage = (float) get_post_meta($product->get_id(), '_arraysubs_bonus_percentage', true);

        echo '<div class="arraysubspro-credit-product-info">';

        if ($amount_type === 'fixed') {
            $credit_amount = (float) get_post_meta($product->get_id(), '_arraysubs_credit_amount', true);
            printf(
                '<p class="credit-amount"><strong>%s</strong> %s</p>',
                esc_html__('Credit Amount:', 'arraysubspro'),
                wp_kses_post(wc_price($credit_amount))
            );
        } elseif ($amount_type === 'custom') {
            $settings = self::getSettings();
            printf(
                '<p class="credit-custom">%s</p>',
                sprintf(
                    /* translators: %1$s: min amount, %2$s: max amount */
                    esc_html__('Enter amount between %1$s and %2$s', 'arraysubspro'),
                    wp_kses_post(wc_price($settings['min_amount'])),
                    wp_kses_post(wc_price($settings['max_amount']))
                )
            );
        }

        if ($bonus_percentage > 0) {
            printf(
                '<p class="credit-bonus"><span class="bonus-badge">+%s%% %s</span></p>',
                esc_html($bonus_percentage),
                esc_html__('Bonus', 'arraysubspro')
            );
        }

        echo '</div>';
    }

    /**
     * Customize add to cart button text
     *
     * @param string     $text    Button text
     * @param WC_Product $product Product
     * @return string
     */
    public function addToCartText(string $text, $product): string
    {
        if ($this->isCreditProduct($product)) {
            return __('Buy Credits', 'arraysubspro');
        }
        return $text;
    }

    /**
     * Render single-product purchase controls for Store Credit products.
     */
    public function renderSingleAddToCartForm(): void
    {
        global $product;

        if (!$this->isCreditProduct($product)) {
            return;
        }

        $product_id = $product->get_id();
        $amount_type = get_post_meta($product_id, '_arraysubs_credit_amount_type', true);
        $settings = self::getSettings();
        ?>
        <form class="cart arraysubspro-credit-cart" action="<?php echo esc_url(apply_filters('woocommerce_add_to_cart_form_action', $product->get_permalink())); ?>" method="post" enctype="multipart/form-data">
            <?php do_action('woocommerce_before_add_to_cart_button'); ?>

            <?php if ('custom' === $amount_type) : ?>
                <div class="arraysubspro-credit-cart__amount">
                    <label for="arraysubs_credit_amount"><?php esc_html_e('Credit Amount', 'arraysubspro'); ?></label>
                    <input
                        type="number"
                        id="arraysubs_credit_amount"
                        name="arraysubs_credit_amount"
                        value="<?php echo esc_attr($settings['default_amount']); ?>"
                        min="<?php echo esc_attr($settings['min_amount']); ?>"
                        max="<?php echo esc_attr($settings['max_amount']); ?>"
                        step="0.01"
                        required
                    >
                </div>
                <?php wp_nonce_field('arraysubs_custom_credit', 'arraysubs_credit_nonce'); ?>
            <?php endif; ?>

            <button type="submit" name="add-to-cart" value="<?php echo esc_attr($product_id); ?>" class="single_add_to_cart_button button alt">
                <?php esc_html_e('Buy Credits', 'arraysubspro'); ?>
            </button>

            <?php do_action('woocommerce_after_add_to_cart_button'); ?>
        </form>
        <?php
    }

    /**
     * Mark store credit products as subscription-like for checkout behavior.
     *
     * @param bool $is_subscription_checkout_product Current classification.
     * @param int  $product_id                       Product ID.
     * @return bool
     */
    public function markCreditProductAsSubscriptionCheckoutItem(bool $is_subscription_checkout_product, int $product_id): bool
    {
        if ($is_subscription_checkout_product) {
            return true;
        }

        return $this->isCreditProduct($product_id);
    }

    /**
     * Add custom data to cart item
     *
     * @param array $cart_item_data Cart item data
     * @param int   $product_id     Product ID
     * @param int   $variation_id   Variation ID
     * @return array
     */
    public function addCartItemData(array $cart_item_data, int $product_id, int $variation_id): array
    {
        if (!$this->isCreditProduct($product_id)) {
            return $cart_item_data;
        }

        $amount_type = get_post_meta($product_id, '_arraysubs_credit_amount_type', true);

        if (
            $amount_type === 'custom'
            && isset($_POST['arraysubs_credit_nonce'])
            && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['arraysubs_credit_nonce'])), 'arraysubs_custom_credit')
            && isset($_POST['arraysubs_credit_amount'])
        ) {
            $settings = self::getSettings();
            $custom_amount = (float) sanitize_text_field(wp_unslash($_POST['arraysubs_credit_amount']));

            // Validate amount
            $custom_amount = max($settings['min_amount'], min($settings['max_amount'], $custom_amount));

            $cart_item_data['arraysubs_credit_amount'] = $custom_amount;
            $cart_item_data['unique_key'] = md5(microtime() . wp_rand());
        }

        return $cart_item_data;
    }

    /**
     * Display cart item data
     *
     * @param array $item_data Cart item data
     * @param array $cart_item Cart item
     * @return array
     */
    public function displayCartItemData(array $item_data, array $cart_item): array
    {
        if (isset($cart_item['arraysubs_credit_amount'])) {
            $item_data[] = [
                'key'   => __('Credit Amount', 'arraysubspro'),
                'value' => wc_price($cart_item['arraysubs_credit_amount']),
            ];
        }

        return $item_data;
    }

    /**
     * Save order item meta
     *
     * @param WC_Order_Item_Product $item          Order item
     * @param string                $cart_item_key Cart item key
     * @param array                 $values        Cart item values
     * @param WC_Order              $order         Order
     */
    public function saveOrderItemMeta($item, $cart_item_key, $values, $order): void
    {
        $product_id = $item->get_product_id();

        // Check if this is a credit product
        if (!$this->isCreditProduct($product_id)) {
            return;
        }

        // Mark this order item as a credit purchase
        $item->add_meta_data('_arraysubs_is_credit_product', 'yes', true);

        // For custom amount products, save the custom amount
        if (isset($values['arraysubs_credit_amount']) && $values['arraysubs_credit_amount'] > 0) {
            $item->add_meta_data('_arraysubs_credit_amount', (float) $values['arraysubs_credit_amount'], true);
            $item->add_meta_data('_arraysubs_custom_credit_amount', (float) $values['arraysubs_credit_amount'], true);
        } else {
            // For fixed amount products, save the fixed amount from product meta
            $amount_type = get_post_meta($product_id, '_arraysubs_credit_amount_type', true);

            if ($amount_type === 'fixed') {
                $credit_amount = (float) get_post_meta($product_id, '_arraysubs_credit_amount', true);
                if ($credit_amount > 0) {
                    $item->add_meta_data('_arraysubs_credit_amount', $credit_amount, true);
                }
            }
        }

        // Save bonus percentage for reference
        $bonus = (float) get_post_meta($product_id, '_arraysubs_bonus_percentage', true);
        if ($bonus > 0) {
            $item->add_meta_data('_arraysubs_bonus_percentage', $bonus, true);
        }
    }

    /**
     * Validate custom credit amount before adding to cart
     *
     * @param bool $passed     Validation passed
     * @param int  $product_id Product ID
     * @param int  $quantity   Quantity
     * @return bool
     */
    public function validateCustomCreditAmount($passed, $product_id, $quantity): bool
    {
        if (!$this->isCreditProduct($product_id)) {
            return $passed;
        }

        $amount_type = get_post_meta($product_id, '_arraysubs_credit_amount_type', true);

        if ($amount_type === 'custom') {
            // Verify nonce
            if (
                !isset($_POST['arraysubs_credit_nonce'])
                || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['arraysubs_credit_nonce'])), 'arraysubs_custom_credit')
            ) {
                wc_add_notice(__('Security check failed. Please try again.', 'arraysubspro'), 'error');
                return false;
            }

            // Check if amount is provided
            if (!isset($_POST['arraysubs_credit_amount']) || empty($_POST['arraysubs_credit_amount'])) {
                wc_add_notice(__('Please enter a credit amount.', 'arraysubspro'), 'error');
                return false;
            }

            $settings = self::getSettings();
            $amount = (float) sanitize_text_field(wp_unslash($_POST['arraysubs_credit_amount']));

            if ($amount < $settings['min_amount']) {
                wc_add_notice(
                    sprintf(
                        /* translators: %s: minimum amount */
                        __('Minimum credit amount is %s.', 'arraysubspro'),
                        wc_price($settings['min_amount'])
                    ),
                    'error'
                );
                return false;
            }

            if ($amount > $settings['max_amount']) {
                wc_add_notice(
                    sprintf(
                        /* translators: %s: maximum amount */
                        __('Maximum credit amount is %s.', 'arraysubspro'),
                        wc_price($settings['max_amount'])
                    ),
                    'error'
                );
                return false;
            }
        }

        return $passed;
    }

    /**
     * Set custom price for cart items with custom credit amounts
     *
     * @param WC_Cart $cart Cart object
     */
    public function setCustomCartItemPrice($cart): void
    {
        if (is_admin() && !defined('DOING_AJAX')) {
            return;
        }

        if (did_action('woocommerce_before_calculate_totals') >= 2) {
            return;
        }

        foreach ($cart->get_cart() as $cart_item) {
            if (isset($cart_item['arraysubs_credit_amount']) && $cart_item['arraysubs_credit_amount'] > 0) {
                $cart_item['data']->set_price($cart_item['arraysubs_credit_amount']);
            }
        }
    }

    /**
     * Buy Credits shortcode
     *
     * @param array $atts Shortcode attributes
     * @return string
     */
    public function buyCreditsShortcode(array $atts = []): string
    {
        if (!is_user_logged_in()) {
            return '<p>' . esc_html__('Please log in to purchase store credits.', 'arraysubspro') . '</p>';
        }

        $atts = shortcode_atts([
            'product_id' => 0,
        ], $atts, 'arraysubs_buy_credits');

        $settings = self::getSettings();

        // If specific product provided, show that product
        if ($atts['product_id']) {
            $product = wc_get_product($atts['product_id']);
            if ($product && $this->isCreditProduct($product)) {
                ob_start();
                wc_get_template_part('content', 'single-product');
                return ob_get_clean();
            }
        }

        // Show credit purchase form
        ob_start();
        $this->renderBuyCreditsForm($settings);
        return ob_get_clean();
    }

    /**
     * Render buy credits form
     *
     * @param array $settings Purchase settings
     */
    private function renderBuyCreditsForm(array $settings): void
    {
        // Find a credit product
        $credit_products = wc_get_products([
            'meta_key'   => self::CREDIT_PRODUCT_META,
            'meta_value' => 'yes',
            'limit'      => 10,
            'status'     => 'publish',
        ]);

        if (empty($credit_products)) {
            echo '<p>' . esc_html__('No credit products available.', 'arraysubspro') . '</p>';
            return;
        }

?>
        <div class="arraysubspro-buy-credits">
            <h3><?php esc_html_e('Purchase Store Credit', 'arraysubspro'); ?></h3>

            <?php if (count($credit_products) > 1) : ?>
                <div class="credit-products-grid">
                    <?php foreach ($credit_products as $product) : ?>
                        <div class="credit-product-card">
                            <h4><?php echo esc_html($product->get_name()); ?></h4>
                            <p class="price"><?php echo wp_kses_post($product->get_price_html()); ?></p>
                            <?php
                            $bonus = (float) get_post_meta($product->get_id(), '_arraysubs_bonus_percentage', true);
                            if ($bonus > 0) :
                            ?>
                                <p class="bonus">+<?php echo esc_html($bonus); ?>% <?php esc_html_e('Bonus', 'arraysubspro'); ?></p>
                            <?php endif; ?>
                            <a href="<?php echo esc_url($product->add_to_cart_url()); ?>" class="button">
                                <?php esc_html_e('Buy Now', 'arraysubspro'); ?>
                            </a>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php
            else :
                $product = $credit_products[0];
                $amount_type = get_post_meta($product->get_id(), '_arraysubs_credit_amount_type', true);
            ?>
                <form class="credit-purchase-form" action="<?php echo esc_url($product->add_to_cart_url()); ?>" method="post">
                    <?php if ($amount_type === 'custom') : ?>
                        <div class="form-row">
                            <label for="arraysubs_credit_amount"><?php esc_html_e('Credit Amount', 'arraysubspro'); ?></label>
                            <input
                                type="number"
                                id="arraysubs_credit_amount"
                                name="arraysubs_credit_amount"
                                value="<?php echo esc_attr($settings['default_amount']); ?>"
                                min="<?php echo esc_attr($settings['min_amount']); ?>"
                                max="<?php echo esc_attr($settings['max_amount']); ?>"
                                step="0.01"
                                required>
                            <small>
                                <?php
                                printf(
                                    /* translators: %1$s: min amount, %2$s: max amount */
                                    esc_html__('Enter amount between %1$s and %2$s', 'arraysubspro'),
                                    wp_kses_post(wc_price($settings['min_amount'])),
                                    wp_kses_post(wc_price($settings['max_amount']))
                                );
                                ?>
                            </small>
                        </div>
                    <?php else : ?>
                        <p class="credit-amount">
                            <?php
                            printf(
                                /* translators: %s: credit amount */
                                esc_html__('Credit Amount: %s', 'arraysubspro'),
                                wp_kses_post(wc_price($product->get_price()))
                            );
                            ?>
                        </p>
                    <?php endif; ?>

                    <?php
                    $bonus = (float) get_post_meta($product->get_id(), '_arraysubs_bonus_percentage', true);
                    if ($bonus > 0) :
                    ?>
                        <p class="bonus-info">
                            <span class="bonus-badge">+<?php echo esc_html($bonus); ?>%</span>
                            <?php esc_html_e('Bonus credit included!', 'arraysubspro'); ?>
                        </p>
                    <?php endif; ?>

                    <input type="hidden" name="add-to-cart" value="<?php echo esc_attr($product->get_id()); ?>">

                    <button type="submit" class="button alt">
                        <?php esc_html_e('Purchase Credit', 'arraysubspro'); ?>
                    </button>
                </form>
            <?php endif; ?>
        </div>
<?php
    }

    /**
     * Get available credit products
     *
     * @return array
     */
    public static function getCreditProducts(): array
    {
        return wc_get_products([
            'meta_key'   => self::CREDIT_PRODUCT_META,
            'meta_value' => 'yes',
            'limit'      => -1,
            'status'     => 'publish',
        ]);
    }
}
