<?php

/**
 * Credit Manager
 *
 * Core credit operations for store credit system.
 * Handles adding, deducting, and retrieving credit balances.
 *
 * @package ArraySubsPro\Features\StoreCredit\Services
 * @since 1.0.0
 */

namespace ArraySubsPro\Features\StoreCredit\Services;

defined('ABSPATH') || exit;

/**
 * Credit Manager class
 */
class CreditManager
{
    /**
     * User meta key for customer-level credit
     */
    const USER_CREDIT_META = '_arraysubs_store_credit';

    /**
     * Post meta key for subscription-level credit
     */
    const SUBSCRIPTION_CREDIT_META = '_store_credit';

    /**
     * Credit transaction types
     */
    const TYPE_CREDIT = 'credit';
    const TYPE_DEBIT  = 'debit';

    /**
     * Credit source types
     */
    const SOURCE_DOWNGRADE     = 'downgrade';
    const SOURCE_REFUND        = 'refund';
    const SOURCE_ADMIN         = 'admin';
    const SOURCE_PROMOTIONAL   = 'promotional';
    const SOURCE_PURCHASE      = 'purchase';
    const SOURCE_RENEWAL       = 'renewal_applied';
    const SOURCE_ORDER         = 'order_applied';
    const SOURCE_EXPIRED       = 'expired';

    /**
     * Add credit to a subscription
     *
     * @param int         $subscription_id Subscription ID
     * @param float       $amount          Credit amount (positive)
     * @param string      $source          Source type
     * @param int|null    $source_id       Related source ID
     * @param string      $note            Note for the transaction
     * @param string|null $currency        Currency code
     *
     * @return array Result data.
     */
    public static function addSubscriptionCredit(
        int $subscription_id,
        float $amount,
        string $source,
        ?int $source_id = null,
        string $note = '',
        ?string $currency = null
    ) {
        if ($amount <= 0) {
            return false;
        }

        $subscription = get_post($subscription_id);
        if (!$subscription || $subscription->post_type !== 'arraysubs_data') {
            return false;
        }

        $customer_id = (int) get_post_meta($subscription_id, '_customer_id', true);
        if (!$customer_id) {
            return false;
        }

        $currency = $currency ?: get_woocommerce_currency();

        // Get current balance
        $current_balance = self::getSubscriptionCredit($subscription_id);

        // Update balance
        $new_balance = $current_balance + $amount;
        update_post_meta($subscription_id, self::SUBSCRIPTION_CREDIT_META, $new_balance);

        // Log the transaction
        $log_id = TransactionLogger::log([
            'customer_id'     => $customer_id,
            'subscription_id' => $subscription_id,
            'amount'          => $amount,
            'type'            => self::TYPE_CREDIT,
            'source'          => $source,
            'source_id'       => $source_id,
            'balance_after'   => $new_balance,
            'note'            => $note,
            'currency'        => $currency,
        ]);

        /**
         * Fires when subscription credit is added
         *
         * @param int    $subscription_id Subscription ID
         * @param float  $amount          Credit amount
         * @param float  $new_balance     New balance
         * @param string $source          Source type
         */
        do_action('arraysubs_subscription_credit_added', $subscription_id, $amount, $new_balance, $source);

        return $log_id;
    }

    /**
     * Deduct credit from a subscription
     *
     * @param int         $subscription_id Subscription ID
     * @param float       $amount          Amount to deduct (positive)
     * @param string      $source          Source type
     * @param int|null    $source_id       Related source ID
     * @param string      $note            Note for the transaction
     * @param string|null $currency        Currency code
     *
     * @return array Result data.
     */
    public static function deductSubscriptionCredit(
        int $subscription_id,
        float $amount,
        string $source,
        ?int $source_id = null,
        string $note = '',
        ?string $currency = null
    ) {
        if ($amount <= 0) {
            return false;
        }

        $current_balance = self::getSubscriptionCredit($subscription_id);
        if ($current_balance <= 0) {
            return false;
        }

        $customer_id = (int) get_post_meta($subscription_id, '_customer_id', true);
        $currency = $currency ?: get_woocommerce_currency();

        // Don't deduct more than available
        $actual_deduction = min($amount, $current_balance);
        $new_balance = $current_balance - $actual_deduction;

        // Update balance
        update_post_meta($subscription_id, self::SUBSCRIPTION_CREDIT_META, $new_balance);

        // Log the transaction
        $log_id = TransactionLogger::log([
            'customer_id'     => $customer_id,
            'subscription_id' => $subscription_id,
            'amount'          => $actual_deduction,
            'type'            => self::TYPE_DEBIT,
            'source'          => $source,
            'source_id'       => $source_id,
            'balance_after'   => $new_balance,
            'note'            => $note,
            'currency'        => $currency,
        ]);

        /**
         * Fires when subscription credit is deducted
         *
         * @param int    $subscription_id Subscription ID
         * @param float  $amount          Deducted amount
         * @param float  $new_balance     New balance
         * @param string $source          Source type
         */
        do_action('arraysubs_subscription_credit_deducted', $subscription_id, $actual_deduction, $new_balance, $source);

        return $log_id;
    }

    /**
     * Add credit to a customer account
     *
     * @param int         $customer_id Customer user ID
     * @param float       $amount      Credit amount (positive)
     * @param string      $source      Source type
     * @param int|null    $source_id   Related source ID
     * @param string      $note        Note for the transaction
     * @param string|null $currency    Currency code
     *
     * @return int|false Transaction log ID or false on failure
     */
    public static function addCustomerCredit(
        int $customer_id,
        float $amount,
        string $source,
        ?int $source_id = null,
        string $note = '',
        ?string $currency = null
    ) {
        if ($amount <= 0 || !$customer_id) {
            return false;
        }

        $user = get_user_by('ID', $customer_id);
        if (!$user) {
            return false;
        }

        $currency = $currency ?: get_woocommerce_currency();

        // Get current balance
        $current_balance = self::getCustomerCredit($customer_id);

        // Update balance
        $new_balance = $current_balance + $amount;
        update_user_meta($customer_id, self::USER_CREDIT_META, $new_balance);

        // Log the transaction
        $log_id = TransactionLogger::log([
            'customer_id'     => $customer_id,
            'subscription_id' => null,
            'amount'          => $amount,
            'type'            => self::TYPE_CREDIT,
            'source'          => $source,
            'source_id'       => $source_id,
            'balance_after'   => $new_balance,
            'note'            => $note,
            'currency'        => $currency,
        ]);

        /**
         * Fires when customer credit is added
         *
         * @param int    $customer_id Customer user ID
         * @param float  $amount      Credit amount
         * @param float  $new_balance New balance
         * @param string $source      Source type
         */
        do_action('arraysubs_customer_credit_added', $customer_id, $amount, $new_balance, $source);

        return $log_id;
    }

    /**
     * Deduct credit from a customer account
     *
     * @param int         $customer_id Customer user ID
     * @param float       $amount      Amount to deduct (positive)
     * @param string      $source      Source type
     * @param int|null    $source_id   Related source ID
     * @param string      $note        Note for the transaction
     * @param string|null $currency    Currency code
     *
     * @return int|false Transaction log ID or false on failure
     */
    public static function deductCustomerCredit(
        int $customer_id,
        float $amount,
        string $source,
        ?int $source_id = null,
        string $note = '',
        ?string $currency = null
    ) {
        if ($amount <= 0 || !$customer_id) {
            return false;
        }

        $current_balance = self::getCustomerCredit($customer_id);
        if ($current_balance <= 0) {
            return false;
        }

        $currency = $currency ?: get_woocommerce_currency();

        // Don't deduct more than available
        $actual_deduction = min($amount, $current_balance);
        $new_balance = $current_balance - $actual_deduction;

        // Update balance
        update_user_meta($customer_id, self::USER_CREDIT_META, $new_balance);

        // Log the transaction
        $log_id = TransactionLogger::log([
            'customer_id'     => $customer_id,
            'subscription_id' => null,
            'amount'          => $actual_deduction,
            'type'            => self::TYPE_DEBIT,
            'source'          => $source,
            'source_id'       => $source_id,
            'balance_after'   => $new_balance,
            'note'            => $note,
            'currency'        => $currency,
        ]);

        /**
         * Fires when customer credit is deducted
         *
         * @param int    $customer_id Customer user ID
         * @param float  $amount      Deducted amount
         * @param float  $new_balance New balance
         * @param string $source      Source type
         */
        do_action('arraysubs_customer_credit_deducted', $customer_id, $actual_deduction, $new_balance, $source);

        return $log_id;
    }

    /**
     * Get subscription credit balance
     *
     * @param int $subscription_id Subscription ID
     *
     * @return float Credit balance
     */
    public static function getSubscriptionCredit(int $subscription_id): float
    {
        return (float) get_post_meta($subscription_id, self::SUBSCRIPTION_CREDIT_META, true);
    }

    /**
     * Get customer credit balance
     *
     * @param int $customer_id Customer user ID
     *
     * @return float Credit balance
     */
    public static function getCustomerCredit(int $customer_id): float
    {
        return (float) get_user_meta($customer_id, self::USER_CREDIT_META, true);
    }

    /**
     * Get total available credit for a subscription's renewal
     * (Subscription credit + Customer credit)
     *
     * @param int $subscription_id Subscription ID
     *
     * @return array {subscription: float, customer: float, total: float}
     */
    public static function getTotalAvailableCredit(int $subscription_id): array
    {
        $subscription_credit = self::getSubscriptionCredit($subscription_id);
        $customer_id = (int) get_post_meta($subscription_id, '_customer_id', true);
        $customer_credit = $customer_id ? self::getCustomerCredit($customer_id) : 0;

        return [
            'subscription' => $subscription_credit,
            'customer'     => $customer_credit,
            'total'        => $subscription_credit + $customer_credit,
        ];
    }

    /**
     * Apply credits to an order
     *
     * Priority: Subscription credit first, then customer credit
     *
     * @param \WC_Order $order           Order object
     * @param int|null  $subscription_id Subscription ID (optional)
     *
     * @return float Total credits applied
     */
    public static function applyCreditsToOrder(\WC_Order $order, ?int $subscription_id = null): float
    {
        // Idempotency guard: if credit was already applied to this order
        // (and not since reversed), do not deduct a second time. The renewal
        // pipeline can re-fire `arraysubs_renewal_invoice_created` on the
        // same order during retries, and without this guard each pass would
        // double-debit the customer's balance.
        $already_applied = (float) $order->get_meta('_arraysubs_credit_applied');
        if ($already_applied > 0) {
            return 0.0;
        }

        $order_total = $order->get_total();
        $customer_id = $order->get_customer_id();

        if ($order_total <= 0 || !$customer_id) {
            return 0.0;
        }

        $total_applied = 0.0;
        $remaining_to_pay = $order_total;
        $currency = $order->get_currency();
        $applied_from_subscription = 0.0;
        $applied_from_customer = 0.0;

        // 1. Apply subscription credit first (if subscription provided)
        if ($subscription_id) {
            $subscription_credit = self::getSubscriptionCredit($subscription_id);

            if ($subscription_credit > 0) {
                $apply_from_subscription = min($subscription_credit, $remaining_to_pay);

                if ($apply_from_subscription > 0) {
                    self::deductSubscriptionCredit(
                        $subscription_id,
                        $apply_from_subscription,
                        self::SOURCE_RENEWAL,
                        $order->get_id(),
                        sprintf(
                            /* translators: %d: order ID */
                            __('Applied to renewal order #%d', 'arraysubspro'),
                            $order->get_id()
                        ),
                        $currency
                    );

                    $total_applied += $apply_from_subscription;
                    $remaining_to_pay -= $apply_from_subscription;
                    $applied_from_subscription = $apply_from_subscription;
                }
            }
        }

        // 2. Apply customer credit
        if ($remaining_to_pay > 0) {
            $customer_credit = self::getCustomerCredit($customer_id);

            if ($customer_credit > 0) {
                $apply_from_customer = min($customer_credit, $remaining_to_pay);

                if ($apply_from_customer > 0) {
                    self::deductCustomerCredit(
                        $customer_id,
                        $apply_from_customer,
                        $subscription_id ? self::SOURCE_RENEWAL : self::SOURCE_ORDER,
                        $order->get_id(),
                        sprintf(
                            /* translators: %d: order ID */
                            __('Applied to order #%d', 'arraysubspro'),
                            $order->get_id()
                        ),
                        $currency
                    );

                    $total_applied += $apply_from_customer;
                    $remaining_to_pay -= $apply_from_customer;
                    $applied_from_customer = $apply_from_customer;
                }
            }
        }

        // Apply discount to order if credits were applied
        if ($total_applied > 0) {
            // Add a fee line item for the credit (negative value = discount)
            $fee = new \WC_Order_Item_Fee();
            $fee->set_name(__('Store Credit Applied', 'arraysubspro'));
            $fee->set_amount(-$total_applied);
            $fee->set_total(-$total_applied);
            $fee->set_tax_status('none');
            $order->add_item($fee);

            // Store credit info in order meta. The split between subscription
            // and customer buckets is preserved so reverseCreditsForOrder()
            // can return the correct amounts to each source on failure.
            $order->update_meta_data('_arraysubs_credit_applied', $total_applied);
            $order->update_meta_data('_arraysubs_credit_subscription_id', $subscription_id);
            $order->update_meta_data('_arraysubs_credit_from_subscription', $applied_from_subscription);
            $order->update_meta_data('_arraysubs_credit_from_customer', $applied_from_customer);
            $order->delete_meta_data('_arraysubs_credit_reversed');

            // Recalculate totals
            $order->calculate_totals();

            // Add order note
            $order->add_order_note(
                sprintf(
                    /* translators: %s: credit amount */
                    __('Store credit applied: %s', 'arraysubspro'),
                    wc_price($total_applied, ['currency' => $currency])
                )
            );

            $order->save();

            /**
             * Fires when credits are applied to an order
             *
             * @param \WC_Order $order           Order object
             * @param float     $total_applied   Total credits applied
             * @param int|null  $subscription_id Subscription ID if renewal
             */
            do_action('arraysubs_credits_applied_to_order', $order, $total_applied, $subscription_id);
        }

        return $total_applied;
    }

    /**
     * Capture the Store Credit fee already copied from cart to order.
     *
     * @param \WC_Order $order Order object.
     * @return float Captured credit amount.
     */
    public static function captureAppliedCheckoutCredit(\WC_Order $order): float
    {
        $already_applied = (float) $order->get_meta('_arraysubs_credit_applied');
        if ($already_applied > 0) {
            return 0.0;
        }

        $fee_amount = 0.0;
        $credit_fee = null;
        foreach ($order->get_items('fee') as $fee_item) {
            if (!$fee_item instanceof \WC_Order_Item_Fee) {
                continue;
            }

            if (__('Store Credit Applied', 'arraysubspro') !== $fee_item->get_name()) {
                continue;
            }

            $line_amount = abs(min(0.0, (float) $fee_item->get_total()));
            if ($line_amount > 0) {
                $fee_amount += $line_amount;
                $credit_fee = $fee_item;
            }
        }

        if ($fee_amount <= 0) {
            return self::applyCreditsToOrder($order);
        }

        $customer_id = $order->get_customer_id();
        if (!$customer_id) {
            return 0.0;
        }

        $customer_credit = self::getCustomerCredit($customer_id);
        $total_applied = min($fee_amount, $customer_credit);

        if ($total_applied <= 0) {
            return 0.0;
        }

        if ($total_applied < $fee_amount && $credit_fee instanceof \WC_Order_Item_Fee) {
            $credit_fee->set_amount(-$total_applied);
            $credit_fee->set_total(-$total_applied);
            $order->calculate_totals();
        }

        $currency = $order->get_currency();
        self::deductCustomerCredit(
            $customer_id,
            $total_applied,
            self::SOURCE_ORDER,
            $order->get_id(),
            sprintf(
                /* translators: %d: order ID */
                __('Applied to order #%d', 'arraysubspro'),
                $order->get_id()
            ),
            $currency
        );

        $order->update_meta_data('_arraysubs_credit_applied', $total_applied);
        $order->update_meta_data('_arraysubs_credit_subscription_id', null);
        $order->update_meta_data('_arraysubs_credit_from_subscription', 0);
        $order->update_meta_data('_arraysubs_credit_from_customer', $total_applied);
        $order->delete_meta_data('_arraysubs_credit_reversed');

        $order->add_order_note(
            sprintf(
                /* translators: %s: credit amount */
                __('Store credit applied: %s', 'arraysubspro'),
                wc_price($total_applied, ['currency' => $currency])
            )
        );

        $order->save();

        do_action('arraysubs_credits_applied_to_order', $order, $total_applied, null);

        return $total_applied;
    }

    /**
     * Reverse a previous credit application on an order.
     *
     * Restores the original credit balance to the subscription and/or
     * customer bucket the credit was deducted from, removes the negative
     * "Store Credit Applied" fee line so the order shows its true unpaid
     * balance, and clears the application meta so a follow-up
     * applyCreditsToOrder() call (e.g. from a manual retry) can re-apply
     * credit cleanly.
     *
     * Idempotent: a second invocation on the same order is a no-op.
     *
     * @param \WC_Order $order           Order whose credit application should be reversed.
     * @param int|null  $subscription_id Subscription ID, defaults to the meta written at apply time.
     * @return float Total credit amount restored.
     */
    public static function reverseCreditsForOrder(\WC_Order $order, ?int $subscription_id = null): float
    {
        $applied = (float) $order->get_meta('_arraysubs_credit_applied');
        if ($applied <= 0) {
            return 0.0;
        }

        if ('yes' === (string) $order->get_meta('_arraysubs_credit_reversed')) {
            return 0.0;
        }

        $from_subscription = (float) $order->get_meta('_arraysubs_credit_from_subscription');
        $from_customer     = (float) $order->get_meta('_arraysubs_credit_from_customer');

        // Older orders predating the per-bucket split: assume customer bucket.
        if ($from_subscription <= 0 && $from_customer <= 0) {
            $from_customer = $applied;
        }

        if (null === $subscription_id) {
            $subscription_id = (int) $order->get_meta('_arraysubs_credit_subscription_id') ?: null;
        }

        $currency    = $order->get_currency();
        $customer_id = $order->get_customer_id();
        $restored    = 0.0;

        if ($from_subscription > 0 && $subscription_id) {
            self::addSubscriptionCredit(
                $subscription_id,
                $from_subscription,
                'reversal',
                $order->get_id(),
                sprintf(
                    /* translators: %d: order ID */
                    __('Reversed: renewal order #%d failed', 'arraysubspro'),
                    $order->get_id()
                ),
                $currency
            );
            $restored += $from_subscription;
        }

        if ($from_customer > 0 && $customer_id) {
            self::addCustomerCredit(
                $customer_id,
                $from_customer,
                'reversal',
                $order->get_id(),
                sprintf(
                    /* translators: %d: order ID */
                    __('Reversed: order #%d failed', 'arraysubspro'),
                    $order->get_id()
                ),
                $currency
            );
            $restored += $from_customer;
        }

        // Remove the negative "Store Credit Applied" fee line so the order
        // total reflects the real outstanding balance for any retry.
        foreach ($order->get_items('fee') as $item_id => $fee_item) {
            if (! $fee_item instanceof \WC_Order_Item_Fee) {
                continue;
            }
            if (__('Store Credit Applied', 'arraysubspro') === $fee_item->get_name()) {
                $order->remove_item($item_id);
            }
        }

        $order->update_meta_data('_arraysubs_credit_reversed', 'yes');
        $order->update_meta_data('_arraysubs_credit_reversed_at', current_time('mysql', true));
        // Clear application meta so a later applyCreditsToOrder() can run.
        $order->delete_meta_data('_arraysubs_credit_applied');
        $order->delete_meta_data('_arraysubs_credit_from_subscription');
        $order->delete_meta_data('_arraysubs_credit_from_customer');

        $order->calculate_totals();

        $order->add_order_note(
            sprintf(
                /* translators: %s: credit amount */
                __('Store credit reversed after payment failure: %s', 'arraysubspro'),
                wc_price($restored, ['currency' => $currency])
            )
        );

        $order->save();

        if ($subscription_id) {
            $note = sprintf(
                /* translators: 1: credit amount, 2: order ID */
                __('Store credit %1$s restored after renewal payment failed on order #%2$d.', 'arraysubspro'),
                wp_strip_all_tags(wc_price($restored, ['currency' => $currency])),
                $order->get_id()
            );
            if (function_exists('arraysubs_add_subscription_note')) {
                arraysubs_add_subscription_note(
                    $subscription_id,
                    $note,
                    'private',
                    0,
                    [],
                    'subscription',
                    'credit_reversed'
                );
            }
        }

        /**
         * Fires when a previous credit application is reversed on an order.
         *
         * @param \WC_Order $order           Order object.
         * @param float     $restored        Total credit amount restored.
         * @param int|null  $subscription_id Subscription ID, when applicable.
         */
        do_action('arraysubs_credits_reversed_on_order', $order, $restored, $subscription_id);

        return $restored;
    }

    /**
     * Process refund as store credit
     *
     * @param int    $order_id   Order ID
     * @param float  $amount     Refund amount
     * @param string $reason     Refund reason
     *
     * @return int|false Transaction log ID or false on failure
     */
    public static function processRefundAsCredit(int $order_id, float $amount, string $reason = ''): array
    {
        $order = wc_get_order($order_id);
        if (!$order || $amount <= 0) {
            return [
                'success' => false,
                'error'   => __('Invalid order or amount.', 'arraysubspro'),
            ];
        }

        $customer_id = $order->get_customer_id();
        if (!$customer_id) {
            return [
                'success' => false,
                'error'   => __('Order has no associated customer.', 'arraysubspro'),
            ];
        }

        $max_refundable = self::getRefundableAmountForOrder($order);
        if ($amount > $max_refundable) {
            return [
                'success' => false,
                'error'   => sprintf(
                    /* translators: %s: max refundable amount */
                    __('Amount exceeds maximum refundable: %s', 'arraysubspro'),
                    wc_price($max_refundable, ['currency' => $order->get_currency()])
                ),
            ];
        }

        $note = $reason ?: sprintf(
            /* translators: %d: order ID */
            __('Refund from order #%d', 'arraysubspro'),
            $order_id
        );

        // Add credit to customer account
        $log_id = self::addCustomerCredit(
            $customer_id,
            $amount,
            self::SOURCE_REFUND,
            $order_id,
            $note,
            $order->get_currency()
        );

        if (!$log_id) {
            return [
                'success' => false,
                'error'   => __('Failed to add store credit.', 'arraysubspro'),
            ];
        }

        $refund = wc_create_refund([
            'amount'         => $amount,
            'reason'         => sprintf(
                /* translators: %s: refund reason */
                __('Refund issued as store credit. %s', 'arraysubspro'),
                $note
            ),
            'order_id'       => $order_id,
            'refund_payment' => false,
            'restock_items'  => false,
        ]);

        if (is_wp_error($refund)) {
            self::deductCustomerCredit(
                $customer_id,
                $amount,
                self::SOURCE_REFUND,
                $order_id,
                sprintf(
                    /* translators: %s: refund failure message */
                    __('Store credit refund rollback: %s', 'arraysubspro'),
                    $refund->get_error_message()
                ),
                $order->get_currency()
            );

            return [
                'success' => false,
                'error'   => $refund->get_error_message(),
            ];
        }

        $refund->update_meta_data('_arraysubs_refund_as_credit', 'yes');
        $refund->update_meta_data('_arraysubs_credit_log_id', absint($log_id));
        $refund->save();

        $order = wc_get_order($order_id);
        if (!$order) {
            return [
                'success'   => true,
                'log_id'    => absint($log_id),
                'refund_id' => $refund->get_id(),
                'amount'    => $amount,
                'new_balance' => self::getCustomerCredit($customer_id),
                'remaining_refundable' => 0,
            ];
        }

        $existing_credit_refunds = $order->get_meta('_arraysubs_credit_refunds') ?: [];
        $existing_credit_refunds = is_array($existing_credit_refunds) ? $existing_credit_refunds : [];
        $existing_credit_refunds[] = [
            'amount'    => $amount,
            'date'      => current_time('mysql', true),
            'log_id'    => absint($log_id),
            'refund_id' => $refund->get_id(),
            'reason'    => $reason,
        ];

        $refunded_as_credit = (float) $order->get_meta('_refunded_as_credit');
        $order->update_meta_data('_arraysubs_credit_refunds', $existing_credit_refunds);
        $order->update_meta_data('_refunded_as_credit', $refunded_as_credit + $amount);
        $order->save();

        $order->add_order_note(
            sprintf(
                /* translators: 1: credit amount, 2: refund reason */
                __('Refund issued as store credit: %1$s. %2$s', 'arraysubspro'),
                wc_price($amount, ['currency' => $order->get_currency()]),
                $reason
            )
        );

        /**
         * Fires when a refund is processed as store credit
         *
         * @param int    $order_id    Order ID
         * @param float  $amount      Refund amount
         * @param int    $customer_id Customer ID
         */
        do_action('arraysubs_refund_as_credit_processed', $order_id, $amount, $customer_id);
        do_action('arraysubs_credit_refund_issued', $customer_id, $amount, $order_id);

        return [
            'success'              => true,
            'log_id'               => absint($log_id),
            'refund_id'            => $refund->get_id(),
            'amount'               => $amount,
            'new_balance'          => self::getCustomerCredit($customer_id),
            'remaining_refundable' => self::getRefundableAmountForOrder($order),
        ];
    }

    /**
     * Get remaining refundable amount while preserving legacy credit refunds
     * that were tracked only in ArraySubsPro meta before Woo refund records
     * were created for store-credit refunds.
     *
     * @param \WC_Order $order Order object.
     * @return float Remaining refundable amount.
     */
    public static function getRefundableAmountForOrder(\WC_Order $order): float
    {
        $total = (float) $order->get_total();
        $wc_refunded = abs((float) $order->get_total_refunded());
        $legacy_credit_refunded = self::getLegacyCreditRefundAmount($order);

        return max(0, $total - $wc_refunded - $legacy_credit_refunded);
    }

    /**
     * Get store-credit refund amount not backed by Woo refund records.
     *
     * @param \WC_Order $order Order object.
     * @return float Legacy credit-refund amount.
     */
    private static function getLegacyCreditRefundAmount(\WC_Order $order): float
    {
        $credit_refunds = $order->get_meta('_arraysubs_credit_refunds') ?: [];
        $credit_refunds = is_array($credit_refunds) ? $credit_refunds : [];

        $legacy_recorded = 0.0;
        $woo_recorded = 0.0;
        foreach ($credit_refunds as $credit_refund) {
            $amount = (float) ($credit_refund['amount'] ?? 0);
            if ($amount <= 0) {
                continue;
            }

            if (!empty($credit_refund['refund_id'])) {
                $woo_recorded += $amount;
                continue;
            }

            $legacy_recorded += $amount;
        }

        $refunded_as_credit = (float) $order->get_meta('_refunded_as_credit');
        $legacy_from_total_meta = max(0, $refunded_as_credit - $woo_recorded);

        return max($legacy_recorded, $legacy_from_total_meta);
    }

    /**
     * Admin adjust credit (add or deduct)
     *
     * @param int    $customer_id Customer user ID
     * @param float  $amount      Adjustment amount (positive for add, negative for deduct)
     * @param string $note        Adjustment note
     *
     * @return int|false Transaction log ID or false on failure
     */
    public static function adminAdjustCredit(int $customer_id, float $amount, string $note = ''): int|false
    {
        if ($amount === 0.0 || !$customer_id) {
            return false;
        }

        if ($amount < 0 && abs($amount) > self::getCustomerCredit($customer_id)) {
            return false;
        }

        if ($amount > 0) {
            return self::addCustomerCredit(
                $customer_id,
                $amount,
                self::SOURCE_ADMIN,
                null,
                $note ?: __('Admin credit adjustment', 'arraysubspro')
            );
        } else {
            return self::deductCustomerCredit(
                $customer_id,
                abs($amount),
                self::SOURCE_ADMIN,
                null,
                $note ?: __('Admin credit adjustment', 'arraysubspro')
            );
        }
    }

    /**
     * Expire old credits
     *
     * Called via scheduled action to expire credits past their expiration date.
     */
    public static function expireOldCredits(): void
    {
        $settings = arraysubs_get_settings();
        $expiration_days = $settings['store_credit']['expiration_days'] ?? 0;

        if ($expiration_days <= 0) {
            return; // No expiration configured
        }

        // This would need to be implemented with expiration date tracking
        // For now, this is a placeholder for future implementation
        do_action('arraysubs_credits_expired');
    }
}
