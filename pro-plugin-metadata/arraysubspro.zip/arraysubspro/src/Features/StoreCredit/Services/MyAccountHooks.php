<?php

/**
 * Store Credit My Account Hooks
 *
 * Registers store credit endpoint in WooCommerce My Account.
 *
 * @package ArraySubsPro\Features\StoreCredit\Services
 * @since 1.0.0
 */

namespace ArraySubsPro\Features\StoreCredit\Services;

defined('ABSPATH') || exit;

use ArraySubs\Supports\Config;

/**
 * Store Credit My Account hooks integration
 */
class MyAccountHooks
{
    /**
     * Enable auto-loading
     *
     * @var bool
     */
    public static bool $loadable = true;

    /**
     * Initialize hooks
     */
    public function __construct()
    {
        // Register endpoint
        add_action('init', [$this, 'registerEndpoint']);

        // Add menu item
        add_filter('woocommerce_account_menu_items', [$this, 'addMenuItem'], 15);

        // Template content
        add_action('woocommerce_account_store-credit_endpoint', [$this, 'endpointContent']);

        // Enqueue assets
        add_action('wp_enqueue_scripts', [$this, 'enqueueAssets']);

        // Add query vars
        add_filter('woocommerce_get_query_vars', [$this, 'addQueryVars']);

        // Flush rewrite rules on activation (run once)
        if (get_option('arraysubs_store_credit_flush_rewrite') !== 'done') {
            add_action('init', function () {
                flush_rewrite_rules();
                update_option('arraysubs_store_credit_flush_rewrite', 'done');
            }, 99);
        }
    }

    /**
     * Register store credit endpoint
     *
     * @return void
     */
    public function registerEndpoint(): void
    {
        add_rewrite_endpoint('store-credit', EP_ROOT | EP_PAGES);
    }

    /**
     * Add query vars
     *
     * @param array $vars Query vars
     * @return array
     */
    public function addQueryVars(array $vars): array
    {
        $vars['store-credit'] = 'store-credit';
        return $vars;
    }

    /**
     * Add menu item to My Account
     *
     * @param array $items Menu items
     * @return array Modified menu items
     */
    public function addMenuItem(array $items): array
    {
        // Don't add menu if store credit is disabled
        if (!arraysubs_get_setting('store_credit.enabled', true)) {
            return $items;
        }

        // Insert after 'subscriptions' or 'orders'
        $new_items = [];

        foreach ($items as $key => $label) {
            $new_items[$key] = $label;

            // Add after subscriptions if it exists, otherwise after orders
            if ($key === 'subscriptions' || ($key === 'orders' && !isset($items['subscriptions']))) {
                $new_items['store-credit'] = __('Store Credit', 'arraysubspro');
            }
        }

        return $new_items;
    }

    /**
     * Store credit endpoint content
     *
     * @return void
     */
    public function endpointContent(): void
    {
        // Check if store credit is enabled
        if (!arraysubs_get_setting('store_credit.enabled', true)) {
            wc_print_notice(__('Store credit is not available.', 'arraysubspro'), 'notice');
            return;
        }

        $customer_id = get_current_user_id();

        if (!$customer_id) {
            wc_print_notice(__('Please log in to view your store credit.', 'arraysubspro'), 'error');
            return;
        }

        // Get credit balance
        $arraysubs_balance = CreditManager::getCustomerCredit($customer_id);

        // Get credit history with pagination
        $per_page = 10;
        $current_page = max(1, absint(get_query_var('paged', 1)));
        $arraysubs_history = $this->getCreditHistory($customer_id, $per_page, $current_page);

        // Get expiring credits
        $arraysubs_expiring_credits = CreditExpiration::getExpiringCredits($customer_id, 30); // Next 30 days
        $arraysubs_total_expiring = CreditExpiration::getTotalExpiringCredit($customer_id, 30);

        include dirname(__DIR__) . '/templates/my-account-store-credit.php';
    }

    /**
     * Get credit history for customer
     *
     * @param int $customer_id Customer ID
     * @param int $per_page    Items per page
     * @param int $page        Current page
     * @return array
     */
    private function getCreditHistory(int $customer_id, int $per_page, int $page): array
    {
        $args = [
            'post_type' => 'arraysubs_credit',
            'post_status' => 'publish',
            'posts_per_page' => $per_page,
            'paged' => $page,
            'meta_query' => [
                [
                    'key' => '_customer_id',
                    'value' => $customer_id,
                    'compare' => '=',
                    'type' => 'NUMERIC',
                ],
            ],
            'orderby' => 'date',
            'order' => 'DESC',
        ];

        $query = new \WP_Query($args);

        return [
            'items' => $query->posts,
            'total' => $query->found_posts,
            'pages' => $query->max_num_pages,
            'current_page' => $page,
        ];
    }

    /**
     * Enqueue assets for store credit page
     *
     * @return void
     */
    public function enqueueAssets(): void
    {
        if (!function_exists('is_account_page') || !is_account_page()) {
            return;
        }

        // Only load on store-credit endpoint
        if (!is_wc_endpoint_url('store-credit')) {
            return;
        }

        // Styles are bundled in customer-portal.css via SCSS
        // Ensure the customer-portal stylesheet is enqueued
        if (!wp_style_is('arraysubspro-customer-portal', 'enqueued')) {
            $asset_file = Config::get('proplugin.public_path') . 'build/customer-portal.asset.php';
            $asset = file_exists($asset_file)
                ? require $asset_file
                : ['dependencies' => [], 'version' => ARRAYSUBSPRO_VERSION];

            wp_enqueue_style(
                'arraysubspro-customer-portal',
                Config::get('proplugin.public_url') . 'build/customer-portal.css',
                [],
                $asset['version']
            );
        }
    }
}
