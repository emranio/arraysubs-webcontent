<?php

/**
 * Customer Credit Controller
 *
 * REST API endpoints for customer-facing store credit features.
 *
 * @package ArraySubsPro\Features\StoreCredit\REST
 * @since 1.0.0
 */

namespace ArraySubsPro\Features\StoreCredit\REST;

defined('ABSPATH') || exit;

use ArraySubs\Supports\BaseRestController;
use ArraySubsPro\Features\StoreCredit\Services\CreditManager;
use ArraySubsPro\Features\StoreCredit\Services\TransactionLogger;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;

/**
 * Customer Credit REST controller
 */
class CustomerCreditController extends BaseRestController
{
    /**
     * Enable auto-loading
     *
     * @var bool
     */
    public static $loadable = true;

    /**
     * REST namespace
     *
     * @var string
     */
    protected $namespace = 'arraysubs/v1';

    /**
     * Constructor
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Register REST routes
     */
    public function registerRoutes(): void
    {
        // Get current user's credit balance
        register_rest_route($this->namespace, '/my-credits', [
            [
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => [$this, 'getMyCredits'],
                'permission_callback' => [$this, 'checkCustomerPermission'],
            ],
        ]);

        // Get current user's credit history
        register_rest_route($this->namespace, '/my-credits/history', [
            [
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => [$this, 'getMyHistory'],
                'permission_callback' => [$this, 'checkCustomerPermission'],
                'args'                => [
                    'page' => [
                        'description' => __('Page number', 'arraysubspro'),
                        'type'        => 'integer',
                        'default'     => 1,
                    ],
                    'per_page' => [
                        'description' => __('Items per page', 'arraysubspro'),
                        'type'        => 'integer',
                        'default'     => 20,
                    ],
                ],
            ],
        ]);
    }

    /**
     * Check customer permission (logged in)
     *
     * @return bool
     */
    public function checkCustomerPermission(): bool
    {
        return is_user_logged_in();
    }

    /**
     * Get current user's credit balance
     *
     * @param WP_REST_Request $request Request object
     *
     * @return WP_REST_Response
     */
    public function getMyCredits(WP_REST_Request $request): WP_REST_Response
    {
        $customer_id = get_current_user_id();

        $balance = CreditManager::getCustomerCredit($customer_id);

        return new WP_REST_Response([
            'success' => true,
            'data'    => [
                'balance'           => $balance,
                'balance_formatted' => wc_price($balance),
            ],
        ], 200);
    }

    /**
     * Get current user's credit history
     *
     * @param WP_REST_Request $request Request object
     *
     * @return WP_REST_Response
     */
    public function getMyHistory(WP_REST_Request $request): WP_REST_Response
    {
        $customer_id = get_current_user_id();
        $page = (int) $request->get_param('page');
        $per_page = (int) $request->get_param('per_page');

        $balance = CreditManager::getCustomerCredit($customer_id);
        $history = TransactionLogger::getCustomerHistory($customer_id, $page, $per_page);

        // Format history for customer view (hide some internal details)
        $formatted_history = array_map(function ($item) {
            return [
                'id'              => $item['id'],
                'date'            => $item['date'],
                'date_formatted'  => $item['date_formatted'],
                'amount'          => $item['amount'],
                'amount_formatted' => wc_price($item['amount']),
                'type'            => $item['type'],
                'source_label'    => $item['source_label'],
                'balance_after'   => $item['balance_after'],
                'balance_after_formatted' => wc_price($item['balance_after']),
                'note'            => $item['note'],
            ];
        }, $history['items']);

        return new WP_REST_Response([
            'success' => true,
            'data'    => [
                'balance'           => $balance,
                'balance_formatted' => wc_price($balance),
                'history'           => $formatted_history,
                'total'             => $history['total'],
                'pages'             => $history['pages'],
                'page'              => $page,
                'per_page'          => $per_page,
            ],
        ], 200);
    }
}
