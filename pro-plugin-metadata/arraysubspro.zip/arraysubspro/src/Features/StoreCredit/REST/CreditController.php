<?php

/**
 * Credit Controller
 *
 * REST API endpoints for store credit management.
 *
 * @package ArraySubsPro\Features\StoreCredit\REST
 * @since 1.0.0
 */

namespace ArraySubsPro\Features\StoreCredit\REST;

defined('ABSPATH') || exit;

use ArraySubs\Supports\BaseRestController;
use ArraySubsPro\Features\StoreCredit\Services\CreditManager;
use ArraySubsPro\Features\StoreCredit\Services\TransactionLogger;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;

/**
 * Credit REST controller
 */
class CreditController extends BaseRestController
{
    /**
     * Enable auto-loading
     *
     * @var bool
     */
    public static $loadable = true;

    /**
     * REST namespace
     *
     * @var string
     */
    protected $namespace = 'arraysubs/v1';

    /**
     * Constructor
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Register REST routes
     */
    public function registerRoutes(): void
    {
        // Search customers by username or email
        register_rest_route($this->namespace, '/credits/search', [
            [
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => [$this, 'searchCustomers'],
                'permission_callback' => [$this, 'checkAdminPermission'],
                'args'                => [
                    'query' => [
                        'description' => __('Search query (username or email)', 'arraysubspro'),
                        'type'        => 'string',
                        'required'    => true,
                    ],
                ],
            ],
        ]);

        // Get customer credit balance and history
        register_rest_route($this->namespace, '/credits/customer/(?P<customer_id>\d+)', [
            [
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => [$this, 'getCustomerCredits'],
                'permission_callback' => [$this, 'checkAdminPermission'],
                'args'                => [
                    'customer_id' => [
                        'description' => __('Customer user ID', 'arraysubspro'),
                        'type'        => 'integer',
                        'required'    => true,
                    ],
                    'page' => [
                        'description' => __('Page number', 'arraysubspro'),
                        'type'        => 'integer',
                        'default'     => 1,
                    ],
                    'per_page' => [
                        'description' => __('Items per page', 'arraysubspro'),
                        'type'        => 'integer',
                        'default'     => 20,
                    ],
                ],
            ],
        ]);

        // Adjust customer credit (add/deduct)
        register_rest_route($this->namespace, '/credits/adjust', [
            [
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => [$this, 'adjustCredit'],
                'permission_callback' => [$this, 'checkAdminPermission'],
                'args'                => [
                    'customer_id' => [
                        'description' => __('Customer user ID', 'arraysubspro'),
                        'type'        => 'integer',
                        'required'    => true,
                    ],
                    'amount' => [
                        'description' => __('Amount to adjust (positive to add, negative to deduct)', 'arraysubspro'),
                        'type'        => 'number',
                        'required'    => true,
                    ],
                    'note' => [
                        'description' => __('Adjustment note', 'arraysubspro'),
                        'type'        => 'string',
                        'default'     => '',
                    ],
                ],
            ],
        ]);

        // Get subscription credit balance and history
        register_rest_route($this->namespace, '/subscriptions/(?P<id>\d+)/credits', [
            [
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => [$this, 'getSubscriptionCredits'],
                'permission_callback' => [$this, 'checkAdminPermission'],
                'args'                => [
                    'id' => [
                        'description' => __('Subscription ID', 'arraysubspro'),
                        'type'        => 'integer',
                        'required'    => true,
                    ],
                    'page' => [
                        'description' => __('Page number', 'arraysubspro'),
                        'type'        => 'integer',
                        'default'     => 1,
                    ],
                    'per_page' => [
                        'description' => __('Items per page', 'arraysubspro'),
                        'type'        => 'integer',
                        'default'     => 10,
                    ],
                ],
            ],
        ]);

        // Get all credit transactions (admin history)
        register_rest_route($this->namespace, '/credits/history', [
            [
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => [$this, 'getAllHistory'],
                'permission_callback' => [$this, 'checkAdminPermission'],
                'args'                => [
                    'page' => [
                        'description' => __('Page number', 'arraysubspro'),
                        'type'        => 'integer',
                        'default'     => 1,
                    ],
                    'per_page' => [
                        'description' => __('Items per page', 'arraysubspro'),
                        'type'        => 'integer',
                        'default'     => 20,
                    ],
                    'source' => [
                        'description' => __('Filter by source', 'arraysubspro'),
                        'type'        => 'string',
                        'default'     => '',
                    ],
                    'type' => [
                        'description' => __('Filter by type (credit/debit)', 'arraysubspro'),
                        'type'        => 'string',
                        'default'     => '',
                    ],
                ],
            ],
        ]);

        // Delete a credit log entry
        register_rest_route($this->namespace, '/credits/log/(?P<log_id>\d+)', [
            [
                'methods'             => WP_REST_Server::DELETABLE,
                'callback'            => [$this, 'deleteLogEntry'],
                'permission_callback' => [$this, 'checkAdminPermission'],
                'args'                => [
                    'log_id' => [
                        'description' => __('Log entry ID', 'arraysubspro'),
                        'type'        => 'integer',
                        'required'    => true,
                    ],
                ],
            ],
        ]);

        // Process refund as store credit
        register_rest_route($this->namespace, '/refunds/as-credit', [
            [
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => [$this, 'refundAsCredit'],
                'permission_callback' => [$this, 'checkAdminPermission'],
                'args'                => [
                    'order_id' => [
                        'description' => __('Order ID', 'arraysubspro'),
                        'type'        => 'integer',
                        'required'    => true,
                    ],
                    'amount' => [
                        'description' => __('Refund amount', 'arraysubspro'),
                        'type'        => 'number',
                        'required'    => true,
                    ],
                    'reason' => [
                        'description' => __('Refund reason', 'arraysubspro'),
                        'type'        => 'string',
                        'default'     => '',
                    ],
                ],
            ],
        ]);

        // Get store credit settings
        register_rest_route($this->namespace, '/store-credit/settings', [
            [
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => [$this, 'getSettings'],
                'permission_callback' => [$this, 'checkAdminPermission'],
            ],
            [
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => [$this, 'saveSettings'],
                'permission_callback' => [$this, 'checkAdminPermission'],
                'args'                => [
                    'settings' => [
                        'description' => __('Store credit settings', 'arraysubspro'),
                        'type'        => 'object',
                        'required'    => true,
                    ],
                ],
            ],
        ]);

        // Get refund eligibility for an order (used by WooCommerce integration)
        register_rest_route($this->namespace, '/orders/(?P<order_id>\d+)/credit-refund-status', [
            [
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => [$this, 'getOrderRefundStatus'],
                'permission_callback' => [$this, 'checkAdminPermission'],
                'args'                => [
                    'order_id' => [
                        'description' => __('Order ID', 'arraysubspro'),
                        'type'        => 'integer',
                        'required'    => true,
                    ],
                ],
            ],
        ]);
    }

    /**
     * Check admin permission
     *
     * @return bool
     */
    public function checkAdminPermission(): bool
    {
        return current_user_can('manage_woocommerce') || current_user_can('manage_options');
    }

    /**
     * Search customers by username or email
     *
     * @param WP_REST_Request $request Request object
     *
     * @return WP_REST_Response
     */
    public function searchCustomers(WP_REST_Request $request): WP_REST_Response
    {
        $query = sanitize_text_field($request->get_param('query'));

        if (strlen($query) < 2) {
            return new WP_REST_Response([
                'success' => false,
                'message' => __('Search query too short', 'arraysubspro'),
            ], 400);
        }

        $users = get_users([
            'search'         => '*' . $query . '*',
            'search_columns' => ['user_login', 'user_email', 'display_name'],
            'number'         => 20,
            'orderby'        => 'display_name',
            'order'          => 'ASC',
        ]);

        $results = [];
        foreach ($users as $user) {
            $results[] = [
                'id'           => $user->ID,
                'display_name' => $user->display_name,
                'email'        => $user->user_email,
                'username'     => $user->user_login,
                'balance'      => CreditManager::getCustomerCredit($user->ID),
            ];
        }

        return new WP_REST_Response([
            'success' => true,
            'data'    => $results,
        ], 200);
    }

    /**
     * Get customer credit balance and history
     *
     * @param WP_REST_Request $request Request object
     *
     * @return WP_REST_Response
     */
    public function getCustomerCredits(WP_REST_Request $request): WP_REST_Response
    {
        $customer_id = (int) $request->get_param('customer_id');
        $page = (int) $request->get_param('page');
        $per_page = (int) $request->get_param('per_page');

        $user = get_user_by('ID', $customer_id);
        if (!$user) {
            return new WP_REST_Response([
                'success' => false,
                'message' => __('Customer not found', 'arraysubspro'),
            ], 404);
        }

        $balance = CreditManager::getCustomerCredit($customer_id);
        $history = TransactionLogger::getCustomerHistory($customer_id, $page, $per_page);

        return new WP_REST_Response([
            'success' => true,
            'data'    => [
                'customer'    => [
                    'id'           => $user->ID,
                    'display_name' => $user->display_name,
                    'email'        => $user->user_email,
                ],
                'balance'     => $balance,
                'balance_formatted' => wc_price($balance),
                'history'     => $history['items'],
                'total'       => $history['total'],
                'pages'       => $history['pages'],
                'page'        => $page,
                'per_page'    => $per_page,
            ],
        ], 200);
    }

    /**
     * Adjust customer credit
     *
     * @param WP_REST_Request $request Request object
     *
     * @return WP_REST_Response
     */
    public function adjustCredit(WP_REST_Request $request): WP_REST_Response
    {
        $customer_id = (int) $request->get_param('customer_id');
        $amount = (float) $request->get_param('amount');
        $note = sanitize_textarea_field($request->get_param('note'));

        $user = get_user_by('ID', $customer_id);
        if (!$user) {
            return new WP_REST_Response([
                'success' => false,
                'message' => __('Customer not found', 'arraysubspro'),
            ], 404);
        }

        if ($amount === 0.0) {
            return new WP_REST_Response([
                'success' => false,
                'message' => __('Amount cannot be zero', 'arraysubspro'),
            ], 400);
        }

        if ($amount < 0) {
            $deduction = abs($amount);
            $balance   = CreditManager::getCustomerCredit($customer_id);

            if ($deduction > $balance) {
                return new WP_REST_Response([
                    'success' => false,
                    'message' => __('Cannot deduct more than available balance', 'arraysubspro'),
                ], 400);
            }
        }

        $log_id = CreditManager::adminAdjustCredit($customer_id, $amount, $note);

        if (!$log_id) {
            return new WP_REST_Response([
                'success' => false,
                'message' => __('Failed to adjust credit', 'arraysubspro'),
            ], 500);
        }

        $new_balance = CreditManager::getCustomerCredit($customer_id);

        return new WP_REST_Response([
            'success' => true,
            'message' => $amount > 0
                ? __('Credit added successfully', 'arraysubspro')
                : __('Credit deducted successfully', 'arraysubspro'),
            'data'    => [
                'log_id'            => $log_id,
                'new_balance'       => $new_balance,
                'new_balance_formatted' => wc_price($new_balance),
            ],
        ], 200);
    }

    /**
     * Get subscription credit balance and history
     *
     * @param WP_REST_Request $request Request object
     *
     * @return WP_REST_Response
     */
    public function getSubscriptionCredits(WP_REST_Request $request): WP_REST_Response
    {
        $subscription_id = (int) $request->get_param('id');
        $page = (int) $request->get_param('page');
        $per_page = (int) $request->get_param('per_page');

        $subscription = get_post($subscription_id);
        if (!$subscription || $subscription->post_type !== 'arraysubs_data') {
            return new WP_REST_Response([
                'success' => false,
                'message' => __('Subscription not found', 'arraysubspro'),
            ], 404);
        }

        $credits = CreditManager::getTotalAvailableCredit($subscription_id);
        $history = TransactionLogger::getSubscriptionHistory($subscription_id, $page, $per_page);

        return new WP_REST_Response([
            'success' => true,
            'data'    => [
                'subscription_credit'   => $credits['subscription'],
                'customer_credit'       => $credits['customer'],
                'total_available'       => $credits['total'],
                'total_available_formatted' => wc_price($credits['total']),
                'history'               => $history['items'],
                'total'                 => $history['total'],
                'pages'                 => $history['pages'],
                'page'                  => $page,
                'per_page'              => $per_page,
            ],
        ], 200);
    }

    /**
     * Get all credit transaction history
     *
     * @param WP_REST_Request $request Request object
     *
     * @return WP_REST_Response
     */
    public function getAllHistory(WP_REST_Request $request): WP_REST_Response
    {
        $page = (int) $request->get_param('page');
        $per_page = (int) $request->get_param('per_page');
        $source = sanitize_text_field($request->get_param('source'));
        $type = sanitize_text_field($request->get_param('type'));

        $filters = [];
        if ($source) {
            $filters['source'] = $source;
        }
        if ($type) {
            $filters['type'] = $type;
        }

        $history = TransactionLogger::getAllTransactions($page, $per_page, $filters);

        return new WP_REST_Response([
            'success' => true,
            'data'    => [
                'items'    => $history['items'],
                'total'    => $history['total'],
                'pages'    => $history['pages'],
                'page'     => $page,
                'per_page' => $per_page,
            ],
        ], 200);
    }

    /**
     * Delete a log entry
     *
     * @param WP_REST_Request $request Request object
     *
     * @return WP_REST_Response
     */
    public function deleteLogEntry(WP_REST_Request $request): WP_REST_Response
    {
        $log_id = (int) $request->get_param('log_id');

        $deleted = TransactionLogger::deleteLog($log_id);

        if (!$deleted) {
            return new WP_REST_Response([
                'success' => false,
                'message' => __('Failed to delete log entry', 'arraysubspro'),
            ], 500);
        }

        return new WP_REST_Response([
            'success' => true,
            'message' => __('Log entry deleted', 'arraysubspro'),
        ], 200);
    }

    /**
     * Process refund as store credit
     *
     * @param WP_REST_Request $request Request object
     *
     * @return WP_REST_Response
     */
    public function refundAsCredit(WP_REST_Request $request): WP_REST_Response
    {
        $order_id = (int) $request->get_param('order_id');
        $amount = (float) $request->get_param('amount');
        $reason = sanitize_textarea_field($request->get_param('reason'));

        $order = wc_get_order($order_id);
        if (!$order) {
            return new WP_REST_Response([
                'success' => false,
                'message' => __('Order not found', 'arraysubspro'),
            ], 404);
        }

        if ($amount <= 0) {
            return new WP_REST_Response([
                'success' => false,
                'message' => __('Amount must be greater than zero', 'arraysubspro'),
            ], 400);
        }

        // Check refundable amount.
        $max_refundable = CreditManager::getRefundableAmountForOrder($order);

        if ($amount > $max_refundable) {
            return new WP_REST_Response([
                'success' => false,
                'message' => sprintf(
                    /* translators: %s: max refundable amount */
                    __('Amount exceeds maximum refundable: %s', 'arraysubspro'),
                    wc_price($max_refundable)
                ),
            ], 400);
        }

        $customer_id = $order->get_customer_id();
        if (!$customer_id) {
            return new WP_REST_Response([
                'success' => false,
                'message' => __('Order has no associated customer', 'arraysubspro'),
            ], 400);
        }

        $result = CreditManager::processRefundAsCredit($order_id, $amount, $reason);

        if (empty($result['success'])) {
            return new WP_REST_Response([
                'success' => false,
                'message' => $result['error'] ?? __('Failed to process refund as credit', 'arraysubspro'),
            ], 500);
        }

        $new_balance = CreditManager::getCustomerCredit($customer_id);

        return new WP_REST_Response([
            'success' => true,
            'message' => __('Refund processed as store credit', 'arraysubspro'),
            'data'    => [
                'log_id'      => $result['log_id'],
                'refund_id'   => $result['refund_id'],
                'amount'      => $amount,
                'new_balance' => $new_balance,
                'new_balance_formatted' => wc_price($new_balance),
            ],
        ], 200);
    }

    /**
     * Get order refund status for credit refunds
     *
     * @param WP_REST_Request $request Request object
     *
     * @return WP_REST_Response
     */
    public function getOrderRefundStatus(WP_REST_Request $request): WP_REST_Response
    {
        $order_id = (int) $request->get_param('order_id');

        $order = wc_get_order($order_id);
        if (!$order) {
            return new WP_REST_Response([
                'success' => false,
                'message' => __('Order not found', 'arraysubspro'),
            ], 404);
        }

        $customer_id = $order->get_customer_id();
        $current_balance = $customer_id ? CreditManager::getCustomerCredit($customer_id) : 0;

        // Calculate max refundable.
        $order_total = $order->get_total();
        $already_refunded = $order->get_total_refunded();
        $existing_credit_refunds = $order->get_meta('_arraysubs_credit_refunds') ?: [];
        $already_refunded_as_credit = array_sum(array_column($existing_credit_refunds, 'amount'));
        $max_refundable = CreditManager::getRefundableAmountForOrder($order);

        $user = $customer_id ? get_user_by('ID', $customer_id) : null;

        return new WP_REST_Response([
            'success' => true,
            'data'    => [
                'order_id'             => $order_id,
                'order_total'          => $order_total,
                'already_refunded'     => $already_refunded,
                'already_refunded_as_credit' => $already_refunded_as_credit,
                'max_refundable'       => max(0, $max_refundable),
                'max_refundable_formatted' => wc_price(max(0, $max_refundable)),
                'customer_id'          => $customer_id,
                'customer_email'       => $user ? $user->user_email : '',
                'current_balance'      => $current_balance,
                'current_balance_formatted' => wc_price($current_balance),
                'credit_refunds'       => $existing_credit_refunds,
            ],
        ], 200);
    }

    /**
     * Get store credit settings
     *
     * @param WP_REST_Request $request Request object
     *
     * @return WP_REST_Response
     */
    public function getSettings(WP_REST_Request $request): WP_REST_Response
    {
        $settings = arraysubs_get_settings();
        $store_credit_settings = $settings['store_credit'] ?? [];

        $defaults = [
            'enabled'                => true,
            'expiration_days'        => 0,
            'auto_apply_to_renewals' => true,
            'apply_at_checkout'      => false,
            'min_order_amount'       => 0,
            'enable_purchase'        => false,
            'min_purchase_amount'    => 10,
            'max_purchase_amount'    => 500,
            'default_purchase_amount' => 50,
        ];

        return new WP_REST_Response([
            'success' => true,
            'data'    => wp_parse_args($store_credit_settings, $defaults),
        ], 200);
    }

    /**
     * Save store credit settings
     *
     * @param WP_REST_Request $request Request object
     *
     * @return WP_REST_Response
     */
    public function saveSettings(WP_REST_Request $request): WP_REST_Response
    {
        $new_settings = $request->get_param('settings');

        $settings = arraysubs_get_settings();
        $settings['store_credit'] = [
            'enabled'                => (bool) ($new_settings['enabled'] ?? true),
            'expiration_days'        => absint($new_settings['expiration_days'] ?? 0),
            'auto_apply_to_renewals' => (bool) ($new_settings['auto_apply_to_renewals'] ?? true),
            'apply_at_checkout'      => (bool) ($new_settings['apply_at_checkout'] ?? false),
            'min_order_amount'       => (float) ($new_settings['min_order_amount'] ?? 0),
            'enable_purchase'        => (bool) ($new_settings['enable_purchase'] ?? false),
            'min_purchase_amount'    => (float) ($new_settings['min_purchase_amount'] ?? 10),
            'max_purchase_amount'    => (float) ($new_settings['max_purchase_amount'] ?? 500),
            'default_purchase_amount' => (float) ($new_settings['default_purchase_amount'] ?? 50),
        ];

        arraysubs_save_settings($settings);

        return new WP_REST_Response([
            'success' => true,
            'message' => __('Settings saved', 'arraysubspro'),
            'data'    => $settings['store_credit'],
        ], 200);
    }
}
