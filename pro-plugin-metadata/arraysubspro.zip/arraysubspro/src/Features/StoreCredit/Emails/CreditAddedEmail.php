<?php

/**
 * Credit Added Email
 *
 * Sent to customers when store credit is added to their account.
 *
 * @package ArraySubsPro\Features\StoreCredit\Emails
 * @since 1.0.0
 */

namespace ArraySubsPro\Features\StoreCredit\Emails;

defined('ABSPATH') || exit;

use ArraySubs\Supports\Config;

/**
 * Credit Added Email class
 */
class CreditAddedEmail extends \WC_Email
{
    /**
     * Customer ID
     *
     * @var int
     */
    protected int $customer_id = 0;

    /**
     * Credit amount
     *
     * @var float
     */
    protected float $credit_amount = 0.0;

    /**
     * New balance
     *
     * @var float
     */
    protected float $new_balance = 0.0;

    /**
     * Credit source
     *
     * @var string
     */
    protected string $credit_source = '';

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->id             = 'arraysubs_credit_added';
        $this->customer_email = true;
        $this->title          = __('[ArraySubsPro] Store Credit Added', 'arraysubspro');
        $this->description    = __('Sent to customers when store credit is added to their account.', 'arraysubspro');

        $this->heading        = __('Store credit has been added to your account!', 'arraysubspro');
        $this->subject        = __('[{site_title}] Store credit added to your account', 'arraysubspro');

        $this->template_base  = Config::get('proplugin.src_path') . '/Features/StoreCredit/templates/';
        $this->template_html  = 'emails/credit-added.php';
        $this->template_plain = 'emails/plain/credit-added.php';

        // Placeholders with sample values for preview
        $this->placeholders = [
            '{site_title}'     => $this->get_blogname(),
            '{site_address}'   => wp_parse_url(home_url(), PHP_URL_HOST),
            '{site_url}'       => home_url(),
            '{store_email}'    => get_option('admin_email'),
            '{customer_name}'  => __('John Doe', 'arraysubspro'),
            '{credit_amount}'  => $this->formatPricePlaceholder(25),
            '{new_balance}'    => $this->formatPricePlaceholder(50),
            '{credit_source}'  => __('Admin adjustment', 'arraysubspro'),
            '{my_account_url}' => wc_get_account_endpoint_url('store-credit'),
        ];

        parent::__construct();

        // Trigger
        add_action('arraysubs_customer_credit_added', [$this, 'trigger'], 10, 4);
        add_action('arraysubs_subscription_credit_added', [$this, 'triggerFromSubscription'], 10, 4);
    }

    /**
     * Get default subject
     *
     * @return string
     */
    public function get_default_subject(): string
    {
        return __('[{site_title}] Store credit added to your account', 'arraysubspro');
    }

    /**
     * Get default heading
     *
     * @return string
     */
    public function get_default_heading(): string
    {
        return __('Store credit has been added to your account!', 'arraysubspro');
    }

    /**
     * Trigger from subscription credit
     *
     * @param int    $subscription_id Subscription ID
     * @param float  $amount          Credit amount
     * @param float  $new_balance     New balance
     * @param string $source          Credit source
     */
    public function triggerFromSubscription(int $subscription_id, float $amount, float $new_balance, string $source): void
    {
        $customer_id = (int) get_post_meta($subscription_id, '_customer_id', true);
        if ($customer_id) {
            $this->trigger($customer_id, $amount, $new_balance, $source);
        }
    }

    /**
     * Trigger the email
     *
     * @param int    $customer_id Customer ID
     * @param float  $amount      Credit amount
     * @param float  $new_balance New balance
     * @param string $source      Credit source
     */
    public function trigger(int $customer_id, float $amount, float $new_balance, string $source): void
    {
        // Don't send for debit sources (usage)
        if (in_array($source, ['renewal_applied', 'order_applied', 'expired'], true)) {
            return;
        }

        $this->customer_id = $customer_id;
        $this->credit_amount = $amount;
        $this->new_balance = $new_balance;
        $this->credit_source = $source;

        $customer = get_user_by('ID', $customer_id);
        if (!$customer) {
            return;
        }

        $this->setup_locale();
        $this->recipient = $customer->user_email;
        $this->populate_placeholders($customer);

        if ($this->is_enabled() && $this->get_recipient()) {
            $this->send(
                $this->get_recipient(),
                $this->get_subject(),
                $this->get_content(),
                $this->get_headers(),
                $this->get_attachments()
            );
        }

        $this->restore_locale();
    }

    /**
     * Populate placeholders
     *
     * @param \WP_User $customer Customer user object
     */
    protected function populate_placeholders(\WP_User $customer): void
    {
        $source_labels = [
            'downgrade' => __('Plan downgrade', 'arraysubspro'),
            'refund' => __('Refund', 'arraysubspro'),
            'admin' => __('Admin adjustment', 'arraysubspro'),
            'promotional' => __('Promotional', 'arraysubspro'),
            'purchase' => __('Purchase', 'arraysubspro'),
        ];

        $this->placeholders['{customer_name}'] = $customer->display_name ?: $customer->user_login;
        $this->placeholders['{credit_amount}'] = $this->formatPricePlaceholder($this->credit_amount);
        $this->placeholders['{new_balance}'] = $this->formatPricePlaceholder($this->new_balance);
        $this->placeholders['{credit_source}'] = $source_labels[$this->credit_source] ?? $this->credit_source;
        $this->placeholders['{my_account_url}'] = wc_get_account_endpoint_url('store-credit');
    }

    /**
     * Format money placeholders for subject/heading text.
     *
     * @param float $amount Amount.
     * @return string
     */
    private function formatPricePlaceholder(float $amount): string
    {
        return html_entity_decode(wp_strip_all_tags(wc_price($amount)), ENT_QUOTES, get_bloginfo('charset'));
    }

    /**
     * Get content HTML
     *
     * @return string
     */
    public function get_content_html(): string
    {
        $source_labels = [
            'downgrade' => __('Plan downgrade', 'arraysubspro'),
            'refund' => __('Refund', 'arraysubspro'),
            'admin' => __('Admin adjustment', 'arraysubspro'),
            'promotional' => __('Promotional', 'arraysubspro'),
            'purchase' => __('Purchase', 'arraysubspro'),
        ];

        return wc_get_template_html(
            $this->template_html,
            [
                'arraysubs_customer_id'    => $this->customer_id,
                'arraysubs_credit_amount'  => $this->credit_amount,
                'arraysubs_new_balance'    => $this->new_balance,
                'arraysubs_credit_source'  => $this->credit_source,
                'arraysubs_source_label'   => $source_labels[$this->credit_source] ?? ucfirst($this->credit_source),
                'arraysubs_email_heading'  => $this->get_heading(),
                'arraysubs_additional_content' => $this->get_additional_content(),
                'arraysubs_sent_to_admin'  => false,
                'arraysubs_plain_text'     => false,
                'arraysubs_email'          => $this,
            ],
            '',
            $this->template_base
        );
    }

    /**
     * Get content plain
     *
     * @return string
     */
    public function get_content_plain(): string
    {
        $source_labels = [
            'downgrade' => __('Plan downgrade', 'arraysubspro'),
            'refund' => __('Refund', 'arraysubspro'),
            'admin' => __('Admin adjustment', 'arraysubspro'),
            'promotional' => __('Promotional', 'arraysubspro'),
            'purchase' => __('Purchase', 'arraysubspro'),
        ];

        return wc_get_template_html(
            $this->template_plain,
            [
                'arraysubs_customer_id'    => $this->customer_id,
                'arraysubs_credit_amount'  => $this->credit_amount,
                'arraysubs_new_balance'    => $this->new_balance,
                'arraysubs_credit_source'  => $this->credit_source,
                'arraysubs_source_label'   => $source_labels[$this->credit_source] ?? ucfirst($this->credit_source),
                'arraysubs_email_heading'  => $this->get_heading(),
                'arraysubs_additional_content' => $this->get_additional_content(),
                'arraysubs_sent_to_admin'  => false,
                'arraysubs_plain_text'     => true,
                'arraysubs_email'          => $this,
            ],
            '',
            $this->template_base
        );
    }

    /**
     * Default additional content
     *
     * @return string
     */
    public function get_default_additional_content(): string
    {
        return __('You can use your store credit towards future purchases and subscription renewals.', 'arraysubspro');
    }

    /**
     * Initialise settings form fields
     */
    public function init_form_fields(): void
    {
        /* translators: %s: comma-separated list of email template placeholders with code tags */
        $placeholder_text = sprintf(
            /* translators: %s: comma-separated list of email template placeholders with code tags */
            __('Available placeholders: %s', 'arraysubspro'),
            '<code>' . implode('</code>, <code>', array_keys($this->placeholders)) . '</code>'
        );

        $this->form_fields = [
            'enabled' => [
                'title'   => __('Enable/Disable', 'arraysubspro'),
                'type'    => 'checkbox',
                'label'   => __('Enable this email notification', 'arraysubspro'),
                'default' => 'yes',
            ],
            'subject' => [
                'title'       => __('Subject', 'arraysubspro'),
                'type'        => 'text',
                'desc_tip'    => true,
                'description' => $placeholder_text,
                'placeholder' => $this->get_default_subject(),
                'default'     => '',
            ],
            'heading' => [
                'title'       => __('Email heading', 'arraysubspro'),
                'type'        => 'text',
                'desc_tip'    => true,
                'description' => $placeholder_text,
                'placeholder' => $this->get_default_heading(),
                'default'     => '',
            ],
            'additional_content' => [
                'title'       => __('Additional content', 'arraysubspro'),
                'description' => __('Text to appear below the main email content.', 'arraysubspro') . ' ' . $placeholder_text,
                'css'         => 'width:400px; height: 75px;',
                'placeholder' => __('N/A', 'arraysubspro'),
                'type'        => 'textarea',
                'default'     => $this->get_default_additional_content(),
                'desc_tip'    => true,
            ],
            'email_type' => [
                'title'       => __('Email type', 'arraysubspro'),
                'type'        => 'select',
                'description' => __('Choose which format of email to send.', 'arraysubspro'),
                'default'     => 'html',
                'class'       => 'email_type wc-enhanced-select',
                'options'     => $this->get_email_type_options(),
                'desc_tip'    => true,
            ],
        ];
    }
}
