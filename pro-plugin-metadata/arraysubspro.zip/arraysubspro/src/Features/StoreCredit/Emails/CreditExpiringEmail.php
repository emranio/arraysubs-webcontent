<?php

/**
 * Credit Expiring Email
 *
 * Sent to customers when their store credit is about to expire.
 *
 * @package ArraySubsPro\Features\StoreCredit\Emails
 * @since 1.0.0
 */

namespace ArraySubsPro\Features\StoreCredit\Emails;

defined('ABSPATH') || exit;

use ArraySubs\Supports\Config;

/**
 * Credit Expiring Email class
 */
class CreditExpiringEmail extends \WC_Email
{
    /**
     * Customer ID
     *
     * @var int
     */
    protected int $customer_id = 0;

    /**
     * Expiring credit amount
     *
     * @var float
     */
    protected float $expiring_amount = 0.0;

    /**
     * Expiration date
     *
     * @var string
     */
    protected string $expires_at = '';

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->id             = 'arraysubs_credit_expiring';
        $this->customer_email = true;
        $this->title          = __('[ArraySubsPro] Store Credit Expiring Soon', 'arraysubspro');
        $this->description    = __('Sent to customers when their store credit is about to expire.', 'arraysubspro');

        $this->heading        = __('Your store credit is expiring soon!', 'arraysubspro');
        $this->subject        = __('[{site_title}] Your store credit expires soon', 'arraysubspro');

        $this->template_base  = Config::get('proplugin.src_path') . '/Features/StoreCredit/templates/';
        $this->template_html  = 'emails/credit-expiring.php';
        $this->template_plain = 'emails/plain/credit-expiring.php';

        $this->placeholders = [
            '{site_title}'       => $this->get_blogname(),
            '{site_address}'     => wp_parse_url(home_url(), PHP_URL_HOST),
            '{site_url}'         => home_url(),
            '{store_email}'      => get_option('admin_email'),
            '{customer_name}'    => __('John Doe', 'arraysubspro'),
            '{expiring_amount}'  => $this->formatPricePlaceholder(30),
            '{expires_at}'       => \arraysubs_format_timestamp_local(
                strtotime('+7 days', \current_time('timestamp', true)),
                \get_option('date_format')
            ),
            '{days_remaining}'   => '7',
            '{my_account_url}'   => wc_get_account_endpoint_url('store-credit'),
            '{shop_url}'         => wc_get_page_permalink('shop'),
        ];

        parent::__construct();

        // Trigger
        add_action('arraysubs_credit_expiring_soon', [$this, 'trigger'], 10, 4);
    }

    /**
     * Trigger the email
     *
     * @param int    $customer_id   Customer ID
     * @param float  $amount        Expiring amount
     * @param string $expires_at    Expiration date
     * @param int    $credit_log_id Credit log ID
     */
    public function trigger(int $customer_id, float $amount, string $expires_at, int $credit_log_id): void
    {
        $this->customer_id = $customer_id;
        $this->expiring_amount = $amount;
        $this->expires_at = $expires_at;

        $customer = get_user_by('ID', $customer_id);
        if (!$customer) {
            return;
        }

        $this->setup_locale();
        $this->recipient = $customer->user_email;
        $this->populate_placeholders($customer);

        if ($this->is_enabled() && $this->get_recipient()) {
            $this->send(
                $this->get_recipient(),
                $this->get_subject(),
                $this->get_content(),
                $this->get_headers(),
                $this->get_attachments()
            );
        }

        $this->restore_locale();
    }

    /**
     * Populate placeholders
     *
     * @param \WP_User $customer Customer user object
     */
    protected function populate_placeholders(\WP_User $customer): void
    {
        $expires_timestamp = \arraysubs_get_datetime_timestamp_from_string(
            $this->expires_at,
            new \DateTimeZone('UTC')
        );
        $days_remaining = $expires_timestamp
            ? max(0, (int) ceil(($expires_timestamp - \current_time('timestamp', true)) / \DAY_IN_SECONDS))
            : 0;

        $this->placeholders['{customer_name}'] = $customer->display_name ?: $customer->user_login;
        $this->placeholders['{expiring_amount}'] = $this->formatPricePlaceholder($this->expiring_amount);
        $this->placeholders['{expires_at}'] = $expires_timestamp
            ? \arraysubs_format_date_local($this->expires_at, wc_date_format())
            : __('N/A', 'arraysubspro');
        $this->placeholders['{days_remaining}'] = $days_remaining;
        $this->placeholders['{my_account_url}'] = wc_get_account_endpoint_url('store-credit');
        $this->placeholders['{shop_url}'] = wc_get_page_permalink('shop');
    }

    /**
     * Format money placeholders for subject/heading text.
     *
     * @param float $amount Amount.
     * @return string
     */
    private function formatPricePlaceholder(float $amount): string
    {
        return html_entity_decode(wp_strip_all_tags(wc_price($amount)), ENT_QUOTES, get_bloginfo('charset'));
    }

    /**
     * Get content HTML
     *
     * @return string
     */
    public function get_content_html(): string
    {
        return wc_get_template_html(
            $this->template_html,
            [
                'arraysubs_customer_id'     => $this->customer_id,
                'arraysubs_expiring_amount' => $this->expiring_amount,
                'arraysubs_expires_at'      => $this->expires_at,
                'arraysubs_email_heading'   => $this->get_heading(),
                'arraysubs_additional_content' => $this->get_additional_content(),
                'arraysubs_sent_to_admin'   => false,
                'arraysubs_plain_text'      => false,
                'arraysubs_email'           => $this,
            ],
            '',
            $this->template_base
        );
    }

    /**
     * Get content plain
     *
     * @return string
     */
    public function get_content_plain(): string
    {
        return wc_get_template_html(
            $this->template_plain,
            [
                'arraysubs_customer_id'     => $this->customer_id,
                'arraysubs_expiring_amount' => $this->expiring_amount,
                'arraysubs_expires_at'      => $this->expires_at,
                'arraysubs_email_heading'   => $this->get_heading(),
                'arraysubs_additional_content' => $this->get_additional_content(),
                'arraysubs_sent_to_admin'   => false,
                'arraysubs_plain_text'      => true,
                'arraysubs_email'           => $this,
            ],
            '',
            $this->template_base
        );
    }

    /**
     * Get default subject
     *
     * @return string
     */
    public function get_default_subject(): string
    {
        return __('[{site_title}] Your store credit expires soon', 'arraysubspro');
    }

    /**
     * Get default heading
     *
     * @return string
     */
    public function get_default_heading(): string
    {
        return __('Your store credit is expiring soon!', 'arraysubspro');
    }

    /**
     * Default additional content
     *
     * @return string
     */
    public function get_default_additional_content(): string
    {
        return __('Use your credit before it expires! Shop now or apply it to your subscription renewal.', 'arraysubspro');
    }

    /**
     * Initialise settings form fields
     */
    public function init_form_fields(): void
    {
        /* translators: %s: comma-separated list of email template placeholders with code tags */
        $placeholder_text = sprintf(
            /* translators: %s: comma-separated list of email template placeholders with code tags */
            __('Available placeholders: %s', 'arraysubspro'),
            '<code>' . implode('</code>, <code>', array_keys($this->placeholders)) . '</code>'
        );

        $this->form_fields = [
            'enabled' => [
                'title'   => __('Enable/Disable', 'arraysubspro'),
                'type'    => 'checkbox',
                'label'   => __('Enable this email notification', 'arraysubspro'),
                'default' => 'yes',
            ],
            'subject' => [
                'title'       => __('Subject', 'arraysubspro'),
                'type'        => 'text',
                'desc_tip'    => true,
                'description' => $placeholder_text,
                'placeholder' => $this->get_default_subject(),
                'default'     => '',
            ],
            'heading' => [
                'title'       => __('Email heading', 'arraysubspro'),
                'type'        => 'text',
                'desc_tip'    => true,
                'description' => $placeholder_text,
                'placeholder' => $this->get_default_heading(),
                'default'     => '',
            ],
            'additional_content' => [
                'title'       => __('Additional content', 'arraysubspro'),
                'description' => __('Text to appear below the main email content.', 'arraysubspro') . ' ' . $placeholder_text,
                'css'         => 'width:400px; height: 75px;',
                'placeholder' => __('N/A', 'arraysubspro'),
                'type'        => 'textarea',
                'default'     => $this->get_default_additional_content(),
                'desc_tip'    => true,
            ],
            'email_type' => [
                'title'       => __('Email type', 'arraysubspro'),
                'type'        => 'select',
                'description' => __('Choose which format of email to send.', 'arraysubspro'),
                'default'     => 'html',
                'class'       => 'email_type wc-enhanced-select',
                'options'     => $this->get_email_type_options(),
                'desc_tip'    => true,
            ],
        ];
    }
}
