<?php

/**
 * Credit Used Email
 *
 * Sent to customers when store credit is used for a purchase or renewal.
 *
 * @package ArraySubsPro\Features\StoreCredit\Emails
 * @since 1.0.0
 */

namespace ArraySubsPro\Features\StoreCredit\Emails;

defined('ABSPATH') || exit;

use ArraySubs\Supports\Config;

/**
 * Credit Used Email class
 */
class CreditUsedEmail extends \WC_Email
{
    /**
     * Customer ID
     *
     * @var int
     */
    protected int $customer_id = 0;

    /**
     * Credit amount used
     *
     * @var float
     */
    protected float $credit_used = 0.0;

    /**
     * Remaining balance
     *
     * @var float
     */
    protected float $remaining_balance = 0.0;

    /**
     * Order ID
     *
     * @var int
     */
    protected int $order_id = 0;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->id             = 'arraysubs_credit_used';
        $this->customer_email = true;
        $this->title          = __('[ArraySubsPro] Store Credit Used', 'arraysubspro');
        $this->description    = __('Sent to customers when store credit is applied to an order.', 'arraysubspro');

        $this->heading        = __('Store credit applied to your order', 'arraysubspro');
        $this->subject        = __('[{site_title}] Store credit used for Order #{order_id}', 'arraysubspro');

        $this->template_base  = Config::get('proplugin.src_path') . '/Features/StoreCredit/templates/';
        $this->template_html  = 'emails/credit-used.php';
        $this->template_plain = 'emails/plain/credit-used.php';

        $this->placeholders = [
            '{site_title}'        => $this->get_blogname(),
            '{site_address}'      => wp_parse_url(home_url(), PHP_URL_HOST),
            '{site_url}'          => home_url(),
            '{store_email}'       => get_option('admin_email'),
            '{customer_name}'     => __('John Doe', 'arraysubspro'),
            '{credit_used}'       => $this->formatPricePlaceholder(20),
            '{remaining_balance}' => $this->formatPricePlaceholder(30),
            '{order_id}'          => '12345',
            '{order_url}'         => wc_get_account_endpoint_url('view-order') . '/12345',
            '{my_account_url}'    => wc_get_account_endpoint_url('store-credit'),
        ];

        parent::__construct();

        // Trigger
        add_action('arraysubs_credits_applied_to_order', [$this, 'trigger'], 10, 3);
    }

    /**
     * Trigger the email
     *
     * @param \WC_Order $order         Order object
     * @param float     $total_applied Total credit applied
     * @param int|null  $subscription_id Subscription ID if renewal
     */
    public function trigger(\WC_Order $order, float $total_applied, ?int $subscription_id = null): void
    {
        if ($total_applied <= 0) {
            return;
        }

        $this->customer_id = $order->get_customer_id();
        if (!$this->customer_id) {
            return;
        }

        $this->credit_used = $total_applied;
        $this->order_id = $order->get_id();

        // Get remaining balance
        $customer_balance = (float) get_user_meta($this->customer_id, '_arraysubs_store_credit', true);
        $subscription_balance = 0;
        if ($subscription_id) {
            $subscription_balance = (float) get_post_meta($subscription_id, '_store_credit', true);
        }
        $this->remaining_balance = $customer_balance + $subscription_balance;

        $customer = get_user_by('ID', $this->customer_id);
        if (!$customer) {
            return;
        }

        $this->setup_locale();
        $this->recipient = $customer->user_email;
        $this->populate_placeholders($customer, $order);

        if ($this->is_enabled() && $this->get_recipient()) {
            $this->send(
                $this->get_recipient(),
                $this->get_subject(),
                $this->get_content(),
                $this->get_headers(),
                $this->get_attachments()
            );
        }

        $this->restore_locale();
    }

    /**
     * Populate placeholders
     *
     * @param \WP_User  $customer Customer user object
     * @param \WC_Order $order    Order object
     */
    protected function populate_placeholders(\WP_User $customer, \WC_Order $order): void
    {
        $this->placeholders['{customer_name}'] = $customer->display_name ?: $customer->user_login;
        $this->placeholders['{credit_used}'] = $this->formatPricePlaceholder($this->credit_used);
        $this->placeholders['{remaining_balance}'] = $this->formatPricePlaceholder($this->remaining_balance);
        $this->placeholders['{order_id}'] = $this->order_id;
        $this->placeholders['{order_url}'] = $order->get_view_order_url();
        $this->placeholders['{my_account_url}'] = wc_get_account_endpoint_url('store-credit');
    }

    /**
     * Format money placeholders for subject/heading text.
     *
     * @param float $amount Amount.
     * @return string
     */
    private function formatPricePlaceholder(float $amount): string
    {
        return html_entity_decode(wp_strip_all_tags(wc_price($amount)), ENT_QUOTES, get_bloginfo('charset'));
    }

    /**
     * Get content HTML
     *
     * @return string
     */
    public function get_content_html(): string
    {
        return wc_get_template_html(
            $this->template_html,
            [
                'arraysubs_customer_id'       => $this->customer_id,
                'arraysubs_credit_used'       => $this->credit_used,
                'arraysubs_remaining_balance' => $this->remaining_balance,
                'arraysubs_order_id'          => $this->order_id,
                'arraysubs_email_heading'     => $this->get_heading(),
                'arraysubs_additional_content' => $this->get_additional_content(),
                'arraysubs_sent_to_admin'     => false,
                'arraysubs_plain_text'        => false,
                'arraysubs_email'             => $this,
            ],
            '',
            $this->template_base
        );
    }

    /**
     * Get content plain
     *
     * @return string
     */
    public function get_content_plain(): string
    {
        return wc_get_template_html(
            $this->template_plain,
            [
                'arraysubs_customer_id'       => $this->customer_id,
                'arraysubs_credit_used'       => $this->credit_used,
                'arraysubs_remaining_balance' => $this->remaining_balance,
                'arraysubs_order_id'          => $this->order_id,
                'arraysubs_email_heading'     => $this->get_heading(),
                'arraysubs_additional_content' => $this->get_additional_content(),
                'arraysubs_sent_to_admin'     => false,
                'arraysubs_plain_text'        => true,
                'arraysubs_email'             => $this,
            ],
            '',
            $this->template_base
        );
    }

    /**
     * Get default subject
     *
     * @return string
     */
    public function get_default_subject(): string
    {
        return __('[{site_title}] Store credit used for Order #{order_id}', 'arraysubspro');
    }

    /**
     * Get default heading
     *
     * @return string
     */
    public function get_default_heading(): string
    {
        return __('Store credit applied to your order', 'arraysubspro');
    }

    /**
     * Default additional content
     *
     * @return string
     */
    public function get_default_additional_content(): string
    {
        return __('Thank you for your purchase!', 'arraysubspro');
    }

    /**
     * Initialise settings form fields
     */
    public function init_form_fields(): void
    {
        /* translators: %s: comma-separated list of email template placeholders with code tags */
        $placeholder_text = sprintf(
            /* translators: %s: comma-separated list of email template placeholders with code tags */
            __('Available placeholders: %s', 'arraysubspro'),
            '<code>' . implode('</code>, <code>', array_keys($this->placeholders)) . '</code>'
        );

        $this->form_fields = [
            'enabled' => [
                'title'   => __('Enable/Disable', 'arraysubspro'),
                'type'    => 'checkbox',
                'label'   => __('Enable this email notification', 'arraysubspro'),
                'default' => 'yes',
            ],
            'subject' => [
                'title'       => __('Subject', 'arraysubspro'),
                'type'        => 'text',
                'desc_tip'    => true,
                'description' => $placeholder_text,
                'placeholder' => $this->get_default_subject(),
                'default'     => '',
            ],
            'heading' => [
                'title'       => __('Email heading', 'arraysubspro'),
                'type'        => 'text',
                'desc_tip'    => true,
                'description' => $placeholder_text,
                'placeholder' => $this->get_default_heading(),
                'default'     => '',
            ],
            'additional_content' => [
                'title'       => __('Additional content', 'arraysubspro'),
                'description' => __('Text to appear below the main email content.', 'arraysubspro') . ' ' . $placeholder_text,
                'css'         => 'width:400px; height: 75px;',
                'placeholder' => __('N/A', 'arraysubspro'),
                'type'        => 'textarea',
                'default'     => $this->get_default_additional_content(),
                'desc_tip'    => true,
            ],
            'email_type' => [
                'title'       => __('Email type', 'arraysubspro'),
                'type'        => 'select',
                'description' => __('Choose which format of email to send.', 'arraysubspro'),
                'default'     => 'html',
                'class'       => 'email_type wc-enhanced-select',
                'options'     => $this->get_email_type_options(),
                'desc_tip'    => true,
            ],
        ];
    }
}
