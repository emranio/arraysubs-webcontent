<?php

/**
 * Credit Expired Email
 *
 * Sent to customers when their store credit has expired.
 *
 * @package ArraySubsPro\Features\StoreCredit\Emails
 * @since 1.0.0
 */

namespace ArraySubsPro\Features\StoreCredit\Emails;

defined('ABSPATH') || exit;

use ArraySubs\Supports\Config;

/**
 * Credit Expired Email class
 */
class CreditExpiredEmail extends \WC_Email
{
    /**
     * Customer ID
     *
     * @var int
     */
    protected int $customer_id = 0;

    /**
     * Expired credit amount
     *
     * @var float
     */
    protected float $expired_amount = 0.0;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->id             = 'arraysubs_credit_expired';
        $this->customer_email = true;
        $this->title          = __('[ArraySubsPro] Store Credit Expired', 'arraysubspro');
        $this->description    = __('Sent to customers when their store credit has expired.', 'arraysubspro');

        $this->heading        = __('Your store credit has expired', 'arraysubspro');
        $this->subject        = __('[{site_title}] Your store credit has expired', 'arraysubspro');

        $this->template_base  = Config::get('proplugin.src_path') . '/Features/StoreCredit/templates/';
        $this->template_html  = 'emails/credit-expired.php';
        $this->template_plain = 'emails/plain/credit-expired.php';

        $this->placeholders = [
            '{site_title}'       => $this->get_blogname(),
            '{site_address}'     => wp_parse_url(home_url(), PHP_URL_HOST),
            '{site_url}'         => home_url(),
            '{store_email}'      => get_option('admin_email'),
            '{customer_name}'    => __('John Doe', 'arraysubspro'),
            '{expired_amount}'   => $this->formatPricePlaceholder(15),
            '{my_account_url}'   => wc_get_account_endpoint_url('store-credit'),
            '{shop_url}'         => wc_get_page_permalink('shop'),
        ];

        parent::__construct();

        // Trigger
        add_action('arraysubs_credit_expired', [$this, 'trigger'], 10, 2);
    }

    /**
     * Trigger the email
     *
     * @param int   $customer_id Customer ID
     * @param float $amount      Expired amount
     */
    public function trigger(int $customer_id, float $amount): void
    {
        $this->customer_id = $customer_id;
        $this->expired_amount = $amount;

        $customer = get_user_by('ID', $customer_id);
        if (!$customer) {
            return;
        }

        $this->setup_locale();
        $this->recipient = $customer->user_email;
        $this->populate_placeholders($customer);

        if ($this->is_enabled() && $this->get_recipient()) {
            $this->send(
                $this->get_recipient(),
                $this->get_subject(),
                $this->get_content(),
                $this->get_headers(),
                $this->get_attachments()
            );
        }

        $this->restore_locale();
    }

    /**
     * Populate placeholders
     *
     * @param \WP_User $customer Customer user object
     */
    protected function populate_placeholders(\WP_User $customer): void
    {
        $this->placeholders['{customer_name}'] = $customer->display_name ?: $customer->user_login;
        $this->placeholders['{expired_amount}'] = $this->formatPricePlaceholder($this->expired_amount);
        $this->placeholders['{my_account_url}'] = wc_get_account_endpoint_url('store-credit');
        $this->placeholders['{shop_url}'] = wc_get_page_permalink('shop');
    }

    /**
     * Format money placeholders for subject/heading text.
     *
     * @param float $amount Amount.
     * @return string
     */
    private function formatPricePlaceholder(float $amount): string
    {
        return html_entity_decode(wp_strip_all_tags(wc_price($amount)), ENT_QUOTES, get_bloginfo('charset'));
    }

    /**
     * Get content HTML
     *
     * @return string
     */
    public function get_content_html(): string
    {
        return wc_get_template_html(
            $this->template_html,
            [
                'arraysubs_customer_id'     => $this->customer_id,
                'arraysubs_expired_amount'  => $this->expired_amount,
                'arraysubs_email_heading'   => $this->get_heading(),
                'arraysubs_additional_content' => $this->get_additional_content(),
                'arraysubs_sent_to_admin'   => false,
                'arraysubs_plain_text'      => false,
                'arraysubs_email'           => $this,
            ],
            '',
            $this->template_base
        );
    }

    /**
     * Get content plain
     *
     * @return string
     */
    public function get_content_plain(): string
    {
        return wc_get_template_html(
            $this->template_plain,
            [
                'arraysubs_customer_id'     => $this->customer_id,
                'arraysubs_expired_amount'  => $this->expired_amount,
                'arraysubs_email_heading'   => $this->get_heading(),
                'arraysubs_additional_content' => $this->get_additional_content(),
                'arraysubs_sent_to_admin'   => false,
                'arraysubs_plain_text'      => true,
                'arraysubs_email'           => $this,
            ],
            '',
            $this->template_base
        );
    }

    /**
     * Get default subject
     *
     * @return string
     */
    public function get_default_subject(): string
    {
        return __('[{site_title}] Your store credit has expired', 'arraysubspro');
    }

    /**
     * Get default heading
     *
     * @return string
     */
    public function get_default_heading(): string
    {
        return __('Your store credit has expired', 'arraysubspro');
    }

    /**
     * Default additional content
     *
     * @return string
     */
    public function get_default_additional_content(): string
    {
        return __('Credit has expired and is no longer available for use. Visit our shop to explore current offers!', 'arraysubspro');
    }

    /**
     * Initialise settings form fields
     */
    public function init_form_fields(): void
    {
        /* translators: %s: comma-separated list of email template placeholders with code tags */
        $placeholder_text = sprintf(
            /* translators: %s: comma-separated list of email template placeholders with code tags */
            __('Available placeholders: %s', 'arraysubspro'),
            '<code>' . implode('</code>, <code>', array_keys($this->placeholders)) . '</code>'
        );

        $this->form_fields = [
            'enabled' => [
                'title'   => __('Enable/Disable', 'arraysubspro'),
                'type'    => 'checkbox',
                'label'   => __('Enable this email notification', 'arraysubspro'),
                'default' => 'yes',
            ],
            'subject' => [
                'title'       => __('Subject', 'arraysubspro'),
                'type'        => 'text',
                'desc_tip'    => true,
                'description' => $placeholder_text,
                'placeholder' => $this->get_default_subject(),
                'default'     => '',
            ],
            'heading' => [
                'title'       => __('Email heading', 'arraysubspro'),
                'type'        => 'text',
                'desc_tip'    => true,
                'description' => $placeholder_text,
                'placeholder' => $this->get_default_heading(),
                'default'     => '',
            ],
            'additional_content' => [
                'title'       => __('Additional content', 'arraysubspro'),
                'description' => __('Text to appear below the main email content.', 'arraysubspro') . ' ' . $placeholder_text,
                'css'         => 'width:400px; height: 75px;',
                'placeholder' => __('N/A', 'arraysubspro'),
                'type'        => 'textarea',
                'default'     => $this->get_default_additional_content(),
                'desc_tip'    => true,
            ],
            'email_type' => [
                'title'       => __('Email type', 'arraysubspro'),
                'type'        => 'select',
                'description' => __('Choose which format of email to send.', 'arraysubspro'),
                'default'     => 'html',
                'class'       => 'email_type wc-enhanced-select',
                'options'     => $this->get_email_type_options(),
                'desc_tip'    => true,
            ],
        ];
    }
}
