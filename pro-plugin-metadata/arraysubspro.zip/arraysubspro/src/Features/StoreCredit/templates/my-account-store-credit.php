<?php

/**
 * My Account - Store Credit
 *
 * Shows customer store credit balance and history.
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/myaccount/store-credit.php.
 *
 * @package ArraySubsPro\Features\StoreCredit\templates
 * @version 1.0.0
 *
 * @var float $arraysubs_balance        Current credit balance
 * @var array $arraysubs_history        Credit history with pagination
 * @var array $arraysubs_expiring_credits Credits expiring soon
 * @var float $arraysubs_total_expiring  Total amount expiring
 */

defined('ABSPATH') || exit;

$arraysubs_source_labels = [
    'refund' => __('Refund', 'arraysubspro'),
    'admin' => __('Admin', 'arraysubspro'),
    'subscription' => __('Subscription', 'arraysubspro'),
    'subscription_credit' => __('Subscription', 'arraysubspro'),
    'order' => __('Order Payment', 'arraysubspro'),
    'purchase' => __('Purchase', 'arraysubspro'),
    'expiration' => __('Expiration', 'arraysubspro'),
    'manual' => __('Manual', 'arraysubspro'),
    'adjustment' => __('Adjustment', 'arraysubspro'),
];

// Check if credit purchase is enabled
$arraysubs_settings = get_option('arraysubs_settings', []);
$arraysubs_purchase_enabled = !empty($arraysubs_settings['store_credit']['enable_purchase']);
$arraysubs_credit_products = $arraysubs_purchase_enabled ? \ArraySubsPro\Features\StoreCredit\Services\CreditPurchase::getCreditProducts() : [];
?>

<div class="arraysubspro-store-credit">
    <!-- Balance Card -->
    <div class="arraysubspro-store-credit-balance">
        <div class="arraysubspro-store-credit-balance__label">
            <?php esc_html_e('Your Store Credit Balance', 'arraysubspro'); ?>
        </div>
        <div class="arraysubspro-store-credit-balance__amount">
            <?php echo wp_kses_post(wc_price($arraysubs_balance)); ?>
        </div>
        <?php if ($arraysubs_purchase_enabled && !empty($arraysubs_credit_products)) : ?>
            <div class="arraysubspro-store-credit-balance__actions">
                <a href="#buy-credits" class="button arraysubspro-buy-credit-btn">
                    <?php esc_html_e('+ Buy More Credit', 'arraysubspro'); ?>
                </a>
            </div>
        <?php endif; ?>
    </div>

    <!-- Buy Credits Section -->
    <?php if ($arraysubs_purchase_enabled && !empty($arraysubs_credit_products)) : ?>
        <div id="buy-credits" class="arraysubspro-store-credit-purchase">
            <h3><?php esc_html_e('Purchase Store Credit', 'arraysubspro'); ?></h3>
            <p class="description"><?php esc_html_e('Add more credit to your account for future purchases and subscription renewals.', 'arraysubspro'); ?></p>

            <div class="arraysubspro-credit-products">
                <?php
                // Get settings for custom amount limits
                $arraysubs_credit_settings = \ArraySubsPro\Features\StoreCredit\Services\CreditPurchase::getSettings();
                $arraysubs_min_amount = $arraysubs_credit_settings['min_amount'];
                $arraysubs_max_amount = $arraysubs_credit_settings['max_amount'];
                $arraysubs_default_amount = $arraysubs_credit_settings['default_amount'];

                foreach ($arraysubs_credit_products as $arraysubs_product) :
                    $arraysubs_amount_type = get_post_meta($arraysubs_product->get_id(), '_arraysubs_credit_amount_type', true);
                    $arraysubs_credit_amount = get_post_meta($arraysubs_product->get_id(), '_arraysubs_credit_amount', true);
                    $arraysubs_bonus_percentage = (float) get_post_meta($arraysubs_product->get_id(), '_arraysubs_bonus_percentage', true);
                    $arraysubs_is_custom = ($arraysubs_amount_type === 'custom');

                    // Determine display amount
                    if ($arraysubs_amount_type === 'fixed' && $arraysubs_credit_amount) {
                        $arraysubs_display_amount = wc_price($arraysubs_credit_amount);
                    } else {
                        $arraysubs_display_amount = __('You Choose', 'arraysubspro');
                    }
                ?>
                    <div class="arraysubspro-credit-product<?php echo $arraysubs_is_custom ? ' arraysubspro-credit-product--custom' : ''; ?>">
                        <div class="arraysubspro-credit-product__info">
                            <h4 class="arraysubspro-credit-product__name"><?php echo esc_html($arraysubs_product->get_name()); ?></h4>
                            <div class="arraysubspro-credit-product__amount">
                                <?php echo wp_kses_post($arraysubs_display_amount); ?>
                            </div>
                            <?php if ($arraysubs_bonus_percentage > 0) : ?>
                                <div class="arraysubspro-credit-product__bonus">
                                    <span class="bonus-badge">+<?php echo esc_html($arraysubs_bonus_percentage); ?>% <?php esc_html_e('Bonus', 'arraysubspro'); ?></span>
                                </div>
                            <?php endif; ?>
                            <?php if (!$arraysubs_is_custom) : ?>
                                <div class="arraysubspro-credit-product__price">
                                    <?php esc_html_e('Price:', 'arraysubspro'); ?> <?php echo wp_kses_post($arraysubs_product->get_price_html()); ?>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="arraysubspro-credit-product__action">
                            <?php if ($arraysubs_is_custom) : ?>
                                <form class="arraysubspro-custom-credit-form" method="post" action="<?php echo esc_url(wc_get_cart_url()); ?>">
                                    <div class="arraysubspro-custom-credit-input">
                                        <span class="currency-symbol"><?php echo esc_html(get_woocommerce_currency_symbol()); ?></span>
                                        <input type="number"
                                            name="arraysubs_credit_amount"
                                            class="input-text"
                                            value="<?php echo esc_attr($arraysubs_default_amount); ?>"
                                            min="<?php echo esc_attr($arraysubs_min_amount); ?>"
                                            max="<?php echo esc_attr($arraysubs_max_amount); ?>"
                                            step="1"
                                            required />
                                    </div>
                                    <p class="arraysubspro-custom-credit-limits">
                                        <?php
                                        printf(
                                            /* translators: %1$s: min amount, %2$s: max amount */
                                            esc_html__('Min: %1$s - Max: %2$s', 'arraysubspro'),
                                            wp_kses_post(wc_price($arraysubs_min_amount)),
                                            wp_kses_post(wc_price($arraysubs_max_amount))
                                        );
                                        ?>
                                    </p>
                                    <input type="hidden" name="add-to-cart" value="<?php echo esc_attr($arraysubs_product->get_id()); ?>" />
                                    <?php wp_nonce_field('arraysubs_custom_credit', 'arraysubs_credit_nonce'); ?>
                                    <button type="submit" class="button alt">
                                        <?php esc_html_e('Add to Cart', 'arraysubspro'); ?>
                                    </button>
                                </form>
                            <?php else : ?>
                                <a href="<?php echo esc_url($arraysubs_product->add_to_cart_url()); ?>" class="button alt">
                                    <?php esc_html_e('Buy Now', 'arraysubspro'); ?>
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    <?php endif; ?>

    <!-- Expiring Credits Warning -->
    <?php if ($arraysubs_total_expiring > 0 && !empty($arraysubs_expiring_credits)) : ?>
        <div class="arraysubspro-store-credit-expiring">
            <span class="arraysubspro-store-credit-expiring__icon">⚠️</span>
            <div class="arraysubspro-store-credit-expiring__text">
                <?php
                printf(
                    /* translators: %s: expiring credit amount */
                    esc_html__('%s of your store credit is expiring within the next 30 days.', 'arraysubspro'),
                    '<span class="arraysubspro-store-credit-expiring__amount">' . wp_kses_post(wc_price($arraysubs_total_expiring)) . '</span>'
                );
                ?>
                <a href="<?php echo esc_url(wc_get_page_permalink('shop')); ?>">
                    <?php esc_html_e('Use it now!', 'arraysubspro'); ?>
                </a>
            </div>
        </div>
    <?php endif; ?>

    <!-- Credit History -->
    <div class="arraysubspro-store-credit-history">
        <h3 class="arraysubspro-store-credit-history__title">
            <?php esc_html_e('Transaction History', 'arraysubspro'); ?>
        </h3>

        <?php if (!empty($arraysubs_history['items'])) : ?>
            <div class="arraysubspro-credit-table-wrapper">
                <table class="arraysubspro-credit-table woocommerce-table shop_table">
                    <thead>
                        <tr>
                            <th><?php esc_html_e('Date', 'arraysubspro'); ?></th>
                            <th><?php esc_html_e('Title', 'arraysubspro'); ?></th>
                            <th><?php esc_html_e('Info', 'arraysubspro'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        foreach ($arraysubs_history['items'] as $arraysubs_credit_log) :
                            $arraysubs_type = get_post_meta($arraysubs_credit_log->ID, '_type', true);
                            $arraysubs_amount = (float) get_post_meta($arraysubs_credit_log->ID, '_amount', true);
                            $arraysubs_source = get_post_meta($arraysubs_credit_log->ID, '_source', true);
                            $arraysubs_note = get_post_meta($arraysubs_credit_log->ID, '_note', true);
                            $arraysubs_expires_at = get_post_meta($arraysubs_credit_log->ID, '_expires_at', true);
                            $arraysubs_is_expired = get_post_meta($arraysubs_credit_log->ID, '_expired', true);
                            $arraysubs_related_order_id = get_post_meta($arraysubs_credit_log->ID, '_related_order_id', true);
                            $arraysubs_related_subscription_id = get_post_meta($arraysubs_credit_log->ID, '_related_subscription_id', true);

                            // Build description
                            $arraysubs_description = $arraysubs_note ?: '';
                            if (!$arraysubs_description) {
                                if ($arraysubs_type === 'credit') {
                                    $arraysubs_description = __('Credit added', 'arraysubspro');
                                } else {
                                    $arraysubs_description = __('Credit applied', 'arraysubspro');
                                }
                            }

                            // Add related links
                            if ($arraysubs_related_order_id) {
                                $arraysubs_order_url = wc_get_endpoint_url('view-order', $arraysubs_related_order_id, wc_get_page_permalink('myaccount'));
                                $arraysubs_description .= ' <a href="' . esc_url($arraysubs_order_url) . '">#' . esc_html($arraysubs_related_order_id) . '</a>';
                            }

                            // Format expiration
                            $arraysubs_expires_display = '—';
                            $arraysubs_expires_class = '';
                            if ($arraysubs_type === 'credit' && $arraysubs_expires_at && !$arraysubs_is_expired) {
                                $arraysubs_expires_timestamp = arraysubs_get_datetime_timestamp_from_string(
                                    $arraysubs_expires_at,
                                    new \DateTimeZone('UTC')
                                );
                                $arraysubs_days_until = $arraysubs_expires_timestamp
                                    ? ceil(($arraysubs_expires_timestamp - current_time('timestamp', true)) / \DAY_IN_SECONDS)
                                    : 0;

                                if ($arraysubs_days_until <= 7) {
                                    $arraysubs_expires_class = 'arraysubspro-credit-expires--soon';
                                }

                                $arraysubs_expires_display = arraysubs_format_date_local($arraysubs_expires_at, wc_date_format());
                            } elseif ($arraysubs_is_expired) {
                                $arraysubs_expires_display = '<span style="color: #999;">' . esc_html__('Expired', 'arraysubspro') . '</span>';
                            }

                            // Source label
                            $arraysubs_source_label = $arraysubs_source_labels[$arraysubs_source] ?? ucfirst($arraysubs_source);
                            $arraysubs_source_class = 'arraysubspro-credit-source--' . esc_attr($arraysubs_source);
                        ?>
                            <tr>
                                <td>
                                    <?php echo esc_html(!empty($arraysubs_credit_log->post_date_gmt) && $arraysubs_credit_log->post_date_gmt !== '0000-00-00 00:00:00' ? arraysubs_format_date_local($arraysubs_credit_log->post_date_gmt, wc_date_format() . ' ' . wc_time_format()) : arraysubs_format_site_local_date($arraysubs_credit_log->post_date, wc_date_format() . ' ' . wc_time_format())); ?>
                                </td>
                                <td>
                                    <div>
                                        <?php echo wp_kses_post($arraysubs_description); ?>
                                    </div>
                                    <span class="arraysubspro-credit-source <?php echo esc_attr($arraysubs_source_class); ?>">
                                        <?php echo esc_html($arraysubs_source_label); ?>
                                    </span>
                                </td>
                                <td>
                                    <?php if ($arraysubs_type === 'credit') : ?>
                                        <span class="arraysubspro-credit-amount--credit">
                                            +<?php echo wp_kses_post(wc_price($arraysubs_amount)); ?>
                                        </span>
                                    <?php else : ?>
                                        <span class="arraysubspro-credit-amount--debit">
                                            -<?php echo wp_kses_post(wc_price($arraysubs_amount)); ?>
                                        </span>
                                    <?php endif; ?>
                                    <span class="arraysubspro-credit-expires <?php echo esc_attr($arraysubs_expires_class); ?>">
                                        <?php echo wp_kses_post($arraysubs_expires_display); ?>
                                    </span>
                                </td>

                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <!-- Pagination -->
            <?php if ($arraysubs_history['pages'] > 1) : ?>
                <nav class="arraysubspro-credit-pagination woocommerce-pagination">
                    <?php
                    echo wp_kses_post(paginate_links([
                        'base' => esc_url_raw(str_replace(999999999, '%#%', remove_query_arg('paged', get_pagenum_link(999999999, false)))),
                        'format' => '?paged=%#%',
                        'current' => max(1, $arraysubs_history['current_page']),
                        'total' => $arraysubs_history['pages'],
                        'prev_text' => '&larr;',
                        'next_text' => '&rarr;',
                        'type' => 'list',
                        'end_size' => 2,
                        'mid_size' => 1,
                    ]));
                    ?>
                </nav>
            <?php endif; ?>

        <?php else : ?>
            <div class="arraysubspro-credit-empty">
                <p><?php esc_html_e('No credit transactions yet.', 'arraysubspro'); ?></p>
                <p><?php esc_html_e('Store credit can be earned through refunds, subscription rewards, or promotional offers.', 'arraysubspro'); ?></p>
            </div>
        <?php endif; ?>
    </div>
</div>