<?php

/**
 * Credit Expired Email - Plain Text
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/emails/plain/credit-expired.php.
 *
 * @package ArraySubsPro\Features\StoreCredit\templates\emails\plain
 * @version 1.0.0
 */

defined('ABSPATH') || exit;

$arraysubs_customer = get_user_by('ID', $arraysubs_customer_id);
$arraysubs_customer_name = $arraysubs_customer ? ($arraysubs_customer->display_name ?: $arraysubs_customer->first_name ?: __('there', 'arraysubspro')) : __('there', 'arraysubspro');

echo "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=\n";
echo esc_html(wp_strip_all_tags($arraysubs_email_heading));
echo "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=\n\n";

printf(
    /* translators: %s: Customer first name */
    esc_html__('Hi %s,', 'arraysubspro'),
    esc_html($arraysubs_customer_name)
);
echo "\n\n";

printf(
    /* translators: %s: Expired credit amount */
    esc_html__('We wanted to let you know that %s of your store credit has expired.', 'arraysubspro'),
    esc_html(wp_strip_all_tags(wc_price($arraysubs_expired_amount)))
);
echo "\n\n";

echo "----------\n";
echo esc_html__('Expired Credit', 'arraysubspro') . ': ' . esc_html(wp_strip_all_tags(wc_price($arraysubs_expired_amount))) . "\n";
echo "----------\n\n";

echo esc_html__('This credit is no longer available for use. If you have any questions, please contact our support team.', 'arraysubspro');
echo "\n\n";

echo esc_html__('Visit Our Shop:', 'arraysubspro') . "\n";
echo esc_url(wc_get_page_permalink('shop'));
echo "\n\n";

echo esc_html__('View your store credit balance:', 'arraysubspro') . "\n";
echo esc_url(wc_get_account_endpoint_url('store-credit'));
echo "\n\n";

if ($arraysubs_additional_content) {
    echo "----------\n\n";
    echo esc_html(wp_strip_all_tags(wptexturize($arraysubs_additional_content)));
    echo "\n\n";
}

// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- WooCommerce core hook
echo wp_kses_post(apply_filters('woocommerce_email_footer_text', get_option('woocommerce_email_footer_text')));
