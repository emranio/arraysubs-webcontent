<?php

/**
 * Credit Expiring Email - Plain Text
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/emails/plain/credit-expiring.php.
 *
 * @package ArraySubsPro\Features\StoreCredit\templates\emails\plain
 * @version 1.0.0
 */

defined('ABSPATH') || exit;

$arraysubs_customer = get_user_by('ID', $arraysubs_customer_id);
$arraysubs_customer_name = $arraysubs_customer ? ($arraysubs_customer->display_name ?: $arraysubs_customer->first_name ?: __('there', 'arraysubspro')) : __('there', 'arraysubspro');

$arraysubs_expires_timestamp = arraysubs_get_datetime_timestamp_from_string(
    $arraysubs_expires_at,
    new \DateTimeZone('UTC')
);
$arraysubs_days_remaining = $arraysubs_expires_timestamp
    ? max(0, (int) ceil(($arraysubs_expires_timestamp - current_time('timestamp', true)) / DAY_IN_SECONDS))
    : 0;

echo "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=\n";
echo esc_html(wp_strip_all_tags($arraysubs_email_heading));
echo "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=\n\n";

printf(
    /* translators: %s: Customer first name */
    esc_html__('Hi %s,', 'arraysubspro'),
    esc_html($arraysubs_customer_name)
);
echo "\n\n";

printf(
    /* translators: 1: Credit amount, 2: Days remaining */
    esc_html__('Just a friendly reminder: %1$s of your store credit will expire in %2$s days!', 'arraysubspro'),
    esc_html(wp_strip_all_tags(wc_price($arraysubs_expiring_amount))),
    esc_html($arraysubs_days_remaining)
);
echo "\n\n";

echo "----------\n";
echo esc_html__('Expiring Credit', 'arraysubspro') . ': ' . esc_html(wp_strip_all_tags(wc_price($arraysubs_expiring_amount))) . "\n";
echo esc_html__('Expiration Date', 'arraysubspro') . ': ' . esc_html(arraysubs_format_date_local($arraysubs_expires_at, wc_date_format())) . "\n";
echo esc_html__('Days Remaining', 'arraysubspro') . ': ' . esc_html($arraysubs_days_remaining) . ' ' . esc_html(_n('day', 'days', $arraysubs_days_remaining, 'arraysubspro')) . "\n";
echo "----------\n\n";

echo esc_html__("Don't let your credit go to waste! Use it for your next purchase or it will be applied automatically to your subscription renewal.", 'arraysubspro');
echo "\n\n";

echo esc_html__('Shop Now:', 'arraysubspro') . "\n";
echo esc_url(wc_get_page_permalink('shop'));
echo "\n\n";

echo esc_html__('View your store credit balance:', 'arraysubspro') . "\n";
echo esc_url(wc_get_account_endpoint_url('store-credit'));
echo "\n\n";

if ($arraysubs_additional_content) {
    echo "----------\n\n";
    echo esc_html(wp_strip_all_tags(wptexturize($arraysubs_additional_content)));
    echo "\n\n";
}

// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- WooCommerce core hook
echo wp_kses_post(apply_filters('woocommerce_email_footer_text', get_option('woocommerce_email_footer_text')));
