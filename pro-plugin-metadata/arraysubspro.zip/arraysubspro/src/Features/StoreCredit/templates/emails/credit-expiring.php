<?php

/**
 * Credit Expiring Soon Email
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/emails/credit-expiring.php.
 *
 * @package ArraySubsPro\Features\StoreCredit\templates\emails
 * @version 1.0.0
 */

defined('ABSPATH') || exit;

$arraysubs_customer = get_user_by('ID', $arraysubs_customer_id);
$arraysubs_customer_name = $arraysubs_customer ? ($arraysubs_customer->display_name ?: $arraysubs_customer->first_name ?: __('there', 'arraysubspro')) : __('there', 'arraysubspro');

$arraysubs_expires_timestamp = arraysubs_get_datetime_timestamp_from_string(
    $arraysubs_expires_at,
    new \DateTimeZone('UTC')
);
$arraysubs_days_remaining = $arraysubs_expires_timestamp
    ? max(0, (int) ceil(($arraysubs_expires_timestamp - current_time('timestamp', true)) / DAY_IN_SECONDS))
    : 0;

// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- WooCommerce core hook
do_action('woocommerce_email_header', $arraysubs_email_heading, $arraysubs_email);
?>

<p>
    <?php
    printf(
        /* translators: %s: Customer first name */
        esc_html__('Hi %s,', 'arraysubspro'),
        esc_html($arraysubs_customer_name)
    );
    ?>
</p>

<p>
    <?php
    printf(
        /* translators: 1: Credit amount, 2: Days remaining */
        esc_html__('Just a friendly reminder: %1$s of your store credit will expire in %2$s days!', 'arraysubspro'),
        wp_kses_post(wc_price($arraysubs_expiring_amount)),
        esc_html($arraysubs_days_remaining)
    );
    ?>
</p>

<table class="td" cellspacing="0" cellpadding="6" style="width: 100%; margin-bottom: 40px;" border="1">
    <tbody>
        <tr>
            <th class="td" scope="row" style="text-align: left;"><?php esc_html_e('Expiring Credit', 'arraysubspro'); ?></th>
            <td class="td" style="text-align: left;">
                <strong style="color: #e74c3c;"><?php echo wp_kses_post(wc_price($arraysubs_expiring_amount)); ?></strong>
            </td>
        </tr>
        <tr>
            <th class="td" scope="row" style="text-align: left;"><?php esc_html_e('Expiration Date', 'arraysubspro'); ?></th>
            <td class="td" style="text-align: left;">
                <?php echo esc_html(arraysubs_format_date_local($arraysubs_expires_at, wc_date_format())); ?>
            </td>
        </tr>
        <tr>
            <th class="td" scope="row" style="text-align: left;"><?php esc_html_e('Days Remaining', 'arraysubspro'); ?></th>
            <td class="td" style="text-align: left;">
                <?php echo esc_html($arraysubs_days_remaining); ?> <?php echo esc_html(_n('day', 'days', $arraysubs_days_remaining, 'arraysubspro')); ?>
            </td>
        </tr>
    </tbody>
</table>

<p><?php esc_html_e("Don't let your credit go to waste! Use it for your next purchase or it will be applied automatically to your subscription renewal.", 'arraysubspro'); ?></p>

<p style="margin-top: 20px;">
    <a class="link" href="<?php echo esc_url(wc_get_page_permalink('shop')); ?>" style="display: inline-block; padding: 10px 20px; background-color: #96588a; color: #ffffff; text-decoration: none; border-radius: 4px;">
        <?php esc_html_e('Shop Now', 'arraysubspro'); ?>
    </a>
</p>

<p>
    <a class="link" href="<?php echo esc_url(wc_get_account_endpoint_url('store-credit')); ?>">
        <?php esc_html_e('View your store credit balance', 'arraysubspro'); ?>
    </a>
</p>

<?php
if ($arraysubs_additional_content) {
    echo wp_kses_post(wpautop(wptexturize($arraysubs_additional_content)));
}

// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- WooCommerce core hook
do_action('woocommerce_email_footer', $arraysubs_email);
