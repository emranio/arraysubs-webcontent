<?php

/**
 * Credit Expired Email
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/emails/credit-expired.php.
 *
 * @package ArraySubsPro\Features\StoreCredit\templates\emails
 * @version 1.0.0
 */

defined('ABSPATH') || exit;

$arraysubs_customer = get_user_by('ID', $arraysubs_customer_id);
$arraysubs_customer_name = $arraysubs_customer ? ($arraysubs_customer->display_name ?: $arraysubs_customer->first_name ?: __('there', 'arraysubspro')) : __('there', 'arraysubspro');

// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- WooCommerce core hook
do_action('woocommerce_email_header', $arraysubs_email_heading, $arraysubs_email);
?>

<p>
    <?php
    printf(
        /* translators: %s: Customer first name */
        esc_html__('Hi %s,', 'arraysubspro'),
        esc_html($arraysubs_customer_name)
    );
    ?>
</p>

<p>
    <?php
    printf(
        /* translators: %s: Expired credit amount */
        esc_html__('We wanted to let you know that %s of your store credit has expired.', 'arraysubspro'),
        wp_kses_post(wc_price($arraysubs_expired_amount))
    );
    ?>
</p>

<table class="td" cellspacing="0" cellpadding="6" style="width: 100%; margin-bottom: 40px;" border="1">
    <tbody>
        <tr>
            <th class="td" scope="row" style="text-align: left;"><?php esc_html_e('Expired Credit', 'arraysubspro'); ?></th>
            <td class="td" style="text-align: left;">
                <span style="color: #999; text-decoration: line-through;"><?php echo wp_kses_post(wc_price($arraysubs_expired_amount)); ?></span>
            </td>
        </tr>
    </tbody>
</table>

<p><?php esc_html_e('This credit is no longer available for use. If you have any questions, please contact our support team.', 'arraysubspro'); ?></p>

<p style="margin-top: 20px;">
    <a class="link" href="<?php echo esc_url(wc_get_page_permalink('shop')); ?>" style="display: inline-block; padding: 10px 20px; background-color: #96588a; color: #ffffff; text-decoration: none; border-radius: 4px;">
        <?php esc_html_e('Visit Our Shop', 'arraysubspro'); ?>
    </a>
</p>

<p>
    <a class="link" href="<?php echo esc_url(wc_get_account_endpoint_url('store-credit')); ?>">
        <?php esc_html_e('View your store credit balance', 'arraysubspro'); ?>
    </a>
</p>

<?php
if ($arraysubs_additional_content) {
    echo wp_kses_post(wpautop(wptexturize($arraysubs_additional_content)));
}

// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- WooCommerce core hook
do_action('woocommerce_email_footer', $arraysubs_email);
