<?php

/**
 * Credit Added Email
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/emails/credit-added.php.
 *
 * @package ArraySubsPro\Features\StoreCredit\templates\emails
 * @version 1.0.0
 */

defined('ABSPATH') || exit;

$arraysubs_customer = get_user_by('ID', $arraysubs_customer_id);
$arraysubs_customer_name = $arraysubs_customer ? ($arraysubs_customer->display_name ?: $arraysubs_customer->first_name ?: __('there', 'arraysubspro')) : __('there', 'arraysubspro');

// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- WooCommerce core hook
do_action('woocommerce_email_header', $arraysubs_email_heading, $arraysubs_email);
?>

<p>
    <?php
    printf(
        /* translators: %s: Customer first name */
        esc_html__('Hi %s,', 'arraysubspro'),
        esc_html($arraysubs_customer_name)
    );
    ?>
</p>

<p>
    <?php
    printf(
        /* translators: %s: Credit amount */
        esc_html__('Great news! %s has been added to your store credit balance.', 'arraysubspro'),
        wp_kses_post(wc_price($arraysubs_credit_amount))
    );
    ?>
</p>

<table class="td" cellspacing="0" cellpadding="6" style="width: 100%; margin-bottom: 40px;" border="1">
    <tbody>
        <tr>
            <th class="td" scope="row" style="text-align: left;"><?php esc_html_e('Credit Added', 'arraysubspro'); ?></th>
            <td class="td" style="text-align: left;">
                <?php echo wp_kses_post(wc_price($arraysubs_credit_amount)); ?>
            </td>
        </tr>
        <tr>
            <th class="td" scope="row" style="text-align: left;"><?php esc_html_e('New Balance', 'arraysubspro'); ?></th>
            <td class="td" style="text-align: left;">
                <strong><?php echo wp_kses_post(wc_price($arraysubs_new_balance)); ?></strong>
            </td>
        </tr>
        <tr>
            <th class="td" scope="row" style="text-align: left;"><?php esc_html_e('Source', 'arraysubspro'); ?></th>
            <td class="td" style="text-align: left;">
                <?php echo esc_html($arraysubs_source_label); ?>
            </td>
        </tr>
    </tbody>
</table>

<p><?php esc_html_e('You can use your store credit for future purchases or let it be applied automatically to your subscription renewals.', 'arraysubspro'); ?></p>

<p>
    <a class="link" href="<?php echo esc_url(wc_get_account_endpoint_url('store-credit')); ?>">
        <?php esc_html_e('View your store credit balance', 'arraysubspro'); ?>
    </a>
</p>

<?php
if ($arraysubs_additional_content) {
    echo wp_kses_post(wpautop(wptexturize($arraysubs_additional_content)));
}

// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- WooCommerce core hook
do_action('woocommerce_email_footer', $arraysubs_email);
