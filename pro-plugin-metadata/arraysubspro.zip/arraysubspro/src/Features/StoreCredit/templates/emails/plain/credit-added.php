<?php

/**
 * Credit Added Email - Plain Text
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/emails/plain/credit-added.php.
 *
 * @package ArraySubsPro\Features\StoreCredit\templates\emails\plain
 * @version 1.0.0
 */

defined('ABSPATH') || exit;

$arraysubs_customer = get_user_by('ID', $arraysubs_customer_id);
$arraysubs_customer_name = $arraysubs_customer ? ($arraysubs_customer->display_name ?: $arraysubs_customer->first_name ?: __('there', 'arraysubspro')) : __('there', 'arraysubspro');

echo "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=\n";
echo esc_html(wp_strip_all_tags($arraysubs_email_heading));
echo "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=\n\n";

printf(
    /* translators: %s: Customer first name */
    esc_html__('Hi %s,', 'arraysubspro'),
    esc_html($arraysubs_customer_name)
);
echo "\n\n";

printf(
    /* translators: %s: Credit amount */
    esc_html__('Great news! %s has been added to your store credit balance.', 'arraysubspro'),
    esc_html(wp_strip_all_tags(wc_price($arraysubs_credit_amount)))
);
echo "\n\n";

echo "----------\n";
echo esc_html__('Credit Added', 'arraysubspro') . ': ' . esc_html(wp_strip_all_tags(wc_price($arraysubs_credit_amount))) . "\n";
echo esc_html__('New Balance', 'arraysubspro') . ': ' . esc_html(wp_strip_all_tags(wc_price($arraysubs_new_balance))) . "\n";
echo esc_html__('Source', 'arraysubspro') . ': ' . esc_html($arraysubs_source_label) . "\n";
echo "----------\n\n";

echo esc_html__('You can use your store credit for future purchases or let it be applied automatically to your subscription renewals.', 'arraysubspro');
echo "\n\n";

echo esc_html__('View your store credit balance:', 'arraysubspro') . "\n";
echo esc_url(wc_get_account_endpoint_url('store-credit'));
echo "\n\n";

if ($arraysubs_additional_content) {
    echo "----------\n\n";
    echo esc_html(wp_strip_all_tags(wptexturize($arraysubs_additional_content)));
    echo "\n\n";
}

// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- WooCommerce core hook
echo wp_kses_post(apply_filters('woocommerce_email_footer_text', get_option('woocommerce_email_footer_text')));
