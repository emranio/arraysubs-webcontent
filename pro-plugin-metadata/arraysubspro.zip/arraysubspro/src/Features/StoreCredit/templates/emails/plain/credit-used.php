<?php

/**
 * Credit Used Email - Plain Text
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/emails/plain/credit-used.php.
 *
 * @package ArraySubsPro\Features\StoreCredit\templates\emails\plain
 * @version 1.0.0
 */

defined('ABSPATH') || exit;

$arraysubs_customer = get_user_by('ID', $arraysubs_customer_id);
$arraysubs_customer_name = $arraysubs_customer ? ($arraysubs_customer->display_name ?: $arraysubs_customer->first_name ?: __('there', 'arraysubspro')) : __('there', 'arraysubspro');

echo "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=\n";
echo esc_html(wp_strip_all_tags($arraysubs_email_heading));
echo "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=\n\n";

printf(
    /* translators: %s: Customer first name */
    esc_html__('Hi %s,', 'arraysubspro'),
    esc_html($arraysubs_customer_name)
);
echo "\n\n";

printf(
    /* translators: 1: Credit amount, 2: Order ID */
    esc_html__('%1$s from your store credit has been applied to order #%2$s.', 'arraysubspro'),
    esc_html(wp_strip_all_tags(wc_price($arraysubs_credit_used))),
    esc_html($arraysubs_order_id)
);
echo "\n\n";

echo "----------\n";
echo esc_html__('Credit Applied', 'arraysubspro') . ': ' . esc_html(wp_strip_all_tags(wc_price($arraysubs_credit_used))) . "\n";
echo esc_html__('Remaining Balance', 'arraysubspro') . ': ' . esc_html(wp_strip_all_tags(wc_price($arraysubs_remaining_balance))) . "\n";
echo esc_html__('Order', 'arraysubspro') . ': #' . esc_html($arraysubs_order_id) . "\n";
echo "----------\n\n";

echo esc_html__('View order details:', 'arraysubspro') . "\n";
echo esc_url(wc_get_endpoint_url('view-order', $arraysubs_order_id, wc_get_page_permalink('myaccount')));
echo "\n\n";

if ($arraysubs_additional_content) {
    echo "----------\n\n";
    echo esc_html(wp_strip_all_tags(wptexturize($arraysubs_additional_content)));
    echo "\n\n";
}

// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- WooCommerce core hook
echo wp_kses_post(apply_filters('woocommerce_email_footer_text', get_option('woocommerce_email_footer_text')));
