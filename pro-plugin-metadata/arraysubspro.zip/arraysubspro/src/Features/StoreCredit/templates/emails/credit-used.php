<?php

/**
 * Credit Used Email
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/emails/credit-used.php.
 *
 * @package ArraySubsPro\Features\StoreCredit\templates\emails
 * @version 1.0.0
 */

defined('ABSPATH') || exit;

$arraysubs_customer = get_user_by('ID', $arraysubs_customer_id);
$arraysubs_customer_name = $arraysubs_customer ? ($arraysubs_customer->display_name ?: $arraysubs_customer->first_name ?: __('there', 'arraysubspro')) : __('there', 'arraysubspro');

// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- WooCommerce core hook
do_action('woocommerce_email_header', $arraysubs_email_heading, $arraysubs_email);
?>

<p>
    <?php
    printf(
        /* translators: %s: Customer first name */
        esc_html__('Hi %s,', 'arraysubspro'),
        esc_html($arraysubs_customer_name)
    );
    ?>
</p>

<p>
    <?php
    printf(
        /* translators: 1: Credit amount, 2: Order ID */
        esc_html__('%1$s from your store credit has been applied to order #%2$s.', 'arraysubspro'),
        wp_kses_post(wc_price($arraysubs_credit_used)),
        esc_html($arraysubs_order_id)
    );
    ?>
</p>

<table class="td" cellspacing="0" cellpadding="6" style="width: 100%; margin-bottom: 40px;" border="1">
    <tbody>
        <tr>
            <th class="td" scope="row" style="text-align: left;"><?php esc_html_e('Credit Applied', 'arraysubspro'); ?></th>
            <td class="td" style="text-align: left;">
                <?php echo wp_kses_post(wc_price($arraysubs_credit_used)); ?>
            </td>
        </tr>
        <tr>
            <th class="td" scope="row" style="text-align: left;"><?php esc_html_e('Remaining Balance', 'arraysubspro'); ?></th>
            <td class="td" style="text-align: left;">
                <strong><?php echo wp_kses_post(wc_price($arraysubs_remaining_balance)); ?></strong>
            </td>
        </tr>
        <tr>
            <th class="td" scope="row" style="text-align: left;"><?php esc_html_e('Order', 'arraysubspro'); ?></th>
            <td class="td" style="text-align: left;">
                <a href="<?php echo esc_url(wc_get_endpoint_url('view-order', $arraysubs_order_id, wc_get_page_permalink('myaccount'))); ?>">
                    #<?php echo esc_html($arraysubs_order_id); ?>
                </a>
            </td>
        </tr>
    </tbody>
</table>

<p>
    <a class="link" href="<?php echo esc_url(wc_get_endpoint_url('view-order', $arraysubs_order_id, wc_get_page_permalink('myaccount'))); ?>">
        <?php esc_html_e('View order details', 'arraysubspro'); ?>
    </a>
</p>

<?php
if ($arraysubs_additional_content) {
    echo wp_kses_post(wpautop(wptexturize($arraysubs_additional_content)));
}

// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- WooCommerce core hook
do_action('woocommerce_email_footer', $arraysubs_email);
