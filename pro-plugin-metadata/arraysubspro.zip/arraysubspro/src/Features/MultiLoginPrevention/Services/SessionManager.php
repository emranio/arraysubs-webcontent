<?php

/**
 * Session Manager
 *
 * Resolves the effective session limit for a user and enforces it
 * by destroying the oldest sessions when the limit is exceeded.
 *
 * @package ArraySubsPro\Features\MultiLoginPrevention\Services
 */

namespace ArraySubsPro\Features\MultiLoginPrevention\Services;

defined('ABSPATH') || exit;

use ArraySubs\Features\MembersAccess\Services\ConditionEvaluator;

/**
 * Manages session counting, limit resolution, and session destruction.
 */
class SessionManager
{
    /**
     * Resolve the effective max-sessions value for a user.
     *
     * 1. Evaluate all enabled Login Limit rules — if any match, the highest
     *    max_sessions among matching rules wins (most permissive).
     * 2. Otherwise fall back to the global toolkit default.
     *
     * @param int $user_id WordPress user ID.
     * @return int Effective max concurrent sessions (>= 1).
     */
    public function getEffectiveMaxSessions(int $user_id): int
    {
        $global_default = $this->getGlobalDefault();

        $login_limit_rules = $this->getLoginLimitRules();
        if (empty($login_limit_rules)) {
            return $global_default;
        }

        $evaluator   = new ConditionEvaluator();
        $max_matched = 0;
        $has_match   = false;

        foreach ($login_limit_rules as $rule) {
            if (empty($rule['enabled'])) {
                continue;
            }

            $conditions = $rule['conditions'] ?? [];
            if ($evaluator->evaluate($user_id, $conditions)) {
                $has_match   = true;
                $rule_limit  = max(1, abs((int) ($rule['max_sessions'] ?? 1)));
                $max_matched = max($max_matched, $rule_limit);
            }
        }

        return $has_match ? $max_matched : $global_default;
    }

    /**
     * Enforce the session limit for a user.
     *
     * Destroys the oldest sessions until only max_sessions remain.
     *
     * @param int $user_id      WordPress user ID.
     * @param int $max_sessions Maximum concurrent sessions allowed.
     * @return int Number of sessions destroyed.
     */
    public function enforceSessionLimit(int $user_id, int $max_sessions): int
    {
        $max_sessions = max(1, abs((int) $max_sessions));
        $manager_class = 'WP_Session_Tokens';
        $manager       = $manager_class::get_instance($user_id);
        $sessions     = $this->getSessionsWithVerifiers($user_id, $manager);

        if (empty($sessions)) {
            return 0;
        }

        // Filter out impersonation sessions if the LoginAsUser feature is active.
        $own_sessions = [];

        foreach ($sessions as $verifier => $session) {
            if ($this->isImpersonationSession($session)) {
                continue;
            } else {
                $own_sessions[$verifier] = $session;
            }
        }

        // Only count/destroy the user's own (non-impersonation) sessions.
        // Note: wp_login fires AFTER wp_set_auth_cookie() has already
        // created the new session token, so the stored sessions already
        // include the new login. We keep max_sessions total (including the
        // new one) and destroy the excess.
        $own_count = count($own_sessions);
        if ($own_count <= $max_sessions) {
            return 0;
        }

        // Sort own sessions by login time ascending (oldest first).
        uasort($own_sessions, function (array $session_a, array $session_b): int {
            return ($session_a['login'] ?? 0) <=> ($session_b['login'] ?? 0);
        });

        // Destroy the oldest sessions until max_sessions remain.
        $to_destroy           = $own_count - $max_sessions;
        $verifiers_to_destroy = array_keys(array_slice($own_sessions, 0, $to_destroy, true));

        return $this->destroySessionsByVerifier($user_id, $manager, $sessions, $verifiers_to_destroy);
    }

    /**
     * Get active sessions keyed by their verifier hashes.
     *
     * WordPress's public get_all() API reindexes the session array with
     * numeric keys, but FIFO eviction needs the original verifier hashes so
     * the oldest sessions can be removed deterministically.
     *
     * @param int    $user_id User ID.
     * @param object $manager Session manager.
     * @return array<string, array>
     */
    private function getSessionsWithVerifiers(int $user_id, object $manager): array
    {
        if ($this->isUserMetaSessionManager($manager)) {
            return $this->getUserMetaSessions($user_id);
        }

        try {
            $reflection = new \ReflectionMethod($manager, 'get_sessions');
            $reflection->setAccessible(true);
            $sessions = $reflection->invoke($manager);
        } catch (\ReflectionException $exception) {
            return [];
        }

        return is_array($sessions) ? $sessions : [];
    }

    /**
     * Get valid session data from the default user-meta session store.
     *
     * @param int $user_id User ID.
     * @return array<string, array>
     */
    private function getUserMetaSessions(int $user_id): array
    {
        $get_user_meta = 'get_user_meta';
        $sessions      = $get_user_meta($user_id, 'session_tokens', true);

        if (!is_array($sessions)) {
            return [];
        }

        $valid_sessions = [];

        foreach ($sessions as $verifier => $session) {
            $prepared_session = $this->prepareSession($session);

            if ($this->isSessionValid($prepared_session)) {
                $valid_sessions[$verifier] = $prepared_session;
            }
        }

        return $valid_sessions;
    }

    /**
     * Normalize a stored session payload.
     *
     * @param mixed $session Stored session payload or legacy expiration timestamp.
     * @return array
     */
    private function prepareSession($session): array
    {
        if (is_int($session)) {
            return [
                'expiration' => $session,
            ];
        }

        return is_array($session) ? $session : [];
    }

    /**
     * Check whether a stored session is still valid.
     *
     * @param array $session Session payload.
     * @return bool
     */
    private function isSessionValid(array $session): bool
    {
        return isset($session['expiration']) && (int) $session['expiration'] >= time();
    }

    /**
     * Destroy specific sessions by their verifier hashes.
     *
     * @param int                  $user_id   User ID.
     * @param object               $manager   Session manager.
     * @param array<string, array> $sessions  Active sessions keyed by verifier.
     * @param array<int, string>   $verifiers Session verifiers to destroy.
     * @return int
     */
    private function destroySessionsByVerifier(int $user_id, object $manager, array $sessions, array $verifiers): int
    {
        if (empty($verifiers)) {
            return 0;
        }

        if ($this->isUserMetaSessionManager($manager)) {
            return $this->destroyUserMetaSessions($user_id, $sessions, $verifiers);
        }

        try {
            $reflection = new \ReflectionMethod($manager, 'update_session');
            $reflection->setAccessible(true);
        } catch (\ReflectionException $exception) {
            return 0;
        }

        $destroyed = 0;

        foreach ($verifiers as $verifier) {
            $reflection->invoke($manager, $verifier, null);
            ++$destroyed;
        }

        return $destroyed;
    }

    /**
     * Check whether the resolved session manager uses the default user-meta store.
     *
     * @param object $manager Session manager.
     * @return bool
     */
    private function isUserMetaSessionManager(object $manager): bool
    {
        return is_a($manager, 'WP_User_Meta_Session_Tokens');
    }

    /**
     * Destroy specific sessions in the default user-meta session store.
     *
     * @param int                  $user_id   User ID.
     * @param array<string, array> $sessions  Active sessions keyed by verifier.
     * @param array<int, string>   $verifiers Session verifiers to destroy.
     * @return int
     */
    private function destroyUserMetaSessions(int $user_id, array $sessions, array $verifiers): int
    {
        $destroyed = 0;

        foreach ($verifiers as $verifier) {
            if (!array_key_exists($verifier, $sessions)) {
                continue;
            }

            unset($sessions[$verifier]);
            ++$destroyed;
        }

        if (!$destroyed) {
            return 0;
        }

        if (empty($sessions)) {
            $delete_user_meta = 'delete_user_meta';
            $delete_user_meta($user_id, 'session_tokens');
        } else {
            $update_user_meta = 'update_user_meta';
            $update_user_meta($user_id, 'session_tokens', $sessions);
        }

        return $destroyed;
    }

    /**
     * Get the global default max sessions from Toolkit settings.
     *
     * @return int
     */
    private function getGlobalDefault(): int
    {
        $settings = arraysubs_get_settings();
        $max      = $settings['toolkit']['multi_login_max_sessions'] ?? 1;

        return max(1, abs((int) $max));
    }

    /**
     * Get the Login Limit rules from Members Access settings.
     *
     * Members Access settings are stored inside the unified
     * arraysubs_settings option under the 'members_access' key.
     *
     * @return array
     */
    private function getLoginLimitRules(): array
    {
        $all_settings = arraysubs_get_settings();
        $ma_settings  = $all_settings['members_access'] ?? [];

        if (empty($ma_settings['login_limit_rules']) || !is_array($ma_settings['login_limit_rules'])) {
            return [];
        }

        return $ma_settings['login_limit_rules'];
    }

    /**
     * Check whether a session is an impersonation session (Login as User).
     *
     * Impersonation sessions store 'arraysubs_impersonated_from_id' in the
     * session data. These sessions must not be counted or destroyed.
     *
     * @param array $session Session data.
     * @return bool
     */
    private function isImpersonationSession(array $session): bool
    {
        return !empty($session['arraysubs_impersonated_from_id']);
    }
}
