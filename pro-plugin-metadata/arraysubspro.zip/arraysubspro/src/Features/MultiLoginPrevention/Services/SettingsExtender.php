<?php

/**
 * Settings Extender
 *
 * Registers login_limit_rules in the Members Access restriction controller
 * via core filters so the key is accepted on save and properly sanitized.
 *
 * @package ArraySubsPro\Features\MultiLoginPrevention\Services
 */

namespace ArraySubsPro\Features\MultiLoginPrevention\Services;

defined('ABSPATH') || exit;

/**
 * Extends Members Access settings for Login Limit rules.
 */
class SettingsExtender
{
    /**
     * Enable auto-loading.
     *
     * @var bool
     */
    public static $loadable = true;

    /**
     * Constructor — register filters on the core restriction controller.
     */
    public function __construct()
    {
        add_filter('arraysubs_members_access_known_keys', [$this, 'registerKnownKeys']);
        add_filter('arraysubs_members_access_default_settings', [$this, 'registerDefaults']);
        add_filter('arraysubs_members_access_sanitize_settings', [$this, 'sanitizeSettings'], 10, 2);
    }

    /**
     * Add login_limit_rules to the allowed settings keys.
     *
     * @param array $keys Existing known keys.
     * @return array
     */
    public function registerKnownKeys(array $keys): array
    {
        $keys[] = 'login_limit_rules';
        return $keys;
    }

    /**
     * Add default value for login_limit_rules.
     *
     * @param array $defaults Existing defaults.
     * @return array
     */
    public function registerDefaults(array $defaults): array
    {
        $defaults['login_limit_rules'] = [];
        return $defaults;
    }

    /**
     * Sanitize login_limit_rules when settings are saved.
     *
     * @param array $sanitized Already-sanitized settings from core.
     * @param array $settings  Raw settings from the request.
     * @return array
     */
    public function sanitizeSettings(array $sanitized, array $settings): array
    {
        if (!isset($settings['login_limit_rules']) || !is_array($settings['login_limit_rules'])) {
            return $sanitized;
        }

        $sanitized['login_limit_rules'] = $this->sanitizeRules($settings['login_limit_rules']);

        return $sanitized;
    }

    /**
     * Sanitize an array of login limit rules.
     *
     * @param array $rules Raw rules.
     * @return array Sanitized rules.
     */
    private function sanitizeRules(array $rules): array
    {
        $sanitized = [];

        foreach ($rules as $rule) {
            if (!is_array($rule)) {
                continue;
            }

            $sanitized_rule = [
                'id'           => sanitize_key($rule['id'] ?? wp_generate_uuid4()),
                'name'         => sanitize_text_field($rule['name'] ?? ''),
                'enabled'      => (bool) ($rule['enabled'] ?? true),
                'conditions'   => $this->sanitizeConditions($rule['conditions'] ?? []),
                'max_sessions' => max(1, absint($rule['max_sessions'] ?? 1)),
            ];

            $sanitized[] = $sanitized_rule;
        }

        return $sanitized;
    }

    /**
     * Sanitize a conditions block (logic + rules).
     *
     * @param array $conditions Raw conditions.
     * @return array
     */
    private function sanitizeConditions(array $conditions): array
    {
        $logic = 'and';
        if (isset($conditions['logic']) && in_array($conditions['logic'], ['and', 'or'], true)) {
            $logic = $conditions['logic'];
        }

        return [
            'logic' => $logic,
            'rules' => $this->sanitizeConditionRules($conditions['rules'] ?? []),
        ];
    }

    /**
     * Sanitize condition rules.
     *
     * Mirrors the core Members Access sanitizer so the login-limit rule type
     * preserves the rich condition structure used by the shared rule builder
     * (IDs, nested groups, ajax-select arrays, numeric values, etc.).
     *
     * @param array $rules Raw condition rules.
     * @return array
     */
    private function sanitizeConditionRules(array $rules): array
    {
        $sanitized = [];

        foreach ($rules as $rule) {
            if (!is_array($rule)) {
                continue;
            }

            $type = sanitize_text_field($rule['type'] ?? '');
            if (empty($type)) {
                continue;
            }

            $sanitized_rule = [
                'type' => $type,
            ];

            if ($type === 'group') {
                $sanitized_rule['logic'] = in_array($rule['logic'] ?? 'and', ['and', 'or'], true)
                    ? $rule['logic']
                    : 'and';
                $sanitized_rule['rules'] = $this->sanitizeConditionRules($rule['rules'] ?? []);
                $sanitized[] = $sanitized_rule;
                continue;
            }

            foreach ($rule as $key => $value) {
                if ($key === 'type') {
                    continue;
                }

                if (is_array($value)) {
                    $sanitized_rule[$key] = array_map(function ($item) {
                        return is_numeric($item) ? absint($item) : sanitize_text_field($item);
                    }, $value);
                } elseif (is_numeric($value)) {
                    $sanitized_rule[$key] = is_float($value + 0) ? floatval($value) : absint($value);
                } else {
                    $sanitized_rule[$key] = sanitize_text_field($value);
                }
            }

            $sanitized[] = $sanitized_rule;
        }

        return $sanitized;
    }
}
