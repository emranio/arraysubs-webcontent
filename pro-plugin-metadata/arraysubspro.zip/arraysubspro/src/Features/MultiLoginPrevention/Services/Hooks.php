<?php

/**
 * Multi-Login Prevention Hooks
 *
 * Enforces concurrent session limits on wp_login and provides a
 * heartbeat-based "session still valid?" check for responsive logout.
 *
 * @package ArraySubsPro\Features\MultiLoginPrevention\Services
 */

namespace ArraySubsPro\Features\MultiLoginPrevention\Services;

defined('ABSPATH') || exit;

/**
 * WordPress hooks for Multi-Login Prevention enforcement.
 */
class Hooks
{
    /**
     * Enable auto-loading.
     *
     * @var bool
     */
    public static $loadable = true;

    /**
     * Constructor — registers hooks.
     */
    public function __construct()
    {
        // Enforce session limit immediately after a successful login.
        // Priority 999 ensures this runs after other wp_login callbacks
        // (including the Login-As-User cookie clear) have completed.
        add_action('wp_login', [$this, 'onLogin'], 999, 2);

        // Heartbeat session validation for responsive forced logout.
        add_filter('heartbeat_received', [$this, 'onHeartbeat'], 10, 2);
    }

    /**
     * Enforce session limits when a user logs in.
     *
     * @param string   $user_login Username.
     * @param \WP_User $user       User object.
     * @return void
     */
    public function onLogin(string $user_login, \WP_User $user): void
    {
        if (!$this->isFeatureEnabled()) {
            return;
        }

        // Skip impersonation logins — the Login-As-User feature fires wp_login
        // when switching but those sessions must not trigger enforcement.
        if ($this->isImpersonationLogin()) {
            return;
        }

        // Admin exemption check.
        if ($this->isAdminExempt($user)) {
            return;
        }

        $session_manager = new SessionManager();
        $max_sessions    = $session_manager->getEffectiveMaxSessions($user->ID);

        $session_manager->enforceSessionLimit($user->ID, $max_sessions);
    }

    /**
     * Heartbeat callback — check if the current session is still valid.
     *
     * If the session was destroyed (by a newer login), respond with a flag
     * so the frontend can redirect to the login page.
     *
     * @param array $response Heartbeat response data.
     * @param array $data     Heartbeat request data.
     * @return array
     */
    public function onHeartbeat(array $response, array $data): array
    {
        if (!$this->isFeatureEnabled()) {
            return $response;
        }

        if (empty($data['arraysubs_session_check'])) {
            return $response;
        }

        $token = wp_get_session_token();
        if (empty($token)) {
            $response['arraysubs_session_expired'] = true;
            return $response;
        }

        $user_id = get_current_user_id();
        if (!$user_id) {
            $response['arraysubs_session_expired'] = true;
            return $response;
        }

        $manager  = \WP_Session_Tokens::get_instance($user_id);
        $session  = $manager->get($token);

        if (empty($session)) {
            $response['arraysubs_session_expired'] = true;
        }

        return $response;
    }

    /**
     * Check whether the Multi-Login Prevention feature is enabled.
     *
     * @return bool
     */
    private function isFeatureEnabled(): bool
    {
        $settings = arraysubs_get_settings();
        return !empty($settings['toolkit']['multi_login_prevention']);
    }

    /**
     * Check whether admin users are exempt from session limits.
     *
     * @param \WP_User $user User to check.
     * @return bool True if the user is an admin and should be exempt.
     */
    private function isAdminExempt(\WP_User $user): bool
    {
        if (!$user->has_cap('manage_options')) {
            return false;
        }

        $settings        = arraysubs_get_settings();
        $include_admins  = !empty($settings['toolkit']['multi_login_include_admins']);

        // If "include admins" is ON, admins are NOT exempt.
        return !$include_admins;
    }

    /**
     * Detect whether the current wp_login is triggered by an impersonation
     * session switch rather than a real customer login.
     *
     * @return bool
     */
    private function isImpersonationLogin(): bool
    {
        if (class_exists('\\ArraySubs\\Features\\LoginAsUser\\Services\\Impersonator')) {
            return \ArraySubs\Features\LoginAsUser\Services\Impersonator::isImpersonating();
        }

        return false;
    }
}
