<?php

/**
 * Multi-Login Prevention Provider
 *
 * @package ArraySubsPro\Features\MultiLoginPrevention
 */

namespace ArraySubsPro\Features\MultiLoginPrevention;

defined('ABSPATH') || exit;

use ArraySubs\Supports\Abstracts\AbstractLoader;

/**
 * Multi-Login Prevention feature entry point.
 */
class Provider extends AbstractLoader
{
    /**
     * Constructor.
     */
    public function __construct()
    {
        $this->classLoader([
            plugin_dir_path(__FILE__) . 'Services',
        ]);
    }
}
