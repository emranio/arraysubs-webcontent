<?php

/**
 * Member Insight Hooks
 *
 * Adds admin shortcuts into existing WordPress and WooCommerce screens.
 *
 * @package ArraySubsPro\Features\MemberInsight\Services
 * @since 1.0.0
 */

namespace ArraySubsPro\Features\MemberInsight\Services;

defined('ABSPATH') || exit;

use ArraySubs\Supports\Config;

/**
 * Member Insight hooks integration.
 */
class Hooks
{
    /**
     * Enable auto-loading.
     *
     * @var bool
     */
    public static $loadable = true;

    /**
     * Constructor.
     */
    public function __construct()
    {
        add_filter('arraysubs_subscription_admin_customer_link', [$this, 'filterSubscriptionCustomerLink'], 10, 4);
        add_action('woocommerce_admin_order_data_after_order_details', [$this, 'renderOrderEditMemberLink']);
        add_filter('woocommerce_admin_order_preview_actions', [$this, 'filterOrderPreviewActions'], 10, 2);
        add_action('admin_enqueue_scripts', [$this, 'enqueueAdminAssets']);
    }

    /**
     * Replace the subscription list customer link with the member insight page.
     *
     * @param string   $customer_href   Existing customer URL.
     * @param int      $customer_id     Customer user ID.
     * @param int      $subscription_id Subscription ID.
     * @param \WP_User $user            Customer user object.
     * @return string
     */
    public function filterSubscriptionCustomerLink(
        string $customer_href,
        int $customer_id,
        int $subscription_id,
        \WP_User $user
    ): string {
        unset($subscription_id, $user);

        if ($customer_id <= 0) {
            return $customer_href;
        }

        return $this->getMemberDetailsUrl($customer_id);
    }

    /**
     * Enqueue admin assets for member insight shortcuts.
     *
     * @param string $hook Current admin hook.
     * @return void
     */
    public function enqueueAdminAssets(string $hook): void
    {
        if ($this->isUserProfilePage($hook)) {
            $this->enqueueUserProfileButtonAsset();
        }

        if ($this->isWcAdminPage()) {
            $this->enqueueCustomersAnalyticsAsset();
        }
    }

    /**
     * Render a member details shortcut on the WooCommerce order edit screen.
     *
     * @param \WC_Order $order Order object.
     * @return void
     */
    public function renderOrderEditMemberLink($order): void
    {
        if (!$order instanceof \WC_Order) {
            return;
        }

        $member_details_url = $this->getOrderMemberDetailsUrl($order);

        if ('' === $member_details_url) {
            return;
        }

?>
        <p class="form-field form-field-wide arraysubspro-member-insight-link">
            <strong><?php esc_html_e('ArraySubs Member Details:', 'arraysubspro'); ?></strong>
            <a class="button button-secondary" style="width: 100%;" href="<?php echo esc_url($member_details_url); ?>">
                <?php esc_html_e('Open Member Details', 'arraysubspro'); ?>
            </a>
        </p>
<?php
    }

    /**
     * Add a member details action to the WooCommerce order preview modal.
     *
     * @param array     $actions Existing preview actions.
     * @param \WC_Order $order   Order object.
     * @return array
     */
    public function filterOrderPreviewActions(array $actions, $order): array
    {
        if (!$order instanceof \WC_Order) {
            return $actions;
        }

        $member_details_url = $this->getOrderMemberDetailsUrl($order);

        if ('' === $member_details_url) {
            return $actions;
        }

        $actions['arraysubspro_member_details'] = [
            'url' => $member_details_url,
            'name' => __('Member details', 'arraysubspro'),
            'title' => __('Open member details', 'arraysubspro'),
            'action' => 'arraysubspro-member-details',
        ];

        return $actions;
    }

    /**
     * Enqueue the user profile heading button enhancement.
     *
     * @return void
     */
    private function enqueueUserProfileButtonAsset(): void
    {
        $asset_file = Config::get('proplugin.public_path') . 'build/admin/user-profile-member-button.asset.php';
        $asset = file_exists($asset_file)
            ? require $asset_file
            : ['dependencies' => ['wp-dom-ready', 'wp-i18n'], 'version' => ARRAYSUBSPRO_VERSION];

        wp_enqueue_script(
            'arraysubspro-user-profile-member-button',
            Config::get('proplugin.public_url') . 'build/admin/user-profile-member-button.js',
            $asset['dependencies'],
            $asset['version'],
            true
        );

        wp_set_script_translations(
            'arraysubspro-user-profile-member-button',
            'arraysubspro',
            Config::get('proplugin.path') . 'languages'
        );

        wp_add_inline_script(
            'arraysubspro-user-profile-member-button',
            'window.arraySubsProMemberInsight = ' . wp_json_encode(
                [
                    'memberDetailsUrl' => $this->getCurrentUserMemberDetailsUrl(),
                ],
                JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT
            ) . ';',
            'before'
        );
    }

    /**
     * Enqueue the WooCommerce customers table enhancement.
     *
     * @return void
     */
    private function enqueueCustomersAnalyticsAsset(): void
    {

        $asset_file = Config::get('proplugin.public_path') . 'build/admin/analytics-customers.asset.php';
        $asset = file_exists($asset_file)
            ? require $asset_file
            : ['dependencies' => ['wp-hooks', 'wp-i18n', 'wp-element'], 'version' => ARRAYSUBSPRO_VERSION];

        wp_enqueue_script(
            'arraysubspro-analytics-customers',
            Config::get('proplugin.public_url') . 'build/admin/analytics-customers.js',
            $asset['dependencies'],
            $asset['version'],
            true
        );

        wp_add_inline_script(
            'arraysubspro-analytics-customers',
            'window.arraySubsProCustomers = ' . wp_json_encode(
                [
                    'memberDetailsBaseUrl' => admin_url('admin.php?page=arraysubs-mainadmin#/manage-members/'),
                ],
                JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT
            ) . ';',
            'before'
        );
    }

    /**
     * Determine whether the current admin user can access member insight links.
     *
     * @return bool
     */
    private function canViewMemberInsight(): bool
    {
        return current_user_can('manage_woocommerce') || current_user_can('manage_options');
    }

    /**
     * Get the member details URL for the current user profile screen target.
     *
     * @return string
     */
    private function getCurrentUserMemberDetailsUrl(): string
    {
        $user_id = get_current_user_id();

        $request_user_id = filter_input(INPUT_GET, 'user_id', FILTER_VALIDATE_INT);
        if ($request_user_id) {
            $user_id = $request_user_id;
        }

        if ($user_id <= 0 || !$this->canViewMemberInsight()) {
            return '';
        }

        return $this->getMemberDetailsUrl($user_id);
    }

    /**
     * Get the member details URL for an order's customer.
     *
     * @param \WC_Order $order Order object.
     * @return string
     */
    private function getOrderMemberDetailsUrl(\WC_Order $order): string
    {
        if (!$this->canViewMemberInsight()) {
            return '';
        }

        $customer_id = $order->get_customer_id();

        if ($customer_id <= 0) {
            return '';
        }

        return $this->getMemberDetailsUrl($customer_id);
    }

    /**
     * Build the member details admin URL.
     *
     * @param int $user_id User ID.
     * @return string
     */
    private function getMemberDetailsUrl(int $user_id): string
    {
        return admin_url('admin.php?page=arraysubs-mainadmin#/manage-members/' . absint($user_id));
    }

    /**
     * Check if the current admin page is a user profile screen.
     *
     * @param string $hook Current admin hook.
     * @return bool
     */
    private function isUserProfilePage(string $hook): bool
    {
        if (!$this->canViewMemberInsight()) {
            return false;
        }

        return in_array($hook, ['profile.php', 'user-edit.php'], true);
    }

    /**
     * Check if the current request is a WooCommerce Admin page.
     *
     * WC Admin uses SPA navigation, so all analytics-related scripts must be
     * loaded on any wc-admin page to survive client-side route changes.
     *
     * @return bool
     */
    private function isWcAdminPage(): bool
    {
        $screen = get_current_screen();

        if (!$screen) {
            return false;
        }

        return $screen->id === 'woocommerce_page_wc-admin'
            || strpos($screen->id, 'wc-admin') !== false;
    }
}
