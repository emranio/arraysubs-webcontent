<?php

/**
 * Member Insight REST Controller
 *
 * REST API endpoints for member insight dashboard.
 * Provides user search and comprehensive member data retrieval.
 *
 * @package ArraySubsPro\Features\MemberInsight\REST
 * @since 1.0.0
 */

namespace ArraySubsPro\Features\MemberInsight\REST;

defined('ABSPATH') || exit;

use ArraySubs\Supports\BaseRestController;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;

/**
 * Member Insight REST controller
 */
class MemberController extends BaseRestController
{
    /**
     * Enable auto-loading
     *
     * @var bool
     */
    public static $loadable = true;

    /**
     * REST namespace
     *
     * @var string
     */
    protected $namespace = 'arraysubs/v1';

    /**
     * Constructor
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Register REST routes
     */
    public function registerRoutes(): void
    {
        register_rest_route($this->namespace, '/members/search', [
            [
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => [$this, 'searchMembers'],
                'permission_callback' => [$this, 'checkAdminPermission'],
                'args'                => [
                    'query' => [
                        'description'       => __('Search query (username, email, or name)', 'arraysubspro'),
                        'type'              => 'string',
                        'required'          => true,
                        'sanitize_callback' => 'sanitize_text_field',
                    ],
                ],
            ],
        ]);

        register_rest_route($this->namespace, '/members/(?P<user_id>\d+)', [
            [
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => [$this, 'getMemberDetails'],
                'permission_callback' => [$this, 'checkAdminPermission'],
                'args'                => [
                    'user_id' => [
                        'description'       => __('User ID', 'arraysubspro'),
                        'type'              => 'integer',
                        'required'          => true,
                        'sanitize_callback' => 'absint',
                    ],
                ],
            ],
            [
                'methods'             => WP_REST_Server::EDITABLE,
                'callback'            => [$this, 'updateMemberDetails'],
                'permission_callback' => [$this, 'checkAdminPermission'],
                'args'                => [
                    'user_id' => [
                        'description'       => __('User ID', 'arraysubspro'),
                        'type'              => 'integer',
                        'required'          => true,
                        'sanitize_callback' => 'absint',
                    ],
                ],
            ],
        ]);
    }

    /**
     * Check admin permission
     *
     * @return bool
     */
    public function checkAdminPermission(): bool
    {
        return current_user_can('manage_woocommerce') || current_user_can('manage_options');
    }

    /**
     * Search members by username, email, or name
     *
     * @param WP_REST_Request $request Request object.
     *
     * @return WP_REST_Response
     */
    public function searchMembers(WP_REST_Request $request): WP_REST_Response
    {
        $query = sanitize_text_field($request->get_param('query'));

        if (strlen($query) < 2) {
            return new WP_REST_Response([
                'success' => false,
                'message' => __('Search query too short', 'arraysubspro'),
            ], 400);
        }

        $users = get_users([
            'search'         => '*' . $query . '*',
            'search_columns' => ['user_login', 'user_email', 'display_name'],
            'number'         => 20,
            'orderby'        => 'display_name',
            'order'          => 'ASC',
        ]);

        $results = [];
        foreach ($users as $user) {
            $active_subs = $this->countSubscriptions($user->ID, 'arraysubs-active');
            $total_subs  = $this->countSubscriptions($user->ID);

            $results[] = [
                'id'                    => $user->ID,
                'display_name'          => $user->display_name,
                'email'                 => $user->user_email,
                'username'              => $user->user_login,
                'active_subscriptions'  => $active_subs,
                'total_subscriptions'   => $total_subs,
                'registered'            => $user->user_registered,
            ];
        }

        return new WP_REST_Response([
            'success' => true,
            'data'    => $results,
        ], 200);
    }

    /**
     * Get comprehensive member details
     *
     * @param WP_REST_Request $request Request object.
     *
     * @return WP_REST_Response
     */
    public function getMemberDetails(WP_REST_Request $request): WP_REST_Response
    {
        $user_id = absint($request->get_param('user_id'));
        $user    = get_user_by('ID', $user_id);

        if (!$user) {
            return new WP_REST_Response([
                'success' => false,
                'message' => __('User not found', 'arraysubspro'),
            ], 404);
        }

        $customer = new \WC_Customer($user_id);

        $data = [
            'profile'       => $this->getProfileData($user, $customer),
            'stats'         => $this->getStatsData($user_id, $customer),
            'subscriptions' => $this->getSubscriptionsData($user_id),
            'orders'        => $this->getOrdersData($user_id),
            'products'      => $this->getNonSubscriptionProducts($user_id),
            'store_credit'  => $this->getStoreCreditData($user_id),
        ];

        $data['profile'] = apply_filters('arraysubs_member_profile_data', $data['profile'], $user_id);

        return new WP_REST_Response([
            'success' => true,
            'data'    => $data,
        ], 200);
    }

    /**
     * Update editable member profile and WooCommerce customer address data.
     *
     * @param WP_REST_Request $request Request object.
     *
     * @return WP_REST_Response
     */
    public function updateMemberDetails(WP_REST_Request $request): WP_REST_Response
    {
        $user_id = absint($request->get_param('user_id'));
        $user    = get_user_by('ID', $user_id);

        if (!$user) {
            return new WP_REST_Response([
                'success' => false,
                'message' => __('User not found', 'arraysubspro'),
            ], 404);
        }

        $profile = (array) $request->get_param('profile');
        $billing = (array) $request->get_param('billing');
        $shipping = (array) $request->get_param('shipping');

        $email = sanitize_email((string) ($profile['email'] ?? $user->user_email));
        if ('' === $email || ! is_email($email)) {
            return new WP_REST_Response([
                'success' => false,
                'message' => __('Enter a valid customer email address.', 'arraysubspro'),
            ], 400);
        }

        $email_owner = email_exists($email);
        if ($email_owner && (int) $email_owner !== $user_id) {
            return new WP_REST_Response([
                'success' => false,
                'message' => __('That email address is already used by another user.', 'arraysubspro'),
            ], 409);
        }

        $first_name = sanitize_text_field((string) ($profile['first_name'] ?? $user->first_name));
        $last_name = sanitize_text_field((string) ($profile['last_name'] ?? $user->last_name));
        $display_name = sanitize_text_field((string) ($profile['display_name'] ?? $user->display_name));

        $user_update = [
            'ID' => $user_id,
            'user_email' => $email,
            'first_name' => $first_name,
            'last_name' => $last_name,
            'display_name' => '' !== $display_name ? $display_name : trim($first_name . ' ' . $last_name),
        ];

        $updated_user_id = wp_update_user($user_update);
        if (is_wp_error($updated_user_id)) {
            return new WP_REST_Response([
                'success' => false,
                'message' => $updated_user_id->get_error_message(),
            ], 400);
        }

        $customer = new \WC_Customer($user_id);
        $billing = $this->sanitizeAddress($billing, true);
        $shipping = $this->sanitizeAddress($shipping, false);

        try {
            $customer->set_billing_first_name($billing['first_name']);
            $customer->set_billing_last_name($billing['last_name']);
            $customer->set_billing_company($billing['company']);
            $customer->set_billing_address_1($billing['address_1']);
            $customer->set_billing_address_2($billing['address_2']);
            $customer->set_billing_city($billing['city']);
            $customer->set_billing_state($billing['state']);
            $customer->set_billing_postcode($billing['postcode']);
            $customer->set_billing_country($billing['country']);
            $customer->set_billing_email($billing['email'] ?: $email);
            $customer->set_billing_phone($billing['phone']);

            $customer->set_shipping_first_name($shipping['first_name']);
            $customer->set_shipping_last_name($shipping['last_name']);
            $customer->set_shipping_company($shipping['company']);
            $customer->set_shipping_address_1($shipping['address_1']);
            $customer->set_shipping_address_2($shipping['address_2']);
            $customer->set_shipping_city($shipping['city']);
            $customer->set_shipping_state($shipping['state']);
            $customer->set_shipping_postcode($shipping['postcode']);
            $customer->set_shipping_country($shipping['country']);
            $customer->set_shipping_phone($shipping['phone']);
            $customer->save();
        } catch (\Throwable $throwable) {
            return new WP_REST_Response([
                'success' => false,
                'message' => $throwable->getMessage(),
            ], 400);
        }

        $additional_shipping = $this->sanitizeAdditionalShippingAddresses(
            $request->get_param('additional_shipping_addresses')
        );
        update_user_meta($user_id, '_arraysubs_additional_shipping_addresses', $additional_shipping);

        $updated_user = get_user_by('ID', $user_id);
        $updated_customer = new \WC_Customer($user_id);

        $data = [
            'profile'       => $this->getProfileData($updated_user, $updated_customer),
            'stats'         => $this->getStatsData($user_id, $updated_customer),
            'subscriptions' => $this->getSubscriptionsData($user_id),
            'orders'        => $this->getOrdersData($user_id),
            'products'      => $this->getNonSubscriptionProducts($user_id),
            'store_credit'  => $this->getStoreCreditData($user_id),
        ];

        $data['profile'] = apply_filters('arraysubs_member_profile_data', $data['profile'], $user_id);

        return new WP_REST_Response([
            'success' => true,
            'message' => __('Member details updated successfully.', 'arraysubspro'),
            'data'    => $data,
        ], 200);
    }

    /**
     * Get user profile data
     *
     * @param \WP_User    $user     WordPress user object.
     * @param \WC_Customer $customer WooCommerce customer object.
     *
     * @return array
     */
    private function getProfileData(\WP_User $user, \WC_Customer $customer): array
    {
        return [
            'id'               => $user->ID,
            'username'         => $user->user_login,
            'email'            => $user->user_email,
            'display_name'     => $user->display_name,
            'first_name'       => $user->first_name,
            'last_name'        => $user->last_name,
            'full_name'        => trim($user->first_name . ' ' . $user->last_name),
            'roles'            => $user->roles,
            'registered'       => $user->user_registered,
            'registered_formatted' => arraysubs_format_date_local(
                $user->user_registered,
                \get_option('date_format') . ' ' . \get_option('time_format')
            ),
            'avatar_url'       => get_avatar_url($user->ID, ['size' => 96]),
            'edit_url'         => get_edit_user_link($user->ID),
            'billing'          => [
                'first_name' => $customer->get_billing_first_name(),
                'last_name'  => $customer->get_billing_last_name(),
                'company'    => $customer->get_billing_company(),
                'address_1'  => $customer->get_billing_address_1(),
                'address_2'  => $customer->get_billing_address_2(),
                'city'       => $customer->get_billing_city(),
                'state'      => $customer->get_billing_state(),
                'postcode'   => $customer->get_billing_postcode(),
                'country'    => $customer->get_billing_country(),
                'email'      => $customer->get_billing_email(),
                'phone'      => $customer->get_billing_phone(),
            ],
            'shipping'         => [
                'first_name' => $customer->get_shipping_first_name(),
                'last_name'  => $customer->get_shipping_last_name(),
                'company'    => $customer->get_shipping_company(),
                'address_1'  => $customer->get_shipping_address_1(),
                'address_2'  => $customer->get_shipping_address_2(),
                'city'       => $customer->get_shipping_city(),
                'state'      => $customer->get_shipping_state(),
                'postcode'   => $customer->get_shipping_postcode(),
                'country'    => $customer->get_shipping_country(),
                'phone'      => $customer->get_shipping_phone(),
            ],
            'additional_shipping_addresses' => $this->getAdditionalShippingAddresses($user->ID),
        ];
    }

    /**
     * Sanitize an address payload.
     *
     * @param array<string, mixed> $address Address payload.
     * @param bool                 $billing Whether this is a billing address.
     *
     * @return array<string, string>
     */
    private function sanitizeAddress(array $address, bool $billing): array
    {
        $sanitized = [
            'first_name' => sanitize_text_field((string) ($address['first_name'] ?? '')),
            'last_name'  => sanitize_text_field((string) ($address['last_name'] ?? '')),
            'company'    => sanitize_text_field((string) ($address['company'] ?? '')),
            'address_1'  => sanitize_text_field((string) ($address['address_1'] ?? '')),
            'address_2'  => sanitize_text_field((string) ($address['address_2'] ?? '')),
            'city'       => sanitize_text_field((string) ($address['city'] ?? '')),
            'state'      => sanitize_text_field((string) ($address['state'] ?? '')),
            'postcode'   => sanitize_text_field((string) ($address['postcode'] ?? '')),
            'country'    => strtoupper(sanitize_text_field((string) ($address['country'] ?? ''))),
            'phone'      => sanitize_text_field((string) ($address['phone'] ?? '')),
        ];

        if ($billing) {
            $sanitized['email'] = sanitize_email((string) ($address['email'] ?? ''));
        }

        return $sanitized;
    }

    /**
     * Get additional shipping addresses.
     *
     * @param int $user_id User ID.
     * @return array<int, array<string, string>>
     */
    private function getAdditionalShippingAddresses(int $user_id): array
    {
        $addresses = get_user_meta($user_id, '_arraysubs_additional_shipping_addresses', true);

        return is_array($addresses) ? array_values($addresses) : [];
    }

    /**
     * Sanitize additional shipping address collection.
     *
     * @param mixed $addresses Raw addresses.
     * @return array<int, array<string, string>>
     */
    private function sanitizeAdditionalShippingAddresses($addresses): array
    {
        if (! is_array($addresses)) {
            return [];
        }

        $sanitized = [];
        foreach ($addresses as $address) {
            if (! is_array($address)) {
                continue;
            }

            $entry = $this->sanitizeAddress($address, false);
            $entry['label'] = sanitize_text_field((string) ($address['label'] ?? ''));

            $has_address = array_filter($entry, static function ($value): bool {
                return '' !== (string) $value;
            });

            if (! empty($has_address)) {
                $sanitized[] = $entry;
            }
        }

        return array_values($sanitized);
    }

    /**
     * Get member statistics
     *
     * @param int          $user_id  User ID.
     * @param \WC_Customer $customer WooCommerce customer object.
     *
     * @return array
     */
    private function getStatsData(int $user_id, \WC_Customer $customer): array
    {
        $total_spent = $customer->get_total_spent();
        $order_count = $customer->get_order_count();

        $total_subs  = $this->countSubscriptions($user_id);
        $active_subs = $this->countSubscriptions($user_id, 'arraysubs-active');

        $total_refunds = $this->getTotalRefunds($user_id);

        return [
            'total_spent'            => (float) $total_spent,
            'total_spent_formatted'  => wc_price($total_spent),
            'total_orders'           => $order_count,
            'total_subscriptions'    => $total_subs,
            'active_subscriptions'   => $active_subs,
            'total_refunds'          => (float) $total_refunds,
            'total_refunds_formatted' => wc_price($total_refunds),
            'store_credit_balance'   => $this->getStoreCreditBalance($user_id),
            'store_credit_formatted' => wc_price($this->getStoreCreditBalance($user_id)),
        ];
    }

    /**
     * Get subscriptions data for a user
     *
     * @param int $user_id User ID.
     *
     * @return array
     */
    private function getSubscriptionsData(int $user_id): array
    {
        $subscriptions = get_posts([
            'post_type'      => 'arraysubs_data',
            'post_status'    => 'any',
            'posts_per_page' => -1,
            'meta_query'     => [ // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
                [
                    'key'   => '_customer_id',
                    'value' => $user_id,
                    'type'  => 'NUMERIC',
                ],
            ],
            'orderby'        => 'date',
            'order'          => 'DESC',
        ]);

        $results = [];
        foreach ($subscriptions as $subscription) {
            $variation_id = (int) get_post_meta($subscription->ID, '_variation_id', true);
            $product_id   = $variation_id > 0
                ? $variation_id
                : (int) get_post_meta($subscription->ID, '_product_id', true);
            $product    = wc_get_product($product_id);

            $results[] = [
                'id'                    => $subscription->ID,
                'status'                => $subscription->post_status,
                'status_label'          => $this->getStatusLabel($subscription->post_status),
                'product_name'          => $product ? $product->get_name() : __('(Deleted Product)', 'arraysubspro'),
                'product_id'            => (int) $product_id,
                'billing_period'        => get_post_meta($subscription->ID, '_billing_period', true),
                'billing_interval'      => get_post_meta($subscription->ID, '_billing_interval', true),
                'total'                 => get_post_meta($subscription->ID, '_order_total', true),
                'total_formatted'       => wc_price(get_post_meta($subscription->ID, '_order_total', true)),
                'currency'              => get_post_meta($subscription->ID, '_order_currency', true),
                'payment_gateway'       => get_post_meta($subscription->ID, '_payment_gateway', true),
                'start_date'            => get_post_meta($subscription->ID, '_start_date', true),
                'next_payment_date'     => get_post_meta($subscription->ID, '_next_payment_date', true),
                'end_date'              => get_post_meta($subscription->ID, '_end_date', true),
                'trial_end_date'        => get_post_meta($subscription->ID, '_trial_end_date', true),
                'created_date'          => $subscription->post_date,
                'created_date_formatted' => !empty($subscription->post_date_gmt) && $subscription->post_date_gmt !== '0000-00-00 00:00:00'
                    ? arraysubs_format_date_local($subscription->post_date_gmt, \get_option('date_format'))
                    : arraysubs_format_site_local_date($subscription->post_date, \get_option('date_format')),
            ];
        }

        return $results;
    }

    /**
     * Get orders data for a user
     *
     * @param int $user_id User ID.
     *
     * @return array
     */
    private function getOrdersData(int $user_id): array
    {
        $orders = wc_get_orders([
            'customer_id' => $user_id,
            'limit'       => 50,
            'orderby'     => 'date',
            'order'       => 'DESC',
            'return'      => 'objects',
        ]);

        $results = [];
        foreach ($orders as $order) {
            $results[] = [
                'id'               => $order->get_id(),
                'number'           => $order->get_order_number(),
                'status'           => $order->get_status(),
                'status_label'     => wc_get_order_status_name($order->get_status()),
                'total'            => (float) $order->get_total(),
                'total_formatted'  => $order->get_formatted_order_total(),
                'currency'         => $order->get_currency(),
                'payment_method'   => $order->get_payment_method_title(),
                'items_count'      => $order->get_item_count(),
                'date_created'     => $order->get_date_created() ? $order->get_date_created()->format('Y-m-d H:i:s') : '',
                'date_formatted'   => $order->get_date_created()
                    ? arraysubs_format_timestamp_local($order->get_date_created()->getTimestamp(), get_option('date_format'))
                    : '',
                'edit_url'         => $order->get_edit_order_url(),
                'type'             => $this->getOrderType($order),
            ];
        }

        return $results;
    }

    /**
     * Get non-subscription products purchased by the user
     *
     * @param int $user_id User ID.
     *
     * @return array
     */
    private function getNonSubscriptionProducts(int $user_id): array
    {
        $orders = wc_get_orders([
            'customer_id' => $user_id,
            'status'      => ['completed', 'processing'],
            'limit'       => -1,
            'return'      => 'objects',
        ]);

        $products = [];
        $seen_ids = [];

        foreach ($orders as $order) {
            foreach ($order->get_items() as $item) {
                $product_id = $item->get_product_id();

                if (in_array($product_id, $seen_ids, true)) {
                    $products[$product_id]['quantity']    += $item->get_quantity();
                    $products[$product_id]['total_spent'] += (float) $item->get_total();
                    continue;
                }

                $product = $item->get_product();
                if (!$product) {
                    continue;
                }

                // Skip subscription products
                $is_subscription = get_post_meta($product_id, '_arraysubs_subscription_enabled', true);
                if ($is_subscription === 'yes') {
                    continue;
                }

                $seen_ids[]            = $product_id;
                $products[$product_id] = [
                    'id'                  => $product_id,
                    'name'                => $product->get_name(),
                    'quantity'            => $item->get_quantity(),
                    'total_spent'         => (float) $item->get_total(),
                    'total_spent_formatted' => wc_price($item->get_total()),
                    'type'                => $product->get_type(),
                ];
            }
        }

        // Re-format totals
        foreach ($products as &$product) {
            $product['total_spent_formatted'] = wc_price($product['total_spent']);
        }

        return array_values($products);
    }

    /**
     * Get store credit data for a user
     *
     * @param int $user_id User ID.
     *
     * @return array
     */
    private function getStoreCreditData(int $user_id): array
    {
        $balance = $this->getStoreCreditBalance($user_id);

        return [
            'balance'           => (float) $balance,
            'balance_formatted' => wc_price($balance),
        ];
    }

    /**
     * Get store credit balance
     *
     * @param int $user_id User ID.
     *
     * @return float
     */
    private function getStoreCreditBalance(int $user_id): float
    {
        if (class_exists('ArraySubsPro\Features\StoreCredit\Services\CreditManager')) {
            return (float) \ArraySubsPro\Features\StoreCredit\Services\CreditManager::getCustomerCredit($user_id);
        }

        return 0.0;
    }

    /**
     * Count subscriptions for a user
     *
     * @param int    $user_id User ID.
     * @param string $status  Post status or 'any'.
     *
     * @return int
     */
    private function countSubscriptions(int $user_id, string $status = 'any'): int
    {
        $args = [
            'post_type'      => 'arraysubs_data',
            'post_status'    => $status,
            'posts_per_page' => -1,
            'fields'         => 'ids',
            'meta_query'     => [ // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
                [
                    'key'   => '_customer_id',
                    'value' => $user_id,
                    'type'  => 'NUMERIC',
                ],
            ],
        ];

        $query = new \WP_Query($args);

        return $query->found_posts;
    }

    /**
     * Get total refunds for a user
     *
     * @param int $user_id User ID.
     *
     * @return float
     */
    private function getTotalRefunds(int $user_id): float
    {
        $orders = wc_get_orders([
            'customer_id' => $user_id,
            'limit'       => -1,
            'return'      => 'objects',
        ]);

        $total_refunded = 0.0;
        foreach ($orders as $order) {
            $total_refunded += (float) $order->get_total_refunded();
        }

        return $total_refunded;
    }

    /**
     * Get order type classification
     *
     * @param \WC_Order $order WooCommerce order.
     *
     * @return string
     */
    private function getOrderType(\WC_Order $order): string
    {
        $is_renewal    = $order->get_meta('_arraysubs_renewal_order');
        $is_switch     = $order->get_meta('_arraysubs_switch_order');
        $is_resubscribe = $order->get_meta('_arraysubs_resubscribe_order');

        if ($is_renewal) {
            return 'renewal';
        }

        if ($is_switch) {
            return 'switch';
        }

        if ($is_resubscribe) {
            return 'resubscribe';
        }

        // Check if it contains any subscription product
        foreach ($order->get_items() as $item) {
            $product_id = $item->get_product_id();
            if (get_post_meta($product_id, '_arraysubs_subscription_enabled', true) === 'yes') {
                return 'subscription';
            }
        }

        return 'regular';
    }

    /**
     * Get human-readable status label
     *
     * @param string $status Post status.
     *
     * @return string
     */
    private function getStatusLabel(string $status): string
    {
        $labels = [
            'arraysubs_active'    => __('Active', 'arraysubspro'),
            'arraysubs_on-hold'   => __('On Hold', 'arraysubspro'),
            'arraysubs_cancelled' => __('Cancelled', 'arraysubspro'),
            'arraysubs_expired'   => __('Expired', 'arraysubspro'),
            'arraysubs_pending'   => __('Pending', 'arraysubspro'),
            'arraysubs_paused'    => __('Paused', 'arraysubspro'),
            'arraysubs_trial'     => __('Trial', 'arraysubspro'),
        ];

        return $labels[$status] ?? ucfirst(str_replace('arraysubs_', '', $status));
    }
}
