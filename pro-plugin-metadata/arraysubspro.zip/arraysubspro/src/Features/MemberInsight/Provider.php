<?php

/**
 * Member Insight Provider
 *
 * Entry point for the Member Insight feature.
 * Provides a comprehensive member lookup and insight dashboard.
 *
 * @package ArraySubsPro\Features\MemberInsight
 * @since 1.0.0
 */

namespace ArraySubsPro\Features\MemberInsight;

defined('ABSPATH') || exit;

use ArraySubs\Supports\Abstracts\AbstractLoader;

/**
 * Member Insight Feature entry point
 */
class Provider extends AbstractLoader
{
    /**
     * Constructor
     */
    public function __construct()
    {
        $this->classLoader([
            plugin_dir_path(__FILE__) . 'Services',
            plugin_dir_path(__FILE__) . 'REST',
        ]);
    }
}
