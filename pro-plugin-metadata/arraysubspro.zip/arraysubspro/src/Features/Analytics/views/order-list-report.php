<?php

/**
 * Order List Report Panel
 *
 * Renders the embedded analytics summary panel on the WooCommerce Orders page.
 * Shows total orders, count by type, and orders with coupons.
 *
 * @package ArraySubsPro\Features\Analytics
 *
 * @var int   $arraysubs_total_orders Total order count.
 * @var array $arraysubs_type_counts  Counts keyed by type string.
 * @var int   $arraysubs_coupon_orders Orders with at least one coupon.
 */

defined('ABSPATH') || exit;

use ArraySubsPro\Features\Analytics\Services\TypeResolver;

?>
<div class="arraysubspro-order-report">
    <div class="arraysubspro-order-report__card arraysubspro-order-report__card--total">
        <span class="arraysubspro-order-report__count">
            <?php echo esc_html(number_format_i18n($arraysubs_total_orders)); ?>
        </span>
        <span class="arraysubspro-order-report__label">
            <?php esc_html_e('Total Orders', 'arraysubspro'); ?>
        </span>
    </div>

    <?php foreach ($arraysubs_type_counts as $arraysubs_type_key => $arraysubs_type_count) : ?>
        <div class="arraysubspro-order-report__card">
            <span class="arraysubspro-order-report__count">
                <?php echo esc_html(number_format_i18n($arraysubs_type_count)); ?>
            </span>
            <span class="arraysubspro-order-report__label">
                <?php echo esc_html(TypeResolver::getLabel($arraysubs_type_key)); ?>
            </span>
        </div>
    <?php endforeach; ?>

    <div class="arraysubspro-order-report__card arraysubspro-order-report__card--coupon">
        <span class="arraysubspro-order-report__count">
            <?php echo esc_html(number_format_i18n($arraysubs_coupon_orders)); ?>
        </span>
        <span class="arraysubspro-order-report__label">
            <?php esc_html_e('Orders with Coupon', 'arraysubspro'); ?>
        </span>
    </div>
</div>
