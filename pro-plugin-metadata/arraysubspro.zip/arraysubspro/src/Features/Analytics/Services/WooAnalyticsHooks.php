<?php

/**
 * WooCommerce Analytics Integration Hooks
 *
 * Extends WooCommerce Analytics > Orders with custom columns and filter support.
 * Adds Type column and server-side filtering for Type, Coupon, and Subscription products.
 *
 * @package ArraySubsPro\Features\Analytics\Services
 */

namespace ArraySubsPro\Features\Analytics\Services;

defined('ABSPATH') || exit;

use ArraySubs\Supports\Config;

/**
 * WooCommerce Analytics integration hooks.
 *
 * Handles:
 * - REST field registration for Type (schema + response via register_rest_field)
 * - Query arg passthrough for custom filters
 * - SQL WHERE/JOIN clauses for Type, Coupon, Subscription products filters
 * - Asset enqueueing on WC Analytics pages
 */
class WooAnalyticsHooks
{
    /**
     * Legacy single-value type query param.
     */
    private const LEGACY_TYPE_QUERY_KEY = 'arraysubs_type';

    /**
     * Advanced include-type query param.
     */
    private const TYPE_INCLUDE_QUERY_KEY = 'arraysubs_type_is';

    /**
     * Advanced exclude-type query param.
     */
    private const TYPE_EXCLUDE_QUERY_KEY = 'arraysubs_type_is_not';

    /**
     * Enable auto-loading.
     *
     * @var bool
     */
    public static $loadable = true;

    /**
     * Stored custom query args from REST request.
     *
     * Context-specific SQL clause filters only receive $clauses (1 param),
     * so we store the custom args here during handleQueryArgs() and read
     * them back in addWhereClauses().
     *
     * @var array
     */
    private $customQueryArgs = [];

    /**
     * Stored custom query args for WC Analytics Products requests.
     *
     * @var array
     */
    private $productsCustomQueryArgs = [];

    /**
     * Stored custom query args for WC Analytics Variations requests.
     *
     * @var array
     */
    private $variationsCustomQueryArgs = [];

    /**
     * Whether HPOS (Custom Orders Table) is enabled.
     *
     * Determines which meta table to query in SQL clauses.
     *
     * @var bool
     */
    private bool $isHpos = false;

    public function __construct()
    {
        $this->isHpos = class_exists('Automattic\WooCommerce\Utilities\OrderUtil')
            && \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled();

        // Enqueue analytics JS on WC Analytics admin pages.
        // This action only fires in wp-admin, so it remains admin-only in practice.
        add_action('admin_enqueue_scripts', [$this, 'enqueueAnalyticsAssets']);

        // Register REST field for Type (extends both schema and response)
        add_action('rest_api_init', [$this, 'registerRestFields']);

        // Query args passthrough (accept custom filter params)
        add_filter('woocommerce_analytics_orders_query_args', [$this, 'handleQueryArgs']);
        add_filter('woocommerce_analytics_orders_stats_query_args', [$this, 'handleQueryArgs']);
        add_filter('woocommerce_analytics_revenue_query_args', [$this, 'handleQueryArgs']);
        add_filter('woocommerce_analytics_revenue_stats_query_args', [$this, 'handleQueryArgs']);

        // Products/Variations query args passthrough (accept custom filter params)
        add_filter('woocommerce_analytics_products_query_args', [$this, 'handleProductsQueryArgs']);
        add_filter('woocommerce_analytics_products_stats_query_args', [$this, 'handleProductsQueryArgs']);
        add_filter('woocommerce_analytics_variations_query_args', [$this, 'handleVariationsQueryArgs']);
        add_filter('woocommerce_analytics_variations_stats_query_args', [$this, 'handleVariationsQueryArgs']);

        // SQL clause extensions for WHERE filtering (no JOIN needed — uses EXISTS subqueries)
        add_filter('woocommerce_analytics_clauses_where_orders_subquery', [$this, 'addWhereClauses']);

        // Also handle stats subquery for summary numbers
        add_filter('woocommerce_analytics_clauses_where_orders_stats_total', [$this, 'addWhereClauses']);
        add_filter('woocommerce_analytics_clauses_where_orders_stats_interval', [$this, 'addWhereClauses']);

        // Products report/stats WHERE clauses
        add_filter('woocommerce_analytics_clauses_where_products_subquery', [$this, 'addProductsWhereClauses']);
        add_filter('woocommerce_analytics_clauses_where_products_stats_total', [$this, 'addProductsWhereClauses']);
        add_filter('woocommerce_analytics_clauses_where_products_stats_interval', [$this, 'addProductsWhereClauses']);

        // Variations report/stats WHERE clauses
        add_filter('woocommerce_analytics_clauses_where_variations_subquery', [$this, 'addVariationsWhereClauses']);
        add_filter('woocommerce_analytics_clauses_where_variations_stats_total', [$this, 'addVariationsWhereClauses']);
        add_filter('woocommerce_analytics_clauses_where_variations_stats_interval', [$this, 'addVariationsWhereClauses']);

        // Revenue report REST data extensions.
        add_filter('woocommerce_analytics_revenue_select_query', [$this, 'injectRootRevenueTotals'], 10, 2);
        add_filter('woocommerce_rest_prepare_report_revenue_stats', [$this, 'injectRevenueMetricsInterval'], 10, 3);
    }

    /**
     * Enqueue Analytics JS extension on WC Analytics pages.
     *
     * @param string $hook The current admin page hook.
     * @return void
     */
    public function enqueueAnalyticsAssets(string $hook): void
    {
        if (!$this->isWcAdminPage()) {
            return;
        }

        // WC Analytics uses SPA navigation — page-specific conditional loading
        // causes scripts to be missing when navigating between analytics pages
        // without a full reload. Each script self-filters by report endpoint,
        // so loading all on any wc-admin page is safe.
        $asset_file = Config::get('proplugin.public_path') . 'build/admin/analytics-orders.asset.php';
        $asset = file_exists($asset_file)
            ? require $asset_file
            : ['dependencies' => ['wp-hooks', 'wp-i18n'], 'version' => ARRAYSUBSPRO_VERSION];

        wp_enqueue_script(
            'arraysubspro-analytics-orders',
            Config::get('proplugin.public_url') . 'build/admin/analytics-orders.js',
            $asset['dependencies'],
            $asset['version'],
            true
        );

        $asset_file = Config::get('proplugin.public_path') . 'build/admin/analytics-products-variations.asset.php';
        $asset = file_exists($asset_file)
            ? require $asset_file
            : ['dependencies' => ['wp-hooks', 'wp-i18n'], 'version' => ARRAYSUBSPRO_VERSION];

        wp_enqueue_script(
            'arraysubspro-analytics-products-variations',
            Config::get('proplugin.public_url') . 'build/admin/analytics-products-variations.js',
            $asset['dependencies'],
            $asset['version'],
            true
        );

        $asset_file = Config::get('proplugin.public_path') . 'build/admin/analytics-revenue.asset.php';
        $asset = file_exists($asset_file)
            ? require $asset_file
            : ['dependencies' => ['wp-hooks', 'wp-i18n'], 'version' => ARRAYSUBSPRO_VERSION];

        wp_enqueue_script(
            'arraysubspro-analytics-revenue',
            Config::get('proplugin.public_url') . 'build/admin/analytics-revenue.js',
            $asset['dependencies'],
            $asset['version'],
            true
        );
    }

    /**
     * Inject custom revenue metrics into the overall totals.
     *
     * This intercepts the raw datastore output before it hits the REST controller.
     * This handles computing both the root totals and the intervals prior to schema filtering.
     *
     * @param object|array $results The report data object.
     * @param array        $args    The query args.
     * @return object|array
     */
    public function injectRootRevenueTotals($results, array $args)
    {
        // 1. Root Totals
        $after = $this->normalizeRevenueDateParam($args['after'] ?? '');
        $before = $this->normalizeRevenueDateParam($args['before'] ?? '');
        $active_subscription_amount = $this->computeActiveSubscriptionAmount();

        $custom_metrics = $this->computeRevenueMetrics($after, $before, $active_subscription_amount);

        if (is_object($results)) {
            if (!isset($results->totals)) {
                $results->totals = clone (object) $custom_metrics;
            } else {
                foreach ($custom_metrics as $key => $value) {
                    if (is_object($results->totals)) {
                        $results->totals->{$key} = $value;
                    } else {
                        $results->totals[$key] = $value;
                    }
                }
            }

            // 2. Intervals
            if (!empty($results->intervals) && is_array($results->intervals)) {
                foreach ($results->intervals as $idx => $interval) {
                    $is_obj = is_object($interval);
                    $arr_int = (array) $interval;

                    $int_after = $this->normalizeRevenueDateParam($arr_int['date_start'] ?? '');
                    $int_before = $this->normalizeRevenueDateParam($arr_int['date_end'] ?? ($arr_int['date_start'] ?? ''));

                    $int_metrics = $this->computeRevenueMetrics($int_after, $int_before, $active_subscription_amount);

                    if (!isset($arr_int['subtotals'])) {
                        $arr_int['subtotals'] = $int_metrics;
                    } else {
                        foreach ($int_metrics as $key => $value) {
                            if (is_object($arr_int['subtotals'])) {
                                $arr_int['subtotals']->{$key} = $value;
                            } else {
                                $arr_int['subtotals'][$key] = $value;
                            }
                        }
                    }

                    $results->intervals[$idx] = $is_obj ? (object) $arr_int : $arr_int;
                }
            }
        }

        return $results;
    }

    /**
     * Restore custom revenue metrics into each interval's REST response payload.
     *
     * The `prepare_item_for_response` strips unexpected properties using the json schema,
     * so we copy them back from the unfiltered `$report` object into the final `$response`.
     *
     * @param \WP_REST_Response $response The prepared response.
     * @param mixed             $report   Unfiltered individual interval object.
     * @param \WP_REST_Request  $request  The request.
     * @return \WP_REST_Response
     */
    public function injectRevenueMetricsInterval(
        \WP_REST_Response $response,
        $report,
        \WP_REST_Request $request
    ): \WP_REST_Response {
        unset($report, $request);

        $data = $response->get_data();

        if (!is_array($data) || !isset($data['subtotals']) || !isset($data['date_start'])) {
            return $response;
        }

        $interval_after = $this->normalizeRevenueDateParam((string) $data['date_start']);
        $interval_before = $this->normalizeRevenueDateParam((string) ($data['date_end'] ?? ''));

        if (empty($interval_before)) {
            $interval_before = $interval_after;
        }

        $active_subscription_amount = $this->computeActiveSubscriptionAmount();
        $interval_metrics = $this->computeRevenueMetrics(
            $interval_after,
            $interval_before,
            $active_subscription_amount
        );

        foreach ($interval_metrics as $key => $val) {
            if (is_object($data['subtotals'])) {
                $data['subtotals']->{$key} = $val;
            } else {
                $data['subtotals'][$key] = $val;
            }
        }

        $response->set_data($data);
        return $response;
    }

    /**
     * Compute custom revenue metrics for a date range.
     *
     * @param string $after                      ISO date lower bound.
     * @param string $before                     ISO date upper bound.
     * @param float  $active_subscription_amount Active subscription amount snapshot.
     * @return array<string, float>
     */
    private function computeRevenueMetrics(string $after, string $before, float $active_subscription_amount): array
    {
        $type_amounts = $this->computeRevenueTypeAmounts($after, $before);

        return [
            'arraysubs_total_subs_renew_amount'     => (float) ($type_amounts[TypeResolver::TYPE_SUBS_RENEW] ?? 0),
            'arraysubs_total_subs_upgrade_amount'   => (float) ($type_amounts[TypeResolver::TYPE_SUBS_UPGRADE] ?? 0),
            'arraysubs_total_credit_purchase_amount' => (float) ($type_amounts[TypeResolver::TYPE_CREDIT_PURCHASE] ?? 0),
            'arraysubs_active_subscription_amount'  => $active_subscription_amount,
        ];
    }

    /**
     * Compute type-based revenue amounts for a date range.
     *
     * @param string $after  ISO date lower bound.
     * @param string $before ISO date upper bound.
     * @return array<string, float>
     */
    private function computeRevenueTypeAmounts(string $after, string $before): array
    {
        if (empty($after) || empty($before)) {
            return [];
        }

        global $wpdb;

        $stats_table = "{$wpdb->prefix}wc_order_stats";
        $meta = $this->getMetaTableInfo("{$stats_table}.order_id");
        $date_column = $this->getRevenueDateColumn();

        $allowed_date_columns = ['date_created', 'date_paid', 'date_completed'];
        if (!in_array($date_column, $allowed_date_columns, true)) {
            $date_column = 'date_paid';
        }

        $allowed_meta_id_columns = ['order_id', 'post_id'];
        $meta_id_column = in_array($meta['id_col'], $allowed_meta_id_columns, true)
            ? $meta['id_col']
            : 'order_id';

        $meta_table = $meta['table'];

        $where_parts = [
            'os.parent_id = 0',
            'om.meta_value IN (%s, %s, %s)',
            "os.{$date_column} >= %s",
            "os.{$date_column} <= %s",
        ];

        $prepare_values = [
            '_arraysubs_computed_type',
            TypeResolver::TYPE_SUBS_RENEW,
            TypeResolver::TYPE_SUBS_UPGRADE,
            TypeResolver::TYPE_CREDIT_PURCHASE,
            $after,
            $before,
        ];

        $args = array_merge($this->customQueryArgs, $this->getRequestCustomQueryArgs());
        $normalized_type_filters = $this->getNormalizedTypeFilters($args);
        $custom_filter_clauses = [];
        $custom_prepare_values = [];

        if (!empty($normalized_type_filters['includes'])) {
            $custom_filter_clauses[] = 'om.meta_value IN ('
                . $this->buildSqlPlaceholders(count($normalized_type_filters['includes']))
                . ')';
            $custom_prepare_values = array_merge($custom_prepare_values, $normalized_type_filters['includes']);
        }

        if (!empty($normalized_type_filters['excludes'])) {
            $custom_filter_clauses[] = 'om.meta_value NOT IN ('
                . $this->buildSqlPlaceholders(count($normalized_type_filters['excludes']))
                . ')';
            $custom_prepare_values = array_merge($custom_prepare_values, $normalized_type_filters['excludes']);
        }

        if (!empty($args['arraysubs_coupon'])) {
            $custom_filter_clauses[] = "EXISTS (
                SELECT 1 FROM {$wpdb->prefix}woocommerce_order_items AS asci
                WHERE asci.order_id = os.order_id
                AND asci.order_item_type = 'coupon'
                AND asci.order_item_name = %s
            )";
            $custom_prepare_values[] = $args['arraysubs_coupon'];
        }

        if (!empty($args['arraysubs_subs_only']) && $args['arraysubs_subs_only'] === 'yes') {
            $custom_filter_clauses[] = "EXISTS (
                SELECT 1 FROM {$meta_table} AS assm
                WHERE assm.{$meta_id_column} = os.order_id
                AND assm.meta_key = '_arraysubs_has_subscription_product'
                AND assm.meta_value = 'yes'
            )";
        }

        if (!empty($custom_filter_clauses)) {
            $where_parts[] = '('
                . implode(' ' . $this->getMatchOperator($args['match'] ?? '') . ' ', $custom_filter_clauses)
                . ')';
            $prepare_values = array_merge($prepare_values, $custom_prepare_values);
        }

        // phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $sql = "SELECT om.meta_value AS order_type, SUM(os.net_total) AS total_amount
            FROM {$stats_table} AS os
            INNER JOIN {$meta_table} AS om
                ON om.{$meta_id_column} = os.order_id
                AND om.meta_key = %s
            WHERE " . implode(' AND ', $where_parts) . '
            GROUP BY om.meta_value';

        $rows = $wpdb->get_results($wpdb->prepare($sql, ...$prepare_values));
        // phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

        $totals = [];

        if (!is_array($rows)) {
            return $totals;
        }

        foreach ($rows as $row) {
            if (!isset($row->order_type)) {
                continue;
            }

            $type = sanitize_text_field((string) $row->order_type);
            $totals[$type] = isset($row->total_amount) ? (float) $row->total_amount : 0.0;
        }

        return $totals;
    }

    /**
     * Compute total recurring amount across active subscriptions.
     *
     * @return float
     */
    private function computeActiveSubscriptionAmount(): float
    {
        global $wpdb;

        // phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $result = $wpdb->get_var($wpdb->prepare(
            "SELECT COALESCE(SUM(CAST(pm.meta_value AS DECIMAL(20, 6))), 0)
            FROM {$wpdb->posts} AS p
            INNER JOIN {$wpdb->postmeta} AS pm
                ON pm.post_id = p.ID
                AND pm.meta_key = %s
            WHERE p.post_type = %s
                AND p.post_status = %s",
            '_subscription_total',
            'arraysubs_sub',
            'wc-active'
        ));
        // phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

        return (float) ($result ?? 0.0);
    }

    /**
     * Get the WC order stats date column used by Revenue report queries.
     *
     * @return string
     */
    private function getRevenueDateColumn(): string
    {
        $date_type = get_option('woocommerce_date_type', 'date_paid');

        if ($date_type === 'date_completed') {
            return 'date_completed';
        }

        if ($date_type === 'date_created') {
            return 'date_created';
        }

        return 'date_paid';
    }

    /**
     * Normalize incoming Revenue date parameters.
     *
     * @param mixed $date_value Raw date value.
     * @return string
     */
    private function normalizeRevenueDateParam($date_value): string
    {
        if (!is_string($date_value)) {
            return '';
        }

        return sanitize_text_field($date_value);
    }

    /**
     * Register REST fields for WooCommerce Analytics Orders report.
     *
     * Uses register_rest_field() which integrates with WC's add_additional_fields_schema()
     * to extend both the schema and response. This is the correct approach — WC does NOT
     * fire a 'woocommerce_rest_reports_orders_schema' filter.
     *
     * @return void
     */
    public function registerRestFields(): void
    {
        register_rest_field('report_orders', 'arraysubs_type', [
            'get_callback' => [$this, 'getTypeFieldValue'],
            'schema'       => [
                'description' => __('Subscription order type', 'arraysubspro'),
                'type'        => 'string',
                'context'     => ['view'],
                'readonly'    => true,
            ],
        ]);
    }

    /**
     * Get the Type field value for a report order.
     *
     * Callback for register_rest_field(). Reads computed meta directly
     * to avoid loading the full WC_Order object per row. Falls back to
     * live TypeResolver resolution for uncomputed orders.
     *
     * @param array $report_item The report item data from DataStore.
     * @return string The order type label.
     */
    public function getTypeFieldValue(array $report_item): string
    {
        $order_id = isset($report_item['order_id']) ? absint($report_item['order_id']) : 0;
        $parent_id = isset($report_item['parent_id']) ? absint($report_item['parent_id']) : 0;

        if (!$order_id) {
            return TypeResolver::TYPE_OTHER;
        }

        // Orders Analytics can include refund rows. For refund rows, classify using
        // the parent shop order to avoid passing refund objects to TypeResolver.
        $lookup_order_id = $parent_id > 0 ? $parent_id : $order_id;

        // Fast path: direct meta read avoids loading full WC_Order per row.
        $computed_type = $this->readOrderMeta($lookup_order_id, '_arraysubs_computed_type');

        // Use stored type only when it is a known non-Other value.
        // Historically, stale early-computed "Other" values can persist.
        if (!empty($computed_type) && $computed_type !== TypeResolver::TYPE_OTHER && in_array($computed_type, TypeResolver::ALL_TYPES, true)) {
            return $computed_type;
        }

        // Slow path: load full order for live type resolution.
        $order = \wc_get_order($lookup_order_id);

        if (!$order instanceof \WC_Order || $order->get_type() !== 'shop_order') {
            return TypeResolver::TYPE_OTHER;
        }

        $resolved_type = TypeResolver::resolve($order);

        // Self-heal stale/invalid computed type to keep analytics queries and UI aligned.
        if ($computed_type !== $resolved_type) {
            $order->update_meta_data('_arraysubs_computed_type', $resolved_type);

            $has_sub = TypeResolver::hasSubscriptionProduct($order) ? 'yes' : 'no';
            $order->update_meta_data('_arraysubs_has_subscription_product', $has_sub);

            $order->save_meta_data();
        }

        return $resolved_type;
    }

    /**
     * Read a single order meta value directly without loading the full WC_Order.
     *
     * Uses the appropriate meta table depending on HPOS vs legacy storage mode.
     *
     * @param int    $order_id The order ID.
     * @param string $meta_key The meta key.
     * @return string The meta value, or empty string if not found.
     */
    private function readOrderMeta(int $order_id, string $meta_key): string
    {
        global $wpdb;

        if ($this->isHpos) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $value = $wpdb->get_var($wpdb->prepare(
                "SELECT meta_value FROM {$wpdb->prefix}wc_orders_meta
                 WHERE order_id = %d AND meta_key = %s LIMIT 1",
                $order_id,
                $meta_key
            ));
        } else {
            $value = get_post_meta($order_id, $meta_key, true);
        }

        return is_string($value) ? $value : '';
    }

    /**
     * Accept custom query parameters from the WC Analytics REST requests.
     *
     * Stores custom args in $this->customQueryArgs for use by SQL clause filters,
     * since context-specific clause filters only receive $clauses (1 param).
     *
     * @param array $args The query args.
     * @return array Modified args.
     */
    public function handleQueryArgs(array $args): array
    {
        $request_args = $this->getRequestCustomQueryArgs();
        $type = $request_args[self::LEGACY_TYPE_QUERY_KEY];
        $type_includes = $request_args[self::TYPE_INCLUDE_QUERY_KEY];
        $type_excludes = $request_args[self::TYPE_EXCLUDE_QUERY_KEY];

        if (empty($type_includes) && !empty($type) && $type !== 'all') {
            $type_includes = [$type];
        }

        $type_includes = $this->sanitizeTypeValues($type_includes);
        $type_excludes = $this->sanitizeTypeValues($type_excludes);

        if (!empty($type_includes)) {
            $args[self::TYPE_INCLUDE_QUERY_KEY] = $type_includes;
        }

        if (!empty($type_excludes)) {
            $args[self::TYPE_EXCLUDE_QUERY_KEY] = $type_excludes;
        }

        if (!empty($type) && $type !== 'all' && in_array($type, TypeResolver::ALL_TYPES, true)) {
            $args[self::LEGACY_TYPE_QUERY_KEY] = $type;
        }

        $coupon = $request_args['arraysubs_coupon'];

        if (!empty($coupon)) {
            $args['arraysubs_coupon'] = $coupon;
        }

        $subs_only = $request_args['arraysubs_subs_only'];

        if ($subs_only === 'yes') {
            $args['arraysubs_subs_only'] = 'yes';
        }

        // Store custom args for SQL clause filters (they only receive $clauses, not $args)
        $this->customQueryArgs = [
            self::LEGACY_TYPE_QUERY_KEY => $args[self::LEGACY_TYPE_QUERY_KEY] ?? '',
            self::TYPE_INCLUDE_QUERY_KEY => $args[self::TYPE_INCLUDE_QUERY_KEY] ?? [],
            self::TYPE_EXCLUDE_QUERY_KEY => $args[self::TYPE_EXCLUDE_QUERY_KEY] ?? [],
            'arraysubs_coupon'    => $args['arraysubs_coupon'] ?? '',
            'arraysubs_subs_only' => $args['arraysubs_subs_only'] ?? '',
            'match'               => $request_args['match'],
        ];

        return $args;
    }

    /**
     * Normalize include/exclude type filters from request or stored args.
     *
     * Falls back to the legacy single-value `arraysubs_type` query arg when no
     * advanced include filters are present.
     *
     * @param array $args Raw request or stored query args.
     * @return array{includes: array, excludes: array}
     */
    private function getNormalizedTypeFilters(array $args): array
    {
        $type_includes = $this->sanitizeTypeValues($args[self::TYPE_INCLUDE_QUERY_KEY] ?? []);
        $type_excludes = $this->sanitizeTypeValues($args[self::TYPE_EXCLUDE_QUERY_KEY] ?? []);
        $legacy_type = $args[self::LEGACY_TYPE_QUERY_KEY] ?? '';

        if (empty($type_includes) && is_string($legacy_type) && $legacy_type !== '' && $legacy_type !== 'all') {
            $type_includes = $this->sanitizeTypeValues([$legacy_type]);
        }

        return [
            'includes' => $type_includes,
            'excludes' => $type_excludes,
        ];
    }

    /**
     * Build a comma-separated list of SQL placeholders.
     *
     * @param int $count Number of placeholders required.
     * @return string
     */
    private function buildSqlPlaceholders(int $count): string
    {
        return implode(', ', array_fill(0, max(0, $count), '%s'));
    }

    /**
     * Get the meta subquery for the current storage mode.
     *
     * Returns a SQL fragment: "SELECT {id_col} FROM {table} WHERE {id_col} = {stats_ref} AND ..."
     * The caller wraps it in EXISTS(...).
     *
     * @param string $stats_ref Reference column from outer query (e.g. wc_order_stats.order_id).
     * @return array{table: string, id_col: string} Meta table and ID column.
     */
    private function getMetaTableInfo(string $stats_ref = ''): array
    {
        global $wpdb;

        if ($this->isHpos) {
            return [
                'table'  => "{$wpdb->prefix}wc_orders_meta",
                'id_col' => 'order_id',
            ];
        }

        return [
            'table'  => $wpdb->postmeta,
            'id_col' => 'post_id',
        ];
    }

    /**
     * Add WHERE clauses for custom filters.
     *
     * Uses EXISTS subqueries instead of JOINs to avoid row duplication.
     * Branches meta table between wc_orders_meta (HPOS) and postmeta (legacy).
     *
     * Context-specific SQL clause filters only pass $clauses (1 param).
     * Custom args are read from $this->customQueryArgs, set by handleQueryArgs().
     *
     * @param array $clauses SQL WHERE clauses.
     * @return array Modified clauses.
     */
    public function addWhereClauses(array $clauses): array
    {
        $args = array_merge($this->customQueryArgs, $this->getRequestCustomQueryArgs());

        global $wpdb;

        $meta = $this->getMetaTableInfo();
        $stats_id = "{$wpdb->prefix}wc_order_stats.order_id";
        $normalized_type_filters = $this->getNormalizedTypeFilters($args);
        $type_includes = $normalized_type_filters['includes'];
        $type_excludes = $normalized_type_filters['excludes'];

        $custom_clauses = [];

        // Type filter — EXISTS subquery on meta table
        if (!empty($type_includes)) {
            $custom_clauses[] = $this->buildTypeExistsClause($type_includes, $stats_id, false);
        }

        if (!empty($type_excludes)) {
            $custom_clauses[] = $this->buildTypeExistsClause($type_excludes, $stats_id, true);
        }

        // Coupon filter — EXISTS subquery on order items (no JOIN = no row duplication)
        if (!empty($args['arraysubs_coupon'])) {
            $custom_clauses[] = $wpdb->prepare(
                "EXISTS (
                    SELECT 1 FROM {$wpdb->prefix}woocommerce_order_items AS asci
                    WHERE asci.order_id = {$wpdb->prefix}wc_order_stats.order_id
                    AND asci.order_item_type = 'coupon'
                    AND asci.order_item_name = %s
                )",
                $args['arraysubs_coupon']
            );
        }

        // Subscription products only filter — EXISTS subquery on meta table
        if (!empty($args['arraysubs_subs_only']) && $args['arraysubs_subs_only'] === 'yes') {
            $custom_clauses[] = "EXISTS (
                SELECT 1 FROM {$meta['table']} AS assm
                WHERE assm.{$meta['id_col']} = {$stats_id}
                AND assm.meta_key = '_arraysubs_has_subscription_product'
                AND assm.meta_value = 'yes'
            )";
        }

        if (empty($custom_clauses)) {
            return $clauses;
        }

        return $this->appendCustomWhereClauses(
            $clauses,
            $custom_clauses,
            $this->getMatchOperator($args['match'] ?? '')
        );
    }

    /**
     * Append custom analytics WHERE clauses while preserving WooCommerce's all/any behaviour.
     *
     * @param array  $clauses        Existing WHERE clauses.
     * @param array  $custom_clauses Custom conditions without the leading AND.
     * @param string $match_operator Match operator (AND|OR).
     * @return array
     */
    private function appendCustomWhereClauses(array $clauses, array $custom_clauses, string $match_operator): array
    {
        $custom_clause = 'AND (' . implode(" {$match_operator} ", $custom_clauses) . ')';

        if ($match_operator !== 'OR') {
            $clauses[] = $custom_clause;
            return $clauses;
        }

        $merge_index = null;

        foreach ($clauses as $index => $clause) {
            if ($this->isMergeableGroupedWhereClause($clause)) {
                $merge_index = $index;
            }
        }

        if ($merge_index === null) {
            $clauses[] = $custom_clause;
            return $clauses;
        }

        $merged_clause = preg_replace(
            '/\)\s*$/',
            " {$match_operator} " . implode(" {$match_operator} ", $custom_clauses) . ')',
            $clauses[$merge_index],
            1
        );

        if (!is_string($merged_clause) || $merged_clause === '') {
            $clauses[] = $custom_clause;
            return $clauses;
        }

        $clauses[$merge_index] = $merged_clause;
        return $clauses;
    }

    /**
     * Determine whether a WHERE clause is a grouped clause that can absorb OR filters.
     *
     * @param string $clause SQL clause.
     * @return bool
     */
    private function isMergeableGroupedWhereClause(string $clause): bool
    {
        return (bool) preg_match('/^\s*AND\s*\(.*\)\s*$/s', $clause);
    }

    /**
     * Build a prepared type filter EXISTS/NOT EXISTS clause.
     *
     * @param array  $types      Allowed type values.
     * @param string $stats_id   Outer stats table order ID reference.
     * @param bool   $exclude    Whether to build a NOT EXISTS clause.
     * @return string
     */
    private function buildTypeExistsClause(array $types, string $stats_id, bool $exclude): string
    {
        global $wpdb;

        $types = $this->sanitizeTypeValues($types);

        if (empty($types)) {
            return '';
        }

        $meta = $this->getMetaTableInfo();
        $quoted_types = array_map(
            static function (string $type): string {
                return "'" . esc_sql($type) . "'";
            },
            $types
        );

        $exists_keyword = $exclude ? 'NOT EXISTS' : 'EXISTS';
        $meta_table = $meta['table'];
        $meta_id_column = $meta['id_col'];
        $meta_key = esc_sql('_arraysubs_computed_type');
        $type_list = implode(', ', $quoted_types);

        return "{$exists_keyword} (
            SELECT 1 FROM {$meta_table} AS asmt
            WHERE asmt.{$meta_id_column} = {$stats_id}
            AND asmt.meta_key = '{$meta_key}'
            AND asmt.meta_value IN ({$type_list})
        )";
    }

    /**
     * Normalize and validate requested type values.
     *
     * @param array $types Raw type values.
     * @return array
     */
    private function sanitizeTypeValues(array $types): array
    {
        $sanitized = array_map(
            static function ($type): string {
                return sanitize_text_field((string) $type);
            },
            $types
        );

        $sanitized = array_filter(
            $sanitized,
            static function (string $type): bool {
                return in_array($type, TypeResolver::ALL_TYPES, true);
            }
        );

        return array_values(array_unique($sanitized));
    }

    /**
     * Normalize a request param into a list of scalar values.
     *
     * @param mixed $raw_value Raw request value.
     * @return array
     */
    private function sanitizeRequestList($raw_value): array
    {
        if (is_array($raw_value)) {
            return array_values(array_filter(array_map(
                static function ($value): string {
                    return is_scalar($value) ? sanitize_text_field((string) $value) : '';
                },
                $raw_value
            )));
        }

        if (!is_string($raw_value) || $raw_value === '') {
            return [];
        }

        return array_values(array_filter(array_map(
            static function (string $value): string {
                return sanitize_text_field(trim($value));
            },
            explode(',', $raw_value)
        )));
    }

    /**
     * Get WooCommerce-style match operator from the request.
     *
     * @param string $match Raw match value.
     * @return string
     */
    private function getMatchOperator(string $match): string
    {
        return strtolower($match) === 'any' ? 'OR' : 'AND';
    }

    /**
     * Accept custom query parameters from WC Analytics Products requests.
     *
     * @param array $args The query args.
     * @return array Modified args.
     */
    public function handleProductsQueryArgs(array $args): array
    {
        $subs_only = $this->getSubsOnlyFilterValue();

        if ($subs_only === 'yes') {
            $args['arraysubs_subs_only'] = 'yes';
        }

        $this->productsCustomQueryArgs = [
            'arraysubs_subs_only' => $args['arraysubs_subs_only'] ?? '',
        ];

        return $args;
    }

    /**
     * Accept custom query parameters from WC Analytics Variations requests.
     *
     * @param array $args The query args.
     * @return array Modified args.
     */
    public function handleVariationsQueryArgs(array $args): array
    {
        $subs_only = $this->getSubsOnlyFilterValue();

        if ($subs_only === 'yes') {
            $args['arraysubs_subs_only'] = 'yes';
        }

        $this->variationsCustomQueryArgs = [
            'arraysubs_subs_only' => $args['arraysubs_subs_only'] ?? '',
        ];

        return $args;
    }

    /**
     * Add Products analytics WHERE clauses for custom filters.
     *
     * @param array $clauses SQL WHERE clauses.
     * @return array Modified clauses.
     */
    public function addProductsWhereClauses(array $clauses): array
    {
        $args = $this->productsCustomQueryArgs;

        if (empty($args['arraysubs_subs_only']) || $args['arraysubs_subs_only'] !== 'yes') {
            return $clauses;
        }

        global $wpdb;

        $clauses[] = $wpdb->prepare(
            "AND EXISTS (
                SELECT 1 FROM {$wpdb->postmeta} AS aspm
                WHERE aspm.post_id = {$wpdb->prefix}wc_order_product_lookup.product_id
                AND aspm.meta_key = %s
                AND aspm.meta_value = %s
            )",
            '_is_subscription',
            'yes'
        );

        return $clauses;
    }

    /**
     * Add Variations analytics WHERE clauses for custom filters.
     *
     * Includes rows where either the parent product OR the variation itself
     * is marked as a subscription product.
     *
     * @param array $clauses SQL WHERE clauses.
     * @return array Modified clauses.
     */
    public function addVariationsWhereClauses(array $clauses): array
    {
        $args = $this->variationsCustomQueryArgs;

        if (empty($args['arraysubs_subs_only']) || $args['arraysubs_subs_only'] !== 'yes') {
            return $clauses;
        }

        global $wpdb;

        $clauses[] = $wpdb->prepare(
            "AND (
                EXISTS (
                    SELECT 1 FROM {$wpdb->postmeta} AS aspm_parent
                    WHERE aspm_parent.post_id = {$wpdb->prefix}wc_order_product_lookup.product_id
                    AND aspm_parent.meta_key = %s
                    AND aspm_parent.meta_value = %s
                )
                OR EXISTS (
                    SELECT 1 FROM {$wpdb->postmeta} AS aspm_variation
                    WHERE aspm_variation.post_id = {$wpdb->prefix}wc_order_product_lookup.variation_id
                    AND aspm_variation.meta_key = %s
                    AND aspm_variation.meta_value = %s
                )
            )",
            '_is_subscription',
            'yes',
            '_is_subscription',
            'yes'
        );

        return $clauses;
    }

    /**
     * Get sanitized subscription-only filter value from request.
     *
     * @return string
     */
    private function getSubsOnlyFilterValue(): string
    {
        // phpcs:disable WordPress.Security.NonceVerification.Recommended
        return isset($_GET['arraysubs_subs_only'])
            ? sanitize_text_field(wp_unslash($_GET['arraysubs_subs_only']))
            : '';
        // phpcs:enable WordPress.Security.NonceVerification.Recommended
    }

    /**
     * Read and sanitize custom analytics filters from the current request.
     *
     * @return array{
     *     arraysubs_type: string,
     *     arraysubs_type_is: array,
     *     arraysubs_type_is_not: array,
     *     arraysubs_coupon: string,
     *     arraysubs_subs_only: string,
     *     match: string
     * }
     */
    private function getRequestCustomQueryArgs(): array
    {
        // phpcs:disable WordPress.Security.NonceVerification.Recommended
        $type = isset($_GET[self::LEGACY_TYPE_QUERY_KEY])
            ? sanitize_text_field(wp_unslash($_GET[self::LEGACY_TYPE_QUERY_KEY]))
            : '';

        $coupon = isset($_GET['arraysubs_coupon'])
            ? sanitize_text_field(wp_unslash($_GET['arraysubs_coupon']))
            : '';

        $subs_only = isset($_GET['arraysubs_subs_only'])
            ? sanitize_text_field(wp_unslash($_GET['arraysubs_subs_only']))
            : '';

        $match = isset($_GET['match'])
            ? sanitize_text_field(wp_unslash($_GET['match']))
            : '';

        $raw_type_includes = isset($_GET[self::TYPE_INCLUDE_QUERY_KEY])
            ? wp_unslash($_GET[self::TYPE_INCLUDE_QUERY_KEY])
            : [];

        $raw_type_excludes = isset($_GET[self::TYPE_EXCLUDE_QUERY_KEY])
            ? wp_unslash($_GET[self::TYPE_EXCLUDE_QUERY_KEY])
            : [];

        $type_includes = $this->sanitizeRequestList($raw_type_includes);
        $type_excludes = $this->sanitizeRequestList($raw_type_excludes);
        // phpcs:enable WordPress.Security.NonceVerification.Recommended

        return [
            self::LEGACY_TYPE_QUERY_KEY => $type,
            self::TYPE_INCLUDE_QUERY_KEY => $type_includes,
            self::TYPE_EXCLUDE_QUERY_KEY => $type_excludes,
            'arraysubs_coupon'    => $coupon,
            'arraysubs_subs_only' => $subs_only,
            'match'               => $match,
        ];
    }

    /**
     * Check if current page is a WooCommerce Admin page.
     *
     * WC Admin uses SPA navigation, so all analytics scripts must be
     * loaded on any wc-admin page to survive client-side route changes.
     *
     * @return bool
     */
    private function isWcAdminPage(): bool
    {
        $screen = get_current_screen();

        if (!$screen) {
            return false;
        }

        return $screen->id === 'woocommerce_page_wc-admin'
            || strpos($screen->id, 'wc-admin') !== false;
    }
}
