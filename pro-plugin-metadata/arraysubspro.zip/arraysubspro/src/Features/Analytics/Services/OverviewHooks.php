<?php

/**
 * Analytics Overview Hooks
 *
 * Integrates subscription analytics into the WooCommerce Analytics Overview page.
 * Registers leaderboards via the standard WC filter, enqueues the overview JS,
 * and invalidates transient caches on subscription lifecycle events.
 *
 * @package ArraySubsPro\Features\Analytics\Services
 */

namespace ArraySubsPro\Features\Analytics\Services;

defined('ABSPATH') || exit;

use ArraySubs\Supports\Config;
use ArraySubsPro\Features\Analytics\REST\OverviewController;

/**
 * Overview hooks for WC Analytics
 */
class OverviewHooks
{
    /**
     * Enable auto-loading
     *
     * @var bool
     */
    public static $loadable = true;

    /**
     * Overview controller instance for leaderboard queries
     *
     * @var OverviewController|null
     */
    private ?OverviewController $controller = null;

    /**
     * Constructor
     */
    public function __construct()
    {
        // Leaderboards (PHP filter).
        add_filter('woocommerce_leaderboards', [$this, 'registerLeaderboards'], 10, 5);

        // Enqueue overview JS on WC admin pages.
        add_action('admin_enqueue_scripts', [$this, 'enqueueAssets']);

        // Cache invalidation on subscription changes.
        add_action('arraysubs_data_status_changed', [$this, 'invalidateCache']);
        add_action('woocommerce_order_status_changed', [$this, 'invalidateCache']);
    }

    /**
     * Get or create the overview controller
     *
     * @return OverviewController
     */
    private function getController(): OverviewController
    {
        if (null === $this->controller) {
            $this->controller = new OverviewController();
        }

        return $this->controller;
    }

    /**
     * Register subscription leaderboards
     *
     * @param array       $leaderboards    Existing leaderboards.
     * @param int         $per_page        Rows per leaderboard.
     * @param string|null $after           Period start (ISO 8601).
     * @param string|null $before          Period end (ISO 8601).
     * @param string      $persisted_query URL query string.
     * @return array
     */
    public function registerLeaderboards(
        array $leaderboards,
        int $per_page,
        ?string $after,
        ?string $before,
        $persisted_query
    ): array {
        $ctrl = $this->getController();

        $leaderboards[] = [
            'id'      => 'arraysubs-top-products-active',
            'label'   => __('Top Subscription Products — Active', 'arraysubspro'),
            'headers' => [
                ['label' => __('Product Name', 'arraysubspro')],
                ['label' => __('Active Subs', 'arraysubspro')],
                ['label' => __('MRR Contribution', 'arraysubspro')],
            ],
            'rows'    => $ctrl->getTopProductsByActive($per_page, $after, $before),
        ];

        $leaderboards[] = [
            'id'      => 'arraysubs-top-products-revenue',
            'label'   => __('Top Subscription Products — Revenue', 'arraysubspro'),
            'headers' => [
                ['label' => __('Product Name', 'arraysubspro')],
                ['label' => __('Total Revenue', 'arraysubspro')],
                ['label' => __('Orders', 'arraysubspro')],
            ],
            'rows'    => $ctrl->getTopProductsByRevenue($per_page, $after, $before),
        ];

        $leaderboards[] = [
            'id'      => 'arraysubs-top-customers-ltv',
            'label'   => __('Top Subscribers — Lifetime Value', 'arraysubspro'),
            'headers' => [
                ['label' => __('Customer', 'arraysubspro')],
                ['label' => __('Active Subs', 'arraysubspro')],
                ['label' => __('Total Spent', 'arraysubspro')],
            ],
            'rows'    => $ctrl->getTopCustomersByLtv($per_page, $after, $before),
        ];

        $leaderboards[] = [
            'id'      => 'arraysubs-top-cancel-reasons',
            'label'   => __('Top Cancellation Reasons', 'arraysubspro'),
            'headers' => [
                ['label' => __('Reason', 'arraysubspro')],
                ['label' => __('Count', 'arraysubspro')],
                ['label' => __('% of Total', 'arraysubspro')],
            ],
            'rows'    => $ctrl->getTopCancellationReasons($per_page, $after, $before),
        ];

        $leaderboards[] = [
            'id'      => 'arraysubs-top-products-churn',
            'label'   => __('Highest Churn Products', 'arraysubspro'),
            'headers' => [
                ['label' => __('Product Name', 'arraysubspro')],
                ['label' => __('Cancellations', 'arraysubspro')],
                ['label' => __('Churn Rate', 'arraysubspro')],
            ],
            'rows'    => $ctrl->getTopProductsByChurn($per_page, $after, $before),
        ];

        return $leaderboards;
    }

    /**
     * Enqueue overview JS on WC Admin pages
     *
     * @param string $hook Current admin page hook.
     * @return void
     */
    public function enqueueAssets(string $hook): void
    {
        if (! $this->isWcAdminPage()) {
            return;
        }

        $asset_file = Config::get('proplugin.public_path') . 'build/admin/analytics-overview.asset.php';
        $asset      = file_exists($asset_file)
            ? require $asset_file
            : ['dependencies' => ['wp-hooks', 'wp-i18n', 'wp-element'], 'version' => ARRAYSUBSPRO_VERSION];

        wp_enqueue_script(
            'arraysubspro-analytics-overview',
            Config::get('proplugin.public_url') . 'build/admin/analytics-overview.js',
            $asset['dependencies'],
            $asset['version'],
            true
        );

        wp_enqueue_style(
            'arraysubspro-analytics-overview',
            Config::get('proplugin.public_url') . 'build/admin/analytics-overview.css',
            [],
            $asset['version']
        );

        $overview_data = [
            'apiBaseUrl' => rest_url(),
            'nonce'      => wp_create_nonce('wp_rest'),
            'currency'   => get_woocommerce_currency(),
        ];

        wp_add_inline_script(
            'arraysubspro-analytics-overview',
            'window.arraySubsOverview = ' . wp_json_encode(
                $overview_data,
                JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT
            ) . ';',
            'before'
        );
    }

    /**
     * Invalidate overview transient caches
     *
     * @return void
     */
    public function invalidateCache(): void
    {
        global $wpdb;

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $wpdb->query(
            "DELETE FROM {$wpdb->options}
            WHERE option_name LIKE '_transient_arraysubs_overview_%'
                OR option_name LIKE '_transient_timeout_arraysubs_overview_%'"
        );
    }

    /**
     * Check if current page is a WC Admin page
     *
     * @return bool
     */
    private function isWcAdminPage(): bool
    {
        $screen = get_current_screen();

        if (! $screen) {
            return false;
        }

        return $screen->id === 'woocommerce_page_wc-admin'
            || strpos($screen->id, 'wc-admin') !== false;
    }
}
