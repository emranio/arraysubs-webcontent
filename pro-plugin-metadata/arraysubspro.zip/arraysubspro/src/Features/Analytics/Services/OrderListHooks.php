<?php

/**
 * WooCommerce Order List Hooks
 *
 * Extends the WooCommerce admin Orders list table with:
 * - Type column (subscription order type badge)
 * - Used Coupon(s) column
 * - Type filter dropdown
 * - Coupon filter dropdown
 * - Subscription products only filter
 * - Embedded report summary panel
 *
 * Supports both HPOS (Custom Orders Table) and legacy post-type modes.
 *
 * @package ArraySubsPro\Features\Analytics\Services
 */

namespace ArraySubsPro\Features\Analytics\Services;

defined('ABSPATH') || exit;

use Automattic\WooCommerce\Internal\Admin\Orders\ListTable as WooCommerceOrdersListTable;
use Automattic\WooCommerce\Internal\DataStores\Orders\OrdersTableQuery;
use ArraySubs\Supports\Config;

/**
 * Order list hooks for WooCommerce Orders admin page.
 */
class OrderListHooks
{
    /**
     * Enable auto-loading.
     *
     * @var bool
     */
    public static $loadable = true;

    /**
     * Whether HPOS (Custom Orders Table) is enabled.
     *
     * @var bool
     */
    private bool $isHpos = false;

    /**
     * Cache for coupon codes dropdown.
     *
     * @var array|null
     */
    private ?array $couponCodesCache = null;

    /**
     * Whether legacy coupon SQL filters have been registered.
     *
     * Prevents duplicate registration of posts_join/posts_groupby filters.
     *
     * @var bool
     */
    private bool $legacyCouponFiltersApplied = false;

    /**
     * Whether HPOS coupon clause filter has been registered.
     *
     * Prevents duplicate registration of woocommerce_orders_table_query_clauses filter.
     *
     * @var bool
     */
    private bool $hposCouponFilterApplied = false;

    public function __construct()
    {
        if (!is_admin()) {
            return;
        }

        $this->isHpos = $this->detectHpos();

        // Column registration
        if ($this->isHpos) {
            add_filter('manage_woocommerce_page_wc-orders_columns', [$this, 'addColumns']);
            add_action('manage_woocommerce_page_wc-orders_custom_column', [$this, 'renderColumnHpos'], 10, 2);
        } else {
            add_filter('manage_edit-shop_order_columns', [$this, 'addColumns']);
            add_action('manage_shop_order_posts_custom_column', [$this, 'renderColumnLegacy'], 10, 2);
        }

        // Filter dropdowns
        if ($this->isHpos) {
            add_action('woocommerce_order_list_table_restrict_manage_orders', [$this, 'removeWooCommerceCustomerFilter'], 1, 2);
            add_action('woocommerce_order_list_table_restrict_manage_orders', [$this, 'renderFilterDropdowns'], 10, 1);
            add_filter('woocommerce_hpos_admin_search_filters', [$this, 'filterHposSearchFilters']);
            add_filter('woocommerce_hpos_generate_where_for_search_filter', [$this, 'generateHposWhereForSearchFilter'], 10, 4);
        } else {
            add_action('restrict_manage_posts', [$this, 'renderFilterDropdownsLegacy'], 10, 1);
        }

        // Query modification for filters
        if ($this->isHpos) {
            add_filter('woocommerce_order_list_table_prepare_items_query_args', [$this, 'filterQueryHpos']);
        } else {
            add_action('pre_get_posts', [$this, 'filterQueryLegacy']);
        }

        // Embedded report panel
        if ($this->isHpos) {
            add_action('woocommerce_order_list_table_extra_tablenav', [$this, 'renderReportPanel'], 10, 2);
        } else {
            add_action('manage_posts_extra_tablenav', [$this, 'renderReportPanelLegacy']);
        }

        // Backfill mechanism
        add_action('admin_init', [$this, 'handleBackfillRequest']);
        add_action('admin_notices', [$this, 'renderBackfillNotice']);

        // Enqueue admin assets
        add_action('admin_enqueue_scripts', [$this, 'enqueueAssets']);
    }

    /**
     * Detect if HPOS (Custom Orders Table) is enabled.
     *
     * @return bool
     */
    private function detectHpos(): bool
    {
        return class_exists('Automattic\WooCommerce\Utilities\OrderUtil')
            && \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled();
    }

    /**
     * Check if we are on the WooCommerce Orders list screen.
     *
     * @return bool
     */
    private function isOrdersScreen(): bool
    {
        $screen = get_current_screen();

        if (!$screen) {
            return false;
        }

        if ($this->isHpos) {
            return $screen->id === 'woocommerce_page_wc-orders';
        }

        return $screen->id === 'edit-shop_order';
    }

    // ─── Columns ─────────────────────────────────────────────────────────

    /**
     * Add custom columns to the WooCommerce Orders list table.
     *
     * Inserts Type and Coupon(s) columns after the order_status column.
     *
     * @param array $columns Existing columns.
     * @return array Modified columns.
     */
    public function addColumns(array $columns): array
    {
        $new_columns = [];

        foreach ($columns as $key => $label) {
            $new_columns[$key] = $label;

            // Insert after order_status column
            if ($key === 'order_status') {
                $new_columns['arraysubs_type'] = esc_html__('Type', 'arraysubspro');
                $new_columns['arraysubs_coupons'] = esc_html__('Coupon(s)', 'arraysubspro');
            }
        }

        // Fallback: if order_status column not found, append at end
        if (!isset($new_columns['arraysubs_type'])) {
            $new_columns['arraysubs_type'] = esc_html__('Type', 'arraysubspro');
            $new_columns['arraysubs_coupons'] = esc_html__('Coupon(s)', 'arraysubspro');
        }

        return $new_columns;
    }

    /**
     * Render custom column content in HPOS mode.
     *
     * In HPOS mode, the callback receives: (string $column_name, \WC_Order $order).
     *
     * @param string    $column_name The column key.
     * @param \WC_Order $order       The WooCommerce order object.
     * @return void
     */
    public function renderColumnHpos(string $column_name, $order): void
    {
        if (!$order instanceof \WC_Order) {
            return;
        }

        switch ($column_name) {
            case 'arraysubs_type':
                $this->renderTypeCell($order);
                break;

            case 'arraysubs_coupons':
                $this->renderCouponCell($order);
                break;
        }
    }

    /**
     * Render custom column content in legacy (post-type) mode.
     *
     * In legacy mode, the callback receives: (string $column_name, int $post_id).
     *
     * @param string $column_name The column key.
     * @param int    $post_id     The post ID.
     * @return void
     */
    public function renderColumnLegacy(string $column_name, int $post_id): void
    {
        if (!in_array($column_name, ['arraysubs_type', 'arraysubs_coupons'], true)) {
            return;
        }

        $order = wc_get_order($post_id);
        if (!$order) {
            return;
        }

        switch ($column_name) {
            case 'arraysubs_type':
                $this->renderTypeCell($order);
                break;

            case 'arraysubs_coupons':
                $this->renderCouponCell($order);
                break;
        }
    }

    /**
     * Render the Type column cell as a styled badge.
     *
     * @param \WC_Order $order The order.
     * @return void
     */
    private function renderTypeCell(\WC_Order $order): void
    {
        $computed_type = $order->get_meta('_arraysubs_computed_type');
        $resolved_type = TypeResolver::resolve($order);

        // Self-heal stale stored meta (e.g. previously computed too early in checkout).
        if (empty($computed_type) || $computed_type !== $resolved_type) {
            $order->update_meta_data('_arraysubs_computed_type', $resolved_type);
            $order->save_meta_data();
            $type = $resolved_type;
        } else {
            $type = $computed_type;
        }

        $label = TypeResolver::getLabel($type);
        $slug = sanitize_title($type);

        printf(
            '<span class="arraysubspro-order-type-badge arraysubspro-order-type-badge--%s">%s</span>',
            esc_attr($slug),
            esc_html($label)
        );
    }

    /**
     * Render the Used Coupon(s) column cell.
     *
     * @param \WC_Order $order The order.
     * @return void
     */
    private function renderCouponCell(\WC_Order $order): void
    {
        $codes = $order->get_coupon_codes();

        if (!empty($codes)) {
            $escaped_codes = array_map('esc_html', $codes);
            echo wp_kses(
                implode(', ', $escaped_codes),
                ['span' => ['class' => []]]
            );
        } else {
            echo '<span class="arraysubspro-order-coupon--empty">&mdash;</span>';
        }
    }

    // ─── Filter Dropdowns ────────────────────────────────────────────────

    /**
     * Render filter dropdowns on WooCommerce Orders page (HPOS mode).
     *
     * @param string $order_type The order type being displayed.
     * @return void
     */
    public function renderFilterDropdowns(string $order_type = ''): void
    {
        if ($order_type !== 'shop_order') {
            return;
        }

        $this->renderTypeFilterDropdown();
        $this->renderCouponFilterDropdown();
        $this->renderSubsOnlyFilterDropdown();
    }

    /**
     * Render filter dropdowns in legacy (post-type) mode.
     *
     * Only renders on the shop_order post type edit screen.
     *
     * @param string $post_type The current post type.
     * @return void
     */
    public function renderFilterDropdownsLegacy(string $post_type = ''): void
    {
        if ($post_type !== 'shop_order') {
            return;
        }

        $this->renderTypeFilterDropdown();
        $this->renderCouponFilterDropdown();
        $this->renderSubsOnlyFilterDropdown();
    }

    /**
     * Remove WooCommerce's registered-customer dropdown on the HPOS orders list.
     *
     * Keeps the list screen lighter while preserving customer lookup in the
     * native search filter dropdown.
     *
     * @param string $order_type The order type being displayed.
     * @param string $which      The table nav position.
     * @return void
     */
    public function removeWooCommerceCustomerFilter(string $order_type = '', string $which = ''): void
    {
        if (!$this->isHpos || $order_type !== 'shop_order') {
            return;
        }

        if (!function_exists('wc_get_container') || !class_exists(WooCommerceOrdersListTable::class)) {
            return;
        }

        $orders_list_table = wc_get_container()->get(WooCommerceOrdersListTable::class);

        if ($orders_list_table instanceof WooCommerceOrdersListTable) {
            remove_action('woocommerce_order_list_table_restrict_manage_orders', [$orders_list_table, 'customers_filter']);
        }
    }

    /**
     * Add the coupon search mode to WooCommerce's native HPOS order search UI.
     *
     * @param array $options Existing search filter options.
     * @return array
     */
    public function filterHposSearchFilters(array $options): array
    {
        if (isset($options['coupons'])) {
            return $options;
        }

        $filtered_options = [];

        foreach ($options as $key => $label) {
            if ($key === 'all') {
                $filtered_options['coupons'] = esc_html__('Coupons', 'arraysubspro');
            }

            $filtered_options[$key] = $label;
        }

        if (!isset($filtered_options['coupons'])) {
            $filtered_options['coupons'] = esc_html__('Coupons', 'arraysubspro');
        }

        return $filtered_options;
    }

    /**
     * Generate the HPOS coupon search WHERE clause using WooCommerce's native hook.
     *
     * @param string           $where         Existing WHERE clause.
     * @param string           $search_term   The sanitized search term.
     * @param string           $search_filter The active search filter slug.
     * @param OrdersTableQuery $query         The HPOS orders table query instance.
     * @return string
     */
    public function generateHposWhereForSearchFilter(
        string $where,
        string $search_term,
        string $search_filter,
        OrdersTableQuery $query
    ): string {
        if ($search_filter !== 'coupons' || $search_term === '') {
            return $where;
        }

        global $wpdb;

        $orders_table = $query->get_table_name('orders');
        $items_table = $query->get_table_name('items');

        // phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table names come from WooCommerce's query object and the search term is prepared.
        return $wpdb->prepare(
            "`$orders_table`.id IN (
                SELECT search_query_items.order_id
                FROM $items_table AS search_query_items
                WHERE search_query_items.order_item_type = %s
                AND search_query_items.order_item_name LIKE %s
            )",
            'coupon',
            '%' . $wpdb->esc_like($search_term) . '%'
        );
        // phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared
    }

    /**
     * Render the Type filter dropdown.
     *
     * @return void
     */
    private function renderTypeFilterDropdown(): void
    {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $current = isset($_GET['arraysubs_type']) ? sanitize_text_field(wp_unslash($_GET['arraysubs_type'])) : '';

        echo '<select name="arraysubs_type" id="arraysubspro-filter-type">';
        printf(
            '<option value="">%s</option>',
            esc_html__('All Types', 'arraysubspro')
        );

        foreach (TypeResolver::ALL_TYPES as $type) {
            printf(
                '<option value="%s" %s>%s</option>',
                esc_attr($type),
                selected($current, $type, false),
                esc_html(TypeResolver::getLabel($type))
            );
        }

        echo '</select>';
    }

    /**
     * Render the Coupon filter dropdown.
     *
     * Populates options from distinct coupon codes in the woocommerce_order_items table.
     *
     * @return void
     */
    private function renderCouponFilterDropdown(): void
    {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $current = isset($_GET['arraysubs_coupon']) ? sanitize_text_field(wp_unslash($_GET['arraysubs_coupon'])) : '';
        $coupons = $this->getAvailableCouponCodes();

        echo '<select name="arraysubs_coupon" id="arraysubspro-filter-coupon">';
        printf(
            '<option value="">%s</option>',
            esc_html__('All Coupons', 'arraysubspro')
        );

        foreach ($coupons as $coupon_code) {
            printf(
                '<option value="%s" %s>%s</option>',
                esc_attr($coupon_code),
                selected($current, $coupon_code, false),
                esc_html($coupon_code)
            );
        }

        echo '</select>';
    }

    /**
     * Render the Subscription Products Only filter dropdown.
     *
     * @return void
     */
    private function renderSubsOnlyFilterDropdown(): void
    {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $current = isset($_GET['arraysubs_subs_only']) ? sanitize_text_field(wp_unslash($_GET['arraysubs_subs_only'])) : '';

        echo '<select name="arraysubs_subs_only" id="arraysubspro-filter-subs-only">';
        printf(
            '<option value="">%s</option>',
            esc_html__('All Orders', 'arraysubspro')
        );
        printf(
            '<option value="yes" %s>%s</option>',
            selected($current, 'yes', false),
            esc_html__('Subscription Products Only', 'arraysubspro')
        );

        echo '</select>';
    }

    /**
     * Get list of available coupon codes from the order items table.
     *
     * Results are cached per request via wp_cache to avoid duplicate queries.
     *
     * @return array Array of coupon code strings.
     */
    private function getAvailableCouponCodes(): array
    {
        if ($this->couponCodesCache !== null) {
            return $this->couponCodesCache;
        }

        $cache_key = 'arraysubs_order_coupon_codes';
        $cached = wp_cache_get($cache_key, 'arraysubspro');

        if (false !== $cached) {
            $this->couponCodesCache = $cached;
            return $cached;
        }

        global $wpdb;

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $coupons = $wpdb->get_col(
            $wpdb->prepare(
                "SELECT DISTINCT order_item_name
                 FROM {$wpdb->prefix}woocommerce_order_items
                 WHERE order_item_type = %s
                 ORDER BY order_item_name ASC",
                'coupon'
            )
        );

        $this->couponCodesCache = is_array($coupons) ? $coupons : [];

        wp_cache_set($cache_key, $this->couponCodesCache, 'arraysubspro', HOUR_IN_SECONDS);

        return $this->couponCodesCache;
    }

    // ─── Query Modification ──────────────────────────────────────────────

    /**
     * Filter orders query in HPOS mode.
     *
     * Adds meta_query conditions for Type, Subscription products, and
     * custom WHERE clause for coupon filter.
     *
     * @param array $args The query args for order list table.
     * @return array Modified query args.
     */
    public function filterQueryHpos(array $args): array
    {
        // phpcs:disable WordPress.Security.NonceVerification.Recommended
        $type = isset($_GET['arraysubs_type'])
            ? sanitize_text_field(wp_unslash($_GET['arraysubs_type']))
            : '';

        $coupon = isset($_GET['arraysubs_coupon'])
            ? sanitize_text_field(wp_unslash($_GET['arraysubs_coupon']))
            : '';

        $subs_only = isset($_GET['arraysubs_subs_only'])
            ? sanitize_text_field(wp_unslash($_GET['arraysubs_subs_only']))
            : '';
        // phpcs:enable WordPress.Security.NonceVerification.Recommended

        if (!isset($args['meta_query'])) {
            $args['meta_query'] = [];
        }

        // Type filter using computed meta
        if (!empty($type) && in_array($type, TypeResolver::ALL_TYPES, true)) {
            $args['meta_query'][] = [
                'key'   => '_arraysubs_computed_type',
                'value' => $type,
            ];
        }

        // Subscription products only filter
        if ($subs_only === 'yes') {
            $args['meta_query'][] = [
                'key'   => '_arraysubs_has_subscription_product',
                'value' => 'yes',
            ];
        }

        // Coupon filter — add SQL clause for HPOS order query (guarded + one-shot)
        if (!empty($coupon) && !$this->hposCouponFilterApplied) {
            $this->hposCouponFilterApplied = true;

            // Self-removing closure: fires once then detaches to prevent clause
            // leaking into any subsequent OrdersTableQuery in the same request.
            $callback = function ($clauses) use ($coupon, &$callback) {
                remove_filter('woocommerce_orders_table_query_clauses', $callback);
                return $this->addCouponClause($clauses, $coupon);
            };

            add_filter('woocommerce_orders_table_query_clauses', $callback);
        }

        return $args;
    }

    /**
     * Add WHERE/JOIN clause for coupon filtering in HPOS mode.
     *
     * @param array  $clauses SQL clauses.
     * @param string $coupon  Coupon code to filter by.
     * @return array Modified clauses.
     */
    private function addCouponClause(array $clauses, string $coupon): array
    {
        global $wpdb;

        $coupon_join = $wpdb->prepare(
            " INNER JOIN {$wpdb->prefix}woocommerce_order_items AS arraysubs_ci
              ON {$wpdb->prefix}wc_orders.id = arraysubs_ci.order_id
              AND arraysubs_ci.order_item_type = 'coupon'
              AND arraysubs_ci.order_item_name = %s",
            $coupon
        );

        if (!empty($clauses['join'])) {
            $clauses['join'] .= $coupon_join;
        } else {
            $clauses['join'] = $coupon_join;
        }

        return $clauses;
    }

    /**
     * Filter orders query in legacy (post-type) mode.
     *
     * Only modifies the main query on the shop_order edit screen.
     *
     * @param \WP_Query $query The WordPress query.
     * @return void
     */
    public function filterQueryLegacy(\WP_Query $query): void
    {
        if (!is_admin() || !$query->is_main_query()) {
            return;
        }

        $screen = get_current_screen();
        if (!$screen || $screen->id !== 'edit-shop_order') {
            return;
        }

        // phpcs:disable WordPress.Security.NonceVerification.Recommended
        $type = isset($_GET['arraysubs_type'])
            ? sanitize_text_field(wp_unslash($_GET['arraysubs_type']))
            : '';

        $coupon = isset($_GET['arraysubs_coupon'])
            ? sanitize_text_field(wp_unslash($_GET['arraysubs_coupon']))
            : '';

        $subs_only = isset($_GET['arraysubs_subs_only'])
            ? sanitize_text_field(wp_unslash($_GET['arraysubs_subs_only']))
            : '';
        // phpcs:enable WordPress.Security.NonceVerification.Recommended

        $meta_query = $query->get('meta_query') ?: [];

        // Type filter
        if (!empty($type) && in_array($type, TypeResolver::ALL_TYPES, true)) {
            $meta_query[] = [
                'key'   => '_arraysubs_computed_type',
                'value' => $type,
            ];
        }

        // Subscription products only filter
        if ($subs_only === 'yes') {
            $meta_query[] = [
                'key'   => '_arraysubs_has_subscription_product',
                'value' => 'yes',
            ];
        }

        if (!empty($meta_query)) {
            $query->set('meta_query', $meta_query);
        }

        // Coupon filter — join order_items table (guarded against double-registration)
        if (!empty($coupon) && !$this->legacyCouponFiltersApplied) {
            $this->legacyCouponFiltersApplied = true;

            add_filter('posts_join', function ($join, $wp_query) use ($coupon, $query) {
                if ($wp_query !== $query) {
                    return $join;
                }
                return $this->addLegacyCouponJoin($join, $coupon);
            }, 10, 2);

            add_filter('posts_groupby', function ($groupby, $wp_query) use ($query) {
                if ($wp_query !== $query) {
                    return $groupby;
                }
                global $wpdb;
                if (empty($groupby)) {
                    return "{$wpdb->posts}.ID";
                }
                return $groupby;
            }, 10, 2);
        }
    }

    /**
     * Add JOIN clause for coupon filtering in legacy mode.
     *
     * @param string $join   The SQL JOIN clause.
     * @param string $coupon The coupon code.
     * @return string Modified JOIN clause.
     */
    private function addLegacyCouponJoin(string $join, string $coupon): string
    {
        global $wpdb;

        $join .= $wpdb->prepare(
            " INNER JOIN {$wpdb->prefix}woocommerce_order_items AS arraysubs_ci
              ON {$wpdb->posts}.ID = arraysubs_ci.order_id
              AND arraysubs_ci.order_item_type = 'coupon'
              AND arraysubs_ci.order_item_name = %s",
            $coupon
        );

        return $join;
    }



    // ─── Report Panel ────────────────────────────────────────────────────

    /**
     * Render the embedded report panel (HPOS mode).
     *
     * Hooks into woocommerce_order_list_table_extra_tablenav to render
     * above the order list.
     *
     * @param string $order_type The order type being displayed.
     * @param string $which      Position: 'top' or 'bottom'.
     * @return void
     */
    public function renderReportPanel(string $order_type = '', string $which = 'top'): void
    {
        if ($order_type !== 'shop_order') {
            return;
        }

        if ($which !== 'top') {
            return;
        }

        if (!$this->isOrdersScreen()) {
            return;
        }

        $this->outputReportPanel();
    }

    /**
     * Render the embedded report panel (legacy mode).
     *
     * @param string $which Position: 'top' or 'bottom'.
     * @return void
     */
    public function renderReportPanelLegacy(string $which = 'top'): void
    {
        if ($which !== 'top') {
            return;
        }

        if (!$this->isOrdersScreen()) {
            return;
        }

        $this->outputReportPanel();
    }

    /**
     * Output the report panel HTML.
     *
     * Queries order counts by type and coupon usage in a single aggregation query.
     * Respects active WooCommerce filters (order_status, date range).
     *
     * @return void
     */
    private function outputReportPanel(): void
    {
        $counts = $this->getReportCounts();

        $arraysubs_total_orders = $counts['total'];
        $arraysubs_type_counts = $counts['by_type'];
        $arraysubs_coupon_orders = $counts['with_coupon'];

        $arraysubs_view_path = dirname(__DIR__) . '/views/order-list-report.php';

        if (file_exists($arraysubs_view_path)) {
            include $arraysubs_view_path;
        }
    }

    /**
     * Get report counts respecting active filters.
     *
     * Performs a single optimized query that groups by _arraysubs_computed_type.
     * Also counts orders with at least one coupon item.
     *
     * @return array{total: int, by_type: array<string, int>, with_coupon: int}
     */
    private function getReportCounts(): array
    {
        global $wpdb;

        // Determine which order statuses to include
        $statuses = $this->getReportStatuses();
        $status_placeholders = implode(', ', array_fill(0, count($statuses), '%s'));

        // Get active filter values
        // phpcs:disable WordPress.Security.NonceVerification.Recommended
        $filter_type = isset($_GET['arraysubs_type'])
            ? sanitize_text_field(wp_unslash($_GET['arraysubs_type']))
            : '';

        $filter_subs_only = isset($_GET['arraysubs_subs_only'])
            ? sanitize_text_field(wp_unslash($_GET['arraysubs_subs_only']))
            : '';

        $filter_coupon = isset($_GET['arraysubs_coupon'])
            ? sanitize_text_field(wp_unslash($_GET['arraysubs_coupon']))
            : '';
        // phpcs:enable WordPress.Security.NonceVerification.Recommended

        // Build WHERE conditions
        $where_parts = [];
        $prepare_args = [];

        // Status filter
        if ($this->isHpos) {
            $where_parts[] = "o.status IN ($status_placeholders)";
        } else {
            $where_parts[] = "o.post_status IN ($status_placeholders)";
        }
        $prepare_args = array_merge($prepare_args, $statuses);

        // Date/month filter (respects WC month dropdown)
        $date_constraints = $this->getReportDateConstraints();
        if (!empty($date_constraints['where'])) {
            $where_parts[] = $date_constraints['where'];
            $prepare_args = array_merge($prepare_args, $date_constraints['args']);
        }

        // Build the base query depending on HPOS
        if ($this->isHpos) {
            $orders_table = "{$wpdb->prefix}wc_orders";
            $orders_id_col = 'o.id';
            $orders_type_clause = "AND o.type = 'shop_order'";
        } else {
            $orders_table = $wpdb->posts;
            $orders_id_col = 'o.ID';
            $orders_type_clause = "AND o.post_type = 'shop_order'";
        }

        // Type filter
        $type_join = '';
        if (!empty($filter_type) && in_array($filter_type, TypeResolver::ALL_TYPES, true)) {
            $type_join = "INNER JOIN {$wpdb->prefix}wc_orders_meta AS type_filter_meta
                          ON {$orders_id_col} = type_filter_meta.order_id
                          AND type_filter_meta.meta_key = '_arraysubs_computed_type'
                          AND type_filter_meta.meta_value = %s";
            $prepare_args[] = $filter_type;
        }

        // For legacy mode, use postmeta instead of wc_orders_meta
        if (!$this->isHpos && !empty($type_join)) {
            $type_join = "INNER JOIN {$wpdb->postmeta} AS type_filter_meta
                          ON {$orders_id_col} = type_filter_meta.post_id
                          AND type_filter_meta.meta_key = '_arraysubs_computed_type'
                          AND type_filter_meta.meta_value = %s";
        }

        // Subscription products only filter
        $subs_join = '';
        if ($filter_subs_only === 'yes') {
            if ($this->isHpos) {
                $subs_join = "INNER JOIN {$wpdb->prefix}wc_orders_meta AS subs_filter_meta
                              ON {$orders_id_col} = subs_filter_meta.order_id
                              AND subs_filter_meta.meta_key = '_arraysubs_has_subscription_product'
                              AND subs_filter_meta.meta_value = 'yes'";
            } else {
                $subs_join = "INNER JOIN {$wpdb->postmeta} AS subs_filter_meta
                              ON {$orders_id_col} = subs_filter_meta.post_id
                              AND subs_filter_meta.meta_key = '_arraysubs_has_subscription_product'
                              AND subs_filter_meta.meta_value = 'yes'";
            }
        }

        // Coupon filter
        $coupon_filter_join = '';
        if (!empty($filter_coupon)) {
            if ($this->isHpos) {
                $coupon_filter_join = $wpdb->prepare(
                    "INNER JOIN {$wpdb->prefix}woocommerce_order_items AS coupon_filter_oi
                     ON o.id = coupon_filter_oi.order_id
                     AND coupon_filter_oi.order_item_type = 'coupon'
                     AND coupon_filter_oi.order_item_name = %s",
                    $filter_coupon
                );
            } else {
                $coupon_filter_join = $wpdb->prepare(
                    "INNER JOIN {$wpdb->prefix}woocommerce_order_items AS coupon_filter_oi
                     ON o.ID = coupon_filter_oi.order_id
                     AND coupon_filter_oi.order_item_type = 'coupon'
                     AND coupon_filter_oi.order_item_name = %s",
                    $filter_coupon
                );
            }
            // Remove from prepare_args since it's already prepared
        }

        // Computed type meta join for grouping
        if ($this->isHpos) {
            $type_meta_join = "LEFT JOIN {$wpdb->prefix}wc_orders_meta AS ct_meta
                               ON {$orders_id_col} = ct_meta.order_id
                               AND ct_meta.meta_key = '_arraysubs_computed_type'";
        } else {
            $type_meta_join = "LEFT JOIN {$wpdb->postmeta} AS ct_meta
                               ON {$orders_id_col} = ct_meta.post_id
                               AND ct_meta.meta_key = '_arraysubs_computed_type'";
        }

        // Coupon item subquery for counting coupon orders
        $coupon_count_subquery = "LEFT JOIN (
            SELECT DISTINCT order_id
            FROM {$wpdb->prefix}woocommerce_order_items
            WHERE order_item_type = 'coupon'
        ) AS has_coupon ON {$orders_id_col} = has_coupon.order_id";

        $where_clause = implode(' AND ', $where_parts);

        $summary_sql = "SELECT
                COALESCE(ct_meta.meta_value, 'Other') AS order_type,
                COUNT(DISTINCT {$orders_id_col}) AS order_count,
                COUNT(DISTINCT has_coupon.order_id) AS coupon_count
             FROM {$orders_table} AS o
             {$type_meta_join}
             {$coupon_count_subquery}
             {$type_join}
             {$subs_join}
             {$coupon_filter_join}
             WHERE {$where_clause}
             {$orders_type_clause}
             GROUP BY order_type";

        // phpcs:ignore WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $sql = $wpdb->prepare($summary_sql, ...$prepare_args);

        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter -- $sql is the output of $wpdb->prepare(); dynamic fragments are WordPress table names ($wpdb->prefix, $wpdb->posts) and hardcoded column/join strings, none from user input. SQL does not support parameterised table/column names.
        $results = $wpdb->get_results($sql);

        // Build the counts
        $total = 0;
        $coupon_total = 0;
        $by_type = [];

        // Initialize all type counts to 0
        foreach (TypeResolver::ALL_TYPES as $type) {
            $by_type[$type] = 0;
        }

        if (!empty($results)) {
            foreach ($results as $row) {
                $type_val = $row->order_type;
                $count = absint($row->order_count);
                $total += $count;
                $coupon_total += absint($row->coupon_count);

                if (isset($by_type[$type_val])) {
                    $by_type[$type_val] = $count;
                } else {
                    // Unrecognized type — add to Other
                    $by_type[TypeResolver::TYPE_OTHER] += $count;
                }
            }
        }

        return [
            'total'       => $total,
            'by_type'     => $by_type,
            'with_coupon' => $coupon_total,
        ];
    }

    /**
     * Get order statuses to include in report.
     *
     * Respects the WooCommerce status filter if active.
     * HPOS uses `status` param, legacy uses `post_status`.
     *
     * @return array Array of status slugs (with wc- prefix).
     */
    private function getReportStatuses(): array
    {
        // phpcs:disable WordPress.Security.NonceVerification.Recommended
        // HPOS uses 'status', legacy uses 'post_status'
        $status_filter = '';
        if ($this->isHpos && isset($_GET['status'])) {
            $status_filter = sanitize_text_field(wp_unslash($_GET['status']));
        } elseif (!$this->isHpos && isset($_GET['post_status'])) {
            $status_filter = sanitize_text_field(wp_unslash($_GET['post_status']));
        } elseif (isset($_GET['status'])) {
            // Fallback: check 'status' for either mode
            $status_filter = sanitize_text_field(wp_unslash($_GET['status']));
        }
        // phpcs:enable WordPress.Security.NonceVerification.Recommended

        if (!empty($status_filter) && $status_filter !== 'all') {
            // Ensure wc- prefix for consistency
            if (strpos($status_filter, 'wc-') !== 0) {
                $status_filter = 'wc-' . $status_filter;
            }
            return [$status_filter];
        }

        // Default WooCommerce visible statuses
        $statuses = array_keys(wc_get_order_statuses());

        // Remove trash/draft statuses
        $statuses = array_filter($statuses, function ($status) {
            return !in_array($status, ['trash', 'draft', 'auto-draft'], true);
        });

        return array_values($statuses);
    }

    /**
     * Get date constraints for the report query.
     *
     * Reads the month filter (`m` param) used by WooCommerce order list table.
     *
     * @return array{where: string, args: array} SQL WHERE fragment and prepare args.
     */
    private function getReportDateConstraints(): array
    {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $month_filter = isset($_GET['m']) ? absint($_GET['m']) : 0;

        if ($month_filter <= 0) {
            return ['where' => '', 'args' => []];
        }

        // 'm' param is YYYYMM format (e.g. 202602)
        $year = (int) substr((string) $month_filter, 0, 4);
        $month = (int) substr((string) $month_filter, 4, 2);

        if ($year < 2000 || $month < 1 || $month > 12) {
            return ['where' => '', 'args' => []];
        }

        // HPOS: date_created_gmt matches WC OrdersTableQuery date handling.
        // Legacy: post_date (local time) matches WP_Query 'm' param semantics.
        $date_col = $this->isHpos ? 'o.date_created_gmt' : 'o.post_date';

        $start = sprintf('%04d-%02d-01 00:00:00', $year, $month);
        $end = gmdate('Y-m-t 23:59:59', strtotime($start));

        return [
            'where' => "{$date_col} >= %s AND {$date_col} <= %s",
            'args'  => [$start, $end],
        ];
    }

    // ─── Backfill Mechanism ──────────────────────────────────────────────

    /**
     * Handle backfill POST request.
     *
     * Processes a batch of orders that lack _arraysubs_computed_type meta.
     * Requires manage_woocommerce capability and nonce verification.
     *
     * @return void
     */
    public function handleBackfillRequest(): void
    {
        if (!isset($_POST['arraysubs_backfill_order_types'])) {
            return;
        }

        if (
            !isset($_POST['_wpnonce'])
            || !wp_verify_nonce(
                sanitize_text_field(wp_unslash($_POST['_wpnonce'])),
                'arraysubs_backfill_order_types'
            )
        ) {
            wp_die(esc_html__('Security check failed', 'arraysubspro'));
        }

        if (!current_user_can('manage_woocommerce') && !current_user_can('manage_options')) {
            wp_die(esc_html__('Permission denied', 'arraysubspro'));
        }

        $processed = Hooks::backfillOrderTypes(200, 0);
        $remaining = $this->getUnprocessedOrderCount();

        $redirect_args = [];

        if ($processed > 0 && $remaining > 0) {
            $redirect_args['arraysubs_backfilled'] = $processed;
            $redirect_args['arraysubs_remaining'] = $remaining;
        } elseif ($processed > 0 && $remaining === 0) {
            $redirect_args['arraysubs_backfill_done'] = $processed;
        } else {
            $redirect_args['arraysubs_backfill_done'] = 0;
        }

        $referer = wp_get_referer();
        $redirect_url = $referer ? $referer : admin_url('admin.php?page=wc-orders');

        // Remove any previous backfill params from referer
        $redirect_url = remove_query_arg(
            ['arraysubs_backfilled', 'arraysubs_remaining', 'arraysubs_backfill_done'],
            $redirect_url
        );

        wp_safe_redirect(add_query_arg($redirect_args, $redirect_url));
        exit;
    }

    /**
     * Render backfill admin notice on the WooCommerce Orders page.
     *
     * Shows a notice with a button when orders need type classification.
     * Displays progress or completion messages after backfill runs.
     *
     * @return void
     */
    public function renderBackfillNotice(): void
    {
        if (!$this->isOrdersScreen()) {
            return;
        }

        if (!current_user_can('manage_woocommerce') && !current_user_can('manage_options')) {
            return;
        }

        // Show completion message
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        if (isset($_GET['arraysubs_backfill_done'])) {
            // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            $done_count = absint($_GET['arraysubs_backfill_done']);
            echo '<div class="notice notice-success is-dismissible"><p>';
            if ($done_count > 0) {
                printf(
                    /* translators: %d: number of orders processed */
                    esc_html__('Successfully computed types for %d orders. All orders are now classified.', 'arraysubspro'),
                    absint($done_count)
                );
            } else {
                esc_html_e('All order types have been computed successfully.', 'arraysubspro');
            }
            echo '</p></div>';
            return;
        }

        // Show batch progress message
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        if (isset($_GET['arraysubs_backfilled'])) {
            // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            $batch_count = absint($_GET['arraysubs_backfilled']);
            // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            $remaining = isset($_GET['arraysubs_remaining']) ? absint($_GET['arraysubs_remaining']) : 0;

            echo '<div class="notice notice-info is-dismissible"><p>';
            printf(
                /* translators: 1: number of orders processed, 2: remaining count */
                esc_html__('Processed %1$d orders. %2$d orders remaining.', 'arraysubspro'),
                absint($batch_count),
                absint($remaining)
            );
            echo '</p></div>';
        }

        // Check if backfill is needed
        $unprocessed = $this->getUnprocessedOrderCount();
        if ($unprocessed <= 0) {
            return;
        }

        echo '<div class="notice notice-warning"><p>';
        printf(
            /* translators: %d: number of orders */
            esc_html__('%d orders need type classification for analytics. ', 'arraysubspro'),
            absint($unprocessed)
        );
        echo '<form method="post" class="arraysubspro-backfill-form">';
        wp_nonce_field('arraysubs_backfill_order_types');
        echo '<input type="hidden" name="arraysubs_backfill_order_types" value="1" />';
        printf(
            '<button type="submit" class="button button-primary">%s</button>',
            esc_html__('Compute Order Types', 'arraysubspro')
        );
        echo '</form></p></div>';
    }

    /**
     * Get the count of orders that lack _arraysubs_computed_type meta.
     *
     * @return int Number of unprocessed orders.
     */
    private function getUnprocessedOrderCount(): int
    {
        global $wpdb;

        if ($this->isHpos) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $count = $wpdb->get_var(
                "SELECT COUNT(o.id) FROM {$wpdb->prefix}wc_orders AS o
                 LEFT JOIN {$wpdb->prefix}wc_orders_meta AS ct
                     ON o.id = ct.order_id AND ct.meta_key = '_arraysubs_computed_type'
                 WHERE o.type = 'shop_order'
                 AND o.status NOT IN ('trash', 'auto-draft')
                 AND ct.order_id IS NULL"
            );
        } else {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $count = $wpdb->get_var(
                "SELECT COUNT(p.ID) FROM {$wpdb->posts} AS p
                 LEFT JOIN {$wpdb->postmeta} AS ct
                     ON p.ID = ct.post_id AND ct.meta_key = '_arraysubs_computed_type'
                 WHERE p.post_type = 'shop_order'
                 AND p.post_status NOT IN ('trash', 'auto-draft')
                 AND ct.post_id IS NULL"
            );
        }

        return absint($count);
    }

    // ─── Asset Enqueueing ────────────────────────────────────────────────

    /**
     * Enqueue admin styles on the WooCommerce Orders page.
     *
     * @param string $hook The current admin page hook.
     * @return void
     */
    public function enqueueAssets(string $hook): void
    {
        if (!$this->isOrdersScreen()) {
            return;
        }

        $asset_file = Config::get('proplugin.public_path') . 'build/admin/analytics-order-list.asset.php';
        $asset = file_exists($asset_file)
            ? require $asset_file
            : ['dependencies' => [], 'version' => ARRAYSUBSPRO_VERSION];

        wp_enqueue_style(
            'arraysubspro-analytics-order-list',
            Config::get('proplugin.public_url') . 'build/admin/analytics-order-list.css',
            [],
            $asset['version']
        );
    }
}
