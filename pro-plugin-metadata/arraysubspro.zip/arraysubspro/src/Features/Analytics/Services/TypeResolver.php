<?php

/**
 * Type Resolver Service
 *
 * Classifies WooCommerce orders into subscription-related types
 * using a priority-based rule chain.
 *
 * @package ArraySubsPro\Features\Analytics\Services
 */

namespace ArraySubsPro\Features\Analytics\Services;

defined('ABSPATH') || exit;

/**
 * Resolves the subscription type of a WooCommerce order.
 *
 * Priority order (first match wins):
 * 1. Credit Purchase — order has credit product line item
 * 2. Subs Trial — initial order with trial subscription
 * 3. Subs Renew — renewal order
 * 4. Subs Upgrade — plan switch order
 * 5. Subs Purchase — initial subscription purchase
 * 6. Other — regular WooCommerce order
 */
class TypeResolver
{
    /**
     * Type constants
     */
    const TYPE_CREDIT_PURCHASE = 'Credit Purchase';
    const TYPE_SUBS_TRIAL      = 'Subs Trial';
    const TYPE_SUBS_RENEW      = 'Subs Renew';
    const TYPE_SUBS_UPGRADE    = 'Subs Upgrade';
    const TYPE_SUBS_PURCHASE   = 'Subs Purchase';
    const TYPE_OTHER           = 'Other';

    /**
     * All defined type values.
     *
     * @var array
     */
    const ALL_TYPES = [
        self::TYPE_CREDIT_PURCHASE,
        self::TYPE_SUBS_TRIAL,
        self::TYPE_SUBS_RENEW,
        self::TYPE_SUBS_UPGRADE,
        self::TYPE_SUBS_PURCHASE,
        self::TYPE_OTHER,
    ];

    /**
     * Resolve the type of a WooCommerce order.
     *
     * Uses priority-based rule chain — first match wins.
     *
     * @param \WC_Order $order The WooCommerce order object.
     * @return string One of the TYPE_* constants.
     */
    public static function resolve(\WC_Order $order): string
    {
        // 1. Credit purchase — has at least one credit product line item
        if (self::isCreditPurchase($order)) {
            return self::TYPE_CREDIT_PURCHASE;
        }

        // 2. Subs Trial — initial subscription order where the subscription has a trial
        if (self::isSubsTrial($order)) {
            return self::TYPE_SUBS_TRIAL;
        }

        // 3. Subs Renew — renewal order
        if (self::isSubsRenew($order)) {
            return self::TYPE_SUBS_RENEW;
        }

        // 4. Subs Upgrade — plan switch / upgrade order
        if (self::isSubsUpgrade($order)) {
            return self::TYPE_SUBS_UPGRADE;
        }

        // 5. Subs Purchase — initial subscription purchase (non-trial)
        if (self::isSubsPurchase($order)) {
            return self::TYPE_SUBS_PURCHASE;
        }

        // 6. Other — regular store order
        return self::TYPE_OTHER;
    }

    /**
     * Check if order contains at least one credit product line item.
     *
     * @param \WC_Order $order The order.
     * @return bool
     */
    private static function isCreditPurchase(\WC_Order $order): bool
    {
        foreach ($order->get_items() as $item) {
            // Check line item meta
            if (self::isYes($item->get_meta('_arraysubs_is_credit_product'))) {
                return true;
            }

            // Check product/variation meta via product objects.
            $variation_id = (int) $item->get_variation_id();
            $product_id = $item->get_product_id();
            $candidate_product_ids = array_filter([$variation_id, $product_id]);

            foreach ($candidate_product_ids as $candidate_product_id) {
                $candidate_product = wc_get_product($candidate_product_id);

                if ($candidate_product && self::isYes($candidate_product->get_meta('_arraysubs_credit_product'))) {
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * Check if order is an initial subscription purchase with a trial.
     *
     * Must have _subscription_ids meta (initial purchase only — renewals use
     * _subscription_id singular) AND the linked subscription must have
     * _trial_end_date set.
     *
     * Note: We intentionally do NOT check the subscription's current status.
     * The _trial_end_date meta is immutable once set at subscription creation,
     * so this classification remains stable even after the trial converts to
     * active. Checking runtime status would cause the computed type to drift
     * from "Subs Trial" to "Subs Purchase" when the subscription converts.
     *
     * @param \WC_Order $order The order.
     * @return bool
     */
    private static function isSubsTrial(\WC_Order $order): bool
    {
        $subscription_ids = self::normalizeSubscriptionIds($order->get_meta('_subscription_ids'));

        if (empty($subscription_ids)) {
            return false;
        }

        foreach ($subscription_ids as $subscription_id) {
            $trial_end_date = \get_post_meta($subscription_id, '_trial_end_date', true);

            if (!empty($trial_end_date)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Check if order is a renewal order.
     *
     * @param \WC_Order $order The order.
     * @return bool
     */
    private static function isSubsRenew(\WC_Order $order): bool
    {
        return $order->get_meta('_is_renewal_order') === 'yes';
    }

    /**
     * Check if order is a plan switch / upgrade order.
     *
     * @param \WC_Order $order The order.
     * @return bool
     */
    private static function isSubsUpgrade(\WC_Order $order): bool
    {
        return $order->get_meta('_arraysubs_order_type') === 'plan_switch';
    }

    /**
     * Check if order is an initial subscription purchase (non-trial).
     *
     * @param \WC_Order $order The order.
     * @return bool
     */
    private static function isSubsPurchase(\WC_Order $order): bool
    {
        $subscription_ids = self::normalizeSubscriptionIds($order->get_meta('_subscription_ids'));

        if (!empty($subscription_ids)) {
            return true;
        }

        // Fallback: during early checkout lifecycle, _subscription_ids may not yet
        // be attached to the order. If the order contains subscription products,
        // and it's not a renewal/plan switch, treat it as an initial purchase.
        if (self::isSubsRenew($order) || self::isSubsUpgrade($order)) {
            return false;
        }

        return self::hasSubscriptionProduct($order);
    }

    /**
     * Normalize _subscription_ids meta value to an array of integers.
     *
     * Handles edge cases where the meta value may be a scalar, serialized string,
     * or already an array. Filters out non-positive values.
     *
     * @param mixed $raw The raw meta value.
     * @return array Array of integer subscription IDs.
     */
    private static function normalizeSubscriptionIds($raw): array
    {
        if (is_array($raw)) {
            return array_filter(array_map('absint', $raw));
        }

        if (is_numeric($raw) && (int) $raw > 0) {
            return [(int) $raw];
        }

        if (is_string($raw) && !empty($raw)) {
            $decoded_json = json_decode($raw, true);
            if (is_array($decoded_json)) {
                return array_filter(array_map('absint', $decoded_json));
            }

            $unserialized = maybe_unserialize($raw);
            if (is_array($unserialized)) {
                return array_filter(array_map('absint', $unserialized));
            }

            $csv_parts = array_filter(array_map('trim', explode(',', $raw)));
            if (!empty($csv_parts) && count($csv_parts) > 1) {
                return array_filter(array_map('absint', $csv_parts));
            }
        }

        return [];
    }

    /**
     * Check if a stored meta value represents a truthy "yes" flag.
     *
     * @param mixed $value Meta value.
     * @return bool
     */
    private static function isYes($value): bool
    {
        return in_array((string) $value, ['yes', '1', 'true'], true);
    }

    /**
     * Check if an order contains at least one subscription product.
     *
     * @param \WC_Order $order The order.
     * @return bool
     */
    public static function hasSubscriptionProduct(\WC_Order $order): bool
    {
        if (!function_exists('arraysubs_is_subscription_product')) {
            return false;
        }

        foreach ($order->get_items() as $item) {
            $product_id = $item->get_product_id();
            if ($product_id && arraysubs_is_subscription_product($product_id)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Get a human-readable label for a type.
     *
     * @param string $type The type constant.
     * @return string Translated label.
     */
    public static function getLabel(string $type): string
    {
        $labels = [
            self::TYPE_CREDIT_PURCHASE => __('Credit Purchase', 'arraysubspro'),
            self::TYPE_SUBS_TRIAL      => __('Subs Trial', 'arraysubspro'),
            self::TYPE_SUBS_RENEW      => __('Subs Renew', 'arraysubspro'),
            self::TYPE_SUBS_UPGRADE    => __('Subs Upgrade', 'arraysubspro'),
            self::TYPE_SUBS_PURCHASE   => __('Subs Purchase', 'arraysubspro'),
            self::TYPE_OTHER           => __('Other', 'arraysubspro'),
        ];

        return $labels[$type] ?? $type;
    }
}
