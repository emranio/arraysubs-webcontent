<?php

/**
 * Analytics Hooks Service
 *
 * Computes and stores order type metadata on order creation/update.
 * This enables fast querying by type in both admin order list and WC Analytics.
 *
 * @package ArraySubsPro\Features\Analytics\Services
 */

namespace ArraySubsPro\Features\Analytics\Services;

defined('ABSPATH') || exit;

/**
 * Hooks for computing order analytics metadata.
 */
class Hooks
{
    /**
     * Enable auto-loading.
     *
     * @var bool
     */
    public static $loadable = true;

    public function __construct()
    {
        // Compute type on order create/update
        add_action('woocommerce_new_order', [$this, 'computeOrderMeta'], 20, 1);
        add_action('woocommerce_update_order', [$this, 'computeOrderMeta'], 20, 1);

        // Recompute after checkout flows finalize order meta/item meta.
        add_action('woocommerce_checkout_order_processed', [$this, 'computeOrderMeta'], 30, 1);
        add_action('woocommerce_store_api_checkout_order_processed', [$this, 'computeOrderMeta'], 30, 1);

        // Recompute after payment completion to catch late metadata changes.
        add_action('woocommerce_payment_complete', [$this, 'computeOrderMeta'], 20, 1);
    }

    /**
     * Compute and store order type and subscription product flag as meta.
     *
     * @param int $order_id The order ID.
     * @return void
     */
    public function computeOrderMeta($order_id): void
    {
        $order = wc_get_order($order_id);
        if (!$order || $order->get_type() !== 'shop_order') {
            return;
        }

        // Compute and store the order type
        $type = TypeResolver::resolve($order);
        $existing_type = $order->get_meta('_arraysubs_computed_type');

        if ($existing_type !== $type) {
            $order->update_meta_data('_arraysubs_computed_type', $type);
        }

        // Compute and store subscription product flag
        $has_sub = TypeResolver::hasSubscriptionProduct($order) ? 'yes' : 'no';
        $existing_has_sub = $order->get_meta('_arraysubs_has_subscription_product');

        if ($existing_has_sub !== $has_sub) {
            $order->update_meta_data('_arraysubs_has_subscription_product', $has_sub);
        }

        // Only save if something changed
        if ($existing_type !== $type || $existing_has_sub !== $has_sub) {
            $order->save_meta_data();
        }
    }

    /**
     * Backfill computed meta for existing orders.
     *
     * Processes orders in batches. Returns the number of orders processed.
     *
     * @param int $batch_size Number of orders per batch.
     * @param int $offset     Offset for pagination.
     * @return int Number of orders processed in this batch.
     */
    public static function backfillOrderTypes(int $batch_size = 100, int $offset = 0): int
    {
        $orders = wc_get_orders([
            'limit'      => $batch_size,
            'offset'     => $offset,
            'type'       => 'shop_order',
            'status'     => array_keys(wc_get_order_statuses()),
            'orderby'    => 'ID',
            'order'      => 'ASC',
            'meta_query' => [
                [
                    'key'     => '_arraysubs_computed_type',
                    'compare' => 'NOT EXISTS',
                ],
            ],
        ]);

        if (empty($orders)) {
            return 0;
        }

        $count = 0;
        foreach ($orders as $order) {
            $type = TypeResolver::resolve($order);
            $order->update_meta_data('_arraysubs_computed_type', $type);

            $has_sub = TypeResolver::hasSubscriptionProduct($order) ? 'yes' : 'no';
            $order->update_meta_data('_arraysubs_has_subscription_product', $has_sub);

            $order->save_meta_data();
            ++$count;
        }

        return $count;
    }
}
