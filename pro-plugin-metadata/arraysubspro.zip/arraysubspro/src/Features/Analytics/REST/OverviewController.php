<?php

/**
 * Analytics Overview REST Controller
 *
 * Provides subscription performance cards, chart time-series, and
 * leaderboard data for the WooCommerce Analytics Overview page.
 *
 * @package ArraySubsPro\Features\Analytics\REST
 */

namespace ArraySubsPro\Features\Analytics\REST;

defined('ABSPATH') || exit;

use ArraySubs\Supports\BaseRestController;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;

/**
 * Overview analytics REST controller
 */
class OverviewController extends BaseRestController
{
    /**
     * Manual MRR normalization multiplier for weekly subscriptions.
     */
    private const WEEKLY_MRR_MULTIPLIER = 4.333;

    /**
     * Enable auto-loading
     *
     * @var bool
     */
    public static $loadable = true;

    /**
     * REST namespace
     *
     * @var string
     */
    protected $namespace = 'arraysubs/v1';

    /**
     * Whether HPOS is enabled
     *
     * @var bool
     */
    private bool $is_hpos = false;

    /**
     * Constructor
     */
    public function __construct()
    {
        parent::__construct();

        $this->is_hpos = class_exists('Automattic\WooCommerce\Utilities\OrderUtil')
            && \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled();
    }

    /**
     * Register REST routes
     */
    public function registerRoutes(): void
    {
        register_rest_route($this->namespace, '/analytics/overview/performance', [
            [
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => [$this, 'getPerformance'],
                'permission_callback' => [$this, 'checkAdminPermission'],
                'args'                => $this->getDateArgs(),
            ],
        ]);

        register_rest_route($this->namespace, '/analytics/overview/charts', [
            [
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => [$this, 'getCharts'],
                'permission_callback' => [$this, 'checkAdminPermission'],
                'args'                => array_merge(
                    $this->getDateArgs(),
                    [
                        'interval' => [
                            'type'              => 'string',
                            'default'           => 'day',
                            'enum'              => ['day', 'week', 'month', 'quarter', 'year'],
                            'sanitize_callback' => 'sanitize_text_field',
                        ],
                        'chart'    => [
                            'type'              => 'string',
                            'required'          => true,
                            'enum'              => [
                                'mrr',
                                'net_growth',
                                'churn_rate',
                                'trial_conversions',
                                'active_count',
                                'renewal_revenue',
                            ],
                            'sanitize_callback' => 'sanitize_text_field',
                        ],
                    ]
                ),
            ],
        ]);
    }

    /**
     * Check admin permission
     *
     * @return bool
     */
    public function checkAdminPermission(): bool
    {
        if (! is_user_logged_in()) {
            return false;
        }

        return current_user_can('manage_woocommerce') || current_user_can('manage_options');
    }

    /**
     * Get performance card data
     *
     * @param WP_REST_Request $request Request object.
     * @return WP_REST_Response
     */
    public function getPerformance(WP_REST_Request $request): WP_REST_Response
    {
        $after  = sanitize_text_field($request->get_param('after'));
        $before = sanitize_text_field($request->get_param('before'));

        $cache_key = 'arraysubs_overview_perf_' . md5($after . $before);
        $cached    = get_transient($cache_key);

        if (false !== $cached) {
            return new WP_REST_Response($cached, 200);
        }

        $period_length = $this->getPeriodLengthInSeconds($after, $before);
        $prev_before   = gmdate('Y-m-d\TH:i:s', strtotime($after));
        $prev_after    = gmdate('Y-m-d\TH:i:s', strtotime($after) - $period_length);

        $currency = get_woocommerce_currency();

        $data = [
            'active_subscriptions'  => [
                'value'      => $this->getActiveCount($before),
                'prev_value' => $this->getActiveCount($prev_before),
            ],
            'mrr'                   => [
                'value'      => $this->computeMrr($before),
                'prev_value' => $this->computeMrr($prev_before),
                'currency'   => $currency,
            ],
            'new_subscriptions'     => [
                'value'      => $this->getNewSubscriptionCount($after, $before),
                'prev_value' => $this->getNewSubscriptionCount($prev_after, $prev_before),
            ],
            'churned_subscriptions' => [
                'value'      => $this->getChurnedCount($after, $before),
                'prev_value' => $this->getChurnedCount($prev_after, $prev_before),
            ],
            'churn_rate'            => $this->computeChurnRate($after, $before, $prev_after, $prev_before),
            'trial_conversion_rate' => $this->computeTrialConversionRate($after, $before, $prev_after, $prev_before),
            'renewal_revenue'       => [
                'value'      => $this->getRenewalRevenue($after, $before),
                'prev_value' => $this->getRenewalRevenue($prev_after, $prev_before),
                'currency'   => $currency,
            ],
            'revenue_at_risk'       => [
                'value'      => $this->computeRevenueAtRisk(),
                'prev_value' => 0,
                'currency'   => $currency,
            ],
            'arpu'                  => $this->computeArpu($before, $prev_before, $currency),
            'retention_saves'       => $this->getRetentionSaves($after, $before, $prev_after, $prev_before),
        ];

        set_transient($cache_key, $data, HOUR_IN_SECONDS);

        return new WP_REST_Response($data, 200);
    }

    /**
     * Get chart time-series data
     *
     * @param WP_REST_Request $request Request object.
     * @return WP_REST_Response
     */
    public function getCharts(WP_REST_Request $request): WP_REST_Response
    {
        $after    = sanitize_text_field($request->get_param('after'));
        $before   = sanitize_text_field($request->get_param('before'));
        $interval = sanitize_text_field($request->get_param('interval'));
        $chart    = sanitize_text_field($request->get_param('chart'));

        $cache_key = 'arraysubs_overview_chart_' . md5($after . $before . $interval . $chart);
        $cached    = get_transient($cache_key);

        if (false !== $cached) {
            return new WP_REST_Response($cached, 200);
        }

        $boundaries = $this->getIntervalBoundaries($after, $before, $interval);

        $method_map = [
            'mrr'               => 'chartMrr',
            'net_growth'        => 'chartNetGrowth',
            'churn_rate'        => 'chartChurnRate',
            'trial_conversions' => 'chartTrialConversions',
            'active_count'      => 'chartActiveCount',
            'renewal_revenue'   => 'chartRenewalRevenue',
        ];

        $method = $method_map[$chart] ?? '';

        if (! $method || ! method_exists($this, $method)) {
            return new WP_REST_Response(['message' => __('Invalid chart type.', 'arraysubspro')], 400);
        }

        $intervals_data = $this->$method($boundaries);

        $current_total  = ! empty($intervals_data) ? end($intervals_data)['value'] : 0;
        $period_length  = $this->getPeriodLengthInSeconds($after, $before);
        $prev_before    = gmdate('Y-m-d\TH:i:s', strtotime($after));
        $prev_after     = gmdate('Y-m-d\TH:i:s', strtotime($after) - $period_length);
        $prev_boundaries = $this->getIntervalBoundaries($prev_after, $prev_before, $interval);
        $prev_data      = $this->$method($prev_boundaries);
        $previous_total = ! empty($prev_data) ? end($prev_data)['value'] : 0;

        $delta = 0;
        if ($previous_total > 0) {
            $delta = round((($current_total - $previous_total) / $previous_total) * 100, 2);
        }

        $data = [
            'intervals' => $intervals_data,
            'totals'    => [
                'current'  => $current_total,
                'previous' => $previous_total,
                'delta'    => $delta,
            ],
        ];

        set_transient($cache_key, $data, HOUR_IN_SECONDS);

        return new WP_REST_Response($data, 200);
    }

    /**
     * Get common date argument schema
     *
     * @return array
     */
    private function getDateArgs(): array
    {
        return [
            'after'  => [
                'type'              => 'string',
                'required'          => true,
                'sanitize_callback' => 'sanitize_text_field',
            ],
            'before' => [
                'type'              => 'string',
                'required'          => true,
                'sanitize_callback' => 'sanitize_text_field',
            ],
        ];
    }

    /**
     * Count active subscriptions at a point in time
     *
     * @param string $at_date ISO 8601 date string.
     * @return int
     */
    private function getActiveCount(string $at_date): int
    {
        global $wpdb;

        $at_mysql = gmdate('Y-m-d H:i:s', strtotime($at_date));

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        return (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(DISTINCT p.ID)
                FROM {$wpdb->posts} p
                INNER JOIN {$wpdb->postmeta} pm_start ON p.ID = pm_start.post_id
                    AND pm_start.meta_key = '_start_date'
                WHERE p.post_type = 'arraysubs_data'
                    AND p.post_status = 'arraysubs-active'
                    AND pm_start.meta_value <= %s",
                $at_mysql
            )
        );
    }

    /**
     * Count new subscriptions created in a period
     *
     * @param string $after  Period start.
     * @param string $before Period end.
     * @return int
     */
    private function getNewSubscriptionCount(string $after, string $before): int
    {
        global $wpdb;

        $after_mysql  = gmdate('Y-m-d H:i:s', strtotime($after));
        $before_mysql = gmdate('Y-m-d H:i:s', strtotime($before));

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        return (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*)
                FROM {$wpdb->posts}
                WHERE post_type = 'arraysubs_data'
                    AND post_date_gmt >= %s
                    AND post_date_gmt <= %s",
                $after_mysql,
                $before_mysql
            )
        );
    }

    /**
     * Count churned (cancelled) subscriptions in a period
     *
     * @param string $after  Period start.
     * @param string $before Period end.
     * @return int
     */
    private function getChurnedCount(string $after, string $before): int
    {
        global $wpdb;

        $after_mysql  = gmdate('Y-m-d H:i:s', strtotime($after));
        $before_mysql = gmdate('Y-m-d H:i:s', strtotime($before));

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        return (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(DISTINCT p.ID)
                FROM {$wpdb->posts} p
                INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
                    AND pm.meta_key = '_cancelled_date'
                WHERE p.post_type = 'arraysubs_data'
                    AND p.post_status = 'arraysubs-cancelled'
                    AND pm.meta_value >= %s
                    AND pm.meta_value <= %s",
                $after_mysql,
                $before_mysql
            )
        );
    }

    /**
     * Compute MRR at a point in time
     *
     * Normalizes all active + trial subscription recurring amounts to monthly.
     *
     * @param string $at_date ISO 8601 date.
     * @return float
     */
    private function computeMrr(string $at_date): float
    {
        global $wpdb;

        $at_mysql = gmdate('Y-m-d H:i:s', strtotime($at_date));

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT
                    pm_amount.meta_value   AS recurring_amount,
                    pm_period.meta_value   AS billing_period,
                    pm_interval.meta_value AS billing_interval
                FROM {$wpdb->posts} p
                INNER JOIN {$wpdb->postmeta} pm_start ON p.ID = pm_start.post_id
                    AND pm_start.meta_key = '_start_date'
                INNER JOIN {$wpdb->postmeta} pm_amount ON p.ID = pm_amount.post_id
                    AND pm_amount.meta_key = '_recurring_amount'
                LEFT JOIN {$wpdb->postmeta} pm_period ON p.ID = pm_period.post_id
                    AND pm_period.meta_key = '_billing_period'
                LEFT JOIN {$wpdb->postmeta} pm_interval ON p.ID = pm_interval.post_id
                    AND pm_interval.meta_key = '_billing_interval'
                WHERE p.post_type = 'arraysubs_data'
                    AND p.post_status IN ('arraysubs-active', 'arraysubs-trial')
                    AND pm_start.meta_value <= %s",
                $at_mysql
            )
        );

        $mrr = 0.0;

        foreach ($rows as $row) {
            $amount   = (float) $row->recurring_amount;
            $period   = $row->billing_period ?: 'month';
            $interval = max(1, (int) $row->billing_interval);

            $mrr += $this->normalizeToMonthly($amount, $period, $interval);
        }

        return round($mrr, 2);
    }

    /**
     * Normalize a recurring amount to monthly
     *
     * @param float  $amount   Recurring amount.
     * @param string $period   Billing period (day, week, month, year).
     * @param int    $interval Billing interval.
     * @return float
     */
    private function normalizeToMonthly(float $amount, string $period, int $interval): float
    {
        switch ($period) {
            case 'day':
                return $amount * (30.44 / $interval);
            case 'week':
                return $amount * (self::WEEKLY_MRR_MULTIPLIER / $interval);
            case 'month':
                return $amount / $interval;
            case 'year':
                return $amount / ($interval * 12);
            default:
                return $amount;
        }
    }

    /**
     * Compute churn rate for a period with previous period comparison
     *
     * @param string $after       Current period start.
     * @param string $before      Current period end.
     * @param string $prev_after  Previous period start.
     * @param string $prev_before Previous period end.
     * @return array
     */
    private function computeChurnRate(
        string $after,
        string $before,
        string $prev_after,
        string $prev_before
    ): array {
        $churned_current = $this->getChurnedCount($after, $before);
        $active_start    = $this->getActiveCount($after);
        $new_current     = $this->getNewSubscriptionCount($after, $before);

        $denominator    = $active_start + $new_current;
        $current_rate   = $denominator > 0 ? round(($churned_current / $denominator) * 100, 2) : 0;

        $churned_prev   = $this->getChurnedCount($prev_after, $prev_before);
        $prev_active    = $this->getActiveCount($prev_after);
        $new_prev       = $this->getNewSubscriptionCount($prev_after, $prev_before);
        $prev_denom     = $prev_active + $new_prev;
        $prev_rate      = $prev_denom > 0 ? round(($churned_prev / $prev_denom) * 100, 2) : 0;

        return [
            'value'      => $current_rate,
            'prev_value' => $prev_rate,
        ];
    }

    /**
     * Compute trial conversion rate
     *
     * @param string $after       Current period start.
     * @param string $before      Current period end.
     * @param string $prev_after  Previous period start.
     * @param string $prev_before Previous period end.
     * @return array
     */
    private function computeTrialConversionRate(
        string $after,
        string $before,
        string $prev_after,
        string $prev_before
    ): array {
        return [
            'value'      => $this->getTrialConversionRate($after, $before),
            'prev_value' => $this->getTrialConversionRate($prev_after, $prev_before),
        ];
    }

    /**
     * Get trial conversion rate for a period
     *
     * @param string $after  Period start.
     * @param string $before Period end.
     * @return float
     */
    private function getTrialConversionRate(string $after, string $before): float
    {
        global $wpdb;

        $after_mysql  = gmdate('Y-m-d H:i:s', strtotime($after));
        $before_mysql = gmdate('Y-m-d H:i:s', strtotime($before));

        // Count trials that ended in this period (trial_end_date within range).
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $total_ended = (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(DISTINCT p.ID)
                FROM {$wpdb->posts} p
                INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
                    AND pm.meta_key = '_trial_end_date'
                WHERE p.post_type = 'arraysubs_data'
                    AND pm.meta_value >= %s
                    AND pm.meta_value <= %s",
                $after_mysql,
                $before_mysql
            )
        );

        if ($total_ended <= 0) {
            return 0.0;
        }

        // Converted = trials that ended in this period AND are now active.
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $converted = (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(DISTINCT p.ID)
                FROM {$wpdb->posts} p
                INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
                    AND pm.meta_key = '_trial_end_date'
                WHERE p.post_type = 'arraysubs_data'
                    AND p.post_status = 'arraysubs-active'
                    AND pm.meta_value >= %s
                    AND pm.meta_value <= %s",
                $after_mysql,
                $before_mysql
            )
        );

        return round(($converted / $total_ended) * 100, 2);
    }

    /**
     * Get renewal revenue for a period
     *
     * @param string $after  Period start.
     * @param string $before Period end.
     * @return float
     */
    private function getRenewalRevenue(string $after, string $before): float
    {
        global $wpdb;

        $after_mysql  = gmdate('Y-m-d H:i:s', strtotime($after));
        $before_mysql = gmdate('Y-m-d H:i:s', strtotime($before));

        if ($this->is_hpos) {
            $orders_table = $wpdb->prefix . 'wc_orders';
            $meta_table   = $wpdb->prefix . 'wc_orders_meta';

            // phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table names from wpdb prefix.
            return (float) $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT COALESCE(SUM(o.total_amount), 0)
                    FROM {$orders_table} o
                    INNER JOIN {$meta_table} om ON o.id = om.order_id
                        AND om.meta_key = '_arraysubs_computed_type'
                        AND om.meta_value = 'Subs Renew'
                    WHERE o.type = 'shop_order'
                        AND o.status IN ('wc-completed', 'wc-processing')
                        AND o.date_created_gmt >= %s
                        AND o.date_created_gmt <= %s",
                    $after_mysql,
                    $before_mysql
                )
            );
            // phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        }

        // Legacy post meta mode.
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        return (float) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COALESCE(SUM(pm_total.meta_value), 0)
                FROM {$wpdb->posts} p
                INNER JOIN {$wpdb->postmeta} pm_type ON p.ID = pm_type.post_id
                    AND pm_type.meta_key = '_arraysubs_computed_type'
                    AND pm_type.meta_value = 'Subs Renew'
                INNER JOIN {$wpdb->postmeta} pm_total ON p.ID = pm_total.post_id
                    AND pm_total.meta_key = '_order_total'
                WHERE p.post_type = 'shop_order'
                    AND p.post_status IN ('wc-completed', 'wc-processing')
                    AND p.post_date_gmt >= %s
                    AND p.post_date_gmt <= %s",
                $after_mysql,
                $before_mysql
            )
        );
    }

    /**
     * Compute revenue at risk (MRR from on-hold + pending cancellation subscriptions)
     *
     * @return float
     */
    private function computeRevenueAtRisk(): float
    {
        global $wpdb;

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $rows = $wpdb->get_results(
            "SELECT
                pm_amount.meta_value   AS recurring_amount,
                pm_period.meta_value   AS billing_period,
                pm_interval.meta_value AS billing_interval
            FROM {$wpdb->posts} p
            INNER JOIN {$wpdb->postmeta} pm_amount ON p.ID = pm_amount.post_id
                AND pm_amount.meta_key = '_recurring_amount'
            LEFT JOIN {$wpdb->postmeta} pm_period ON p.ID = pm_period.post_id
                AND pm_period.meta_key = '_billing_period'
            LEFT JOIN {$wpdb->postmeta} pm_interval ON p.ID = pm_interval.post_id
                AND pm_interval.meta_key = '_billing_interval'
            LEFT JOIN {$wpdb->postmeta} pm_wait ON p.ID = pm_wait.post_id
                AND pm_wait.meta_key = '_waiting_cancellation'
            WHERE p.post_type = 'arraysubs_data'
                AND (
                    p.post_status = 'arraysubs-on-hold'
                    OR (p.post_status IN ('arraysubs-active', 'arraysubs-trial') AND pm_wait.meta_value = '1')
                )"
        );

        $total = 0.0;

        foreach ($rows as $row) {
            $amount   = (float) $row->recurring_amount;
            $period   = $row->billing_period ?: 'month';
            $interval = max(1, (int) $row->billing_interval);

            $total += $this->normalizeToMonthly($amount, $period, $interval);
        }

        return round($total, 2);
    }

    /**
     * Compute ARPU
     *
     * @param string $at_date      Current point.
     * @param string $prev_at_date Previous point.
     * @param string $currency     Store currency.
     * @return array
     */
    private function computeArpu(string $at_date, string $prev_at_date, string $currency): array
    {
        $mrr      = $this->computeMrr($at_date);
        $prev_mrr = $this->computeMrr($prev_at_date);

        $customers      = $this->getUniqueActiveCustomers($at_date);
        $prev_customers = $this->getUniqueActiveCustomers($prev_at_date);

        return [
            'value'      => $customers > 0 ? round($mrr / $customers, 2) : 0,
            'prev_value' => $prev_customers > 0 ? round($prev_mrr / $prev_customers, 2) : 0,
            'currency'   => $currency,
        ];
    }

    /**
     * Count unique active customers at a point in time
     *
     * @param string $at_date ISO 8601 date.
     * @return int
     */
    private function getUniqueActiveCustomers(string $at_date): int
    {
        global $wpdb;

        $at_mysql = gmdate('Y-m-d H:i:s', strtotime($at_date));

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        return (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(DISTINCT pm_cust.meta_value)
                FROM {$wpdb->posts} p
                INNER JOIN {$wpdb->postmeta} pm_start ON p.ID = pm_start.post_id
                    AND pm_start.meta_key = '_start_date'
                INNER JOIN {$wpdb->postmeta} pm_cust ON p.ID = pm_cust.post_id
                    AND pm_cust.meta_key = '_customer_id'
                WHERE p.post_type = 'arraysubs_data'
                    AND p.post_status IN ('arraysubs-active', 'arraysubs-trial')
                    AND pm_start.meta_value <= %s
                    AND pm_cust.meta_value > 0",
                $at_mysql
            )
        );
    }

    /**
     * Get retention saves count
     *
     * @param string $after       Current start.
     * @param string $before      Current end.
     * @param string $prev_after  Previous start.
     * @param string $prev_before Previous end.
     * @return array
     */
    private function getRetentionSaves(
        string $after,
        string $before,
        string $prev_after,
        string $prev_before
    ): array {
        return [
            'value'      => $this->countRetentionEvents($after, $before),
            'prev_value' => $this->countRetentionEvents($prev_after, $prev_before),
        ];
    }

    /**
     * Count retention offer_accepted events in a period
     *
     * @param string $after  Period start.
     * @param string $before Period end.
     * @return int
     */
    private function countRetentionEvents(string $after, string $before): int
    {
        global $wpdb;

        $table = $wpdb->prefix . 'arraysubs_retention_logs';

        // phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name from wpdb prefix.
        return (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*)
                FROM {$table}
                WHERE event_type = 'offer_accepted'
                    AND created_at >= %s
                    AND created_at <= %s",
                gmdate('Y-m-d H:i:s', strtotime($after)),
                gmdate('Y-m-d H:i:s', strtotime($before))
            )
        );
        // phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
    }

    /**
     * Compute period length in seconds
     *
     * @param string $after  Period start.
     * @param string $before Period end.
     * @return int
     */
    private function getPeriodLengthInSeconds(string $after, string $before): int
    {
        return max(1, abs(strtotime($before) - strtotime($after)));
    }

    /**
     * Get interval boundaries for charting
     *
     * @param string $after    Period start.
     * @param string $before   Period end.
     * @param string $interval Interval type.
     * @return array Array of ['start' => string, 'end' => string, 'label' => string].
     */
    private function getIntervalBoundaries(string $after, string $before, string $interval): array
    {
        $start_ts   = strtotime($after);
        $end_ts     = strtotime($before);
        $boundaries = [];

        if (! $start_ts || ! $end_ts || $start_ts >= $end_ts) {
            return $boundaries;
        }

        $current = $start_ts;
        $max_intervals = 365;
        $count = 0;

        while ($current < $end_ts && $count < $max_intervals) {
            $next = $this->advanceInterval($current, $interval);
            $next = min($next, $end_ts);

            $boundaries[] = [
                'start' => gmdate('Y-m-d H:i:s', $current),
                'end'   => gmdate('Y-m-d H:i:s', $next),
                'label' => gmdate('Y-m-d', $current),
            ];

            $current = $next;
            ++$count;
        }

        return $boundaries;
    }

    /**
     * Advance timestamp by one interval
     *
     * @param int    $timestamp Current timestamp.
     * @param string $interval  Interval type.
     * @return int
     */
    private function advanceInterval(int $timestamp, string $interval): int
    {
        switch ($interval) {
            case 'day':
                return strtotime('+1 day', $timestamp);
            case 'week':
                return strtotime('+1 week', $timestamp);
            case 'month':
                return strtotime('+1 month', $timestamp);
            case 'quarter':
                return strtotime('+3 months', $timestamp);
            case 'year':
                return strtotime('+1 year', $timestamp);
            default:
                return strtotime('+1 day', $timestamp);
        }
    }

    /**
     * Chart: MRR over time
     *
     * @param array $boundaries Interval boundaries.
     * @return array
     */
    private function chartMrr(array $boundaries): array
    {
        $data = [];

        foreach ($boundaries as $b) {
            $data[] = [
                'date'  => $b['label'],
                'value' => $this->computeMrr($b['end']),
            ];
        }

        return $data;
    }

    /**
     * Chart: Net subscription growth per interval
     *
     * @param array $boundaries Interval boundaries.
     * @return array
     */
    private function chartNetGrowth(array $boundaries): array
    {
        $data = [];

        foreach ($boundaries as $b) {
            $new     = $this->getNewSubscriptionCount($b['start'], $b['end']);
            $churned = $this->getChurnedCount($b['start'], $b['end']);

            $data[] = [
                'date'  => $b['label'],
                'value' => $new - $churned,
            ];
        }

        return $data;
    }

    /**
     * Chart: Churn rate per interval
     *
     * @param array $boundaries Interval boundaries.
     * @return array
     */
    private function chartChurnRate(array $boundaries): array
    {
        $data = [];

        foreach ($boundaries as $b) {
            $churned     = $this->getChurnedCount($b['start'], $b['end']);
            $active      = $this->getActiveCount($b['start']);
            $new         = $this->getNewSubscriptionCount($b['start'], $b['end']);
            $denominator = $active + $new;

            $data[] = [
                'date'  => $b['label'],
                'value' => $denominator > 0 ? round(($churned / $denominator) * 100, 2) : 0,
            ];
        }

        return $data;
    }

    /**
     * Chart: Trial conversion rate per interval
     *
     * @param array $boundaries Interval boundaries.
     * @return array
     */
    private function chartTrialConversions(array $boundaries): array
    {
        $data = [];

        foreach ($boundaries as $b) {
            $data[] = [
                'date'  => $b['label'],
                'value' => $this->getTrialConversionRate($b['start'], $b['end']),
            ];
        }

        return $data;
    }

    /**
     * Chart: Active subscription count at each interval point
     *
     * @param array $boundaries Interval boundaries.
     * @return array
     */
    private function chartActiveCount(array $boundaries): array
    {
        $data = [];

        foreach ($boundaries as $b) {
            $data[] = [
                'date'  => $b['label'],
                'value' => $this->getActiveCount($b['end']),
            ];
        }

        return $data;
    }

    /**
     * Chart: Renewal revenue per interval
     *
     * @param array $boundaries Interval boundaries.
     * @return array
     */
    private function chartRenewalRevenue(array $boundaries): array
    {
        $data = [];

        foreach ($boundaries as $b) {
            $data[] = [
                'date'  => $b['label'],
                'value' => $this->getRenewalRevenue($b['start'], $b['end']),
            ];
        }

        return $data;
    }

    /**
     * Get top products by active subscriptions (for leaderboard)
     *
     * @param int    $per_page Number of rows.
     * @param string $after    Period start.
     * @param string $before   Period end.
     * @return array
     */
    public function getTopProductsByActive(int $per_page, ?string $after, ?string $before): array
    {
        global $wpdb;

        $before_mysql = gmdate('Y-m-d H:i:s', $before ? strtotime($before) : time());

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT
                    COALESCE(NULLIF(pm_var.meta_value, '0'), pm_prod.meta_value) AS effective_product_id,
                    COUNT(DISTINCT p.ID) AS active_count,
                    SUM(
                        CAST(pm_amount.meta_value AS DECIMAL(19,4))
                    ) AS total_recurring,
                    MAX(pm_period.meta_value) AS billing_period,
                    MAX(pm_interval.meta_value) AS billing_interval
                FROM {$wpdb->posts} p
                INNER JOIN {$wpdb->postmeta} pm_start ON p.ID = pm_start.post_id
                    AND pm_start.meta_key = '_start_date'
                INNER JOIN {$wpdb->postmeta} pm_prod ON p.ID = pm_prod.post_id
                    AND pm_prod.meta_key = '_product_id'
                LEFT JOIN {$wpdb->postmeta} pm_var ON p.ID = pm_var.post_id
                    AND pm_var.meta_key = '_variation_id'
                INNER JOIN {$wpdb->postmeta} pm_amount ON p.ID = pm_amount.post_id
                    AND pm_amount.meta_key = '_recurring_amount'
                LEFT JOIN {$wpdb->postmeta} pm_period ON p.ID = pm_period.post_id
                    AND pm_period.meta_key = '_billing_period'
                LEFT JOIN {$wpdb->postmeta} pm_interval ON p.ID = pm_interval.post_id
                    AND pm_interval.meta_key = '_billing_interval'
                WHERE p.post_type = 'arraysubs_data'
                    AND p.post_status = 'arraysubs-active'
                    AND pm_start.meta_value <= %s
                GROUP BY effective_product_id
                ORDER BY active_count DESC
                LIMIT %d",
                $before_mysql,
                $per_page
            )
        );

        $result = [];

        foreach ($rows as $row) {
            $product_id = (int) $row->effective_product_id;
            $product    = wc_get_product($product_id);
            $name       = $product ? $product->get_name() : sprintf(
                /* translators: %d: product ID */
                __('Product #%d', 'arraysubspro'),
                $product_id
            );

            $mrr = 0.0;
            $period   = $row->billing_period ?: 'month';
            $interval = max(1, (int) $row->billing_interval);
            $mrr      = $this->normalizeToMonthly((float) $row->total_recurring, $period, $interval);

            $edit_url = get_edit_post_link($product_id, 'raw') ?: '#';

            $result[] = [
                [
                    'display' => '<a href="' . esc_url($edit_url) . '">' . esc_html($name) . '</a>',
                    'value'   => $name,
                ],
                [
                    'display' => (string) (int) $row->active_count,
                    'value'   => (int) $row->active_count,
                    'format'  => 'number',
                ],
                [
                    'display' => wc_price($mrr),
                    'value'   => $mrr,
                    'format'  => 'currency',
                ],
            ];
        }

        return $result;
    }

    /**
     * Get top products by revenue (for leaderboard)
     *
     * @param int    $per_page Number of rows.
     * @param string $after    Period start.
     * @param string $before   Period end.
     * @return array
     */
    public function getTopProductsByRevenue(int $per_page, ?string $after, ?string $before): array
    {
        global $wpdb;

        $after_mysql  = gmdate('Y-m-d H:i:s', $after ? strtotime($after) : strtotime('-30 days'));
        $before_mysql = gmdate('Y-m-d H:i:s', $before ? strtotime($before) : time());

        if ($this->is_hpos) {
            $orders_table = $wpdb->prefix . 'wc_orders';
            $meta_table   = $wpdb->prefix . 'wc_orders_meta';
            $items_table  = $wpdb->prefix . 'woocommerce_order_items';
            $itemmeta     = $wpdb->prefix . 'woocommerce_order_itemmeta';

            // phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table names from wpdb prefix.
            $rows = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT
                        COALESCE(NULLIF(oim_var.meta_value, '0'), oim_prod.meta_value) AS effective_product_id,
                        SUM(CAST(oim_total.meta_value AS DECIMAL(19,4))) AS total_revenue,
                        COUNT(DISTINCT o.id) AS order_count
                    FROM {$orders_table} o
                    INNER JOIN {$meta_table} om ON o.id = om.order_id
                        AND om.meta_key = '_arraysubs_has_subscription_product'
                        AND om.meta_value = 'yes'
                    INNER JOIN {$items_table} oi ON o.id = oi.order_id
                        AND oi.order_item_type = 'line_item'
                    INNER JOIN {$itemmeta} oim_prod ON oi.order_item_id = oim_prod.order_item_id
                        AND oim_prod.meta_key = '_product_id'
                    LEFT JOIN {$itemmeta} oim_var ON oi.order_item_id = oim_var.order_item_id
                        AND oim_var.meta_key = '_variation_id'
                    INNER JOIN {$itemmeta} oim_total ON oi.order_item_id = oim_total.order_item_id
                        AND oim_total.meta_key = '_line_total'
                    WHERE o.type = 'shop_order'
                        AND o.status IN ('wc-completed', 'wc-processing')
                        AND o.date_created_gmt >= %s
                        AND o.date_created_gmt <= %s
                    GROUP BY effective_product_id
                    ORDER BY total_revenue DESC
                    LIMIT %d",
                    $after_mysql,
                    $before_mysql,
                    $per_page
                )
            );
            // phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        } else {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $rows = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT
                        COALESCE(NULLIF(oim_var.meta_value, '0'), oim_prod.meta_value) AS effective_product_id,
                        SUM(CAST(oim_total.meta_value AS DECIMAL(19,4))) AS total_revenue,
                        COUNT(DISTINCT p.ID) AS order_count
                    FROM {$wpdb->posts} p
                    INNER JOIN {$wpdb->postmeta} pm_sub ON p.ID = pm_sub.post_id
                        AND pm_sub.meta_key = '_arraysubs_has_subscription_product'
                        AND pm_sub.meta_value = 'yes'
                    INNER JOIN {$wpdb->prefix}woocommerce_order_items oi ON p.ID = oi.order_id
                        AND oi.order_item_type = 'line_item'
                    INNER JOIN {$wpdb->prefix}woocommerce_order_itemmeta oim_prod ON oi.order_item_id = oim_prod.order_item_id
                        AND oim_prod.meta_key = '_product_id'
                    LEFT JOIN {$wpdb->prefix}woocommerce_order_itemmeta oim_var ON oi.order_item_id = oim_var.order_item_id
                        AND oim_var.meta_key = '_variation_id'
                    INNER JOIN {$wpdb->prefix}woocommerce_order_itemmeta oim_total ON oi.order_item_id = oim_total.order_item_id
                        AND oim_total.meta_key = '_line_total'
                    WHERE p.post_type = 'shop_order'
                        AND p.post_status IN ('wc-completed', 'wc-processing')
                        AND p.post_date_gmt >= %s
                        AND p.post_date_gmt <= %s
                    GROUP BY effective_product_id
                    ORDER BY total_revenue DESC
                    LIMIT %d",
                    $after_mysql,
                    $before_mysql,
                    $per_page
                )
            );
        }

        $result = [];

        foreach ($rows as $row) {
            $product_id = (int) $row->effective_product_id;
            $product    = wc_get_product($product_id);
            $name       = $product ? $product->get_name() : sprintf(
                /* translators: %d: product ID */
                __('Product #%d', 'arraysubspro'),
                $product_id
            );

            $edit_url = get_edit_post_link($product_id, 'raw') ?: '#';

            $result[] = [
                [
                    'display' => '<a href="' . esc_url($edit_url) . '">' . esc_html($name) . '</a>',
                    'value'   => $name,
                ],
                [
                    'display' => wc_price((float) $row->total_revenue),
                    'value'   => (float) $row->total_revenue,
                    'format'  => 'currency',
                ],
                [
                    'display' => (string) (int) $row->order_count,
                    'value'   => (int) $row->order_count,
                    'format'  => 'number',
                ],
            ];
        }

        return $result;
    }

    /**
     * Get top customers by lifetime value (for leaderboard)
     *
     * @param int    $per_page Number of rows.
     * @param string $after    Period start.
     * @param string $before   Period end.
     * @return array
     */
    public function getTopCustomersByLtv(int $per_page, ?string $after, ?string $before): array
    {
        global $wpdb;

        $before_mysql = gmdate('Y-m-d H:i:s', $before ? strtotime($before) : time());

        if ($this->is_hpos) {
            $orders_table = $wpdb->prefix . 'wc_orders';

            // phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name from wpdb prefix.
            $rows = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT
                        pm_cust.meta_value AS customer_id,
                        COUNT(DISTINCT p.ID) AS active_subs,
                        COALESCE(
                            (SELECT SUM(o.total_amount)
                             FROM {$orders_table} o
                             WHERE o.customer_id = pm_cust.meta_value
                                AND o.type = 'shop_order'
                                AND o.status IN ('wc-completed', 'wc-processing')),
                            0
                        ) AS total_spent
                    FROM {$wpdb->posts} p
                    INNER JOIN {$wpdb->postmeta} pm_cust ON p.ID = pm_cust.post_id
                        AND pm_cust.meta_key = '_customer_id'
                    INNER JOIN {$wpdb->postmeta} pm_start ON p.ID = pm_start.post_id
                        AND pm_start.meta_key = '_start_date'
                    WHERE p.post_type = 'arraysubs_data'
                        AND p.post_status = 'arraysubs-active'
                        AND pm_start.meta_value <= %s
                        AND pm_cust.meta_value > 0
                    GROUP BY pm_cust.meta_value
                    ORDER BY total_spent DESC
                    LIMIT %d",
                    $before_mysql,
                    $per_page
                )
            );
            // phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        } else {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $rows = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT
                        pm_cust.meta_value AS customer_id,
                        COUNT(DISTINCT p.ID) AS active_subs,
                        COALESCE(
                            (SELECT SUM(pm_total.meta_value)
                             FROM {$wpdb->posts} o
                             INNER JOIN {$wpdb->postmeta} pm_total ON o.ID = pm_total.post_id
                                AND pm_total.meta_key = '_order_total'
                             INNER JOIN {$wpdb->postmeta} pm_oc ON o.ID = pm_oc.post_id
                                AND pm_oc.meta_key = '_customer_user'
                                AND pm_oc.meta_value = pm_cust.meta_value
                             WHERE o.post_type = 'shop_order'
                                AND o.post_status IN ('wc-completed', 'wc-processing')),
                            0
                        ) AS total_spent
                    FROM {$wpdb->posts} p
                    INNER JOIN {$wpdb->postmeta} pm_cust ON p.ID = pm_cust.post_id
                        AND pm_cust.meta_key = '_customer_id'
                    INNER JOIN {$wpdb->postmeta} pm_start ON p.ID = pm_start.post_id
                        AND pm_start.meta_key = '_start_date'
                    WHERE p.post_type = 'arraysubs_data'
                        AND p.post_status = 'arraysubs-active'
                        AND pm_start.meta_value <= %s
                        AND pm_cust.meta_value > 0
                    GROUP BY pm_cust.meta_value
                    ORDER BY total_spent DESC
                    LIMIT %d",
                    $before_mysql,
                    $per_page
                )
            );
        }

        $result = [];

        foreach ($rows as $row) {
            $customer_id = (int) $row->customer_id;
            $user        = get_user_by('id', $customer_id);
            $name        = $user ? trim($user->first_name . ' ' . $user->last_name) : '';

            if (empty($name) && $user) {
                $name = $user->display_name;
            }

            if (empty($name)) {
                $name = sprintf(
                    /* translators: %d: customer ID */
                    __('Customer #%d', 'arraysubspro'),
                    $customer_id
                );
            }

            $member_url = admin_url('admin.php?page=arraysubs#/member-insight/' . $customer_id);

            $result[] = [
                [
                    'display' => '<a href="' . esc_url($member_url) . '">' . esc_html($name) . '</a>',
                    'value'   => $name,
                ],
                [
                    'display' => (string) (int) $row->active_subs,
                    'value'   => (int) $row->active_subs,
                    'format'  => 'number',
                ],
                [
                    'display' => wc_price((float) $row->total_spent),
                    'value'   => (float) $row->total_spent,
                    'format'  => 'currency',
                ],
            ];
        }

        return $result;
    }

    /**
     * Get top cancellation reasons (for leaderboard)
     *
     * @param int    $per_page Number of rows.
     * @param string $after    Period start.
     * @param string $before   Period end.
     * @return array
     */
    public function getTopCancellationReasons(int $per_page, ?string $after, ?string $before): array
    {
        global $wpdb;

        $table        = $wpdb->prefix . 'arraysubs_retention_logs';
        $after_mysql  = gmdate('Y-m-d H:i:s', $after ? strtotime($after) : strtotime('-30 days'));
        $before_mysql = gmdate('Y-m-d H:i:s', $before ? strtotime($before) : time());

        // phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name from wpdb prefix.
        $total_cancelled = (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*)
                FROM {$table}
                WHERE event_type = 'cancelled'
                    AND created_at >= %s
                    AND created_at <= %s",
                $after_mysql,
                $before_mysql
            )
        );

        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT reason, COUNT(*) AS cnt
                FROM {$table}
                WHERE event_type = 'cancelled'
                    AND reason != ''
                    AND created_at >= %s
                    AND created_at <= %s
                GROUP BY reason
                ORDER BY cnt DESC
                LIMIT %d",
                $after_mysql,
                $before_mysql,
                $per_page
            )
        );
        // phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared

        $result = [];

        foreach ($rows as $row) {
            $count   = (int) $row->cnt;
            $percent = $total_cancelled > 0 ? round(($count / $total_cancelled) * 100, 1) : 0;

            $result[] = [
                [
                    'display' => esc_html($row->reason),
                    'value'   => $row->reason,
                ],
                [
                    'display' => (string) $count,
                    'value'   => $count,
                    'format'  => 'number',
                ],
                [
                    'display' => $percent . '%',
                    'value'   => $percent,
                    'format'  => 'number',
                ],
            ];
        }

        return $result;
    }

    /**
     * Get top products by churn (for leaderboard)
     *
     * @param int    $per_page Number of rows.
     * @param string $after    Period start.
     * @param string $before   Period end.
     * @return array
     */
    public function getTopProductsByChurn(int $per_page, ?string $after, ?string $before): array
    {
        global $wpdb;

        $after_mysql  = gmdate('Y-m-d H:i:s', $after ? strtotime($after) : strtotime('-30 days'));
        $before_mysql = gmdate('Y-m-d H:i:s', $before ? strtotime($before) : time());

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT
                    COALESCE(NULLIF(pm_var.meta_value, '0'), pm_prod.meta_value) AS effective_product_id,
                    COUNT(DISTINCT p.ID) AS cancel_count
                FROM {$wpdb->posts} p
                INNER JOIN {$wpdb->postmeta} pm_cancel ON p.ID = pm_cancel.post_id
                    AND pm_cancel.meta_key = '_cancelled_date'
                INNER JOIN {$wpdb->postmeta} pm_prod ON p.ID = pm_prod.post_id
                    AND pm_prod.meta_key = '_product_id'
                LEFT JOIN {$wpdb->postmeta} pm_var ON p.ID = pm_var.post_id
                    AND pm_var.meta_key = '_variation_id'
                WHERE p.post_type = 'arraysubs_data'
                    AND p.post_status = 'arraysubs-cancelled'
                    AND pm_cancel.meta_value >= %s
                    AND pm_cancel.meta_value <= %s
                GROUP BY effective_product_id
                ORDER BY cancel_count DESC
                LIMIT %d",
                $after_mysql,
                $before_mysql,
                $per_page
            )
        );

        $result = [];

        foreach ($rows as $row) {
            $product_id   = (int) $row->effective_product_id;
            $cancel_count = (int) $row->cancel_count;
            $product      = wc_get_product($product_id);
            $name         = $product ? $product->get_name() : sprintf(
                /* translators: %d: product ID */
                __('Product #%d', 'arraysubspro'),
                $product_id
            );

            // Get active count for this product to calculate churn rate.
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $active_for_product = (int) $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT COUNT(DISTINCT p2.ID)
                    FROM {$wpdb->posts} p2
                    INNER JOIN {$wpdb->postmeta} pm2_prod ON p2.ID = pm2_prod.post_id
                        AND pm2_prod.meta_key = '_product_id'
                    LEFT JOIN {$wpdb->postmeta} pm2_var ON p2.ID = pm2_var.post_id
                        AND pm2_var.meta_key = '_variation_id'
                    WHERE p2.post_type = 'arraysubs_data'
                        AND p2.post_status = 'arraysubs-active'
                        AND COALESCE(NULLIF(pm2_var.meta_value, '0'), pm2_prod.meta_value) = %s",
                    (string) $product_id
                )
            );

            $total_pool = $active_for_product + $cancel_count;
            $churn_rate = $total_pool > 0 ? round(($cancel_count / $total_pool) * 100, 1) : 0;

            $edit_url = get_edit_post_link($product_id, 'raw') ?: '#';

            $result[] = [
                [
                    'display' => '<a href="' . esc_url($edit_url) . '">' . esc_html($name) . '</a>',
                    'value'   => $name,
                ],
                [
                    'display' => (string) $cancel_count,
                    'value'   => $cancel_count,
                    'format'  => 'number',
                ],
                [
                    'display' => $churn_rate . '%',
                    'value'   => $churn_rate,
                    'format'  => 'number',
                ],
            ];
        }

        return $result;
    }
}
