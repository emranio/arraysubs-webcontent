<?php

/**
 * Analytics Provider
 *
 * @package ArraySubsPro\Features\Analytics
 */

namespace ArraySubsPro\Features\Analytics;

defined('ABSPATH') || exit;

use ArraySubs\Supports\Abstracts\AbstractLoader;

/**
 * Analytics feature entry point.
 *
 * Provides order type classification, WooCommerce Analytics integration,
 * and admin order list enhancements.
 */
class Provider extends AbstractLoader
{

    public function __construct()
    {
        $this->classLoader([
            plugin_dir_path(__FILE__) . 'Services',
            plugin_dir_path(__FILE__) . 'REST',
        ]);
    }
}
