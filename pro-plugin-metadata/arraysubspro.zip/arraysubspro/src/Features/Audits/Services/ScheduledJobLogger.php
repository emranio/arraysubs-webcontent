<?php

/**
 * Scheduled-Job Logger
 *
 * Hooks into Action Scheduler execution lifecycle to log every
 * arraysubs scheduled-job run (success and failure) as a note.
 *
 * @package ArraySubsPro\Features\Audits\Services
 */

namespace ArraySubsPro\Features\Audits\Services;

defined('ABSPATH') || exit;

use ArraySubs\Supports\ActionScheduler;

/**
 * Logs Action Scheduler job executions as notes
 */
class ScheduledJobLogger
{
    /**
     * Enable auto-loading
     *
     * @var bool
     */
    public static $loadable = true;

    /**
     * Human-readable labels for known hooks
     *
     * @var array
     */
    private static array $hook_labels = [];

    /**
     * Constructor
     */
    public function __construct()
    {
        add_action('action_scheduler_after_execute', [$this, 'onActionSuccess'], 10, 2);
        add_action('action_scheduler_failed_execution', [$this, 'onActionFailed'], 10, 2);
        add_action('init', [$this, 'fixMisclassifiedJobNotes']);
    }

    /**
     * One-time migration: fix scheduled-job notes that were stored as 'private'
     * due to a register_post_meta sanitize callback bug.
     */
    public function fixMisclassifiedJobNotes(): void
    {
        if (get_option('arraysubs_job_notes_type_fixed')) {
            return;
        }

        global $wpdb;

        // Notes with _job_hook meta are scheduled-job notes regardless of _note_type.
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- One-time migration to repair misclassified note types.
        $note_ids = $wpdb->get_col(
            "SELECT DISTINCT p.ID
             FROM {$wpdb->posts} p
             INNER JOIN {$wpdb->postmeta} jh ON p.ID = jh.post_id AND jh.meta_key = '_job_hook'
             INNER JOIN {$wpdb->postmeta} nt ON p.ID = nt.post_id AND nt.meta_key = '_note_type'
             WHERE p.post_type = 'arraysubs_sub_note'
               AND nt.meta_value != 'scheduled_job'"
        );

        if (! empty($note_ids)) {
            foreach ($note_ids as $note_id) {
                // Use direct query to bypass the sanitize callback during migration.
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- One-time migration update.
                $wpdb->update(
                    $wpdb->postmeta,
                    ['meta_value' => 'scheduled_job'],
                    [
                        'post_id'  => (int) $note_id,
                        'meta_key' => '_note_type',
                    ]
                );
            }

            clean_post_cache(0);
        }

        update_option('arraysubs_job_notes_type_fixed', 1, true);
    }

    /**
     * Log a successful Action Scheduler execution
     *
     * @param int                            $action_id The action ID.
     * @param \ActionScheduler_Action|null   $action    The action object (AS >= 3.5).
     */
    public function onActionSuccess(int $action_id, $action = null): void
    {
        $this->logExecution($action_id, 'success', $action);
    }

    /**
     * Log a failed Action Scheduler execution
     *
     * @param int             $action_id The action ID.
     * @param \Exception|null $exception The exception that caused the failure.
     */
    public function onActionFailed(int $action_id, $exception = null): void
    {
        $error = '';
        if ($exception instanceof \Exception) {
            $error = $exception->getMessage();
        }

        $this->logExecution($action_id, 'failed', null, $error);
    }

    /**
     * Core logging logic
     *
     * @param int                          $action_id Action ID.
     * @param string                       $status    'success' or 'failed'.
     * @param \ActionScheduler_Action|null $action    The action object.
     * @param string                       $error     Error message for failures.
     */
    private function logExecution(int $action_id, string $status, $action = null, string $error = ''): void
    {
        if (! function_exists('arraysubs_add_scheduled_job_note')) {
            return;
        }

        $hook  = '';
        $args  = [];
        $group = '';

        if (null !== $action && method_exists($action, 'get_hook')) {
            $hook  = $action->get_hook();
            $args  = $action->get_args();
            $group = $action->get_group();
        } else {
            $fetched = $this->fetchActionFromStore($action_id);
            if ($fetched) {
                $hook  = $fetched->get_hook();
                $args  = $fetched->get_args();
                $group = $fetched->get_group();
            }
        }

        if (! $hook || ! $this->isArraySubsHook($hook)) {
            return;
        }

        if ('success' === $status) {
            $business_error = $this->getBusinessFailureError($hook, $args);
            if ($business_error) {
                $status = 'failed';
                $error  = $business_error;
            }
        }

        $summary = $this->buildSummary($hook, $status, $args, $error);

        arraysubs_add_scheduled_job_note($hook, $status, $summary, $args, $group, $error);
    }

    /**
     * Detect handled business failures for actions that can complete at the
     * Action Scheduler level while still failing the subscription workflow.
     *
     * @param string $hook Hook name.
     * @param array  $args Action arguments.
     *
     * @return string Failure reason, or empty string when the job succeeded.
     */
    private function getBusinessFailureError(string $hook, array $args): string
    {
        if (ActionScheduler::HOOK_PROCESS_RENEWAL !== $hook) {
            return '';
        }

        $subscription_id = ! empty($args[0]) && is_numeric($args[0]) ? (int) $args[0] : 0;
        if ($subscription_id <= 0) {
            return '';
        }

        return trim((string) get_post_meta($subscription_id, '_last_payment_failure_reason', true));
    }

    /**
     * Check if a hook belongs to ArraySubs
     *
     * @param string $hook Hook name.
     *
     * @return bool
     */
    private function isArraySubsHook(string $hook): bool
    {
        return str_starts_with($hook, 'arraysubs_');
    }

    /**
     * Build a two-line human-readable summary of the job execution
     *
     * @param string $hook   Hook name.
     * @param string $status Execution status.
     * @param array  $args   Action arguments.
     * @param string $error  Error message.
     *
     * @return string HTML summary.
     */
    private function buildSummary(string $hook, string $status, array $args, string $error): string
    {
        $label      = $this->getHookLabel($hook);
        $status_tag = 'success' === $status
            ? '<strong style="color:#1e4620;">&#10003; Success</strong>'
            : '<strong style="color:#991b1b;">&#10007; Failed</strong>';

        $line1 = sprintf('[%s] %s', esc_html($label), $status_tag);

        $line2 = $this->buildDetailLine($hook, $args, $error);

        return $line1 . '<br>' . $line2;
    }

    /**
     * Build the second detail line based on hook type and arguments
     *
     * @param string $hook  Hook name.
     * @param array  $args  Action arguments.
     * @param string $error Error message.
     *
     * @return string Detail text.
     */
    private function buildDetailLine(string $hook, array $args, string $error): string
    {
        if ($error) {
            return esc_html($error);
        }

        $sub_id = ! empty($args[0]) && is_numeric($args[0]) ? (int) $args[0] : 0;

        switch ($hook) {
            case ActionScheduler::HOOK_PROCESS_RENEWAL:
                return $sub_id
                    ? sprintf('Processed renewal for subscription #%d.', $sub_id)
                    : 'Processed renewal.';

            case ActionScheduler::HOOK_PROCESS_TRIAL_CONVERSION:
                return $sub_id
                    ? sprintf('Converted trial to paid for subscription #%d.', $sub_id)
                    : 'Converted trial to paid.';

            case ActionScheduler::HOOK_PROCESS_TRIAL_CONVERSIONS:
                return 'Batch-checked subscriptions for trial conversions.';

            case ActionScheduler::HOOK_GENERATE_UPCOMING_RENEWALS:
                return 'Generated upcoming renewal invoices.';

            case ActionScheduler::HOOK_CHECK_OVERDUE_RENEWALS:
                return 'Checked for overdue renewal payments.';

            case ActionScheduler::HOOK_CANCEL_SUBSCRIPTION:
                return $sub_id
                    ? sprintf('Scheduled cancellation executed for subscription #%d.', $sub_id)
                    : 'Cancelled subscription.';

            case ActionScheduler::HOOK_HOLD_SUBSCRIPTION:
                return $sub_id
                    ? sprintf('Placed subscription #%d on hold.', $sub_id)
                    : 'Placed subscription on hold.';

            case ActionScheduler::HOOK_EXPIRE_SUBSCRIPTION:
                return $sub_id
                    ? sprintf('Expired subscription #%d.', $sub_id)
                    : 'Expired subscription.';

            case ActionScheduler::HOOK_RESUME_SUBSCRIPTION:
                return $sub_id
                    ? sprintf('Resumed subscription #%d.', $sub_id)
                    : 'Resumed subscription.';

            case ActionScheduler::HOOK_PROCESS_SKIPPED_CYCLE:
                return $sub_id
                    ? sprintf('Processed skipped billing cycle for subscription #%d.', $sub_id)
                    : 'Processed skipped billing cycle.';

            case ActionScheduler::HOOK_SEND_RENEWAL_REMINDER:
                $days = isset($args[1]) ? (int) $args[1] : 0;
                $detail = $sub_id
                    ? sprintf('Sent renewal reminder for subscription #%d', $sub_id)
                    : 'Sent renewal reminder';
                return $days ? $detail . sprintf(' (%d days before due).', $days) : $detail . '.';

            case ActionScheduler::HOOK_SEND_PAYMENT_FAILED:
                $order_id = isset($args[1]) ? (int) $args[1] : 0;
                $detail   = $sub_id
                    ? sprintf('Sent payment-failed notice for subscription #%d', $sub_id)
                    : 'Sent payment-failed notice';
                return $order_id ? $detail . sprintf(', order #%d.', $order_id) : $detail . '.';

            case ActionScheduler::HOOK_SEND_EXPIRING_SOON:
                return $sub_id
                    ? sprintf('Sent expiring-soon notice for subscription #%d.', $sub_id)
                    : 'Sent expiring-soon notice.';

            case ActionScheduler::HOOK_SEND_CREDIT_EXPIRING:
                $customer = $sub_id;
                $log_id   = isset($args[1]) ? (int) $args[1] : 0;
                return $log_id
                    ? sprintf('Sent credit-expiring notice for customer #%d, credit log #%d.', $customer, $log_id)
                    : sprintf('Sent credit-expiring notice for customer #%d.', $customer);

            case ActionScheduler::HOOK_CLEANUP_OLD_DATA:
                return 'Cleaned up old subscription data.';

            case ActionScheduler::HOOK_EXPIRE_STORE_CREDITS:
                return 'Checked and expired overdue store credits.';

            case ActionScheduler::HOOK_CLEANUP_WEBHOOK_EVENTS:
                return 'Cleaned up processed webhook events.';

            case ActionScheduler::HOOK_GATEWAY_RECONCILE:
                return 'Ran gateway payment reconciliation.';

            case ActionScheduler::HOOK_BACKFILL_RETENTION_LOGS:
                $offset = isset($args[0]) ? (int) $args[0] : 0;
                return sprintf('Backfilled retention analytics (offset %d).', $offset);

            default:
                return $sub_id
                    ? sprintf('Ran scheduled action for subscription #%d.', $sub_id)
                    : 'Ran scheduled action.';
        }
    }

    /**
     * Get a human-readable label for a hook
     *
     * @param string $hook Hook name.
     *
     * @return string Label.
     */
    private function getHookLabel(string $hook): string
    {
        if (empty(self::$hook_labels)) {
            self::$hook_labels = [
                ActionScheduler::HOOK_PROCESS_RENEWAL           => 'Process Renewal',
                ActionScheduler::HOOK_PROCESS_TRIAL_CONVERSION  => 'Trial Conversion',
                ActionScheduler::HOOK_PROCESS_TRIAL_CONVERSIONS => 'Batch Trial Conversions',
                ActionScheduler::HOOK_GENERATE_UPCOMING_RENEWALS => 'Generate Upcoming Renewals',
                ActionScheduler::HOOK_CHECK_OVERDUE_RENEWALS    => 'Check Overdue Renewals',
                ActionScheduler::HOOK_CANCEL_SUBSCRIPTION       => 'Cancel Subscription',
                ActionScheduler::HOOK_HOLD_SUBSCRIPTION         => 'Hold Subscription',
                ActionScheduler::HOOK_EXPIRE_SUBSCRIPTION       => 'Expire Subscription',
                ActionScheduler::HOOK_RESUME_SUBSCRIPTION       => 'Resume Subscription',
                ActionScheduler::HOOK_PROCESS_SKIPPED_CYCLE     => 'Process Skipped Cycle',
                ActionScheduler::HOOK_SEND_RENEWAL_REMINDER     => 'Renewal Reminder Email',
                ActionScheduler::HOOK_SEND_PAYMENT_FAILED       => 'Payment Failed Email',
                ActionScheduler::HOOK_SEND_EXPIRING_SOON        => 'Expiring Soon Email',
                ActionScheduler::HOOK_SEND_CREDIT_EXPIRING      => 'Credit Expiring Email',
                ActionScheduler::HOOK_CLEANUP_OLD_DATA           => 'Cleanup Old Data',
                ActionScheduler::HOOK_EXPIRE_STORE_CREDITS       => 'Expire Store Credits',
                ActionScheduler::HOOK_CLEANUP_WEBHOOK_EVENTS     => 'Cleanup Webhook Events',
                ActionScheduler::HOOK_GATEWAY_RECONCILE          => 'Gateway Reconcile',
                ActionScheduler::HOOK_BACKFILL_RETENTION_LOGS    => 'Backfill Retention Logs',
            ];
        }

        return self::$hook_labels[$hook] ?? $this->formatHookName($hook);
    }

    /**
     * Format an unknown hook name into a readable label
     *
     * @param string $hook Hook name.
     *
     * @return string Formatted label.
     */
    private function formatHookName(string $hook): string
    {
        $name = str_replace('arraysubs_', '', $hook);
        return ucwords(str_replace('_', ' ', $name));
    }

    /**
     * Fetch an action object from the Action Scheduler store
     *
     * @param int $action_id Action ID.
     *
     * @return \ActionScheduler_Action|null Action object or null.
     */
    private function fetchActionFromStore(int $action_id)
    {
        if (! function_exists('ActionScheduler')) {
            return null;
        }

        try {
            $store  = \ActionScheduler::store();
            $action = $store->fetch_action($action_id);
            return $action ?: null;
        } catch (\Exception $e) {
            return null;
        }
    }
}
