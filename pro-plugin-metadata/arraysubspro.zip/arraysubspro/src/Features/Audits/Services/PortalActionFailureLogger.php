<?php

/**
 * Portal Action Failure Logger
 *
 * @package ArraySubsPro\Features\Audits\Services
 */

namespace ArraySubsPro\Features\Audits\Services;

defined('ABSPATH') || exit;

use WP_Error;
use WP_REST_Request;
use WP_REST_Response;

/**
 * Records failed customer portal REST actions for troubleshooting.
 */
class PortalActionFailureLogger
{
    /**
     * Enable auto-loading.
     *
     * @var bool
     */
    public static $loadable = true;

    /**
     * Constructor.
     */
    public function __construct()
    {
        add_filter('rest_request_after_callbacks', [$this, 'recordFailure'], 10, 3);
    }

    /**
     * Record failed customer portal actions.
     *
     * @param mixed           $response REST response or error.
     * @param array<mixed>    $handler  Route handler.
     * @param WP_REST_Request $request  REST request.
     * @return mixed
     */
    public function recordFailure($response, $handler, $request)
    {
        unset($handler);

        if (! $request instanceof WP_REST_Request || 'POST' !== $request->get_method()) {
            return $response;
        }

        $route = $request->get_route();
        if (! preg_match('#^/arraysubs/v1/my-subscriptions/(?P<subscription_id>\d+)/(?P<action>[a-z0-9-]+)$#', $route, $matches)) {
            return $response;
        }

        $failure = $this->extractFailure($response);
        if (empty($failure)) {
            return $response;
        }

        $subscription_id = absint($matches['subscription_id']);
        if ($subscription_id <= 0) {
            return $response;
        }

        $this->createFailureNote(
            $subscription_id,
            sanitize_key($matches['action']),
            $route,
            $request,
            $failure
        );

        return $response;
    }

    /**
     * Extract failure details from the REST response.
     *
     * @param mixed $response REST response or error.
     * @return array{code:string,message:string,http_status:int}|null
     */
    private function extractFailure($response): ?array
    {
        if (is_wp_error($response)) {
            $code = (string) $response->get_error_code();
            $data = $response->get_error_data($code);

            return [
                'code'        => $code,
                'message'     => (string) $response->get_error_message($code),
                'http_status' => is_array($data) ? absint($data['status'] ?? 500) : 500,
            ];
        }

        if ($response instanceof WP_REST_Response && $response->get_status() >= 400) {
            $data = $response->get_data();

            return [
                'code'        => is_array($data) ? sanitize_key((string) ($data['code'] ?? 'portal_action_failed')) : 'portal_action_failed',
                'message'     => is_array($data) ? wp_strip_all_tags((string) ($data['message'] ?? '')) : '',
                'http_status' => $response->get_status(),
            ];
        }

        return null;
    }

    /**
     * Create the troubleshooting note row.
     *
     * @param int             $subscription_id Subscription ID.
     * @param string          $action          Portal action key.
     * @param string          $route           REST route.
     * @param WP_REST_Request $request         REST request.
     * @param array<string,mixed> $failure     Failure details.
     * @return int|WP_Error
     */
    private function createFailureNote(
        int $subscription_id,
        string $action,
        string $route,
        WP_REST_Request $request,
        array $failure
    ) {
        $customer_id = get_current_user_id();
        $user        = $customer_id > 0 ? get_user_by('id', $customer_id) : false;
        $email       = $user instanceof \WP_User ? $user->user_email : '';
        $label       = $this->getActionLabel($action);
        $status      = absint($failure['http_status'] ?? 500);
        $code        = sanitize_key((string) ($failure['code'] ?? 'portal_action_failed'));
        $message     = wp_strip_all_tags((string) ($failure['message'] ?? ''));
        $summary     = sprintf(
            /* translators: 1: action label, 2: error code, 3: HTTP status. */
            __('Portal action failed: %1$s returned %2$s (HTTP %3$d).', 'arraysubspro'),
            $label,
            $code,
            $status
        );

        if ($message !== '') {
            $summary .= ' ' . $message;
        }

        $note_id = wp_insert_post(
            [
                'post_type'    => 'arraysubs_sub_note',
                'post_status'  => 'publish',
                'post_content' => wp_kses_post($summary),
                'post_author'  => $customer_id,
                'post_parent'  => 0,
            ],
            true
        );

        if (is_wp_error($note_id)) {
            return $note_id;
        }

        update_post_meta($note_id, '_subscription_id', $subscription_id);
        update_post_meta($note_id, '_note_type', 'portal_action_failure');
        update_post_meta($note_id, '_added_by', $customer_id);
        update_post_meta($note_id, '_is_system', false);
        update_post_meta($note_id, '_audit_entity', 'subscription');
        update_post_meta($note_id, '_event_type', 'portal_action_failed');
        update_post_meta($note_id, '_portal_action_status', 'open');
        update_post_meta($note_id, '_portal_action_action', $action);
        update_post_meta($note_id, '_portal_action_label', $label);
        update_post_meta($note_id, '_portal_action_error_code', $code);
        update_post_meta($note_id, '_portal_action_http_status', $status);
        update_post_meta($note_id, '_portal_action_message', $message);
        update_post_meta($note_id, '_portal_action_route', sanitize_text_field($route));
        update_post_meta($note_id, '_portal_action_method', sanitize_text_field($request->get_method()));
        update_post_meta($note_id, '_portal_action_customer_id', $customer_id);
        update_post_meta($note_id, '_portal_action_customer_email', sanitize_email($email));
        update_post_meta($note_id, '_portal_action_context', wp_json_encode($this->getRequestContext($request)));
        update_post_meta($note_id, '_portal_action_suggested_resolution', $this->getSuggestedResolution($action, $code));

        return $note_id;
    }

    /**
     * Get a customer-facing action label.
     *
     * @param string $action Action key.
     * @return string
     */
    private function getActionLabel(string $action): string
    {
        $labels = [
            'cancel'            => __('Cancel', 'arraysubspro'),
            'undo-cancellation' => __('Undo Cancellation', 'arraysubspro'),
            'reactivate'        => __('Reactivate', 'arraysubspro'),
            'retry-payment'     => __('Retry Payment', 'arraysubspro'),
            'shipping-address'  => __('Shipping Address', 'arraysubspro'),
            'skip'              => __('Skip Renewal', 'arraysubspro'),
            'undo-skip'         => __('Undo Skip', 'arraysubspro'),
            'pause'             => __('Pause', 'arraysubspro'),
            'resume'            => __('Resume', 'arraysubspro'),
            'auto-renew'        => __('Auto Renew', 'arraysubspro'),
        ];

        return $labels[$action] ?? ucwords(str_replace('-', ' ', $action));
    }

    /**
     * Build sanitized request context.
     *
     * @param WP_REST_Request $request REST request.
     * @return array<string,mixed>
     */
    private function getRequestContext(WP_REST_Request $request): array
    {
        $params = $request->get_params();
        unset($params['_wpnonce'], $params['nonce']);

        return [
            'params' => $this->sanitizeContextValue($params),
            'body'   => $this->sanitizeContextValue($request->get_json_params()),
        ];
    }

    /**
     * Sanitize context recursively.
     *
     * @param mixed $value Raw value.
     * @return mixed
     */
    private function sanitizeContextValue($value)
    {
        if (is_array($value)) {
            $sanitized = [];

            foreach ($value as $key => $item) {
                $sanitized[sanitize_key((string) $key)] = $this->sanitizeContextValue($item);
            }

            return $sanitized;
        }

        if (is_bool($value) || is_int($value) || is_float($value) || null === $value) {
            return $value;
        }

        return sanitize_text_field((string) $value);
    }

    /**
     * Get suggested resolution text.
     *
     * @param string $action Action key.
     * @param string $code   Error code.
     * @return string
     */
    private function getSuggestedResolution(string $action, string $code): string
    {
        if ('cancel' === $action && 'cancellation_disabled' === $code) {
            return __('Re-enable Allow Customers to Cancel in General Settings, or leave the row open if cancellation should remain disabled.', 'arraysubspro');
        }

        if ('reactivate' === $action && 'reactivation_disabled' === $code) {
            return __('Re-enable customer reactivation in General Settings, or confirm the customer should contact support.', 'arraysubspro');
        }

        if ('retry-payment' === $action) {
            return __('Review the renewal failure, payment method, and gateway status before retrying again.', 'arraysubspro');
        }

        return __('Review the subscription, customer permissions, and related feature settings before marking this failure resolved.', 'arraysubspro');
    }
}
