<?php

/**
 * Audits Provider
 *
 * Entry point for the Audits feature.
 * Provides activity audit logs and scheduled-job visibility.
 *
 * @package ArraySubsPro\Features\Audits
 */

namespace ArraySubsPro\Features\Audits;

defined('ABSPATH') || exit;

use ArraySubs\Supports\Abstracts\AbstractLoader;

/**
 * Audits feature entry point
 */
class Provider extends AbstractLoader
{
    /**
     * Constructor
     */
    public function __construct()
    {
        $this->classLoader([
            plugin_dir_path(__FILE__) . 'Services',
            plugin_dir_path(__FILE__) . 'REST',
        ]);
    }
}
