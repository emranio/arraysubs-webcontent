<?php

/**
 * Renewal Failure Troubleshooting REST Controller
 *
 * @package ArraySubsPro\Features\Audits\REST
 */

namespace ArraySubsPro\Features\Audits\REST;

defined('ABSPATH') || exit;

use ArraySubs\Features\RecurringBilling\Services\RenewalProcessor;
use ArraySubs\Supports\BaseRestController;
use WP_Error;
use WP_Post;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;

/**
 * Renewal failure troubleshooting REST controller.
 */
class RenewalFailureController extends BaseRestController
{
    /**
     * Enable auto-loading.
     *
     * @var bool
     */
    public static $loadable = true;

    /**
     * REST namespace.
     *
     * @var string
     */
    protected $namespace = 'arraysubs/v1';

    /**
     * Constructor.
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Register REST routes.
     *
     * @return void
     */
    public function registerRoutes(): void
    {
        register_rest_route($this->namespace, '/audits/renewal-failures', [
            [
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => [$this, 'getFailures'],
                'permission_callback' => [$this, 'checkAdminPermission'],
                'args'                => [
                    'page'     => [
                        'type'              => 'integer',
                        'default'           => 1,
                        'sanitize_callback' => 'absint',
                    ],
                    'per_page' => [
                        'type'              => 'integer',
                        'default'           => 30,
                        'sanitize_callback' => 'absint',
                    ],
                ],
            ],
        ]);

        register_rest_route($this->namespace, '/audits/renewal-failures/(?P<subscription_id>\d+)/retry', [
            [
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => [$this, 'retryFailure'],
                'permission_callback' => [$this, 'checkAdminPermission'],
                'args'                => [
                    'subscription_id' => [
                        'type'              => 'integer',
                        'required'          => true,
                        'sanitize_callback' => 'absint',
                    ],
                ],
            ],
        ]);

        register_rest_route($this->namespace, '/audits/renewal-failures/(?P<subscription_id>\d+)/resolve', [
            [
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => [$this, 'resolveFailure'],
                'permission_callback' => [$this, 'checkAdminPermission'],
                'args'                => [
                    'subscription_id' => [
                        'type'              => 'integer',
                        'required'          => true,
                        'sanitize_callback' => 'absint',
                    ],
                ],
            ],
        ]);
    }

    /**
     * Check admin permission.
     *
     * @return bool
     */
    public function checkAdminPermission(): bool
    {
        if (! is_user_logged_in()) {
            return false;
        }

        return current_user_can('manage_woocommerce') || current_user_can('manage_options');
    }

    /**
     * Get active renewal failures.
     *
     * @param WP_REST_Request $request Request object.
     * @return WP_REST_Response
     */
    public function getFailures(WP_REST_Request $request): WP_REST_Response
    {
        $page     = max(1, absint($request->get_param('page')));
        $per_page = min(100, max(1, absint($request->get_param('per_page'))));

        $query = new \WP_Query([
            'post_type'      => 'arraysubs_data',
            'post_status'    => function_exists('arraysubs_get_subscription_statuses')
                ? array_keys(arraysubs_get_subscription_statuses())
                : 'any',
            'posts_per_page' => $per_page,
            'paged'          => $page,
            'orderby'        => 'modified',
            'order'          => 'DESC',
            'meta_query'     => [ // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Troubleshooting screen must filter recorded failure meta.
                'relation' => 'AND',
                [
                    'key'     => '_last_payment_failure',
                    'compare' => 'EXISTS',
                ],
                [
                    'key'     => '_last_payment_failure',
                    'value'   => '',
                    'compare' => '!=',
                ],
                [
                    'relation' => 'OR',
                    [
                        'key'     => '_renewal_failure_resolved',
                        'compare' => 'NOT EXISTS',
                    ],
                    [
                        'key'     => '_renewal_failure_resolved',
                        'value'   => 'yes',
                        'compare' => '!=',
                    ],
                ],
            ],
        ]);

        $failures = [];
        foreach ($query->posts as $subscription) {
            if ($subscription instanceof WP_Post) {
                $failures[] = $this->formatFailure($subscription);
            }
        }

        return arraysubs_rest_response([
            'failures'    => $failures,
            'total'       => (int) $query->found_posts,
            'total_pages' => (int) $query->max_num_pages,
            'page'        => $page,
        ]);
    }

    /**
     * Retry a failed renewal.
     *
     * @param WP_REST_Request $request Request object.
     * @return WP_REST_Response|WP_Error
     */
    public function retryFailure(WP_REST_Request $request)
    {
        $subscription = $this->getSubscriptionFromRequest($request);
        if (is_wp_error($subscription)) {
            return $subscription;
        }

        delete_post_meta($subscription->ID, '_renewal_failure_resolved');
        delete_post_meta($subscription->ID, '_renewal_failure_resolved_at');
        delete_post_meta($subscription->ID, '_renewal_failure_resolved_by');

        $processor = new RenewalProcessor();
        $result    = $processor->manualRetry($subscription->ID, 'admin:' . get_current_user_id());
        $fresh     = arraysubs_get_subscription($subscription->ID);
        $failure   = $fresh instanceof WP_Post && empty($result['success'])
            ? $this->formatFailure($fresh)
            : null;

        return arraysubs_rest_response(
            [
                'result'  => [
                    'success'  => ! empty($result['success']),
                    'status'   => (string) ($result['status'] ?? ''),
                    'order_id' => (int) ($result['order_id'] ?? 0),
                ],
                'failure' => $failure,
            ],
            200,
            (string) ($result['message'] ?? __('Renewal retry completed.', 'arraysubspro'))
        );
    }

    /**
     * Mark a renewal failure as administratively resolved.
     *
     * @param WP_REST_Request $request Request object.
     * @return WP_REST_Response|WP_Error
     */
    public function resolveFailure(WP_REST_Request $request)
    {
        $subscription = $this->getSubscriptionFromRequest($request);
        if (is_wp_error($subscription)) {
            return $subscription;
        }

        $order    = $this->getLatestRenewalOrder($subscription->ID);
        $order_id = $order instanceof \WC_Order ? $order->get_id() : 0;
        $now      = current_time('mysql', true);
        $user_id  = get_current_user_id();

        update_post_meta($subscription->ID, '_renewal_failure_resolved', 'yes');
        update_post_meta($subscription->ID, '_renewal_failure_resolved_at', $now);
        update_post_meta($subscription->ID, '_renewal_failure_resolved_by', $user_id);

        if (function_exists('arraysubs_add_subscription_note')) {
            arraysubs_add_subscription_note(
                $subscription->ID,
                sprintf(
                    /* translators: %d: order ID. */
                    __('Renewal failure marked resolved by admin for Order #%d. This is an administrative dismissal and does not change the order payment status.', 'arraysubspro'),
                    $order_id
                ),
                'private',
                $user_id,
                [
                    [
                        'field'          => 'renewal_failure_status',
                        'label'          => __('Renewal failure status', 'arraysubspro'),
                        'previous_value' => __('Open', 'arraysubspro'),
                        'changed_value'  => __('Resolved', 'arraysubspro'),
                    ],
                ],
                'subscription',
                'renewal_failure_resolved'
            );
        }

        return arraysubs_rest_response(
            [
                'subscription_id' => $subscription->ID,
                'order_id'        => $order_id,
                'resolved_at'     => $now,
            ],
            200,
            __('Renewal failure marked as resolved.', 'arraysubspro')
        );
    }

    /**
     * Get a subscription from a route request.
     *
     * @param WP_REST_Request $request Request object.
     * @return WP_Post|WP_Error
     */
    private function getSubscriptionFromRequest(WP_REST_Request $request)
    {
        $subscription_id = absint($request->get_param('subscription_id'));
        $subscription    = arraysubs_get_subscription($subscription_id);

        if (! $subscription instanceof WP_Post) {
            return new WP_Error(
                'subscription_not_found',
                __('Subscription not found.', 'arraysubspro'),
                ['status' => 404]
            );
        }

        return $subscription;
    }

    /**
     * Format a subscription failure row.
     *
     * @param WP_Post $subscription Subscription post.
     * @return array<string, mixed>
     */
    private function formatFailure(WP_Post $subscription): array
    {
        $subscription_id = $subscription->ID;
        $order           = $this->getLatestRenewalOrder($subscription_id);
        $customer_id     = (int) get_post_meta($subscription_id, '_customer_id', true);
        $customer_email  = (string) get_post_meta($subscription_id, '_customer_email', true);
        $customer_name   = '';
        $user            = $customer_id > 0 ? get_user_by('id', $customer_id) : false;

        if ($user instanceof \WP_User) {
            $customer_name  = $user->display_name;
            $customer_email = $customer_email ?: $user->user_email;
        }

        if ('' === $customer_name) {
            $customer_name = $customer_email ?: __('Unknown customer', 'arraysubspro');
        }

        $category = (string) get_post_meta($subscription_id, '_last_payment_failure_category', true);
        $reason   = (string) get_post_meta($subscription_id, '_last_payment_failure_reason', true);

        return [
            'subscription_id'       => $subscription_id,
            'subscription_number'   => $subscription_id,
            'subscription_status'   => $subscription->post_status,
            'subscription_label'    => function_exists('arraysubs_get_status_label')
                ? arraysubs_get_status_label($subscription->post_status)
                : $subscription->post_status,
            'subscription_url'      => '#/subscriptions/detail/' . $subscription_id,
            'customer_id'           => $customer_id,
            'customer_name'         => $customer_name,
            'customer_email'        => $customer_email,
            'failure_category'      => $category ?: 'unknown',
            'failure_label'         => function_exists('arraysubs_describe_payment_failure_category')
                ? arraysubs_describe_payment_failure_category($category ?: 'unknown')
                : ($category ?: __('Unknown', 'arraysubspro')),
            'failure_reason'        => wp_strip_all_tags($reason),
            'failed_at'             => (string) get_post_meta($subscription_id, '_last_payment_failure', true),
            'failed_at_timestamp'   => $this->timestampFromMeta(get_post_meta($subscription_id, '_last_payment_failure', true)),
            'last_attempted_at'     => (string) get_post_meta($subscription_id, '_payment_retry_last_attempt_at', true),
            'last_attempted_timestamp' => $this->timestampFromMeta(get_post_meta($subscription_id, '_payment_retry_last_attempt_at', true)),
            'next_retry_at'         => (string) get_post_meta($subscription_id, '_payment_retry_next_attempt_at', true),
            'next_retry_timestamp'  => $this->timestampFromMeta(get_post_meta($subscription_id, '_payment_retry_next_attempt_at', true)),
            'retry_attempts'        => (int) get_post_meta($subscription_id, '_payment_retry_attempts', true),
            'gateway'               => (string) get_post_meta($subscription_id, '_payment_gateway', true),
            'order_id'              => $order instanceof \WC_Order ? $order->get_id() : 0,
            'order_status'          => $order instanceof \WC_Order ? $order->get_status() : '',
            'order_status_label'    => $order instanceof \WC_Order ? wc_get_order_status_name($order->get_status()) : '',
            'order_total'           => $order instanceof \WC_Order ? $order->get_formatted_order_total() : '',
            'order_url'             => $order instanceof \WC_Order ? $order->get_edit_order_url() : '',
            'can_retry'             => in_array($subscription->post_status, ['arraysubs-active', 'arraysubs-trial', 'arraysubs-on-hold'], true),
        ];
    }

    /**
     * Find the latest unpaid renewal order for a subscription.
     *
     * @param int $subscription_id Subscription ID.
     * @return \WC_Order|null
     */
    private function getLatestRenewalOrder(int $subscription_id): ?\WC_Order
    {
        $orders = wc_get_orders([
            'limit'      => 1,
            'status'     => ['failed', 'pending', 'on-hold'],
            'orderby'    => 'date',
            'order'      => 'DESC',
            'meta_query' => [ // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Renewal order lookup requires ArraySubs order meta.
                'relation' => 'AND',
                [
                    'key'   => '_is_renewal_order',
                    'value' => 'yes',
                ],
                [
                    'key'   => '_subscription_id',
                    'value' => $subscription_id,
                ],
            ],
        ]);

        $order = ! empty($orders) ? reset($orders) : null;

        return $order instanceof \WC_Order ? $order : null;
    }

    /**
     * Convert stored meta date values to UTC timestamps.
     *
     * @param mixed $value Stored meta value.
     * @return int|null
     */
    private function timestampFromMeta($value): ?int
    {
        if (empty($value)) {
            return null;
        }

        if (is_numeric($value)) {
            return (int) $value;
        }

        return arraysubs_get_datetime_timestamp_from_string(
            (string) $value,
            new \DateTimeZone('UTC')
        );
    }
}
