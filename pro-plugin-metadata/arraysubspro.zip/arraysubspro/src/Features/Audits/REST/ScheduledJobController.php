<?php

/**
 * Scheduled-Job Logs REST Controller
 *
 * REST API endpoint for querying scheduled-job execution logs.
 *
 * @package ArraySubsPro\Features\Audits\REST
 */

namespace ArraySubsPro\Features\Audits\REST;

defined('ABSPATH') || exit;

use ArraySubs\Supports\BaseRestController;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;

/**
 * Scheduled-Job logs REST controller
 */
class ScheduledJobController extends BaseRestController
{
    /**
     * Enable auto-loading
     *
     * @var bool
     */
    public static $loadable = true;

    /**
     * REST namespace
     *
     * @var string
     */
    protected $namespace = 'arraysubs/v1';

    /**
     * Constructor
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Register REST routes
     */
    public function registerRoutes(): void
    {
        register_rest_route($this->namespace, '/audits/scheduled-job-logs', [
            [
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => [$this, 'getJobLogs'],
                'permission_callback' => [$this, 'checkAdminPermission'],
                'args'                => [
                    'page'      => [
                        'type'              => 'integer',
                        'default'           => 1,
                        'sanitize_callback' => 'absint',
                    ],
                    'per_page'  => [
                        'type'              => 'integer',
                        'default'           => 30,
                        'sanitize_callback' => 'absint',
                    ],
                    'date_from' => [
                        'type'              => 'string',
                        'default'           => '',
                        'sanitize_callback' => 'sanitize_text_field',
                    ],
                    'date_to'   => [
                        'type'              => 'string',
                        'default'           => '',
                        'sanitize_callback' => 'sanitize_text_field',
                    ],
                ],
            ],
        ]);
    }

    /**
     * Check admin permission
     *
     * @return bool
     */
    public function checkAdminPermission(): bool
    {
        if (! is_user_logged_in()) {
            return false;
        }

        return current_user_can('manage_woocommerce') || current_user_can('manage_options');
    }

    /**
     * Get scheduled-job execution logs
     *
     * @param WP_REST_Request $request Request object.
     *
     * @return WP_REST_Response
     */
    public function getJobLogs(WP_REST_Request $request): WP_REST_Response
    {
        $page      = max(1, absint($request->get_param('page')));
        $per_page  = min(100, max(1, absint($request->get_param('per_page'))));
        $date_from = sanitize_text_field($request->get_param('date_from'));
        $date_to   = sanitize_text_field($request->get_param('date_to'));

        $args = [
            'post_type'      => 'arraysubs_sub_note',
            'post_status'    => 'publish',
            'posts_per_page' => $per_page,
            'paged'          => $page,
            'orderby'        => 'date',
            'order'          => 'DESC',
            'meta_query'     => [ // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Required for filtering by note type.
                [
                    'key'     => '_note_type',
                    'value'   => 'scheduled_job',
                    'compare' => '=',
                ],
            ],
        ];

        $this->applyDateQuery($args, $date_from, $date_to);

        $query = new \WP_Query($args);

        $logs = [];
        foreach ($query->posts as $note) {
            $logs[] = $this->formatJobLog($note);
        }

        return arraysubs_rest_response(
            [
                'logs'        => $logs,
                'total'       => (int) $query->found_posts,
                'total_pages' => (int) $query->max_num_pages,
                'page'        => $page,
            ]
        );
    }

    /**
     * Format a scheduled-job log note for API response
     *
     * @param \WP_Post $note The note post.
     *
     * @return array Formatted log entry.
     */
    private function formatJobLog(\WP_Post $note): array
    {
        $date_gmt = $note->post_date_gmt;
        if (empty($date_gmt) || '0000-00-00 00:00:00' === $date_gmt) {
            $date_gmt = get_gmt_from_date($note->post_date);
        }

        $date_timestamp = $date_gmt
            ? arraysubs_get_datetime_timestamp_from_string($date_gmt, new \DateTimeZone('UTC'))
            : null;

        $job_args_raw = get_post_meta($note->ID, '_job_args', true);
        $job_args     = $job_args_raw ? json_decode($job_args_raw, true) : [];

        $subscription_id = (int) get_post_meta($note->ID, '_subscription_id', true);

        return [
            'id'              => $note->ID,
            'content'         => $note->post_content,
            'date'            => $note->post_date,
            'date_gmt'        => $date_gmt,
            'date_timestamp'  => $date_timestamp,
            'date_display'    => $date_gmt ? arraysubs_format_date_local($date_gmt) : '',
            'job_hook'        => get_post_meta($note->ID, '_job_hook', true) ?: '',
            'job_status'      => get_post_meta($note->ID, '_job_status', true) ?: 'success',
            'job_group'       => get_post_meta($note->ID, '_job_group', true) ?: '',
            'job_error'       => get_post_meta($note->ID, '_job_error', true) ?: '',
            'job_args'        => is_array($job_args) ? $job_args : [],
            'subscription_id' => $subscription_id,
        ];
    }

    /**
     * Apply date query filters
     *
     * @param array  $args      WP_Query arguments (passed by reference).
     * @param string $date_from Start date (Y-m-d).
     * @param string $date_to   End date (Y-m-d).
     */
    private function applyDateQuery(array &$args, string $date_from, string $date_to): void
    {
        $date_query = [];

        if ($date_from && preg_match('/^\d{4}-\d{2}-\d{2}$/', $date_from)) {
            $date_query[] = [
                'after'     => $date_from,
                'inclusive' => true,
            ];
        }

        if ($date_to && preg_match('/^\d{4}-\d{2}-\d{2}$/', $date_to)) {
            $date_query[] = [
                'before'    => $date_to . ' 23:59:59',
                'inclusive' => true,
            ];
        }

        if (! empty($date_query)) {
            $args['date_query'] = $date_query;
        }
    }
}
