<?php

/**
 * Audit REST Controller
 *
 * REST API endpoint for querying subscription activity audit logs
 * across all subscriptions with filtering and pagination.
 *
 * @package ArraySubsPro\Features\Audits\REST
 */

namespace ArraySubsPro\Features\Audits\REST;

defined('ABSPATH') || exit;

use ArraySubs\Supports\BaseRestController;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;

/**
 * Audit activity logs REST controller
 */
class AuditController extends BaseRestController
{
    /**
     * Enable auto-loading
     *
     * @var bool
     */
    public static $loadable = true;

    /**
     * REST namespace
     *
     * @var string
     */
    protected $namespace = 'arraysubs/v1';

    /**
     * Temporary WHERE conditions for the posts_where filter
     *
     * @var array
     */
    private array $content_conditions = [];

    /**
     * Constructor
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Register REST routes
     */
    public function registerRoutes(): void
    {
        register_rest_route($this->namespace, '/audits/activity-logs', [
            [
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => [$this, 'getActivityLogs'],
                'permission_callback' => [$this, 'checkAdminPermission'],
                'args'                => [
                    'page'        => [
                        'type'              => 'integer',
                        'default'           => 1,
                        'sanitize_callback' => 'absint',
                    ],
                    'per_page'    => [
                        'type'              => 'integer',
                        'default'           => 30,
                        'sanitize_callback' => 'absint',
                    ],
                    'author_role' => [
                        'type'              => 'string',
                        'default'           => '',
                        'sanitize_callback' => 'sanitize_text_field',
                    ],
                    'entity'      => [
                        'type'              => 'string',
                        'default'           => '',
                        'sanitize_callback' => 'sanitize_text_field',
                    ],
                    'date_from'   => [
                        'type'              => 'string',
                        'default'           => '',
                        'sanitize_callback' => 'sanitize_text_field',
                    ],
                    'date_to'     => [
                        'type'              => 'string',
                        'default'           => '',
                        'sanitize_callback' => 'sanitize_text_field',
                    ],
                    'search'      => [
                        'type'              => 'string',
                        'default'           => '',
                        'sanitize_callback' => 'sanitize_text_field',
                    ],
                ],
            ],
        ]);

        register_rest_route($this->namespace, '/audits/logging-settings', [
            [
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => [$this, 'getLoggingSettings'],
                'permission_callback' => [$this, 'checkAdminPermission'],
            ],
            [
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => [$this, 'updateLoggingSettings'],
                'permission_callback' => [$this, 'checkAdminPermission'],
                'args'                => [
                    'product'  => [
                        'type'              => 'boolean',
                        'sanitize_callback' => 'rest_sanitize_boolean',
                    ],
                    'coupon'   => [
                        'type'              => 'boolean',
                        'sanitize_callback' => 'rest_sanitize_boolean',
                    ],
                    'email'    => [
                        'type'              => 'boolean',
                        'sanitize_callback' => 'rest_sanitize_boolean',
                    ],
                    'settings' => [
                        'type'              => 'boolean',
                        'sanitize_callback' => 'rest_sanitize_boolean',
                    ],
                ],
            ],
        ]);
    }

    /**
     * Check admin permission
     *
     * @return bool
     */
    public function checkAdminPermission(): bool
    {
        if (! is_user_logged_in()) {
            return false;
        }

        return current_user_can('manage_woocommerce') || current_user_can('manage_options');
    }

    /**
     * Get activity logs with filtering and pagination
     *
     * @param WP_REST_Request $request Request object.
     *
     * @return WP_REST_Response
     */
    public function getActivityLogs(WP_REST_Request $request): WP_REST_Response
    {
        $page        = max(1, absint($request->get_param('page')));
        $per_page    = min(100, max(1, absint($request->get_param('per_page'))));
        $author_role = sanitize_text_field($request->get_param('author_role'));
        $entity      = sanitize_text_field($request->get_param('entity'));
        $date_from   = sanitize_text_field($request->get_param('date_from'));
        $date_to     = sanitize_text_field($request->get_param('date_to'));
        $search      = sanitize_text_field($request->get_param('search'));

        $valid_entities = ['subscription', 'member', 'product', 'order', 'coupon', 'email', 'settings', 'other'];
        if ($entity && ! in_array($entity, $valid_entities, true)) {
            $entity = '';
        }

        $valid_roles = ['system', 'admin', 'customer', 'gateway'];
        if ($author_role && ! in_array($author_role, $valid_roles, true)) {
            $author_role = '';
        }

        $args = [
            'post_type'      => 'arraysubs_sub_note',
            'post_status'    => 'publish',
            'posts_per_page' => $per_page,
            'paged'          => $page,
            'orderby'        => 'date',
            'order'          => 'DESC',
            'meta_query'     => [ // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Required for filtering audit logs by role metadata.
                [
                    'relation' => 'OR',
                    [
                        'key'     => '_note_type',
                        'value'   => 'scheduled_job',
                        'compare' => '!=',
                    ],
                    [
                        'key'     => '_note_type',
                        'compare' => 'NOT EXISTS',
                    ],
                ],
            ],
        ];

        $this->applyAuthorRoleMetaQuery($args, $author_role);
        $this->applyDateQuery($args, $date_from, $date_to);

        $this->content_conditions = [];
        $this->buildContentConditions($author_role, $entity, $search);

        if (! empty($this->content_conditions)) {
            add_filter('posts_where', [$this, 'addContentWhereConditions']);
        }

        $query = new \WP_Query($args);

        remove_filter('posts_where', [$this, 'addContentWhereConditions']);
        $this->content_conditions = [];

        $logs = [];
        foreach ($query->posts as $note) {
            $logs[] = arraysubs_format_note($note);
        }

        return arraysubs_rest_response(
            [
                'logs'        => $logs,
                'total'       => (int) $query->found_posts,
                'total_pages' => (int) $query->max_num_pages,
                'page'        => $page,
            ]
        );
    }

    /**
     * Filter callback for posts_where to add content-based conditions
     *
     * @param string $where Existing WHERE clause.
     *
     * @return string Modified WHERE clause.
     */
    public function addContentWhereConditions(string $where): string
    {
        foreach ($this->content_conditions as $condition) {
            $where .= ' AND ' . $condition;
        }
        return $where;
    }

    /**
     * Apply author role meta_query filters
     *
     * @param array  $args        WP_Query arguments (passed by reference).
     * @param string $author_role Author role filter value.
     */
    private function applyAuthorRoleMetaQuery(array &$args, string $author_role): void
    {
        if (! $author_role) {
            return;
        }

        switch ($author_role) {
            case 'system':
            case 'gateway':
                $args['meta_query'][] = [
                    'key'     => '_is_system',
                    'value'   => '1',
                    'compare' => '=',
                ];
                break;

            case 'admin':
                $admin_ids = $this->getAdminUserIds();
                if (empty($admin_ids)) {
                    $args['post__in'] = [0];
                    return;
                }
                $args['meta_query']['relation'] = 'AND';
                $args['meta_query'][]           = [
                    'relation' => 'OR',
                    [
                        'key'     => '_is_system',
                        'value'   => '1',
                        'compare' => '!=',
                    ],
                    [
                        'key'     => '_is_system',
                        'compare' => 'NOT EXISTS',
                    ],
                ];
                $args['meta_query'][] = [
                    'key'     => '_added_by',
                    'value'   => $admin_ids,
                    'compare' => 'IN',
                ];
                break;

            case 'customer':
                $admin_ids                      = $this->getAdminUserIds();
                $args['meta_query']['relation'] = 'AND';
                $args['meta_query'][]           = [
                    'relation' => 'OR',
                    [
                        'key'     => '_is_system',
                        'value'   => '1',
                        'compare' => '!=',
                    ],
                    [
                        'key'     => '_is_system',
                        'compare' => 'NOT EXISTS',
                    ],
                ];
                $args['meta_query'][] = [
                    'key'     => '_added_by',
                    'value'   => '0',
                    'compare' => '>',
                    'type'    => 'NUMERIC',
                ];
                if (! empty($admin_ids)) {
                    $args['meta_query'][] = [
                        'key'     => '_added_by',
                        'value'   => $admin_ids,
                        'compare' => 'NOT IN',
                    ];
                }
                break;
        }
    }

    /**
     * Apply date query filters
     *
     * @param array  $args      WP_Query arguments (passed by reference).
     * @param string $date_from Start date (Y-m-d format).
     * @param string $date_to   End date (Y-m-d format).
     */
    private function applyDateQuery(array &$args, string $date_from, string $date_to): void
    {
        $date_query = [];

        if ($date_from && preg_match('/^\d{4}-\d{2}-\d{2}$/', $date_from)) {
            $date_query[] = [
                'after'     => $date_from,
                'inclusive' => true,
            ];
        }

        if ($date_to && preg_match('/^\d{4}-\d{2}-\d{2}$/', $date_to)) {
            $date_query[] = [
                'before'    => $date_to . ' 23:59:59',
                'inclusive' => true,
            ];
        }

        if (! empty($date_query)) {
            $args['date_query'] = $date_query;
        }
    }

    /**
     * Build content-based SQL WHERE conditions for entity and author role
     *
     * @param string $author_role Author role filter.
     * @param string $entity      Entity type filter.
     * @param string $search      Search text filter.
     */
    private function buildContentConditions(string $author_role, string $entity, string $search): void
    {
        global $wpdb;

        if ('system' === $author_role) {
            $this->content_conditions[] = $wpdb->prepare(
                "{$wpdb->posts}.post_content NOT LIKE %s",
                '%' . $wpdb->esc_like('[Gateway:') . '%'
            );
        }

        if ('gateway' === $author_role) {
            $this->content_conditions[] = $wpdb->prepare(
                "{$wpdb->posts}.post_content LIKE %s",
                '%' . $wpdb->esc_like('[Gateway:') . '%'
            );
        }

        if ($entity) {
            $entity_condition = $this->getEntityFilterSqlCondition($entity);
            if ($entity_condition) {
                $this->content_conditions[] = $entity_condition;
            }
        }

        if ($search) {
            $this->content_conditions[] = $wpdb->prepare(
                "{$wpdb->posts}.post_content LIKE %s",
                '%' . $wpdb->esc_like($search) . '%'
            );
        }
    }

    /**
     * Classify a note's entity type based on content patterns
     *
     * @param string $content Raw note content text.
     *
     * @return string Entity type identifier.
     */
    private function classifyEntity(string $content): string
    {
        $lower = strtolower($content);

        if (
            str_contains($lower, 'settings updated')
            || str_contains($lower, 'setting updated')
            || str_contains($lower, 'auto-renewal')
            || str_contains($lower, 'dates updated')
            || str_contains($lower, 'address updated')
        ) {
            return 'settings';
        }

        if (
            str_contains($lower, 'member #')
            || str_contains($lower, 'customer data updated')
            || str_contains($lower, 'user data updated')
            || str_contains($lower, 'profile field changed')
            || str_contains($lower, 'account details updated')
        ) {
            return 'member';
        }

        if (
            str_contains($lower, 'order updated')
            || str_contains($lower, 'order #') && str_contains($lower, 'status changed')
            || str_contains($lower, 'order status changed')
            || str_contains($lower, 'payment successful')
            || str_contains($lower, 'payment failed')
            || str_contains($lower, 'payment method changed')
        ) {
            return 'order';
        }

        if (
            str_contains($lower, 'product changed')
            || str_contains($lower, 'product settings updated')
            || str_contains($lower, 'product created')
            || str_contains($lower, 'product updated')
            || str_contains($lower, 'product deleted')
            || str_contains($lower, 'product moved to trash')
            || str_contains($lower, 'product variation')
            || str_contains($lower, 'quantity changed')
            || str_contains($lower, 'recurring amount')
            || str_contains($lower, 'upgraded from')
            || str_contains($lower, 'downgraded from')
            || str_contains($lower, 'crossgraded from')
        ) {
            return 'product';
        }

        if (
            str_contains($lower, 'status changed')
            || str_contains($lower, 'subscription created')
            || str_contains($lower, 'reactivated')
            || str_contains($lower, 'on hold')
            || str_contains($lower, 'trial')
            || str_contains($lower, 'synchronized')
            || str_contains($lower, 'unsynced')
            || str_contains($lower, 'cancelled')
            || str_contains($lower, 'cancellation')
            || str_contains($lower, 'scheduled to cancel')
            || str_contains($lower, 'renewal invoice')
            || str_contains($lower, 'renewal order')
            || str_contains($lower, 'renewal processed')
            || str_contains($lower, 'next payment date changed')
        ) {
            return 'subscription';
        }

        if (
            str_contains($lower, 'coupon')
            || str_contains($lower, 'discount cycles')
            || str_contains($lower, 'retention discount')
        ) {
            return 'coupon';
        }

        if (str_contains($lower, 'email sent')) {
            return 'email';
        }

        return 'other';
    }

    /**
     * Get SQL WHERE condition for entity-based content filtering
     *
     * @param string $entity Entity type to filter by.
     *
     * @return string SQL condition string (already prepared).
     */
    private function getEntitySqlCondition(string $entity): string
    {
        global $wpdb;

        $patterns = [
            'product'      => [
                'Product changed',
                'Product settings updated',
                'Product created',
                'Product updated',
                'Product deleted',
                'Product moved to trash',
                'Product variation',
                'Quantity changed',
                'Recurring amount',
                'graded from',
            ],
            'order'        => [
                'Order updated',
                'Order status changed',
                'Order #',
                'Payment successful',
                'Payment failed',
                'Payment method changed',
            ],
            'subscription' => [
                'Status changed',
                'Subscription created',
                'reactivated',
                'on hold',
                'trial',
                'synchronized',
                'unsynced',
                'address updated',
                'dates updated',
                'auto-renewal',
                'cancel',
                'cancellation',
                'scheduled to cancel',
                'Renewal invoice',
                'Renewal order',
                'Renewal processed',
                'Next payment date changed',
            ],
            'member'       => [
                'Member #',
                'Customer data updated',
                'User data updated',
                'Profile field changed',
                'Account details updated',
            ],
            'coupon'       => [
                'Coupon',
                'discount cycles',
                'Retention discount',
            ],
            'email'        => [
                'Email sent',
            ],
            'settings'     => [
                'Settings updated:',
            ],
        ];

        $settings_patterns = $patterns['settings'];

        $col = "{$wpdb->posts}.post_content";

        if ('subscription' === $entity) {
            $subscription_likes = [];
            foreach ($patterns['subscription'] as $pattern) {
                $subscription_likes[] = $wpdb->prepare(
                    "{$col} LIKE %s",
                    '%' . $wpdb->esc_like($pattern) . '%'
                );
            }

            $settings_not_likes = [];
            foreach ($settings_patterns as $pattern) {
                $settings_not_likes[] = $wpdb->prepare(
                    "{$col} NOT LIKE %s",
                    '%' . $wpdb->esc_like($pattern) . '%'
                );
            }

            return '((' . implode(' OR ', $subscription_likes) . ') AND (' . implode(' AND ', $settings_not_likes) . '))';
        }

        if ('order' === $entity) {
            $order_likes = [];
            foreach ($patterns['order'] as $pattern) {
                if ('Order #' === $pattern) {
                    $order_likes[] = '((' . $wpdb->prepare("{$col} LIKE %s", '%' . $wpdb->esc_like('Order #') . '%') . ' AND ' . $wpdb->prepare("{$col} LIKE %s", '%' . $wpdb->esc_like('status changed') . '%') . '))';
                    continue;
                }
                $order_likes[] = $wpdb->prepare(
                    "{$col} LIKE %s",
                    '%' . $wpdb->esc_like($pattern) . '%'
                );
            }

            return '(' . implode(' OR ', $order_likes) . ')';
        }

        if (isset($patterns[$entity])) {
            $likes = [];
            foreach ($patterns[$entity] as $pattern) {
                $likes[] = $wpdb->prepare(
                    "{$col} LIKE %s",
                    '%' . $wpdb->esc_like($pattern) . '%'
                );
            }
            return '(' . implode(' OR ', $likes) . ')';
        }

        if ('other' === $entity) {
            $not_likes = [];
            foreach ($patterns as $group) {
                foreach ($group as $pattern) {
                    $not_likes[] = $wpdb->prepare(
                        "{$col} NOT LIKE %s",
                        '%' . $wpdb->esc_like($pattern) . '%'
                    );
                }
            }
            return '(' . implode(' AND ', $not_likes) . ')';
        }

        return '';
    }

    /**
     * Get SQL WHERE condition for the entity filter.
     *
     * Prefer stored `_audit_entity` metadata because the UI badge uses the same
     * stored value through arraysubs_format_note(). Fall back to legacy content
     * matching only for notes that do not have stored entity metadata.
     *
     * @param string $entity Entity type to filter by.
     *
     * @return string SQL condition string (already prepared).
     */
    private function getEntityFilterSqlCondition(string $entity): string
    {
        global $wpdb;

        $stored_entity_condition = $wpdb->prepare(
            "EXISTS (
                SELECT 1 FROM {$wpdb->postmeta} AS audit_entity_meta
                WHERE audit_entity_meta.post_id = {$wpdb->posts}.ID
                AND audit_entity_meta.meta_key = %s
                AND audit_entity_meta.meta_value = %s
            )",
            '_audit_entity',
            $entity
        );

        $legacy_entity_condition = $this->getEntitySqlCondition($entity);

        if (! $legacy_entity_condition) {
            return '(' . $stored_entity_condition . ')';
        }

        $missing_stored_entity_condition = $wpdb->prepare(
            "NOT EXISTS (
                SELECT 1 FROM {$wpdb->postmeta} AS missing_audit_entity_meta
                WHERE missing_audit_entity_meta.post_id = {$wpdb->posts}.ID
                AND missing_audit_entity_meta.meta_key = %s
            )",
            '_audit_entity'
        );

        return '(' . $stored_entity_condition . ' OR (' . $missing_stored_entity_condition . ' AND ' . $legacy_entity_condition . '))';
    }

    /**
     * Get audit logging settings
     *
     * @return WP_REST_Response
     */
    public function getLoggingSettings(): WP_REST_Response
    {
        $entities = ['product', 'coupon', 'email', 'settings'];
        $result   = [];

        foreach ($entities as $entity) {
            $result[$entity] = (bool) arraysubs_get_setting("audit_logging.{$entity}", true);
        }

        return arraysubs_rest_response($result);
    }

    /**
     * Update audit logging settings
     *
     * @param WP_REST_Request $request Request object.
     *
     * @return WP_REST_Response
     */
    public function updateLoggingSettings(WP_REST_Request $request): WP_REST_Response
    {
        $entities = ['product', 'coupon', 'email', 'settings'];

        foreach ($entities as $entity) {
            $value = $request->get_param($entity);
            if (null !== $value) {
                arraysubs_update_setting("audit_logging.{$entity}", (bool) $value);
            }
        }

        return $this->getLoggingSettings();
    }

    /**
     * Get IDs of users with admin or shop manager capabilities
     *
     * @return int[] Array of admin user IDs.
     */
    private function getAdminUserIds(): array
    {
        $cached = wp_cache_get('arraysubs_admin_user_ids', 'arraysubs');
        if (false !== $cached) {
            return $cached;
        }

        $users = get_users(
            [
                'role__in' => ['administrator', 'shop_manager'],
                'fields'   => 'ID',
            ]
        );

        $ids = array_map('intval', $users);
        wp_cache_set('arraysubs_admin_user_ids', $ids, 'arraysubs', HOUR_IN_SECONDS);

        return $ids;
    }
}
