<?php

/**
 * Portal Action Failure Troubleshooting REST Controller
 *
 * @package ArraySubsPro\Features\Audits\REST
 */

namespace ArraySubsPro\Features\Audits\REST;

defined('ABSPATH') || exit;

use ArraySubs\Supports\BaseRestController;
use WP_Error;
use WP_Post;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;

/**
 * Portal action failure troubleshooting REST controller.
 */
class PortalActionFailureController extends BaseRestController
{
    /**
     * Enable auto-loading.
     *
     * @var bool
     */
    public static $loadable = true;

    /**
     * REST namespace.
     *
     * @var string
     */
    protected $namespace = 'arraysubs/v1';

    /**
     * Constructor.
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Register REST routes.
     *
     * @return void
     */
    public function registerRoutes(): void
    {
        register_rest_route($this->namespace, '/audits/portal-action-failures', [
            [
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => [$this, 'getFailures'],
                'permission_callback' => [$this, 'checkAdminPermission'],
                'args'                => [
                    'page'     => [
                        'type'              => 'integer',
                        'default'           => 1,
                        'sanitize_callback' => 'absint',
                    ],
                    'per_page' => [
                        'type'              => 'integer',
                        'default'           => 30,
                        'sanitize_callback' => 'absint',
                    ],
                ],
            ],
        ]);

        register_rest_route($this->namespace, '/audits/portal-action-failures/(?P<failure_id>\d+)/resolve', [
            [
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => [$this, 'resolveFailure'],
                'permission_callback' => [$this, 'checkAdminPermission'],
                'args'                => [
                    'failure_id' => [
                        'type'              => 'integer',
                        'required'          => true,
                        'sanitize_callback' => 'absint',
                    ],
                ],
            ],
        ]);
    }

    /**
     * Check admin permission.
     *
     * @return bool
     */
    public function checkAdminPermission(): bool
    {
        if (! is_user_logged_in()) {
            return false;
        }

        return current_user_can('manage_woocommerce') || current_user_can('manage_options');
    }

    /**
     * Get unresolved portal action failures.
     *
     * @param WP_REST_Request $request Request object.
     * @return WP_REST_Response
     */
    public function getFailures(WP_REST_Request $request): WP_REST_Response
    {
        $page     = max(1, absint($request->get_param('page')));
        $per_page = min(100, max(1, absint($request->get_param('per_page'))));

        $query = new \WP_Query([
            'post_type'      => 'arraysubs_sub_note',
            'post_status'    => 'publish',
            'posts_per_page' => $per_page,
            'paged'          => $page,
            'orderby'        => 'date',
            'order'          => 'DESC',
            'meta_query'     => [ // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Troubleshooting queue filters structured failure notes.
                'relation' => 'AND',
                [
                    'key'     => '_note_type',
                    'value'   => 'portal_action_failure',
                    'compare' => '=',
                ],
                [
                    'relation' => 'OR',
                    [
                        'key'     => '_portal_action_status',
                        'compare' => 'NOT EXISTS',
                    ],
                    [
                        'key'     => '_portal_action_status',
                        'value'   => 'resolved',
                        'compare' => '!=',
                    ],
                ],
            ],
        ]);

        $failures = [];
        foreach ($query->posts as $note) {
            if ($note instanceof WP_Post) {
                $failures[] = $this->formatFailure($note);
            }
        }

        return arraysubs_rest_response([
            'failures'    => $failures,
            'total'       => (int) $query->found_posts,
            'total_pages' => (int) $query->max_num_pages,
            'page'        => $page,
        ]);
    }

    /**
     * Mark a portal action failure as resolved.
     *
     * @param WP_REST_Request $request Request object.
     * @return WP_REST_Response|WP_Error
     */
    public function resolveFailure(WP_REST_Request $request)
    {
        $failure_id = absint($request->get_param('failure_id'));
        $note       = get_post($failure_id);

        if (! $note instanceof WP_Post || 'arraysubs_sub_note' !== $note->post_type) {
            return new WP_Error(
                'portal_action_failure_not_found',
                __('Portal action failure not found.', 'arraysubspro'),
                ['status' => 404]
            );
        }

        if ('portal_action_failure' !== (string) get_post_meta($failure_id, '_note_type', true)) {
            return new WP_Error(
                'invalid_portal_action_failure',
                __('The selected note is not a portal action failure.', 'arraysubspro'),
                ['status' => 400]
            );
        }

        $now             = current_time('mysql', true);
        $user_id         = get_current_user_id();
        $subscription_id = (int) get_post_meta($failure_id, '_subscription_id', true);
        $action_label    = (string) get_post_meta($failure_id, '_portal_action_label', true);
        $error_code      = (string) get_post_meta($failure_id, '_portal_action_error_code', true);

        update_post_meta($failure_id, '_portal_action_status', 'resolved');
        update_post_meta($failure_id, '_portal_action_resolved_at', $now);
        update_post_meta($failure_id, '_portal_action_resolved_by', $user_id);

        $this->recordResolutionAudit($subscription_id, $action_label, $error_code, $user_id);

        return arraysubs_rest_response(
            [
                'failure_id'      => $failure_id,
                'subscription_id' => $subscription_id,
                'resolved_at'     => $now,
            ],
            200,
            __('Portal action failure marked as resolved.', 'arraysubspro')
        );
    }

    /**
     * Record activity audit for the resolution.
     *
     * @param int    $subscription_id Subscription ID.
     * @param string $action_label    Action label.
     * @param string $error_code      Error code.
     * @param int    $user_id         Admin user ID.
     * @return void
     */
    private function recordResolutionAudit(int $subscription_id, string $action_label, string $error_code, int $user_id): void
    {
        $content = sprintf(
            /* translators: 1: action label, 2: error code. */
            __('Portal action failure marked resolved by admin: %1$s (%2$s).', 'arraysubspro'),
            $action_label ?: __('Portal action', 'arraysubspro'),
            $error_code ?: __('unknown', 'arraysubspro')
        );
        $changes = [
            [
                'field'          => 'portal_action_failure_status',
                'label'          => __('Portal action failure status', 'arraysubspro'),
                'previous_value' => __('Open', 'arraysubspro'),
                'changed_value'  => __('Resolved', 'arraysubspro'),
            ],
        ];

        if ($subscription_id > 0 && function_exists('arraysubs_add_subscription_note')) {
            arraysubs_add_subscription_note(
                $subscription_id,
                $content,
                'private',
                $user_id,
                $changes,
                'subscription',
                'portal_action_failure_resolved'
            );

            return;
        }

        if (function_exists('arraysubs_add_global_note')) {
            arraysubs_add_global_note(
                $content,
                'private',
                $user_id,
                $changes,
                'other'
            );
        }
    }

    /**
     * Format a portal action failure note for API response.
     *
     * @param WP_Post $note Failure note.
     * @return array<string,mixed>
     */
    private function formatFailure(WP_Post $note): array
    {
        $subscription_id = (int) get_post_meta($note->ID, '_subscription_id', true);
        $subscription    = $subscription_id > 0 ? arraysubs_get_subscription($subscription_id) : null;
        $customer_id     = (int) get_post_meta($note->ID, '_portal_action_customer_id', true);
        $customer_email  = (string) get_post_meta($note->ID, '_portal_action_customer_email', true);
        $customer_name   = '';
        $user            = $customer_id > 0 ? get_user_by('id', $customer_id) : false;

        if ($user instanceof \WP_User) {
            $customer_name  = $user->display_name;
            $customer_email = $customer_email ?: $user->user_email;
        }

        if ('' === $customer_name) {
            $customer_name = $customer_email ?: __('Unknown customer', 'arraysubspro');
        }

        $date_gmt = $note->post_date_gmt;
        if (empty($date_gmt) || '0000-00-00 00:00:00' === $date_gmt) {
            $date_gmt = get_gmt_from_date($note->post_date);
        }

        return [
            'id'                      => $note->ID,
            'action'                  => (string) get_post_meta($note->ID, '_portal_action_action', true),
            'action_label'            => (string) get_post_meta($note->ID, '_portal_action_label', true),
            'customer_id'             => $customer_id,
            'customer_name'           => $customer_name,
            'customer_email'          => $customer_email,
            'subscription_id'         => $subscription_id,
            'subscription_status'     => $subscription instanceof WP_Post ? $subscription->post_status : '',
            'subscription_label'      => $subscription instanceof WP_Post && function_exists('arraysubs_get_status_label')
                ? arraysubs_get_status_label($subscription->post_status)
                : '',
            'subscription_url'        => $subscription_id > 0 ? '#/subscriptions/detail/' . $subscription_id : '',
            'error_code'              => (string) get_post_meta($note->ID, '_portal_action_error_code', true),
            'http_status'             => (int) get_post_meta($note->ID, '_portal_action_http_status', true),
            'message'                 => (string) get_post_meta($note->ID, '_portal_action_message', true),
            'route'                   => (string) get_post_meta($note->ID, '_portal_action_route', true),
            'method'                  => (string) get_post_meta($note->ID, '_portal_action_method', true),
            'suggested_resolution'    => (string) get_post_meta($note->ID, '_portal_action_suggested_resolution', true),
            'context'                 => $this->decodeJsonMeta((string) get_post_meta($note->ID, '_portal_action_context', true)),
            'created_at'              => $note->post_date,
            'created_at_gmt'          => $date_gmt,
            'created_at_timestamp'    => $date_gmt ? arraysubs_get_datetime_timestamp_from_string($date_gmt, new \DateTimeZone('UTC')) : null,
        ];
    }

    /**
     * Decode JSON note meta.
     *
     * @param string $raw Raw JSON.
     * @return array<mixed>
     */
    private function decodeJsonMeta(string $raw): array
    {
        if ('' === $raw) {
            return [];
        }

        $decoded = json_decode($raw, true);

        return is_array($decoded) ? $decoded : [];
    }
}
