<?php

/**
 * Abstract ArraySubs Gateway
 *
 * Base class for all ArraySubs payment gateways. Extends WC_Payment_Gateway to add
 * subscription lifecycle awareness, webhook handling, recurring payment support,
 * and capability declaration.
 *
 * Each concrete gateway (Stripe, Paddle, PayPal) extends this single class.
 * Settings live in WooCommerce > Settings > Payments via init_form_fields().
 *
 * @package ArraySubsPro\Features\AutomaticPayments\Abstracts
 * @since 1.0.0
 */

namespace ArraySubsPro\Features\AutomaticPayments\Abstracts;

defined('ABSPATH') || exit;

use ArraySubsPro\Features\AutomaticPayments\Services\DatabaseMigration;
use ArraySubsPro\Features\AutomaticPayments\Services\PaymentMetaNormalizer;
use ArraySubsPro\Features\AutomaticPayments\Contracts\AutomaticGatewayContract;

/**
 * Abstract ArraySubs Gateway
 *
 * @abstract
 */
abstract class AbstractArraySubsGateway extends \WC_Payment_Gateway implements AutomaticGatewayContract
{
    // ─── Normalized Event Type Constants ─────────────────────────────────

    const EVENT_PAYMENT_SUCCEEDED       = 'payment_succeeded';
    const EVENT_PAYMENT_FAILED          = 'payment_failed';
    const EVENT_PAYMENT_REQUIRES_ACTION = 'payment_requires_action';
    const EVENT_PAYMENT_METHOD_UPDATED  = 'payment_method_updated';
    const EVENT_CARD_EXPIRING           = 'card_expiring';
    const EVENT_REFUND_CREATED          = 'refund_created';
    const EVENT_DISPUTE_CREATED         = 'dispute_created';
    const EVENT_DISPUTE_RESOLVED        = 'dispute_resolved';
    const EVENT_SUBSCRIPTION_CANCELLED  = 'subscription_cancelled';

	// ─── Properties ──────────────────────────────────────────────────────

    /**
     * ArraySubs subscription capability flags.
     *
     * @var array<string, bool>
     */
    protected array $subscriptionCapabilities = [
        'automatic_payments'                => true,
        'trials'                            => false,
        'pause'                             => false,
        'resume'                            => false,
        'cancel_at_period_end'              => false,
        'cancel_at_period_end_reversible'   => false,
        'retention_amount_update'           => false,
        'product_sync'                      => false,
        'payment_method_update'             => true,
        'card_auto_update'                  => false,
        'card_expiry_notice'                => false,
        'disputes'                          => false,
        'sca'                               => false,
        'hosted_payment_page'               => false,
        'customer_portal'                   => false,
        'mixed_cart'                        => false,
        'multiple_subscriptions'            => false,
        'different_billing_cycles'          => false,
        'supports_sync'                     => false,
    ];

    /**
     * Map of gateway-native event types to normalized event types.
     * Concrete gateways populate this in their constructors.
     *
     * @var array<string, string>
     */
    protected array $eventMap = [];

	// ─── Capability Check ────────────────────────────────────────────────

    /**
     * Check if a subscription-specific capability is supported.
     *
     * @param string $capability One of the subscriptionCapabilities keys.
     * @return bool
     */
    public function supportsSubscriptionCapability(string $capability): bool
    {
        return $this->subscriptionCapabilities[$capability] ?? false;
    }

    /**
     * Get all subscription capabilities.
     *
     * @return array<string, bool>
     */
    public function getSubscriptionCapabilities(): array
    {
        return $this->subscriptionCapabilities;
    }

	// ─── WC Settings Base Fields ─────────────────────────────────────────

    /**
     * Define base gateway settings fields.
     * Concrete gateways call parent::init_form_fields() then merge their own.
     *
     * @return void
     */
    public function init_form_fields(): void
    {
        $this->form_fields = [
            'enabled'     => [
                'title'   => __('Enable/Disable', 'arraysubspro'),
                'type'    => 'checkbox',
                'label'   => __('Enable this payment gateway', 'arraysubspro'),
                'default' => 'no',
            ],
            'title'       => [
                'title'       => __('Title', 'arraysubspro'),
                'type'        => 'text',
                'description' => __('Payment method title shown to customers at checkout.', 'arraysubspro'),
                'default'     => '',
            ],
            'description' => [
                'title'       => __('Description', 'arraysubspro'),
                'type'        => 'textarea',
                'description' => __('Payment method description shown to customers at checkout.', 'arraysubspro'),
                'default'     => '',
            ],
            'test_mode'   => [
                'title'       => __('Test Mode', 'arraysubspro'),
                'type'        => 'checkbox',
                'label'       => __('Enable test/sandbox mode', 'arraysubspro'),
                'default'     => 'yes',
                'description' => __('Use test API keys and sandbox environment.', 'arraysubspro'),
            ],
        ];
    }

	// ─── WC Checkout: process_payment ────────────────────────────────────

    /**
     * Process payment for an order.
     * WooCommerce calls this during checkout for subscription and non-subscription orders.
     *
     * @param int $order_id The WooCommerce order ID.
     * @return array{result: string, redirect: string}
     */
    public function process_payment($order_id): array
    {
        $order = wc_get_order($order_id);

        if (! $order) {
            wc_add_notice(__('Order not found.', 'arraysubspro'), 'error');
            return [
                'result'   => 'failure',
                'redirect' => '',
            ];
        }

        if ($this->isSubscriptionOrder($order)) {
            return $this->processSubscriptionPayment($order);
        }

        return $this->processStandardPayment($order);
    }

    /**
     * Process a subscription order payment.
     *
     * @param \WC_Order $order The WooCommerce order.
     * @return array{result: string, redirect: string}
     */
    abstract protected function processSubscriptionPayment(\WC_Order $order): array;

    /**
     * Process a standard (non-subscription) order payment.
     *
     * @param \WC_Order $order The WooCommerce order.
     * @return array{result: string, redirect: string}
     */
    abstract protected function processStandardPayment(\WC_Order $order): array;

	// ─── WC Refund: process_refund ───────────────────────────────────────

    /**
     * Process a refund for an order.
     * WooCommerce calls this when admin initiates a refund.
     *
     * @param int        $order_id The WooCommerce order ID.
     * @param float|null $amount   The refund amount (null = full refund).
     * @param string     $reason   The refund reason.
     * @return bool|\WP_Error True on success, WP_Error on failure.
     */
    public function process_refund($order_id, $amount = null, $reason = '')
    {
        return $this->processGatewayRefund((int) $order_id, $amount ? (float) $amount : null, $reason);
    }

    /**
     * Execute the refund at the gateway.
     *
     * @param int        $order_id The WooCommerce order ID.
     * @param float|null $amount   The refund amount.
     * @param string     $reason   The refund reason.
     * @return bool|\WP_Error
     */
    abstract protected function processGatewayRefund(int $order_id, ?float $amount, string $reason);

	// ─── WC Availability ─────────────────────────────────────────────────

    /**
     * Check if the gateway is available for use.
     *
     * @return bool
     */
    public function is_available(): bool
    {
        if (! parent::is_available()) {
            return false;
        }

        return $this->hasRequiredCredentials();
    }

    /**
     * Check if the gateway needs setup.
     *
     * @return bool
     */
    public function needs_setup(): bool
    {
        return ! $this->hasRequiredCredentials();
    }

    /**
     * Check if required API credentials are configured.
     *
     * @return bool
     */
    abstract protected function hasRequiredCredentials(): bool;

	// ─── Recurring Payment ───────────────────────────────────────────────

    /**
     * Process a renewal payment (off-session automatic charge).
     *
     * @param int       $subscription_id The subscription post ID.
     * @param \WC_Order $order           The renewal order.
     * @return array{success: bool, transaction_id: string, message: string, raw: array}
     */
    abstract public function processRenewalPayment(int $subscription_id, \WC_Order $order): array;

	// ─── Trial Setup ─────────────────────────────────────────────────────

    /**
     * Handle setup intent / payment method collection for free trial.
     *
     * @param \WC_Order $order           The $0 or signup-fee-only order.
     * @param int       $subscription_id The subscription being created.
     * @param array     $trial_data      Trial configuration data.
     * @return array{success: bool, remote_customer_id: string, remote_payment_method_id: string, message: string, raw: array}
     */
    abstract public function setupTrialPaymentMethod(\WC_Order $order, int $subscription_id, array $trial_data): array;

	// ─── Payment Context Capture ─────────────────────────────────────────

    /**
     * Capture and normalize gateway-specific payment context after successful checkout.
     *
     * @param \WC_Order $order           The paid order.
     * @param int       $subscription_id The subscription ID.
     * @return array{success: bool, gateway_slug: string, remote_customer_id: string, remote_payment_method_id: string, remote_transaction_id: string, brand: string, last4: string, payment_method_type: string, message: string, raw: array}
     */
    abstract public function capturePaymentContext(\WC_Order $order, int $subscription_id): array;

	// ─── Cancellation Cleanup ────────────────────────────────────────────

    /**
     * Cancel any remote billing context when subscription is cancelled locally.
     *
     * @param int   $subscription_id The subscription ID.
     * @param array $context         Cancellation context.
     * @return array{success: bool, message: string, raw: array}
     */
    abstract public function cancelRemoteBillingContext(int $subscription_id, array $context = []): array;

	// ─── Payment Method Display ──────────────────────────────────────────

    /**
     * Format stored payment method for UI display.
     *
     * @param int $subscription_id The subscription ID.
     * @return array{gateway: string, title: string, brand: string, last4: string, expiry: string, is_expired: bool, can_update: bool, update_url: string, update_type: string}
     */
    abstract public function formatPaymentMethodForDisplay(int $subscription_id): array;

	// ─── Payment Method Update ───────────────────────────────────────────

    /**
     * Get the payment method update mechanism for customer portal.
     *
     * @param int   $subscription_id The subscription ID.
     * @param array $context         Update context.
     * @return array{success: bool, type: string, url: string, message: string, raw: array}
     */
    abstract public function getPaymentMethodUpdateMechanism(int $subscription_id, array $context = []): array;

	// ─── Webhook Handling ────────────────────────────────────────────────

    /**
     * Verify the webhook signature / authenticity.
     *
     * @param \WP_REST_Request $request Raw incoming request.
     * @return bool True if signature is valid.
     */
    abstract public function verifyWebhookSignature(\WP_REST_Request $request): bool;

    /**
     * Parse raw webhook payload into a normalized structure.
     *
     * @param \WP_REST_Request $request The incoming request.
     * @return array{success: bool, gateway_event_id: string, gateway_event_type: string, normalized_event_type: string, occurred_at: int, payload: array, raw_body: string}
     */
    abstract public function parseWebhook(\WP_REST_Request $request): array;

    /**
     * Resolve the subscription, order, and customer IDs from parsed webhook data.
     *
     * @param array $parsed_webhook Output from parseWebhook().
     * @return array{subscription_id: int, order_id: int, customer_id: int}
     */
    abstract public function resolveEntityIds(array $parsed_webhook): array;

	// ─── Required Event Handler Methods ──────────────────────────────────

    /**
     * Handle successful payment (initial, renewal, or proration).
     *
     * @param array $context Event context with parsed webhook + resolved entities.
     * @return array{success: bool, message: string}
     */
    abstract public function handlePaymentSucceeded(array $context): array;

    /**
     * Handle payment failure.
     *
     * @param array $context Event context.
     * @return array{success: bool, message: string}
     */
    abstract public function handlePaymentFailed(array $context): array;

    /**
     * Handle payment requiring customer action (SCA/3DS).
     *
     * @param array $context Event context.
     * @return array{success: bool, message: string}
     */
    abstract public function handlePaymentRequiresAction(array $context): array;

    /**
     * Handle payment method updated (card auto-updater, customer portal change).
     *
     * @param array $context Event context.
     * @return array{success: bool, message: string}
     */
    abstract public function handlePaymentMethodUpdated(array $context): array;

    /**
     * Handle card expiration notice.
     *
     * @param array $context Event context.
     * @return array{success: bool, message: string}
     */
    abstract public function handleCardExpiring(array $context): array;

    /**
     * Handle external refund created at gateway.
     *
     * @param array $context Event context.
     * @return array{success: bool, message: string}
     */
    abstract public function handleRefundCreated(array $context): array;

    /**
     * Handle dispute/chargeback opened.
     *
     * @param array $context Event context.
     * @return array{success: bool, message: string}
     */
    abstract public function handleDisputeCreated(array $context): array;

    /**
     * Handle dispute resolved (won or lost).
     *
     * @param array $context Event context.
     * @return array{success: bool, message: string}
     */
    abstract public function handleDisputeResolved(array $context): array;

    /**
     * Handle external subscription cancellation.
     *
     * @param array $context Event context.
     * @return array{success: bool, message: string}
     */
    abstract public function handleSubscriptionCancelled(array $context): array;

	// ─── Optional Methods (Default No-Op) ────────────────────────────────

    /**
     * Notify gateway that subscription is paused.
     *
     * @param int   $subscription_id The subscription ID.
     * @param array $context         Pause context.
     * @return array{success: bool, message: string, raw: array}
     */
    public function pauseRemoteBillingContext(int $subscription_id, array $context = []): array
    {
        return ['success' => true, 'message' => 'Gateway does not support pause sync', 'raw' => []];
    }

    /**
     * Notify gateway that subscription is resumed.
     *
     * @param int   $subscription_id The subscription ID.
     * @param array $context         Resume context.
     * @return array{success: bool, message: string, raw: array}
     */
    public function resumeRemoteBillingContext(int $subscription_id, array $context = []): array
    {
        return ['success' => true, 'message' => 'Gateway does not support resume sync', 'raw' => []];
    }

    /**
     * Reverse a previously scheduled end-of-period cancellation at the gateway.
     *
     * Only relevant for gateways that natively support a "cancel at period end" model
     * (capability `cancel_at_period_end_reversible`). Default is a no-op failure
     * because most gateways either cancel immediately or have no reversal path.
     *
     * @param int   $subscription_id The subscription ID.
     * @param array $context         Restore context.
     * @return array{success: bool, message: string, raw: array}
     */
    public function restoreScheduledCancel(int $subscription_id, array $context = []): array
    {
        return ['success' => false, 'message' => 'Gateway does not support reversing a scheduled cancellation', 'raw' => []];
    }

    /**
     * Check whether a recent successful charge exists at the gateway for a given
     * renewal context — used before a retry to avoid double-charging when a
     * webhook was missed but the customer was actually charged.
     *
     * Default: returns indeterminate. Gateways that support charge lookups
     * (Stripe in particular) should override this.
     *
     * @param int       $subscription_id Subscription ID.
     * @param \WC_Order $order           The renewal order being retried.
     * @param array     $context         Lookup context (e.g. window in seconds).
     * @return array{found: bool, charged: bool, transaction_id: string, message: string, raw: array}
     */
    public function verifyRecentChargeForOrder(int $subscription_id, \WC_Order $order, array $context = []): array
    {
        return [
            'found'          => false,
            'charged'        => false,
            'transaction_id' => '',
            'message'        => 'Gateway does not support pre-retry charge verification',
            'raw'            => [],
        ];
    }

    /**
     * Pull the authoritative subscription state from the gateway and report
     * differences against local meta. The caller decides which fields to apply.
     *
     * Default returns an empty result. Gateways override to implement.
     *
     * @param int $subscription_id The subscription ID.
     * @return array{success: bool, message: string, gateway_status: string, next_payment_date: string, payment_method: array, recent_charges: array, raw: array}
     */
    public function syncFromGateway(int $subscription_id): array
    {
        return [
            'success'           => false,
            'message'           => 'Gateway does not support sync',
            'gateway_status'    => '',
            'next_payment_date' => '',
            'payment_method'    => [],
            'recent_charges'    => [],
            'raw'               => [],
        ];
    }

    /**
     * Update the next renewal amount at the gateway for retention discounts.
     *
     * @param int   $subscription_id The subscription ID.
     * @param float $new_amount      The new amount.
     * @param array $context         Update context.
     * @return array{success: bool, message: string, raw: array}
     */
    public function updateNextRenewalAmount(int $subscription_id, float $new_amount, array $context = []): array
    {
        return ['success' => false, 'message' => 'Gateway does not support renewal amount updates', 'raw' => []];
    }

    /**
     * Sync a WooCommerce product to the gateway's remote catalog.
     *
     * @param \WC_Product $product The product to sync.
     * @return array{success: bool, remote_product_id: string, message: string, raw: array}
     */
    public function syncProduct(\WC_Product $product): array
    {
        return ['success' => true, 'remote_product_id' => '', 'message' => 'No sync needed', 'raw' => []];
    }

    /**
     * Delete a product from the gateway's remote catalog.
     *
     * @param \WC_Product $product The product to delete remotely.
     * @return array{success: bool, message: string, raw: array}
     */
    public function deleteRemoteProduct(\WC_Product $product): array
    {
        return ['success' => true, 'message' => 'No remote product to delete', 'raw' => []];
    }

    /**
     * Render payment fields at checkout.
     * Override for gateways with inline elements.
     *
     * @return void
     */
    public function payment_fields(): void
    {
        if ($this->description) {
            echo wp_kses_post(wpautop(wptexturize($this->description)));
        }
    }

	// ─── Shared Helper Methods ───────────────────────────────────────────

    /**
     * Get the gateway slug (WC gateway ID).
     *
     * @return string
     */
    public function getGatewaySlug(): string
    {
        return $this->id;
    }

    /**
     * Get the event map for this gateway.
     *
     * @return array<string, string>
     */
    public function getEventMap(): array
    {
        return $this->eventMap;
    }

    /**
     * Normalize a gateway-native event type to a standard event constant.
     *
     * @param string $gateway_event_type The native event type.
     * @return string Normalized event type or empty string if not mapped.
     */
    public function normalizeEventType(string $gateway_event_type): string
    {
        return $this->eventMap[$gateway_event_type] ?? '';
    }

    /**
     * Check if this is a test mode transaction.
     *
     * @return bool
     */
    public function isTestMode(): bool
    {
        return 'yes' === $this->get_option('test_mode', 'yes');
    }

    /**
     * Get the display title used by admin/API surfaces.
     *
     * @return string
     */
    public function getGatewayTitle(): string
    {
        return (string) $this->get_title();
    }

    /**
     * Get the gateway description used by admin/API surfaces.
     *
     * @return string
     */
    public function getGatewayDescription(): string
    {
        return (string) $this->get_description();
    }

    /**
     * Whether the gateway is enabled in WooCommerce settings.
     *
     * @return bool
     */
    public function isGatewayEnabled(): bool
    {
        return 'yes' === $this->enabled;
    }

    /**
     * Whether the gateway is currently available for checkout/automation.
     *
     * @return bool
     */
    public function isGatewayAvailable(): bool
    {
        return $this->is_available();
    }

    /**
     * Whether the gateway still needs setup.
     *
     * @return bool
     */
    public function gatewayNeedsSetup(): bool
    {
        return $this->needs_setup();
    }

    /**
     * Default retry configuration for gateways that do not publish local retry rules.
     *
     * @return array{enabled: bool, max_attempts: int, interval_seconds: int}
     */
    public function getRetryConfig(): array
    {
        return [
            'enabled'          => false,
            'max_attempts'     => 0,
            'interval_seconds' => 0,
        ];
    }

    /**
     * Default retry config publisher.
     *
     * @param array $config          Current retry config.
     * @param int   $subscription_id Subscription ID.
     * @return array
     */
    public function publishRetryConfigForSubscription(array $config, int $subscription_id): array
    {
        return $config;
    }

    /**
     * Check if an order contains subscription products.
     *
     * @param \WC_Order $order The order to check.
     * @return bool
     */
    protected function isSubscriptionOrder(\WC_Order $order): bool
    {
        if (function_exists('arraysubs_is_subscription_product')) {
            foreach ($order->get_items() as $item) {
                $product_id = $item->get_variation_id() ?: $item->get_product_id();
                if ($product_id && arraysubs_is_subscription_product($product_id)) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Get the subscription(s) linked to an order.
     *
     * @param \WC_Order $order The order.
     * @return array Array of subscription post IDs.
     */
    protected function getSubscriptionsForOrder(\WC_Order $order): array
    {
        return PaymentMetaNormalizer::findSubscriptionIdsForOrder($order->get_id());
    }

    /**
     * Capture gateway context (customer ID, payment method ID, brand,
     * last4, etc.) from a paid WC order and persist it on the
     * subscription. Concrete gateways override this to read their own
     * gateway-specific order meta keys.
     *
     * Default implementation is a no-op so gateways that have no
     * non-webhook capture path remain safe. Called from
     * AutomaticPayments\Hooks::onGatewayContextCaptured() to provide a
     * webhook-independent backup capture.
     *
     * @param \WC_Order $order           The paid order.
     * @param int       $subscription_id The subscription post ID linked to the order.
     * @return void
     */
    public function captureContextFromOrder(\WC_Order $order, int $subscription_id): void
    {
        // No-op default. Concrete gateways override.
    }

    /**
     * Persist gateway-specific meta on subscription.
     *
     * @param int   $subscription_id The subscription post ID.
     * @param array $data            Key-value pairs of meta to store.
     * @return void
     */
    protected function persistGatewayMeta(int $subscription_id, array $data): void
    {
        $allowed_keys = [
            '_payment_gateway',
            '_gateway_customer_id',
            '_gateway_payment_method_id',
            '_gateway_session_id',
            '_gateway_status',
            '_payment_method_brand',
            '_payment_method_last4',
            '_payment_method_expiry_month',
            '_payment_method_expiry_year',
            '_payment_method_type',
            '_last_gateway_transaction_id',
            '_cancellation_source',
            '_refund_source',
        ];

        foreach ($data as $key => $value) {
            if (in_array($key, $allowed_keys, true)) {
                update_post_meta($subscription_id, $key, sanitize_text_field((string) $value));
            }
        }
    }

    /**
     * Persist gateway-specific meta on a WooCommerce order.
     *
     * @param \WC_Order $order The order.
     * @param array     $data  Key-value pairs of meta to store.
     * @return void
     */
    protected function persistOrderGatewayMeta(\WC_Order $order, array $data): void
    {
        foreach ($data as $key => $value) {
            $order->update_meta_data($key, sanitize_text_field((string) $value));
        }
        $order->save();
    }

    /**
     * Get stored gateway meta from subscription.
     *
     * @param int $subscription_id The subscription post ID.
     * @return array Gateway meta data.
     */
    protected function getGatewayMeta(int $subscription_id): array
    {
        return [
            'gateway_slug'       => get_post_meta($subscription_id, '_payment_gateway', true),
            'customer_id'        => get_post_meta($subscription_id, '_gateway_customer_id', true),
            'payment_method_id'  => get_post_meta($subscription_id, '_gateway_payment_method_id', true),
            'session_id'         => get_post_meta($subscription_id, '_gateway_session_id', true),
            'status'             => get_post_meta($subscription_id, '_gateway_status', true),
            'brand'              => get_post_meta($subscription_id, '_payment_method_brand', true),
            'last4'              => get_post_meta($subscription_id, '_payment_method_last4', true),
            'expiry_month'       => (int) get_post_meta($subscription_id, '_payment_method_expiry_month', true),
            'expiry_year'        => (int) get_post_meta($subscription_id, '_payment_method_expiry_year', true),
            'payment_method_type' => get_post_meta($subscription_id, '_payment_method_type', true),
            'transaction_id'     => get_post_meta($subscription_id, '_last_gateway_transaction_id', true),
        ];
    }

    /**
     * Check if order total is zero.
     *
     * @param \WC_Order $order The order.
     * @return bool
     */
    protected function isZeroTotalOrder(\WC_Order $order): bool
    {
        return (float) $order->get_total() <= 0;
    }

    /**
     * Add a private subscription note.
     *
     * @param int    $subscription_id The subscription post ID.
     * @param string $message         The note message.
     * @return void
     */
    protected function addSubscriptionPrivateNote(int $subscription_id, string $message): void
    {
        if (function_exists('arraysubs_add_subscription_note')) {
            arraysubs_add_subscription_note($subscription_id, $this->formatGatewayNoteMessage($message), 'private', 0, [], 'subscription');
        }
    }

    /**
     * Add a customer-visible subscription note.
     *
     * @param int    $subscription_id The subscription post ID.
     * @param string $message         The note message.
     * @return void
     */
    protected function addSubscriptionCustomerNote(int $subscription_id, string $message): void
    {
        if (function_exists('arraysubs_add_subscription_note')) {
            arraysubs_add_subscription_note($subscription_id, $this->formatGatewayNoteMessage($message), 'customer', 0, [], 'subscription');
        }
    }

    /**
     * Prefix a note with a gateway marker if it does not already have one.
     *
     * @param string $message Note body.
     * @return string
     */
    protected function formatGatewayNoteMessage(string $message): string
    {
        if (preg_match('/^\s*\[Gateway:\s*[^\]]+\]\s*/i', $message)) {
            return $message;
        }

        return sprintf('[Gateway: %1$s] %2$s', $this->getGatewayNoteLabel(), $message);
    }

    /**
     * Get a readable gateway label for note prefixes.
     *
     * @return string
     */
    protected function getGatewayNoteLabel(): string
    {
        $label = $this->method_title ?: $this->title ?: $this->id;
        $label = wp_strip_all_tags((string) $label);
        $label = str_replace(' (ArraySubs)', '', $label);

        return $label ?: $this->id;
    }

    /**
     * Mark order as paid.
     *
     * @param \WC_Order $order          The order.
     * @param string    $transaction_id Gateway transaction ID.
     * @return void
     */
    protected function markOrderPaid(\WC_Order $order, string $transaction_id): void
    {
        $order->payment_complete($transaction_id);
    }

    /**
     * Record payment failure on order and subscription.
     *
     * @param \WC_Order $order           The order.
     * @param int       $subscription_id The subscription ID.
     * @param string    $error_code      Error code.
     * @param string    $error_message   Error message.
     * @return void
     */
    protected function recordPaymentFailure(\WC_Order $order, int $subscription_id, string $error_code, string $error_message): void
    {
        $note = sprintf(
            /* translators: 1: gateway slug, 2: error code, 3: error message */
            __('[Gateway: %1$s] Payment failed — %2$s: %3$s', 'arraysubspro'),
            esc_html($this->id),
            esc_html($error_code),
            esc_html($error_message)
        );

        $order->add_order_note($note);
        $order->update_status('failed');

        $this->addSubscriptionPrivateNote($subscription_id, $note);
    }

    /**
     * Fire a gateway-specific WordPress action hook.
     *
     * @param string $hook    The hook name (e.g., 'arraysubs_gateway_payment_succeeded').
     * @param array  $payload The hook arguments.
     * @return void
     */
    protected function emitWebhookAction(string $hook, array $payload): void
    {
        $normalized_payload = $this->normalizeWebhookActionPayload($hook, $payload);

        // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.DynamicHooknameFound -- dynamic hook is intentional
        do_action($hook, ...$normalized_payload);
    }

    /**
     * Normalize gateway webhook action payloads to the core hook contract.
     *
     * @param string $hook    Hook name.
     * @param array  $payload Raw payload.
     * @return array
     */
    protected function normalizeWebhookActionPayload(string $hook, array $payload): array
    {
        $subscription_id = (int) ($payload[0] ?? 0);
        $order_id        = (int) ($payload[1] ?? 0);
        $gateway_slug    = isset($payload[2]) && is_string($payload[2]) ? $payload[2] : $this->id;
        $details         = isset($payload[3]) && is_array($payload[3]) ? $payload[3] : [];

        switch ($hook) {
            case 'arraysubs_gateway_payment_succeeded':
                return [
                    $subscription_id,
                    $order_id,
                    $this->extractTransactionReference($details),
                    $gateway_slug,
                ];

            case 'arraysubs_gateway_payment_failed':
                return [
                    $subscription_id,
                    $order_id,
                    $this->extractFailureReason($details),
                    $gateway_slug,
                ];

            case 'arraysubs_gateway_refund_created':
                return [
                    $subscription_id,
                    $order_id,
                    $this->extractRefundAmount($details),
                    $gateway_slug,
                ];

            case 'arraysubs_gateway_subscription_cancelled':
                return [$subscription_id, $gateway_slug];

            default:
                return $payload;
        }
    }

    /**
     * Extract a stable transaction reference from gateway payload data.
     *
     * @param array $details Gateway payload.
     * @return string
     */
    protected function extractTransactionReference(array $details): string
    {
        $candidates = [
            $details['payment_intent'] ?? '',
            $details['transaction_id'] ?? '',
            $details['sale_id'] ?? '',
            $details['capture_id'] ?? '',
            $details['id'] ?? '',
        ];

        foreach ($candidates as $candidate) {
            if (is_array($candidate) && ! empty($candidate['id']) && is_string($candidate['id'])) {
                return $candidate['id'];
            }

            if (is_string($candidate) && '' !== $candidate) {
                return $candidate;
            }
        }

        if (! empty($details['payments'][0]['id']) && is_string($details['payments'][0]['id'])) {
            return $details['payments'][0]['id'];
        }

        return '';
    }

    /**
     * Extract a human-readable failure reason from gateway payload data.
     *
     * @param array $details Gateway payload.
     * @return string
     */
    protected function extractFailureReason(array $details): string
    {
        $candidates = [
            $details['error_message'] ?? '',
            $details['error_code'] ?? '',
            $details['status_change_note'] ?? '',
            $details['reason'] ?? '',
            $details['last_payment_error']['message'] ?? '',
            $details['last_payment_error']['code'] ?? '',
            $details['payments'][0]['method_details']['error']['type'] ?? '',
        ];

        foreach ($candidates as $candidate) {
            if (is_string($candidate) && '' !== $candidate) {
                return $candidate;
            }
        }

        return 'payment_failed';
    }

    /**
     * Extract a normalized refund amount from gateway payload data.
     *
     * @param array $details Gateway payload.
     * @return float
     */
    protected function extractRefundAmount(array $details): float
    {
        if (! empty($details['refunds']['data']) && is_array($details['refunds']['data'])) {
            $latest_refund = end($details['refunds']['data']);
            $currency      = strtoupper((string) ($details['currency'] ?? ''));

            if (is_array($latest_refund) && isset($latest_refund['amount']) && is_numeric($latest_refund['amount'])) {
                return $this->fromMinorUnits((float) $latest_refund['amount'], $currency);
            }
        }

        $candidates = [
            $details['amount']['total'] ?? null,
            $details['total_refunded_amount']['value'] ?? null,
            $details['totals']['total'] ?? null,
            $details['amount'] ?? null,
        ];

        foreach ($candidates as $candidate) {
            if (is_numeric($candidate)) {
                return (float) $candidate;
            }
        }
        return 0.0;
    }

    /**
     * Convert a minor-unit amount into a major-unit amount.
     *
     * @param float  $amount   Amount in gateway minor units.
     * @param string $currency ISO currency code.
     * @return float
     */
    protected function fromMinorUnits(float $amount, string $currency): float
    {
        $zero_decimal_currencies = [
            'BIF',
            'CLP',
            'DJF',
            'GNF',
            'JPY',
            'KMF',
            'KRW',
            'MGA',
            'PYG',
            'RWF',
            'UGX',
            'VND',
            'VUV',
            'XAF',
            'XOF',
            'XPF',
        ];

        if (in_array($currency, $zero_decimal_currencies, true)) {
            return $amount;
        }

        return round($amount / 100, 2);
    }

    /**
     * Log to WC logger with gateway-specific source.
     *
     * @param string $level   Log level: debug, info, notice, warning, error, critical, alert, emergency.
     * @param string $message The log message.
     * @param array  $context Additional context data.
     * @return void
     */
    protected function log(string $level, string $message, array $context = []): void
    {
        if (! function_exists('wc_get_logger')) {
            return;
        }

        $logger = wc_get_logger();
        $logger->log($level, $message, array_merge($context, ['source' => $this->id]));
    }

    /**
     * Find a WooCommerce order by gateway transaction ID.
     *
     * @param string $transaction_id The transaction ID to search for.
     * @return \WC_Order|null
     */
    protected function findOrderByGatewayTransactionId(string $transaction_id): ?\WC_Order
    {
        $orders = wc_get_orders([
            'transaction_id' => $transaction_id,
            'limit'          => 1,
        ]);

        return ! empty($orders) ? $orders[0] : null;
    }

    /**
     * Check if an event was already processed (idempotency).
     * Delegates to the DatabaseMigration table lookup.
     *
     * @param string $event_id Gateway event ID.
     * @return bool
     */
    public function isDuplicateEvent(string $event_id): bool
    {
        if (! DatabaseMigration::tableExists()) {
            return false;
        }

        global $wpdb;

        $table = $wpdb->prefix . 'arraysubs_webhook_events';

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $exists = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$table} WHERE gateway_slug = %s AND event_id = %s", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
                $this->id,
                $event_id
            )
        );

        return (int) $exists > 0;
    }

    /**
     * Remember that an event was processed (for idempotency).
     *
     * @param string $event_id   Gateway event ID.
     * @param string $event_type Gateway event type.
     * @return void
     */
    public function rememberEvent(string $event_id, string $event_type = ''): void
    {
        if (! DatabaseMigration::tableExists()) {
            return;
        }

        global $wpdb;

        $table = $wpdb->prefix . 'arraysubs_webhook_events';

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
        $wpdb->insert(
            $table,
            [
                'gateway_slug' => $this->id,
                'event_id'     => sanitize_text_field($event_id),
                'event_type'   => sanitize_text_field($event_type),
                'processed_at' => current_time('mysql', true),
            ],
            ['%s', '%s', '%s', '%s']
        );
    }
}
