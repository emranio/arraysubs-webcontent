<?php

/**
 * Automatic Gateway Contract
 *
 * Shared contract for automatic-payment integrations. Implementations may be
 * WooCommerce checkout gateways (PayPal/Paddle) or non-checkout delegates
 * (Stripe via the official WooCommerce Stripe gateway).
 *
 * @package ArraySubsPro\Features\AutomaticPayments\Contracts
 */

namespace ArraySubsPro\Features\AutomaticPayments\Contracts;

defined('ABSPATH') || exit;

/**
 * Automatic gateway contract.
 */
interface AutomaticGatewayContract
{
    const EVENT_PAYMENT_SUCCEEDED       = 'payment_succeeded';
    const EVENT_PAYMENT_FAILED          = 'payment_failed';
    const EVENT_PAYMENT_REQUIRES_ACTION = 'payment_requires_action';
    const EVENT_PAYMENT_METHOD_UPDATED  = 'payment_method_updated';
    const EVENT_CARD_EXPIRING           = 'card_expiring';
    const EVENT_REFUND_CREATED          = 'refund_created';
    const EVENT_DISPUTE_CREATED         = 'dispute_created';
    const EVENT_DISPUTE_RESOLVED        = 'dispute_resolved';
    const EVENT_SUBSCRIPTION_CANCELLED  = 'subscription_cancelled';

    public function getGatewaySlug(): string;

    public function getGatewayTitle(): string;

    public function getGatewayDescription(): string;

    public function isGatewayEnabled(): bool;

    public function isGatewayAvailable(): bool;

    public function gatewayNeedsSetup(): bool;

    public function isTestMode(): bool;

    public function getSubscriptionCapabilities(): array;

    public function supportsSubscriptionCapability(string $capability): bool;

    public function formatPaymentMethodForDisplay(int $subscription_id): array;

    public function getPaymentMethodUpdateMechanism(int $subscription_id, array $context = []): array;

    public function processRenewalPayment(int $subscription_id, \WC_Order $order): array;

    public function setupTrialPaymentMethod(\WC_Order $order, int $subscription_id, array $trial_data): array;

    public function verifyRecentChargeForOrder(int $subscription_id, \WC_Order $order, array $context = []): array;

    public function syncFromGateway(int $subscription_id): array;

    public function cancelRemoteBillingContext(int $subscription_id, array $context = []): array;

    public function pauseRemoteBillingContext(int $subscription_id, array $context = []): array;

    public function resumeRemoteBillingContext(int $subscription_id, array $context = []): array;

    public function restoreScheduledCancel(int $subscription_id, array $context = []): array;

    public function capturePaymentContext(\WC_Order $order, int $subscription_id): array;

    public function captureContextFromOrder(\WC_Order $order, int $subscription_id): void;

    public function getRetryConfig(): array;

    public function publishRetryConfigForSubscription(array $config, int $subscription_id): array;

    public function verifyWebhookSignature(\WP_REST_Request $request): bool;

    public function parseWebhook(\WP_REST_Request $request): array;

    public function resolveEntityIds(array $parsed_webhook): array;

    public function normalizeEventType(string $gateway_event_type): string;

    public function isDuplicateEvent(string $event_id): bool;

    public function rememberEvent(string $event_id, string $event_type = ''): void;

    public function handlePaymentSucceeded(array $context): array;

    public function handlePaymentFailed(array $context): array;

    public function handlePaymentRequiresAction(array $context): array;

    public function handlePaymentMethodUpdated(array $context): array;

    public function handleCardExpiring(array $context): array;

    public function handleRefundCreated(array $context): array;

    public function handleDisputeCreated(array $context): array;

    public function handleDisputeResolved(array $context): array;

    public function handleSubscriptionCancelled(array $context): array;
}
