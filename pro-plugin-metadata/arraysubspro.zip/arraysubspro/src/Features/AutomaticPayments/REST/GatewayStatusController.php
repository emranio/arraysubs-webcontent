<?php

/**
 * Gateway Status REST Controller
 *
 * Admin-only endpoints for viewing gateway health and status information.
 *
 * @package ArraySubsPro\Features\AutomaticPayments\REST
 * @since 1.0.0
 */

namespace ArraySubsPro\Features\AutomaticPayments\REST;

defined('ABSPATH') || exit;

use ArraySubs\Supports\BaseRestController;
use ArraySubsPro\Features\AutomaticPayments\Contracts\AutomaticGatewayContract;
use ArraySubsPro\Features\AutomaticPayments\Services\GatewayRegistry;
use ArraySubsPro\Features\AutomaticPayments\Services\GatewayResolver;

/**
 * Gateway Status REST Controller
 *
 * Provides endpoints for admin gateway health monitoring.
 */
class GatewayStatusController extends BaseRestController
{
    /**
     * REST base path.
     *
     * @var string
     */
    protected $rest_base = 'gateways';

    /**
     * Register gateway status routes.
     *
     * @return void
     */
    public function registerRoutes(): void
    {
        register_rest_route(
            $this->namespace,
            '/' . $this->rest_base,
            [
                [
                    'methods'             => 'GET',
                    'callback'            => [$this, 'getGateways'],
                    'permission_callback' => [$this, 'checkAdminPermission'],
                ],
            ]
        );

        register_rest_route(
            $this->namespace,
            '/' . $this->rest_base . '/(?P<gateway_slug>[a-z0-9_-]+)',
            [
                [
                    'methods'             => 'GET',
                    'callback'            => [$this, 'getGatewayStatus'],
                    'permission_callback' => [$this, 'checkAdminPermission'],
                    'args'                => [
                        'gateway_slug' => [
                            'required'          => true,
                            'type'              => 'string',
                            'sanitize_callback' => 'sanitize_text_field',
                        ],
                    ],
                ],
            ]
        );
    }

    /**
     * Check admin permission.
     *
     * @return bool
     */
    public function checkAdminPermission(): bool
    {
        if (! is_user_logged_in()) {
            return false;
        }

        return current_user_can('manage_woocommerce') || current_user_can('manage_options');
    }

    /**
     * Get all registered ArraySubs gateways and their status.
     *
     * @param \WP_REST_Request $request The REST request.
     * @return \WP_REST_Response
     */
    public function getGateways(\WP_REST_Request $request): \WP_REST_Response
    {
        $gateways     = GatewayRegistry::getAll();
        $gateway_data = [];

        foreach ($gateways as $gateway) {
            $gateway_data[] = $this->formatGatewayData($gateway);
        }

        return new \WP_REST_Response(
            [
                'success' => true,
                'data'    => $gateway_data,
            ],
            200
        );
    }

    /**
     * Get detailed status for a specific gateway.
     *
     * @param \WP_REST_Request $request The REST request.
     * @return \WP_REST_Response
     */
    public function getGatewayStatus(\WP_REST_Request $request): \WP_REST_Response
    {
        $slug    = sanitize_text_field($request->get_param('gateway_slug'));
        $gateway = GatewayResolver::resolveBySlug($slug);

        if (! $gateway) {
            return new \WP_REST_Response(
                [
                    'success' => false,
                    'message' => __('Gateway not found.', 'arraysubspro'),
                ],
                404
            );
        }

        $data = $this->formatGatewayData($gateway);

        // Add detailed capabilities
        $data['capabilities'] = $gateway->getSubscriptionCapabilities();

        // Add webhook URL
        $data['webhook_url'] = rest_url($this->namespace . '/webhooks/' . $slug);

        return new \WP_REST_Response(
            [
                'success' => true,
                'data'    => $data,
            ],
            200
        );
    }

    /**
     * Format gateway instance into API response data.
     *
     * @param AutomaticGatewayContract $gateway The gateway instance.
     * @return array
     */
    private function formatGatewayData(AutomaticGatewayContract $gateway): array
    {
        return [
            'slug'        => $gateway->getGatewaySlug(),
            'title'       => $gateway->getGatewayTitle(),
            'description' => $gateway->getGatewayDescription(),
            'enabled'     => $gateway->isGatewayEnabled(),
            'test_mode'   => $gateway->isTestMode(),
            'needs_setup' => $gateway->gatewayNeedsSetup(),
            'available'   => $gateway->isGatewayAvailable(),
        ];
    }
}
