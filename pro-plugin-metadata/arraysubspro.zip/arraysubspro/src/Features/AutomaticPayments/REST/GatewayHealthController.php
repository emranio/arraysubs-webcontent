<?php

/**
 * Gateway Health REST Controller
 *
 * Admin-only endpoints for the Gateway Health Dashboard.
 * Provides webhook event logs, per-gateway connection status,
 * subscription counts, and admin actions (detach, reattach).
 *
 * @package ArraySubsPro\Features\AutomaticPayments\REST
 * @since 1.0.0
 */

namespace ArraySubsPro\Features\AutomaticPayments\REST;

defined('ABSPATH') || exit;

use ArraySubs\Supports\BaseRestController;
use ArraySubsPro\Features\AutomaticPayments\Services\GatewayRegistry;
use ArraySubsPro\Features\AutomaticPayments\Services\PaymentLoggingService;
use ArraySubsPro\Features\AutomaticPayments\Services\StripeAvailability;
use ArraySubsPro\Features\AutomaticPayments\Services\StripeSettingsTab;
use ArraySubsPro\Features\AutomaticPayments\Services\StripeWebhookProvisioner;

/**
 * Gateway Health REST Controller
 */
class GatewayHealthController extends BaseRestController
{
    /**
     * REST base path.
     *
     * @var string
     */
    protected $rest_base = 'gateway-health';

    /**
     * Register gateway health routes.
     *
     * @return void
     */
    public function registerRoutes(): void
    {
        // Dashboard overview
        register_rest_route(
            $this->namespace,
            '/' . $this->rest_base,
            [
                [
                    'methods'             => 'GET',
                    'callback'            => [$this, 'getDashboard'],
                    'permission_callback' => [$this, 'checkAdminPermission'],
                ],
            ]
        );

        // Webhook event log
        register_rest_route(
            $this->namespace,
            '/' . $this->rest_base . '/webhook-log',
            [
                [
                    'methods'             => 'GET',
                    'callback'            => [$this, 'getWebhookLog'],
                    'permission_callback' => [$this, 'checkAdminPermission'],
                    'args'                => [
                        'gateway' => [
                            'type'              => 'string',
                            'sanitize_callback' => 'sanitize_text_field',
                        ],
                        'event_type' => [
                            'type'              => 'string',
                            'sanitize_callback' => 'sanitize_text_field',
                        ],
                        'per_page' => [
                            'type'              => 'integer',
                            'default'           => 50,
                            'sanitize_callback' => 'absint',
                        ],
                        'page' => [
                            'type'              => 'integer',
                            'default'           => 1,
                            'sanitize_callback' => 'absint',
                        ],
                    ],
                ],
            ]
        );

        // Detach gateway from subscription
        register_rest_route(
            $this->namespace,
            '/' . $this->rest_base . '/detach/(?P<subscription_id>[\d]+)',
            [
                [
                    'methods'             => 'POST',
                    'callback'            => [$this, 'detachGateway'],
                    'permission_callback' => [$this, 'checkAdminPermission'],
                    'args'                => [
                        'subscription_id' => [
                            'required'          => true,
                            'type'              => 'integer',
                            'sanitize_callback' => 'absint',
                        ],
                    ],
                ],
            ]
        );
    }

    /**
     * Check admin permission.
     *
     * @return bool
     */
    public function checkAdminPermission(): bool
    {
        if (! is_user_logged_in()) {
            return false;
        }

        return current_user_can('manage_woocommerce') || current_user_can('manage_options');
    }

    /**
     * Get gateway health dashboard data.
     *
     * Lists all registered gateways with connection status,
     * subscription counts, and last webhook timestamp.
     *
     * @param \WP_REST_Request $request The REST request.
     * @return \WP_REST_Response
     */
    public function getDashboard(\WP_REST_Request $request): \WP_REST_Response
    {
        $gateways      = GatewayRegistry::getAll();
        $dashboard_data = [];

        foreach ($gateways as $gateway) {
            $slug         = $gateway->getGatewaySlug();
            $enabled      = $gateway->isGatewayEnabled();
            $needs_setup  = $gateway->gatewayNeedsSetup();
            $available    = $gateway->isGatewayAvailable();
            $test_mode    = $gateway->isTestMode();
            $capabilities = $gateway->getSubscriptionCapabilities();

            // Count subscriptions using this gateway
            $subscription_count = $this->countSubscriptionsForGateway($slug);

            // Get last webhook timestamp
            $last_webhook = $this->getLastWebhookTimestamp($slug);

            // Build webhook URL
            $webhook_url = 'stripe' === $slug
                ? $this->getOfficialStripeWebhookUrl()
                : rest_url($this->namespace . '/webhooks/' . $slug);

            $dashboard_data[] = [
                'slug'               => $slug,
                'title'              => $gateway->getGatewayTitle(),
                'description'        => $gateway->getGatewayDescription(),
                'enabled'            => $enabled,
                'needs_setup'        => $needs_setup,
                'available'          => $available,
                'test_mode'          => $test_mode,
                'subscription_count' => $subscription_count,
                'last_webhook_at'    => $last_webhook,
                'webhook_url'        => $webhook_url,
                'settings_url'       => admin_url('admin.php?page=wc-settings&tab=checkout&section=' . $slug),
                'capabilities'       => $capabilities,
            ];

            if ('stripe' === $slug) {
                $dashboard_data[count($dashboard_data) - 1]['stripe'] = $this->getStripeHealthData();
            }
        }

        return new \WP_REST_Response(
            [
                'success' => true,
                'data'    => $dashboard_data,
            ],
            200
        );
    }

    /**
     * Get webhook event log.
     *
     * @param \WP_REST_Request $request The REST request.
     * @return \WP_REST_Response
     */
    public function getWebhookLog(\WP_REST_Request $request): \WP_REST_Response
    {
        global $wpdb;

        $gateway    = sanitize_text_field($request->get_param('gateway') ?? '');
        $event_type = sanitize_text_field($request->get_param('event_type') ?? '');
        $per_page   = absint($request->get_param('per_page') ?? 50);
        $page       = absint($request->get_param('page') ?? 1);
        $offset     = ($page - 1) * $per_page;

        // Clamp per_page to reasonable limits
        $per_page = min(max($per_page, 1), 100);

        $table = $wpdb->prefix . 'arraysubs_webhook_events';

        // Check table existence
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $table_exists = $wpdb->get_var(
            $wpdb->prepare('SHOW TABLES LIKE %s', $table)
        );

        if (! $table_exists) {
            return new \WP_REST_Response(
                [
                    'success' => true,
                    'data'    => [],
                    'total'   => 0,
                    'pages'   => 0,
                ],
                200
            );
        }

        $where_clauses = [];
        $where_values  = [];

        if (! empty($gateway)) {
            $gateway_slugs = $this->getWebhookLogSlugsForGateway($gateway);
            $placeholders  = implode(',', array_fill(0, count($gateway_slugs), '%s'));
            $where_clauses[] = "gateway_slug IN ({$placeholders})"; // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $where_values    = array_merge($where_values, $gateway_slugs);
        }

        if (! empty($event_type)) {
            $where_clauses[] = 'event_type = %s';
            $where_values[]  = $event_type;
        }

        $where = '';
        if (! empty($where_clauses)) {
            $where_sql = ' WHERE ' . implode(' AND ', $where_clauses);
            $where     = $wpdb->prepare($where_sql, ...$where_values); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
        }

        // Get total count
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $total = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table}{$where}");

        // Get paginated events
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $events = $wpdb->get_results(
            $wpdb->prepare(
                // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
                "SELECT gateway_slug, event_id, event_type, processed_at FROM {$table}{$where} ORDER BY processed_at DESC LIMIT %d OFFSET %d",
                $per_page,
                $offset
            ),
            ARRAY_A
        );

        return new \WP_REST_Response(
            [
                'success' => true,
                'data'    => $events ?: [],
                'total'   => $total,
                'pages'   => (int) ceil($total / $per_page),
                'page'    => $page,
            ],
            200
        );
    }

    /**
     * Detach gateway from a subscription.
     *
     * Removes all gateway meta, setting the subscription to manual payment.
     *
     * @param \WP_REST_Request $request The REST request.
     * @return \WP_REST_Response
     */
    public function detachGateway(\WP_REST_Request $request): \WP_REST_Response
    {
        $subscription_id = absint($request->get_param('subscription_id'));

        $subscription = arraysubs_get_subscription($subscription_id);

        if (! $subscription instanceof \WP_Post) {
            return new \WP_REST_Response(
                [
                    'success' => false,
                    'message' => __('Subscription not found.', 'arraysubspro'),
                ],
                404
            );
        }

        $gateway_slug = get_post_meta($subscription_id, '_payment_gateway', true);

        if (empty($gateway_slug)) {
            return new \WP_REST_Response(
                [
                    'success' => false,
                    'message' => __('No gateway attached to this subscription.', 'arraysubspro'),
                ],
                400
            );
        }

        // Set gateway status to detached
        update_post_meta($subscription_id, '_gateway_status', 'detached');

        // Clear payment gateway reference so it falls back to manual
        delete_post_meta($subscription_id, '_payment_gateway');
        delete_post_meta($subscription_id, '_gateway_payment_method_id');
        delete_post_meta($subscription_id, '_gateway_session_id');
        delete_post_meta($subscription_id, '_last_gateway_transaction_id');

        // Clear payment method display info
        delete_post_meta($subscription_id, '_payment_method_brand');
        delete_post_meta($subscription_id, '_payment_method_last4');
        delete_post_meta($subscription_id, '_payment_method_type');
        delete_post_meta($subscription_id, '_payment_method_expiry_month');
        delete_post_meta($subscription_id, '_payment_method_expiry_year');

        // Log the action
        PaymentLoggingService::logPayment(
            $gateway_slug,
            $subscription_id,
            sprintf(
                'Gateway detached by admin (user #%d). Subscription reverted to manual payment.',
                get_current_user_id()
            )
        );

        return new \WP_REST_Response(
            [
                'success' => true,
                'message' => __('Gateway detached. Subscription reverted to manual payment.', 'arraysubspro'),
            ],
            200
        );
    }

    /**
     * Count active subscriptions using a specific gateway.
     *
     * @param string $gateway_slug The gateway slug.
     * @return int
     */
    private function countSubscriptionsForGateway(string $gateway_slug): int
    {
        global $wpdb;

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $count = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(DISTINCT p.ID)
                FROM {$wpdb->posts} p
                INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
                WHERE p.post_type = 'arraysubs_data'
                AND p.post_status IN ('arraysubs-active', 'arraysubs-on-hold', 'arraysubs-trial', 'arraysubs-pending')
                AND pm.meta_key = '_payment_gateway'
                AND pm.meta_value = %s",
                $gateway_slug
            )
        );

        return (int) $count;
    }

    /**
     * Get the last webhook event timestamp for a gateway.
     *
     * @param string $gateway_slug The gateway slug.
     * @return string|null ISO 8601 date or null.
     */
    private function getLastWebhookTimestamp(string $gateway_slug): ?string
    {
        global $wpdb;

        $table = $wpdb->prefix . 'arraysubs_webhook_events';

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $table_exists = $wpdb->get_var(
            $wpdb->prepare('SHOW TABLES LIKE %s', $table)
        );

        if (! $table_exists) {
            return null;
        }

        $gateway_slugs = $this->getWebhookLogSlugsForGateway($gateway_slug);
        $placeholders  = implode(',', array_fill(0, count($gateway_slugs), '%s'));

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $last = $wpdb->get_var(
            $wpdb->prepare(
                // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
                "SELECT processed_at FROM {$table} WHERE gateway_slug IN ({$placeholders}) ORDER BY processed_at DESC LIMIT 1",
                ...$gateway_slugs
            )
        );

        return $last ?: null;
    }

    /**
     * Get official Stripe plugin health data.
     *
     * @return array
     */
    private function getStripeHealthData(): array
    {
        $settings          = get_option('woocommerce_stripe_settings', []);
        $settings          = is_array($settings) ? $settings : [];
        $official_secret   = '' !== $this->getOfficialStripeWebhookSecret($settings);
        $secondary_secret  = '' !== StripeSettingsTab::getSecondaryWebhookSecret();
        $official_webhook  = $this->getOfficialStripeWebhookUrl($settings);
        $secondary_status  = StripeWebhookProvisioner::getStoredStatus();
        $secondary_webhook = StripeWebhookProvisioner::getEndpointUrl();
        $account           = [];

        if (StripeAvailability::isAvailable() && class_exists('\WC_Stripe_API')) {
            try {
                $response = \WC_Stripe_API::retrieve('account');
                if (is_object($response) && empty($response->error)) {
                    $account = [
                        'id'              => isset($response->id) ? (string) $response->id : '',
                        'display_name'    => isset($response->settings->dashboard->display_name) ? (string) $response->settings->dashboard->display_name : '',
                        'charges_enabled' => ! empty($response->charges_enabled),
                        'payouts_enabled' => ! empty($response->payouts_enabled),
                    ];
                }
            } catch (\Throwable $throwable) {
                $account = [
                    'error' => $throwable->getMessage(),
                ];
            }
        }

        return [
            'availability'                    => StripeAvailability::getStatus(),
            'installed_version'               => StripeAvailability::getInstalledVersion(),
            'minimum_version'                 => StripeAvailability::getMinVersion(),
            'tested_version'                  => StripeAvailability::getTestedVersion(),
            'official_webhook_configured'     => $official_secret,
            'official_webhook_url'            => $official_webhook,
            'secondary_webhook_configured'    => $secondary_secret,
            'secondary_webhook_url'           => $secondary_webhook,
            'secondary_webhook_endpoint_id'    => $secondary_status['endpoint_id'] ?? '',
            'secondary_webhook_mode'           => $secondary_status['mode'] ?? '',
            'secondary_webhook_last_error'     => $secondary_status['last_error'] ?? '',
            'secondary_last_webhook_at'       => $this->getLastWebhookTimestamp('arraysubs_stripe'),
            'account'                         => $account,
        ];
    }

    /**
     * Get webhook event table slugs that belong to a visible gateway.
     *
     * @param string $gateway_slug Gateway slug.
     * @return array<int, string>
     */
    private function getWebhookLogSlugsForGateway(string $gateway_slug): array
    {
        $gateway_slug = sanitize_key($gateway_slug);

        if ('stripe' === $gateway_slug) {
            return ['stripe', 'arraysubs_stripe'];
        }

        return [$gateway_slug];
    }

    /**
     * Get the active Woo Stripe webhook signing secret.
     *
     * @param array<string, mixed> $settings Woo Stripe settings.
     * @return string
     */
    private function getOfficialStripeWebhookSecret(array $settings): string
    {
        $test_mode = $this->isOfficialStripeTestMode($settings);
        $primary   = $test_mode ? 'test_webhook_secret' : 'webhook_secret';
        $fallback  = $test_mode ? 'webhook_secret' : 'test_webhook_secret';

        $secret = trim((string) ($settings[$primary] ?? ''));
        if ('' !== $secret) {
            return $secret;
        }

        return trim((string) ($settings[$fallback] ?? ''));
    }

    /**
     * Check whether the official Stripe plugin is in test mode.
     *
     * @param array<string, mixed> $settings Woo Stripe settings.
     * @return bool
     */
    private function isOfficialStripeTestMode(array $settings): bool
    {
        if (class_exists('\WC_Stripe_Mode')) {
            return (bool) \WC_Stripe_Mode::is_test();
        }

        return 'yes' === ($settings['testmode'] ?? 'no');
    }

    /**
     * Get the official Woo Stripe webhook URL.
     *
     * @param array<string, mixed>|null $settings Woo Stripe settings.
     * @return string
     */
    private function getOfficialStripeWebhookUrl(?array $settings = null): string
    {
        $settings = is_array($settings) ? $settings : get_option('woocommerce_stripe_settings', []);
        $settings = is_array($settings) ? $settings : [];

        $data_key = $this->isOfficialStripeTestMode($settings) ? 'test_webhook_data' : 'webhook_data';
        $data     = $settings[$data_key] ?? [];

        if (is_array($data) && ! empty($data['url'])) {
            return esc_url_raw((string) $data['url']);
        }

        return add_query_arg('wc-api', 'wc_stripe', home_url('/'));
    }
}
