<?php

/**
 * Webhook REST Controller
 *
 * Public REST endpoint that receives webhook payloads from payment gateways.
 * Permission callback returns true (webhooks are unauthenticated).
 * Security is enforced via gateway-specific signature verification.
 *
 * @package ArraySubsPro\Features\AutomaticPayments\REST
 * @since 1.0.0
 */

namespace ArraySubsPro\Features\AutomaticPayments\REST;

defined('ABSPATH') || exit;

use ArraySubs\Supports\BaseRestController;
use ArraySubsPro\Features\AutomaticPayments\Services\GatewayRegistry;
use ArraySubsPro\Features\AutomaticPayments\Services\WebhookRouter;
use ArraySubsPro\Features\AutomaticPayments\Services\PaymentLoggingService;

/**
 * Webhook REST Controller
 *
 * Receives webhook payloads from external gateways and delegates to WebhookRouter.
 */
class WebhookController extends BaseRestController
{
    /**
     * REST base path.
     *
     * @var string
     */
    protected $rest_base = 'webhooks';

    /**
     * Register webhook routes.
     *
     * @return void
     */
    public function registerRoutes(): void
    {
        register_rest_route(
            $this->namespace,
            '/' . $this->rest_base . '/(?P<gateway_slug>[a-z0-9_-]+)',
            [
                [
                    'methods'             => 'POST',
                    'callback'            => [$this, 'handleWebhook'],
                    'permission_callback' => '__return_true',
                ],
            ]
        );
    }

    /**
     * Handle incoming webhook.
     *
     * WebhookRouter handles the full processing pipeline (signature verification,
     * parsing, idempotency, dispatch) and returns a complete WP_REST_Response.
     *
     * @param \WP_REST_Request $request The REST request.
     * @return \WP_REST_Response
     */
    public function handleWebhook(\WP_REST_Request $request): \WP_REST_Response
    {
        $gateway_slug = sanitize_text_field($request->get_param('gateway_slug'));

        if (empty($gateway_slug)) {
            return new \WP_REST_Response(
                ['error' => 'Missing gateway slug'],
                400
            );
        }

        $gateway = GatewayRegistry::get($gateway_slug);

        if (! $gateway) {
            return new \WP_REST_Response(
                ['error' => 'Unknown gateway'],
                404
            );
        }

        PaymentLoggingService::logWebhook(
            $gateway_slug,
            'info',
            'Webhook received'
        );

        return WebhookRouter::process($gateway_slug, $request);
    }
}
