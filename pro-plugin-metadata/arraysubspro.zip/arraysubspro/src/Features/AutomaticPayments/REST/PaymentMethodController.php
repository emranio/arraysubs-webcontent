<?php

/**
 * Payment Method REST Controller
 *
 * Customer-facing endpoints for viewing and updating payment methods
 * on subscriptions with automatic payment gateways.
 *
 * @package ArraySubsPro\Features\AutomaticPayments\REST
 * @since 1.0.0
 */

namespace ArraySubsPro\Features\AutomaticPayments\REST;

defined('ABSPATH') || exit;

use ArraySubs\Supports\BaseRestController;
use ArraySubsPro\Features\AutomaticPayments\Services\PaymentMethodCoordinator;

/**
 * Payment Method REST Controller
 *
 * Provides endpoints for customers to view and update payment methods
 * on their subscriptions.
 */
class PaymentMethodController extends BaseRestController
{
    /**
     * REST base path.
     *
     * @var string
     */
    protected $rest_base = 'subscriptions/(?P<subscription_id>[\d]+)/payment-method';

    /**
     * Register payment method routes.
     *
     * @return void
     */
    public function registerRoutes(): void
    {
        register_rest_route(
            $this->namespace,
            '/' . $this->rest_base,
            [
                [
                    'methods'             => 'GET',
                    'callback'            => [$this, 'getPaymentMethod'],
                    'permission_callback' => [$this, 'checkSubscriptionPermission'],
                    'args'                => [
                        'subscription_id' => [
                            'required'          => true,
                            'type'              => 'integer',
                            'sanitize_callback' => 'absint',
                        ],
                    ],
                ],
            ]
        );

        register_rest_route(
            $this->namespace,
            '/' . $this->rest_base . '/update',
            [
                [
                    'methods'             => 'POST',
                    'callback'            => [$this, 'getUpdateMechanism'],
                    'permission_callback' => [$this, 'checkSubscriptionPermission'],
                    'args'                => [
                        'subscription_id' => [
                            'required'          => true,
                            'type'              => 'integer',
                            'sanitize_callback' => 'absint',
                        ],
                        'return_url' => [
                            'type'              => 'string',
                            'sanitize_callback' => 'esc_url_raw',
                        ],
                    ],
                ],
            ]
        );
    }

    /**
     * Check that the current user owns the subscription or is an admin.
     *
     * @param \WP_REST_Request $request The REST request.
     * @return bool|\WP_Error
     */
    public function checkSubscriptionPermission(\WP_REST_Request $request)
    {
        if (! is_user_logged_in()) {
            return false;
        }

        // Admins can access any subscription
        if (current_user_can('manage_woocommerce') || current_user_can('manage_options')) {
            return true;
        }

        $subscription_id = absint($request->get_param('subscription_id'));
        $customer_id     = get_post_meta($subscription_id, '_customer_id', true);

        if (empty($customer_id) || intval($customer_id) <= 0) {
            return false;
        }

        return intval($customer_id) === get_current_user_id();
    }

    /**
     * Get payment method display data for a subscription.
     *
     * @param \WP_REST_Request $request The REST request.
     * @return \WP_REST_Response
     */
    public function getPaymentMethod(\WP_REST_Request $request): \WP_REST_Response
    {
        $subscription_id = absint($request->get_param('subscription_id'));

        $display_data = PaymentMethodCoordinator::getDisplayData($subscription_id);

        if (empty($display_data)) {
            return new \WP_REST_Response(
                [
                    'success' => false,
                    'message' => __('No payment method found for this subscription.', 'arraysubspro'),
                ],
                404
            );
        }

        return new \WP_REST_Response(
            [
                'success' => true,
                'data'    => $display_data,
            ],
            200
        );
    }

    /**
     * Get the payment method update mechanism for a subscription.
     *
     * @param \WP_REST_Request $request The REST request.
     * @return \WP_REST_Response
     */
    public function getUpdateMechanism(\WP_REST_Request $request): \WP_REST_Response
    {
        $subscription_id = absint($request->get_param('subscription_id'));

        if (! PaymentMethodCoordinator::canUpdatePaymentMethod($subscription_id)) {
            return new \WP_REST_Response(
                [
                    'success' => false,
                    'message' => __('Payment method update is not available for this subscription.', 'arraysubspro'),
                ],
                403
            );
        }

        $context = [
            'customer_id' => get_current_user_id(),
            'return_url'  => esc_url_raw($request->get_param('return_url') ?? ''),
        ];

        $mechanism = PaymentMethodCoordinator::getUpdateMechanism($subscription_id, $context);

        if (empty($mechanism) || empty($mechanism['success'])) {
            return new \WP_REST_Response(
                [
                    'success' => false,
                    'message' => $mechanism['message'] ?? __('Unable to initiate payment method update.', 'arraysubspro'),
                ],
                500
            );
        }

        return new \WP_REST_Response(
            [
                'success' => true,
                'data'    => $mechanism,
            ],
            200
        );
    }
}
