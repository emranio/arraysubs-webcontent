<?php

/**
 * Auto-Renew REST Controller
 *
 * Customer-facing endpoint for toggling auto-renew on/off
 * for subscriptions with automatic payment gateways.
 *
 * @package ArraySubsPro\Features\AutomaticPayments\REST
 * @since 1.0.0
 */

namespace ArraySubsPro\Features\AutomaticPayments\REST;

defined('ABSPATH') || exit;

use ArraySubs\Supports\BaseRestController;
use ArraySubsPro\Features\AutomaticPayments\Services\GatewayResolver;
use ArraySubsPro\Features\AutomaticPayments\Services\PaymentLoggingService;

/**
 * Auto-Renew REST Controller
 *
 * Allows customers to toggle automatic renewal on or off
 * from the customer portal.
 */
class AutoRenewController extends BaseRestController
{
    /**
     * REST base path.
     *
     * @var string
     */
    protected $rest_base = 'subscriptions/(?P<subscription_id>[\d]+)/auto-renew';

    /**
     * Register auto-renew routes.
     *
     * @return void
     */
    public function registerRoutes(): void
    {
        register_rest_route(
            $this->namespace,
            '/' . $this->rest_base,
            [
                [
                    'methods'             => 'POST',
                    'callback'            => [$this, 'toggleAutoRenew'],
                    'permission_callback' => [$this, 'checkSubscriptionPermission'],
                    'args'                => [
                        'subscription_id' => [
                            'required'          => true,
                            'type'              => 'integer',
                            'sanitize_callback' => 'absint',
                        ],
                        'enabled' => [
                            'required'          => true,
                            'type'              => 'boolean',
                            'sanitize_callback' => 'rest_sanitize_boolean',
                        ],
                    ],
                ],
            ]
        );
    }

    /**
     * Check that the current user owns the subscription or is an admin.
     *
     * @param \WP_REST_Request $request The REST request.
     * @return bool|\WP_Error
     */
    public function checkSubscriptionPermission(\WP_REST_Request $request)
    {
        if (! is_user_logged_in()) {
            return false;
        }

        // Admins can access any subscription
        if (current_user_can('manage_woocommerce') || current_user_can('manage_options')) {
            return true;
        }

        $subscription_id = absint($request->get_param('subscription_id'));
        $customer_id     = get_post_meta($subscription_id, '_customer_id', true);

        if (empty($customer_id) || intval($customer_id) <= 0) {
            return false;
        }

        return intval($customer_id) === get_current_user_id();
    }

    /**
     * Toggle auto-renew for a subscription.
     *
     * @param \WP_REST_Request $request The REST request.
     * @return \WP_REST_Response
     */
    public function toggleAutoRenew(\WP_REST_Request $request): \WP_REST_Response
    {
        $subscription_id = absint($request->get_param('subscription_id'));
        $enabled         = rest_sanitize_boolean($request->get_param('enabled'));
        $can_reenable    = false;

        // Verify the toggle setting is enabled globally
        if (
            ! function_exists('arraysubs_is_auto_renew_toggle_allowed')
            || ! arraysubs_is_auto_renew_toggle_allowed()
        ) {
            return new \WP_REST_Response(
                [
                    'success' => false,
                    'message' => __('Auto-renew toggle is not available.', 'arraysubspro'),
                ],
                403
            );
        }

        // Verify the subscription exists
        $subscription = function_exists('arraysubs_get_subscription')
            ? arraysubs_get_subscription($subscription_id)
            : get_post($subscription_id);

        if (! $subscription instanceof \WP_Post) {
            return new \WP_REST_Response(
                [
                    'success' => false,
                    'message' => __('Subscription not found.', 'arraysubspro'),
                ],
                404
            );
        }

        if (
            ! function_exists('arraysubs_is_automatic_payment_subscription')
            || ! arraysubs_is_automatic_payment_subscription($subscription_id)
        ) {
            return new \WP_REST_Response(
                [
                    'success' => false,
                    'message' => __('This subscription does not have an active automatic payment gateway.', 'arraysubspro'),
                ],
                400
            );
        }

        // Verify the subscription has a resolvable automatic payment gateway
        $gateway = GatewayResolver::resolveForSubscription($subscription_id);

        if (! $gateway || ! $gateway->supportsSubscriptionCapability('automatic_payments')) {
            return new \WP_REST_Response(
                [
                    'success' => false,
                    'message' => __('This subscription does not have an active automatic payment gateway.', 'arraysubspro'),
                ],
                400
            );
        }

        $gateway_slug   = $gateway->getGatewaySlug();
        $gateway_status = strtolower((string) get_post_meta($subscription_id, '_gateway_status', true));

        if ($enabled === (function_exists('arraysubs_is_auto_renew_enabled') ? arraysubs_is_auto_renew_enabled($subscription_id) : true)) {
            $can_reenable = $this->canSubscriptionReenableAutoRenew($gateway_status, $gateway_slug, $gateway, $subscription_id);

            return new \WP_REST_Response(
                [
                    'success' => true,
                    'data'    => [
                        'auto_renew'   => $enabled,
                        'can_reenable' => $can_reenable,
                    ],
                    'message' => $enabled
                        ? __('Auto-renew is already enabled.', 'arraysubspro')
                        : __('Auto-renew is already disabled.', 'arraysubspro'),
                ],
                200
            );
        }

        // Verify subscription is in an eligible status
        $allowed_statuses = [
            'arraysubs-active',
            'arraysubs-on-hold',
            'arraysubs-trial',
        ];

        if (! in_array($subscription->post_status, $allowed_statuses, true)) {
            return new \WP_REST_Response(
                [
                    'success' => false,
                    'message' => __('Auto-renew can only be changed for active, on-hold, or trial subscriptions.', 'arraysubspro'),
                ],
                400
            );
        }

        // Check for pending cancellation
        $waiting_cancellation = get_post_meta($subscription_id, '_waiting_cancellation', true);
        if (! empty($waiting_cancellation)) {
            return new \WP_REST_Response(
                [
                    'success' => false,
                    'message' => __('Cannot change auto-renew for a subscription pending cancellation.', 'arraysubspro'),
                ],
                400
            );
        }

        // If re-enabling, verify the payment method is still available
        if ($enabled) {
            $pm_id = get_post_meta($subscription_id, '_gateway_payment_method_id', true);

            if (empty($pm_id) || in_array($gateway_status, ['detached', 'errored', 'cancelled', 'inactive'], true)) {
                return new \WP_REST_Response(
                    [
                        'success' => false,
                        'message' => __('Cannot enable auto-renew: your automatic payment setup is no longer active. Please update your payment method first.', 'arraysubspro'),
                    ],
                    400
                );
            }

            if ('paused' === $gateway_status && $gateway->supportsSubscriptionCapability('resume')) {
                $resume_result = $gateway->resumeRemoteBillingContext($subscription_id, [
                    'source' => 'customer_auto_renew_toggle',
                ]);

                if (empty($resume_result['success'])) {
                    PaymentLoggingService::logPayment(
                        $gateway_slug,
                        $subscription_id,
                        sprintf('Failed to resume remote billing while enabling auto-renew: %s', $resume_result['message'] ?? 'unknown error'),
                        'error'
                    );

                    return new \WP_REST_Response(
                        [
                            'success' => false,
                            'message' => $resume_result['message'] ?? __('Failed to resume automatic billing at the payment gateway.', 'arraysubspro'),
                        ],
                        500
                    );
                }

                update_post_meta($subscription_id, '_gateway_status', 'active');
                $gateway_status = 'active';
            }
        } elseif ('arraysubs_paddle' === $gateway_slug && $gateway->supportsSubscriptionCapability('pause')) {
            $pause_result = $gateway->pauseRemoteBillingContext($subscription_id, [
                'source' => 'customer_auto_renew_toggle',
            ]);

            if (empty($pause_result['success'])) {
                PaymentLoggingService::logPayment(
                    $gateway_slug,
                    $subscription_id,
                    sprintf('Failed to pause remote billing while disabling auto-renew: %s', $pause_result['message'] ?? 'unknown error'),
                    'error'
                );

                return new \WP_REST_Response(
                    [
                        'success' => false,
                        'message' => $pause_result['message'] ?? __('Failed to pause automatic billing at the payment gateway.', 'arraysubspro'),
                    ],
                    500
                );
            }

            update_post_meta($subscription_id, '_gateway_status', 'paused');
            $gateway_status = 'paused';
        } elseif ('arraysubs_paypal' === $gateway_slug) {
            $cancel_result = $gateway->cancelRemoteBillingContext($subscription_id, [
                'reason' => __('Cancelled by customer turning off auto-renew.', 'arraysubspro'),
                'source' => 'customer_auto_renew_toggle',
            ]);

            if (empty($cancel_result['success'])) {
                PaymentLoggingService::logPayment(
                    $gateway_slug,
                    $subscription_id,
                    sprintf('Failed to cancel remote billing while disabling auto-renew: %s', $cancel_result['message'] ?? 'unknown error'),
                    'error'
                );

                return new \WP_REST_Response(
                    [
                        'success' => false,
                        'message' => $cancel_result['message'] ?? __('Failed to stop automatic billing at the payment gateway.', 'arraysubspro'),
                    ],
                    500
                );
            }

            $gateway_status = 'inactive';
        }

        $can_reenable = $this->canSubscriptionReenableAutoRenew($gateway_status, $gateway_slug, $gateway, $subscription_id);

        // Perform the toggle
        $new_value = $enabled ? 'on' : 'off';
        update_post_meta($subscription_id, '_auto_renew', $new_value);

        // Determine the actor: an admin acting on behalf of a customer
        // should not be attributed as "by customer". The endpoint accepts
        // both via checkSubscriptionPermission(), so detect explicitly.
        $current_user   = wp_get_current_user();
        $sub_customer_id = (int) get_post_meta($subscription_id, '_customer_id', true);
        $acting_as_admin = (
            ($current_user->ID !== $sub_customer_id)
            && (current_user_can('manage_woocommerce') || current_user_can('manage_options'))
        );
        $actor_label = $acting_as_admin
            ? __('admin', 'arraysubspro')
            : __('customer', 'arraysubspro');

        $note_text = $enabled
            ? sprintf(
                /* translators: 1: actor (customer or admin), 2: user display name */
                __('Auto-renew enabled by %1$s (%2$s). Automatic payments will resume for the next renewal.', 'arraysubspro'),
                esc_html($actor_label),
                esc_html($current_user->display_name)
            )
            : sprintf(
                /* translators: 1: actor (customer or admin), 2: user display name */
                __('Auto-renew disabled by %1$s (%2$s). Next renewal will generate a manual invoice instead of automatic charge.', 'arraysubspro'),
                esc_html($actor_label),
                esc_html($current_user->display_name)
            );

        if (function_exists('arraysubs_add_subscription_note')) {
            arraysubs_add_subscription_note($subscription_id, $note_text, 'private', 0, [], 'subscription');
        }

        // Log the change
        PaymentLoggingService::logPayment(
            $gateway_slug,
            $subscription_id,
            sprintf(
                $enabled ? 'Auto-renew enabled by %s' : 'Auto-renew disabled by %s',
                $acting_as_admin ? 'admin' : 'customer'
            ),
            'info'
        );

        /**
         * Fires when auto-renew is toggled for a subscription.
         *
         * @param int    $subscription_id The subscription post ID.
         * @param bool   $enabled         Whether auto-renew is now enabled.
         * @param string $gateway_slug    The payment gateway slug.
         */
        do_action('arraysubspro_auto_renew_toggled', $subscription_id, $enabled, $gateway_slug);

        return new \WP_REST_Response(
            [
                'success' => true,
                'data'    => [
                    'auto_renew'   => $enabled,
                    'can_reenable' => $can_reenable,
                ],
                'message' => $enabled
                    ? __('Auto-renew has been enabled. Your subscription will be charged automatically.', 'arraysubspro')
                    : __('Auto-renew has been disabled. You will receive an invoice for manual payment at your next renewal.', 'arraysubspro'),
            ],
            200
        );
    }

    /**
     * Determine whether a subscription can immediately re-enable auto-renew.
     *
     * @param string $gateway_status  Current gateway status.
     * @param string $gateway_slug    Current gateway slug.
     * @param mixed  $gateway         Resolved gateway instance.
     * @param int    $subscription_id Subscription ID.
     * @return bool
     */
    private function canSubscriptionReenableAutoRenew(string $gateway_status, string $gateway_slug, $gateway, int $subscription_id): bool
    {
        $pm_id = get_post_meta($subscription_id, '_gateway_payment_method_id', true);

        if (empty($pm_id) || ! $gateway) {
            return false;
        }

        if ('paused' === $gateway_status) {
            return $gateway->supportsSubscriptionCapability('resume');
        }

        if ('arraysubs_paypal' === $gateway_slug && 'inactive' === $gateway_status) {
            return false;
        }

        return empty($gateway_status) || 'active' === $gateway_status;
    }
}
