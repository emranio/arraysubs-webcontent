<?php

/**
 * Automatic Payments Provider
 *
 * Entry point for the Automatic Payments feature.
 * Loads all services, REST controllers, and gateway infrastructure.
 *
 * @package ArraySubsPro\Features\AutomaticPayments
 * @since 1.0.0
 */

namespace ArraySubsPro\Features\AutomaticPayments;

defined('ABSPATH') || exit;

use ArraySubs\Supports\Abstracts\AbstractLoader;

/**
 * Automatic Payments feature entry point
 */
class Provider extends AbstractLoader
{
    /**
     * Constructor
     */
    public function __construct()
    {
        $this->classLoader([
            plugin_dir_path(__FILE__) . 'Services',
            plugin_dir_path(__FILE__) . 'REST',
        ]);
    }
}
