<?php

/**
 * Stripe Delegate
 *
 * Non-checkout automatic-payment adapter that delegates first-purchase UI and
 * refunds to the official WooCommerce Stripe Gateway while keeping ArraySubs
 * renewal, retry, webhook, and reporting contracts intact.
 *
 * @package ArraySubsPro\Features\AutomaticPayments\Gateways\Stripe
 */

namespace ArraySubsPro\Features\AutomaticPayments\Gateways\Stripe;

defined('ABSPATH') || exit;

use ArraySubsPro\Features\AutomaticPayments\Contracts\AutomaticGatewayContract;
use ArraySubsPro\Features\AutomaticPayments\Services\DatabaseMigration;
use ArraySubsPro\Features\AutomaticPayments\Services\MandateRegistry;
use ArraySubsPro\Features\AutomaticPayments\Services\PaymentLoggingService;
use ArraySubsPro\Features\AutomaticPayments\Services\PaymentMetaNormalizer;
use ArraySubsPro\Features\AutomaticPayments\Services\StripeAvailability;
use ArraySubsPro\Features\AutomaticPayments\Services\StripeOrderContextBridge;
use ArraySubsPro\Features\AutomaticPayments\Services\StripeSettingsTab;
use ArraySubsPro\Features\AutomaticPayments\Services\TwoWaySyncGuard;

/**
 * Stripe automatic-payment delegate.
 */
class StripeDelegate implements AutomaticGatewayContract
{
    /**
     * Gateway slug used by the official plugin.
     *
     * @var string
     */
    const GATEWAY_SLUG = 'stripe';

    /**
     * Secondary webhook slug kept for existing ArraySubs webhook endpoint.
     *
     * @var string
     */
    const SECONDARY_WEBHOOK_SLUG = 'arraysubs_stripe';

    /**
     * Stripe bank-debit methods requiring mandate forwarding.
     *
     * @var array<string>
     */
    private array $mandate_methods = [
        'sepa_debit',
        'us_bank_account',
        'bacs_debit',
        'au_becs_debit',
        'acss_debit',
    ];

    /**
     * Subscription capabilities.
     *
     * @var array<string, bool>
     */
    private array $subscription_capabilities = [
        'automatic_payments'       => true,
        'trials'                   => true,
        'pause'                    => false,
        'resume'                   => false,
        'retention_amount_update'  => true,
        'product_sync'             => false,
        'payment_method_update'    => true,
        'card_auto_update'         => true,
        'card_expiry_notice'       => true,
        'disputes'                 => true,
        'sca'                      => true,
        'refunds'                  => true,
        'hosted_payment_page'      => true,
        'customer_portal'          => true,
        'mixed_cart'               => true,
        'multiple_subscriptions'   => true,
        'different_billing_cycles' => true,
        'supports_sync'            => true,
    ];

    /**
     * Secondary webhook event map.
     *
     * @var array<string, string>
     */
    private array $event_map = [
        'payment_intent.succeeded'                 => self::EVENT_PAYMENT_SUCCEEDED,
        'payment_intent.payment_failed'            => self::EVENT_PAYMENT_FAILED,
        'payment_intent.requires_action'           => self::EVENT_PAYMENT_REQUIRES_ACTION,
        'invoice.payment_succeeded'                => self::EVENT_PAYMENT_SUCCEEDED,
        'invoice.payment_failed'                   => self::EVENT_PAYMENT_FAILED,
        'charge.succeeded'                         => self::EVENT_PAYMENT_SUCCEEDED,
        'charge.refunded'                          => self::EVENT_REFUND_CREATED,
        'charge.dispute.created'                   => self::EVENT_DISPUTE_CREATED,
        'charge.dispute.closed'                    => self::EVENT_DISPUTE_RESOLVED,
        'setup_intent.succeeded'                   => self::EVENT_PAYMENT_METHOD_UPDATED,
        'customer.source.expiring'                  => self::EVENT_CARD_EXPIRING,
        'payment_method.updated'                    => self::EVENT_PAYMENT_METHOD_UPDATED,
        'payment_method.automatically_updated'      => self::EVENT_PAYMENT_METHOD_UPDATED,
        'payment_method.card_automatically_updated' => self::EVENT_PAYMENT_METHOD_UPDATED,
    ];

    /**
     * Constructor.
     */
    public function __construct()
    {
        add_action('arraysubs_register_automatic_gateway', [$this, 'registerGateway']);
        add_filter('arraysubs_payment_retry_config', [$this, 'publishRetryConfigForSubscription'], 10, 2);
        add_action('wc_stripe_webhook_received', [$this, 'handleOfficialStripeWebhook'], 30, 3);
        add_action('wc_stripe_deferred_webhook', [$this, 'handleDeferredOfficialStripeWebhook'], 20, 3);
        add_action('woocommerce_api_wc_stripe', [$this, 'rememberSkippedOfficialPaymentIntentWebhook'], 5);
        add_action('woocommerce_create_refund', [$this, 'prepareOrderForStripeRefund'], 5, 2);
    }

    /**
     * Register this non-WC gateway delegate.
     *
     * @param array<string, AutomaticGatewayContract> $gateways Gateways.
     * @return void
     */
    public function registerGateway(array &$gateways): void
    {
        $gateways[self::GATEWAY_SLUG] = $this;
    }

    public function getGatewaySlug(): string
    {
        return self::GATEWAY_SLUG;
    }

    public function getGatewayTitle(): string
    {
        return __('Stripe', 'arraysubspro');
    }

    public function getGatewayDescription(): string
    {
        return __('Stripe payments are processed by the official WooCommerce Stripe Gateway. ArraySubsPro handles subscription renewals and lifecycle automation.', 'arraysubspro');
    }

    public function isGatewayEnabled(): bool
    {
        $settings = get_option('woocommerce_stripe_settings', []);
        return StripeAvailability::isAvailable() && is_array($settings) && 'yes' === ($settings['enabled'] ?? 'no');
    }

    public function isGatewayAvailable(): bool
    {
        if (! $this->isGatewayEnabled() || ! function_exists('WC')) {
            return false;
        }

        $gateways = WC()->payment_gateways() ? WC()->payment_gateways()->payment_gateways() : [];
        $gateway  = $gateways[self::GATEWAY_SLUG] ?? null;

        return $gateway && method_exists($gateway, 'is_available') ? (bool) $gateway->is_available() : true;
    }

    public function gatewayNeedsSetup(): bool
    {
        return ! StripeAvailability::isAvailable() || ! $this->hasOfficialCredentials();
    }

    public function isTestMode(): bool
    {
        if (class_exists('\WC_Stripe_Mode')) {
            return (bool) \WC_Stripe_Mode::is_test();
        }

        $settings = get_option('woocommerce_stripe_settings', []);
        return is_array($settings) && 'yes' === ($settings['testmode'] ?? 'no');
    }

    public function getSubscriptionCapabilities(): array
    {
        return $this->subscription_capabilities;
    }

    public function supportsSubscriptionCapability(string $capability): bool
    {
        return $this->subscription_capabilities[$capability] ?? false;
    }

    public function processRenewalPayment(int $subscription_id, \WC_Order $order): array
    {
        if (! StripeAvailability::isAvailable() || ! class_exists('\WC_Stripe_API')) {
            return $this->buildFailure('stripe_unavailable', __('WooCommerce Stripe Gateway is not available.', 'arraysubspro'));
        }

        $meta = $this->getGatewayMeta($subscription_id);
        if ('' === $meta['customer_id'] || '' === $meta['payment_method_id']) {
            return $this->buildFailure('missing_credentials', __('Missing Stripe customer or payment method for renewal.', 'arraysubspro'));
        }

        $amount   = self::toSmallestUnit((float) $order->get_total(), $order->get_currency());
        $currency = strtolower($order->get_currency());

        $this->prepareRenewalOrderMeta($order, $subscription_id, $meta);

        if ($amount <= 0) {
            $order->payment_complete('renewal_zero_amount');
            return [
                'success'        => true,
                'status'         => 'paid',
                'transaction_id' => 'renewal_zero_amount',
                'message'        => __('Zero-amount renewal completed.', 'arraysubspro'),
                'raw'            => [],
            ];
        }

        $params = [
            'amount'         => $amount,
            'currency'       => $currency,
            'customer'       => $meta['customer_id'],
            'payment_method' => $meta['payment_method_id'],
            'off_session'    => 'true',
            'confirm'        => 'true',
            'metadata'       => [
                'order_id'        => $order->get_id(),
                'subscription_id' => $subscription_id,
                'renewal'         => 'true',
                'site_url'        => home_url(),
            ],
        ];

        $mandate_id = MandateRegistry::getMandateForSubscription($subscription_id);
        if ($mandate_id && in_array($meta['payment_method_type'], $this->mandate_methods, true)) {
            $params['mandate'] = $mandate_id;
            $params['payment_method_options'][$meta['payment_method_type']] = ['mandate' => $mandate_id];
        }

        PaymentLoggingService::logPayment(
            self::GATEWAY_SLUG,
            $subscription_id,
            sprintf('Creating Stripe off-session renewal PaymentIntent for order #%d.', $order->get_id())
        );

        $intent = $this->stripeRequest($params, 'payment_intents', 'POST');

        if (is_wp_error($intent)) {
            $error_data = (array) $intent->get_error_data();
            $pi         = $this->objectToArray($error_data['payment_intent'] ?? []);
            $pi_id      = (string) ($pi['id'] ?? '');

            if ('' !== $pi_id) {
                $this->storeIntentMeta($order, $pi_id);
            }

            if ('authentication_required' === ($error_data['code'] ?? '') || 'requires_action' === ($pi['status'] ?? '')) {
                return $this->handleRequiresActionResult($subscription_id, $order, $pi ?: ['id' => $pi_id]);
            }

            return $this->buildFailure((string) ($error_data['code'] ?? 'stripe_api_error'), $intent->get_error_message(), $pi_id, $error_data);
        }

        $intent    = $this->objectToArray($intent);
        $intent_id = (string) ($intent['id'] ?? '');
        if ('' !== $intent_id) {
            $this->storeIntentMeta($order, $intent_id);
        }

        $status = (string) ($intent['status'] ?? '');
        if ('succeeded' === $status) {
            $charge_id      = $this->extractChargeIdFromIntent($intent);
            $transaction_id = $charge_id ?: $intent_id;

            if ('' !== $intent_id) {
                $this->storeIntentMeta($order, $intent_id, $charge_id);
            }

            $order->payment_complete($transaction_id);
            update_post_meta($subscription_id, '_last_gateway_transaction_id', sanitize_text_field($transaction_id));

            return [
                'success'        => true,
                'status'         => 'paid',
                'transaction_id' => $transaction_id,
                'message'        => __('Renewal charge completed by Stripe.', 'arraysubspro'),
                'raw'            => $intent,
            ];
        }

        if ('processing' === $status) {
            update_post_meta($subscription_id, '_last_gateway_transaction_id', sanitize_text_field($intent_id));
            return [
                'success'        => true,
                'status'         => 'pending',
                'transaction_id' => $intent_id,
                'message'        => __('Renewal charge submitted to Stripe; awaiting webhook confirmation.', 'arraysubspro'),
                'raw'            => $intent,
            ];
        }

        if (in_array($status, ['requires_action', 'requires_confirmation'], true)) {
            return $this->handleRequiresActionResult($subscription_id, $order, $intent);
        }

        return $this->buildFailure(
            'unexpected_status',
            /* translators: %s: Stripe PaymentIntent status. */
            sprintf(__('Unexpected Stripe PaymentIntent status: %s', 'arraysubspro'), $status ?: 'unknown'),
            $intent_id,
            $intent
        );
    }

    public function setupTrialPaymentMethod(\WC_Order $order, int $subscription_id, array $trial_data): array
    {
        $this->captureContextFromOrder($order, $subscription_id);

        return [
            'success'                  => true,
            'remote_customer_id'       => (string) get_post_meta($subscription_id, '_gateway_customer_id', true),
            'remote_payment_method_id' => (string) get_post_meta($subscription_id, '_gateway_payment_method_id', true),
            'message'                  => __('Stripe payment method setup is handled by the official Stripe checkout flow.', 'arraysubspro'),
            'raw'                      => [],
        ];
    }

    public function capturePaymentContext(\WC_Order $order, int $subscription_id): array
    {
        return (new StripeOrderContextBridge(false))->capture($order, $subscription_id);
    }

    public function captureContextFromOrder(\WC_Order $order, int $subscription_id): void
    {
        $this->capturePaymentContext($order, $subscription_id);
    }

    public function cancelRemoteBillingContext(int $subscription_id, array $context = []): array
    {
        update_post_meta($subscription_id, '_gateway_status', 'inactive');
        PaymentLoggingService::logPayment(
            self::GATEWAY_SLUG,
            $subscription_id,
            __('Stripe billing context marked inactive locally. Saved payment methods remain attached in Stripe.', 'arraysubspro')
        );

        return [
            'success' => true,
            'message' => __('Stripe billing context marked inactive locally.', 'arraysubspro'),
            'raw'     => [],
        ];
    }

    public function pauseRemoteBillingContext(int $subscription_id, array $context = []): array
    {
        return ['success' => false, 'message' => __('Stripe does not support remote pause for ArraySubs-managed subscriptions.', 'arraysubspro'), 'raw' => []];
    }

    public function resumeRemoteBillingContext(int $subscription_id, array $context = []): array
    {
        return ['success' => false, 'message' => __('Stripe does not support remote resume for ArraySubs-managed subscriptions.', 'arraysubspro'), 'raw' => []];
    }

    public function restoreScheduledCancel(int $subscription_id, array $context = []): array
    {
        return ['success' => false, 'message' => __('Stripe does not manage scheduled cancellations for ArraySubs subscriptions.', 'arraysubspro'), 'raw' => []];
    }

    public function getRetryConfig(): array
    {
        return [
            'enabled'          => true,
            'max_attempts'     => 3,
            'interval_seconds' => DAY_IN_SECONDS,
        ];
    }

    /**
     * Normalize legacy ArraySubs Stripe renewal orders before Woo Stripe refunds them.
     *
     * WooCommerce Stripe refunds use the Woo transaction ID as the charge ID.
     * Older ArraySubs renewal orders stored the PaymentIntent there, so resolve
     * and persist the backing charge before WooCommerce calls process_refund().
     *
     * @param mixed $refund Refund object being created.
     * @param array $args   wc_create_refund() arguments.
     * @return void
     */
    public function prepareOrderForStripeRefund($refund, array $args): void
    {
        if (empty($args['refund_payment']) || empty($args['order_id'])) {
            return;
        }

        $order = wc_get_order(absint($args['order_id']));
        if (!$order instanceof \WC_Order || self::GATEWAY_SLUG !== $order->get_payment_method()) {
            return;
        }

        $this->ensureStripeChargeTransactionForOrder($order);
    }

    public function publishRetryConfigForSubscription(array $config, int $subscription_id): array
    {
        $slug = (string) get_post_meta($subscription_id, '_payment_gateway', true);
        return self::GATEWAY_SLUG === $slug ? array_merge($config, $this->getRetryConfig()) : $config;
    }

    public function verifyRecentChargeForOrder(int $subscription_id, \WC_Order $order, array $context = []): array
    {
        $stored_transaction_id = (string) ($order->get_meta('_stripe_intent_id', true) ?: $order->get_meta('_arraysubs_pending_transaction_id', true));

        if ('' !== $stored_transaction_id) {
            $pi = $this->stripeRetrieve('payment_intents/' . rawurlencode($stored_transaction_id));
            if (! is_wp_error($pi)) {
                $status = (string) ($pi['status'] ?? '');
                $charge_id = $this->extractChargeIdFromIntent($pi);
                if ('succeeded' === $status && '' !== $charge_id) {
                    $this->storeIntentMeta($order, (string) ($pi['id'] ?? $stored_transaction_id), $charge_id);
                }

                return [
                    'found'          => true,
                    'charged'        => 'succeeded' === $status,
                    'transaction_id' => 'succeeded' === $status && '' !== $charge_id
                        ? $charge_id
                        : (string) ($pi['id'] ?? $stored_transaction_id),
                    'message'        => sprintf('PaymentIntent %s status: %s', $stored_transaction_id, $status),
                    'raw'            => $pi,
                ];
            }
        }

        $customer_id = (string) get_post_meta($subscription_id, '_gateway_customer_id', true);
        if ('' === $customer_id) {
            return ['found' => false, 'charged' => false, 'transaction_id' => '', 'message' => 'No Stripe customer ID stored', 'raw' => []];
        }

        $created_after = time() - (int) ($context['window_seconds'] ?? 7 * DAY_IN_SECONDS);
        $list          = $this->stripeRequest(
            [
                'customer' => $customer_id,
                'created'  => ['gte' => $created_after],
                'limit'    => 50,
            ],
            'payment_intents',
            'GET'
        );

        if (is_wp_error($list) || empty($list['data'])) {
            return ['found' => false, 'charged' => false, 'transaction_id' => '', 'message' => 'No recent PaymentIntents found', 'raw' => []];
        }

        foreach ($list['data'] as $pi) {
            $metadata = is_array($pi['metadata'] ?? null) ? $pi['metadata'] : [];
            if (
                (string) ($metadata['order_id'] ?? '') !== (string) $order->get_id()
                || (string) ($metadata['subscription_id'] ?? '') !== (string) $subscription_id
            ) {
                continue;
            }

            if ('succeeded' === (string) ($pi['status'] ?? '')) {
                $charge_id = $this->extractChargeIdFromIntent($pi);
                if ('' !== $charge_id && ! empty($pi['id'])) {
                    $this->storeIntentMeta($order, (string) $pi['id'], $charge_id);
                }

                return [
                    'found'          => true,
                    'charged'        => true,
                    'transaction_id' => $charge_id ?: (string) ($pi['id'] ?? ''),
                    'message'        => sprintf('Found succeeded Stripe PaymentIntent %s for order #%d', $pi['id'] ?? '', $order->get_id()),
                    'raw'            => $pi,
                ];
            }
        }

        return ['found' => false, 'charged' => false, 'transaction_id' => '', 'message' => 'No matching successful PaymentIntent found', 'raw' => []];
    }

    public function syncFromGateway(int $subscription_id): array
    {
        $customer_id = (string) get_post_meta($subscription_id, '_gateway_customer_id', true);
        $pm_id       = (string) get_post_meta($subscription_id, '_gateway_payment_method_id', true);

        if ('' === $customer_id) {
            return $this->buildSyncFailure(__('No Stripe customer linked to this subscription.', 'arraysubspro'));
        }

        $customer = $this->stripeRetrieve('customers/' . rawurlencode($customer_id));
        if (is_wp_error($customer)) {
            return $this->buildSyncFailure($customer->get_error_message());
        }

        $pm_data = [];
        if ('' !== $pm_id) {
            $pm = $this->stripeRetrieve('payment_methods/' . rawurlencode($pm_id));
            if (! is_wp_error($pm)) {
                $type = (string) ($pm['type'] ?? 'card');
                $card = is_array($pm[$type] ?? null) ? $pm[$type] : ($pm['card'] ?? []);
                $pm_data = [
                    'brand'        => $card['brand'] ?? '',
                    'last4'        => $card['last4'] ?? '',
                    'expiry_month' => $card['exp_month'] ?? '',
                    'expiry_year'  => $card['exp_year'] ?? '',
                    'wallet'       => $card['wallet']['type'] ?? '',
                    'detached'     => empty($pm['customer']),
                ];
            }
        }

        $charges_list = $this->stripeRequest(
            [
                'customer' => $customer_id,
                'created'  => ['gte' => time() - 30 * DAY_IN_SECONDS],
                'limit'    => 20,
            ],
            'payment_intents',
            'GET'
        );

        $recent_charges = [];
        if (! is_wp_error($charges_list) && ! empty($charges_list['data'])) {
            foreach ($charges_list['data'] as $pi) {
                $metadata = is_array($pi['metadata'] ?? null) ? $pi['metadata'] : [];
                if ((string) ($metadata['subscription_id'] ?? '') !== (string) $subscription_id) {
                    continue;
                }

                $recent_charges[] = [
                    'transaction_id'    => $this->extractChargeIdFromIntent($pi) ?: (string) ($pi['id'] ?? ''),
                    'payment_intent_id' => (string) ($pi['id'] ?? ''),
                    'order_id'          => (int) ($metadata['order_id'] ?? 0),
                    'status'            => (string) ($pi['status'] ?? ''),
                    'amount'            => (int) ($pi['amount'] ?? 0),
                    'currency'          => strtoupper((string) ($pi['currency'] ?? '')),
                    'created'           => (int) ($pi['created'] ?? 0),
                ];
            }
        }

        return [
            'success'           => true,
            'message'           => __('Stripe state retrieved.', 'arraysubspro'),
            'gateway_status'    => 'active',
            'next_payment_date' => '',
            'payment_method'    => $pm_data,
            'recent_charges'    => $recent_charges,
            'raw'               => ['customer' => $customer],
        ];
    }

    public function formatPaymentMethodForDisplay(int $subscription_id): array
    {
        $meta   = $this->getGatewayMeta($subscription_id);
        $brand  = ucfirst($meta['brand'] ?: __('Card', 'arraysubspro'));
        $last4  = $meta['last4'] ?: '****';
        $wallet = (string) get_post_meta($subscription_id, '_payment_method_wallet', true);
        $expiry = '';

        if ($meta['expiry_month'] > 0 && $meta['expiry_year'] > 0) {
            $expiry = sprintf('%02d/%d', $meta['expiry_month'], $meta['expiry_year']);
        }

        $title = sprintf(
            /* translators: 1: card brand, 2: last 4 digits */
            __('%1$s ending in %2$s', 'arraysubspro'),
            $brand,
            $last4
        );

        if ('' !== $wallet) {
            $title = sprintf(
                /* translators: 1: wallet type, 2: card title */
                __('%1$s (%2$s)', 'arraysubspro'),
                ucwords(str_replace('_', ' ', $wallet)),
                $title
            );
        }

        return [
            'gateway'     => self::GATEWAY_SLUG,
            'title'       => $title,
            'brand'       => $meta['brand'],
            'last4'       => $last4,
            'expiry'      => $expiry,
            'is_expired'  => $this->isExpired($meta['expiry_month'], $meta['expiry_year']),
            'can_update'  => true,
            'update_url'  => '',
            'update_type' => 'stripe_portal',
        ];
    }

    public function getPaymentMethodUpdateMechanism(int $subscription_id, array $context = []): array
    {
        $customer_id = (string) get_post_meta($subscription_id, '_gateway_customer_id', true);
        if ('' === $customer_id) {
            return ['success' => false, 'type' => '', 'url' => '', 'message' => __('No Stripe customer found for this subscription.', 'arraysubspro'), 'raw' => []];
        }

        $return_url = (string) ($context['return_url'] ?? wc_get_account_endpoint_url('subscriptions'));
        $session    = $this->stripeRequest(
            [
                'customer'   => $customer_id,
                'return_url' => $return_url,
            ],
            'billing_portal/sessions',
            'POST'
        );

        if (is_wp_error($session)) {
            return ['success' => false, 'type' => 'stripe_portal', 'url' => '', 'message' => $session->get_error_message(), 'raw' => []];
        }

        return [
            'success' => true,
            'type'    => 'stripe_portal',
            'url'     => (string) ($session['url'] ?? ''),
            'message' => __('Redirecting to Stripe customer portal.', 'arraysubspro'),
            'raw'     => $session,
        ];
    }

    public function verifyWebhookSignature(\WP_REST_Request $request): bool
    {
        $secret = StripeSettingsTab::getSecondaryWebhookSecret();
        if ('' === $secret) {
            return false;
        }

        $signature = $request->get_header('Stripe-Signature') ?: $request->get_header('stripe_signature');
        if ('' === (string) $signature) {
            return false;
        }

        return $this->verifyStripeSignature($request->get_body(), (string) $signature, $secret);
    }

    public function parseWebhook(\WP_REST_Request $request): array
    {
        $body  = $request->get_body();
        $event = json_decode($body, true);

        if (! is_array($event) || empty($event['id']) || empty($event['type'])) {
            return ['success' => false, 'gateway_event_id' => '', 'gateway_event_type' => '', 'normalized_event_type' => '', 'occurred_at' => 0, 'payload' => [], 'raw_body' => $body];
        }

        return [
            'success'               => true,
            'gateway_event_id'      => (string) $event['id'],
            'gateway_event_type'    => (string) $event['type'],
            'normalized_event_type' => $this->normalizeEventType((string) $event['type']),
            'occurred_at'           => (int) ($event['created'] ?? time()),
            'payload'               => is_array($event['data']['object'] ?? null) ? $event['data']['object'] : [],
            'raw_body'              => $body,
        ];
    }

    public function resolveEntityIds(array $parsed_webhook): array
    {
        $payload = $parsed_webhook['payload'] ?? [];
        $result  = [
            'subscription_id' => 0,
            'order_id'        => 0,
            'customer_id'     => 0,
        ];

        $metadata = is_array($payload['metadata'] ?? null) ? $payload['metadata'] : [];
        if (! empty($metadata['order_id'])) {
            $result['order_id'] = absint($metadata['order_id']);
        }
        if (! empty($metadata['subscription_id'])) {
            $result['subscription_id'] = absint($metadata['subscription_id']);
        }

        if ($result['subscription_id'] <= 0 && ! empty($payload['customer']) && is_string($payload['customer'])) {
            $result['subscription_id'] = PaymentMetaNormalizer::findSubscriptionByGatewayCustomer($payload['customer'], self::GATEWAY_SLUG);
        }

        if ($result['order_id'] <= 0 && ! empty($payload['payment_intent'])) {
            $pi_id = is_string($payload['payment_intent']) ? $payload['payment_intent'] : (string) ($payload['payment_intent']['id'] ?? '');
            $order = '' !== $pi_id ? $this->findOrderByGatewayTransactionId($pi_id) : null;
            if ($order instanceof \WC_Order) {
                $result['order_id'] = $order->get_id();
            }
        }

        if ($result['subscription_id'] <= 0 && $result['order_id'] > 0) {
            $subscription_ids = PaymentMetaNormalizer::findSubscriptionIdsForOrder($result['order_id']);
            $result['subscription_id'] = ! empty($subscription_ids) ? (int) $subscription_ids[0] : 0;
        }

        if ($result['order_id'] <= 0 && $result['subscription_id'] > 0) {
            $result['order_id'] = PaymentMetaNormalizer::findOrderForSubscription($result['subscription_id'], 'renewal')
                ?: PaymentMetaNormalizer::findOrderForSubscription($result['subscription_id'], 'initial');
        }

        if ($result['subscription_id'] > 0) {
            $result['customer_id'] = absint(get_post_meta($result['subscription_id'], '_customer_id', true));
        }

        return $result;
    }

    public function normalizeEventType(string $gateway_event_type): string
    {
        return $this->event_map[$gateway_event_type] ?? '';
    }

    public function isDuplicateEvent(string $event_id): bool
    {
        if (! DatabaseMigration::tableExists()) {
            return false;
        }

        global $wpdb;
        $table = $wpdb->prefix . 'arraysubs_webhook_events';

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        return (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$table} WHERE gateway_slug = %s AND event_id = %s", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
                self::SECONDARY_WEBHOOK_SLUG,
                $event_id
            )
        ) > 0;
    }

    public function rememberEvent(string $event_id, string $event_type = ''): void
    {
        if (! DatabaseMigration::tableExists()) {
            return;
        }

        global $wpdb;
        $table = $wpdb->prefix . 'arraysubs_webhook_events';

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
        $wpdb->insert(
            $table,
            [
                'gateway_slug' => self::SECONDARY_WEBHOOK_SLUG,
                'event_id'     => sanitize_text_field($event_id),
                'event_type'   => sanitize_text_field($event_type),
                'processed_at' => current_time('mysql', true),
            ],
            ['%s', '%s', '%s', '%s']
        );
    }

    public function handleOfficialStripeWebhook(string $event_type, $notification, $resolved_order = null): void
    {
        $normalized_event_type = $this->normalizeOfficialEventType($event_type);
        if ('' === $normalized_event_type) {
            return;
        }

        $payload = $this->extractObjectFromNotification($notification);
        $parsed  = [
            'success'               => true,
            'gateway_event_id'      => (string) ($notification->id ?? ($notification['id'] ?? '')),
            'gateway_event_type'    => $event_type,
            'normalized_event_type' => $normalized_event_type,
            'occurred_at'           => (int) ($notification->created ?? ($notification['created'] ?? time())),
            'payload'               => $payload,
            'raw_body'              => '',
        ];

        if (! empty($parsed['gateway_event_id']) && $this->isDuplicateEvent($parsed['gateway_event_id'])) {
            return;
        }

        $entities = $this->resolveEntityIds($parsed);
        if ($resolved_order instanceof \WC_Order) {
            $entities['order_id'] = $resolved_order->get_id();
        }

        $context = [
            'parsed'             => $parsed,
            'payload'            => $payload,
            'gateway_event_type' => $event_type,
            'subscription_id'    => $entities['subscription_id'],
            'order_id'           => $entities['order_id'],
            'customer_id'        => $entities['customer_id'],
            'order'              => $resolved_order instanceof \WC_Order ? $resolved_order : ($entities['order_id'] ? wc_get_order($entities['order_id']) : null),
            'subscription'       => $entities['subscription_id'] && function_exists('arraysubs_get_subscription') ? arraysubs_get_subscription($entities['subscription_id']) : null,
            'gateway_slug'       => self::GATEWAY_SLUG,
        ];

        $this->dispatchNormalizedEvent($parsed['normalized_event_type'], $context);

        if (! empty($parsed['gateway_event_id'])) {
            $this->rememberEvent($parsed['gateway_event_id'], $event_type);
        }
    }

    /**
     * Process Woo Stripe deferred webhooks after the official handler has run.
     *
     * Woo Stripe defers payment_intent.succeeded events and can return early
     * for already-complete orders before firing wc_stripe_webhook_received.
     * This hook preserves ArraySubs logging for those successful events.
     *
     * @param string $webhook_type    Stripe event type.
     * @param array  $additional_data Deferred action metadata.
     * @param mixed  $notification    Stripe event payload.
     * @return void
     */
    public function handleDeferredOfficialStripeWebhook(string $webhook_type, array $additional_data = [], $notification = null): void
    {
        if (null === $notification || '' === $this->normalizeOfficialEventType($webhook_type)) {
            return;
        }

        $order = null;
        if (! empty($additional_data['order_id'])) {
            $resolved_order = wc_get_order(absint($additional_data['order_id']));
            $order          = $resolved_order instanceof \WC_Order ? $resolved_order : null;
        }

        $this->handleOfficialStripeWebhook($webhook_type, $notification, $order);
    }

    /**
     * Remember official Stripe payment_intent.succeeded webhooks Woo Stripe skips.
     *
     * Woo Stripe does not emit wc_stripe_webhook_received for successful
     * PaymentIntent events when no order is found or the order is already paid.
     * Gateway Logs still need to show that Stripe delivered the event.
     *
     * @return void
     */
    public function rememberSkippedOfficialPaymentIntentWebhook(): void
    {
        $body = (string) file_get_contents('php://input');
        if ('' === $body) {
            return;
        }

        $event = json_decode($body, true);
        if (
            ! is_array($event)
            || 'payment_intent.succeeded' !== (string) ($event['type'] ?? '')
            || empty($event['id'])
        ) {
            return;
        }

        $secret = $this->getOfficialWebhookSecret();
        $signature = (string) ($_SERVER['HTTP_STRIPE_SIGNATURE'] ?? '');
        if ('' === $secret || '' === $signature || ! $this->verifyStripeSignature($body, $signature, $secret)) {
            return;
        }

        if ($this->isDuplicateEvent((string) $event['id'])) {
            return;
        }

        $payload = is_array($event['data']['object'] ?? null) ? $event['data']['object'] : [];
        $order   = $this->resolveOrderFromPaymentIntentPayload($payload);

        if ($order instanceof \WC_Order) {
            $allowed_statuses = apply_filters('wc_stripe_allowed_payment_processing_statuses', ['pending', 'failed'], $order);
            if ($order->has_status(is_array($allowed_statuses) ? $allowed_statuses : ['pending', 'failed'])) {
                return;
            }
        }

        $this->rememberEvent((string) $event['id'], 'payment_intent.succeeded');
    }

    /**
     * Normalize events received from the official WooCommerce Stripe webhook.
     *
     * @param string $event_type Stripe event type.
     * @return string
     */
    private function normalizeOfficialEventType(string $event_type): string
    {
        $official_map = [
            'payment_intent.succeeded'       => self::EVENT_PAYMENT_SUCCEEDED,
            'payment_intent.payment_failed'  => self::EVENT_PAYMENT_FAILED,
            'payment_intent.requires_action' => self::EVENT_PAYMENT_REQUIRES_ACTION,
            'invoice.payment_succeeded'      => self::EVENT_PAYMENT_SUCCEEDED,
            'invoice.payment_failed'         => self::EVENT_PAYMENT_FAILED,
            'charge.succeeded'               => self::EVENT_PAYMENT_SUCCEEDED,
            'charge.refunded'                => self::EVENT_REFUND_CREATED,
            'charge.dispute.created'         => self::EVENT_DISPUTE_CREATED,
            'charge.dispute.closed'          => self::EVENT_DISPUTE_RESOLVED,
            'setup_intent.succeeded'         => self::EVENT_PAYMENT_METHOD_UPDATED,
        ];

        return $official_map[$event_type] ?? '';
    }

    public function handlePaymentSucceeded(array $context): array
    {
        $subscription_id = (int) ($context['subscription_id'] ?? 0);
        $order           = $context['order'] ?? null;
        $payload         = $context['payload'] ?? [];

        if ($order instanceof \WC_Order && $subscription_id > 0) {
            $this->captureContextFromOrder($order, $subscription_id);
        }

        if ($subscription_id > 0) {
            PaymentLoggingService::logPayment(
                self::GATEWAY_SLUG,
                $subscription_id,
                sprintf('Stripe payment confirmed via official webhook for order #%d.', (int) ($context['order_id'] ?? 0))
            );
        }

        $this->doAction('arraysubs_gateway_payment_succeeded', $subscription_id, (int) ($context['order_id'] ?? 0), $this->extractTransactionReference($payload), self::GATEWAY_SLUG);

        return ['success' => true, 'message' => 'Payment succeeded processed'];
    }

    public function handlePaymentFailed(array $context): array
    {
        $payload         = $context['payload'] ?? [];
        $subscription_id = (int) ($context['subscription_id'] ?? 0);
        $order           = $context['order'] ?? null;
        $error_code      = (string) ($payload['last_payment_error']['code'] ?? 'payment_failed');
        $error_message   = (string) ($payload['last_payment_error']['message'] ?? __('Payment was declined.', 'arraysubspro'));

        PaymentLoggingService::logPaymentFailure(self::GATEWAY_SLUG, $subscription_id, $order, $error_code, $error_message);
        $this->doAction('arraysubs_gateway_payment_failed', $subscription_id, (int) ($context['order_id'] ?? 0), $error_message, self::GATEWAY_SLUG);

        return ['success' => true, 'message' => 'Payment failure recorded'];
    }

    public function handlePaymentRequiresAction(array $context): array
    {
        $order           = $context['order'] ?? null;
        $subscription_id = (int) ($context['subscription_id'] ?? 0);
        $payload         = $context['payload'] ?? [];

        if ($order instanceof \WC_Order && $subscription_id > 0) {
            $this->storeRequiresActionContext($subscription_id, $order, $payload);
        }

        return ['success' => true, 'message' => 'Payment action requirement recorded'];
    }

    public function handlePaymentMethodUpdated(array $context): array
    {
        $payload         = $context['payload'] ?? [];
        $subscription_id = (int) ($context['subscription_id'] ?? 0);

        if ($subscription_id <= 0 && ! empty($payload['customer']) && is_string($payload['customer'])) {
            $subscription_id = PaymentMetaNormalizer::findSubscriptionByGatewayCustomer($payload['customer'], self::GATEWAY_SLUG);
        }

        if ($subscription_id <= 0) {
            return ['success' => true, 'message' => 'No matching subscription for payment method update'];
        }

        $pm_id = (string) ($payload['id'] ?? ($payload['payment_method'] ?? ''));
        if ('' === $pm_id) {
            return ['success' => false, 'message' => 'No payment method ID in event'];
        }

        $old_data = $this->getPaymentMethodHookData($subscription_id);
        $type     = (string) ($payload['type'] ?? 'card');
        $card     = is_array($payload[$type] ?? null) ? $payload[$type] : ($payload['card'] ?? []);
        $meta     = [
            '_gateway_payment_method_id'   => $pm_id,
            '_gateway_customer_id'         => (string) ($payload['customer'] ?? get_post_meta($subscription_id, '_gateway_customer_id', true)),
            '_payment_method_type'         => $type,
            '_payment_method_brand'        => (string) ($card['brand'] ?? ''),
            '_payment_method_last4'        => (string) ($card['last4'] ?? ''),
            '_payment_method_expiry_month' => (string) ($card['exp_month'] ?? ''),
            '_payment_method_expiry_year'  => (string) ($card['exp_year'] ?? ''),
            '_payment_method_wallet'       => (string) ($card['wallet']['type'] ?? ('link' === $type ? 'link' : '')),
            '_gateway_status'              => 'active',
        ];

        foreach ($meta as $key => $value) {
            if ('' !== $value) {
                update_post_meta($subscription_id, $key, sanitize_text_field($value));
            }
        }

        update_post_meta($subscription_id, '_payment_method_updated_at', current_time('mysql', true));
        update_post_meta($subscription_id, '_payment_method_source', 'stripe');
        if (function_exists('arraysubs_reset_payment_retry_attempts')) {
            arraysubs_reset_payment_retry_attempts($subscription_id);
        } else {
            delete_post_meta($subscription_id, '_last_payment_failure');
            delete_post_meta($subscription_id, '_last_payment_failure_reason');
            delete_post_meta($subscription_id, '_last_payment_failure_category');
        }

        PaymentLoggingService::logPayment(
            self::GATEWAY_SLUG,
            $subscription_id,
            sprintf(
                /* translators: 1: brand, 2: last four */
                __('Payment method updated by Stripe: %1$s ending in %2$s', 'arraysubspro'),
                ucfirst((string) ($card['brand'] ?? 'card')),
                (string) ($card['last4'] ?? '****')
            )
        );

        $this->doAction('arraysubs_payment_method_updated', $subscription_id, $old_data, $this->getPaymentMethodHookData($subscription_id));

        return ['success' => true, 'message' => 'Payment method updated'];
    }

    public function handleCardExpiring(array $context): array
    {
        $payload         = $context['payload'] ?? [];
        $subscription_id = (int) ($context['subscription_id'] ?? 0);

        if ($subscription_id <= 0 && ! empty($payload['customer']) && is_string($payload['customer'])) {
            $subscription_id = PaymentMetaNormalizer::findSubscriptionByGatewayCustomer($payload['customer'], self::GATEWAY_SLUG);
        }

        if ($subscription_id <= 0) {
            return ['success' => true, 'message' => 'No matching subscription for card expiry notice'];
        }

        PaymentLoggingService::logPayment(
            self::GATEWAY_SLUG,
            $subscription_id,
            __('Card on file is expiring soon. Customer notification queued.', 'arraysubspro')
        );

        $this->doAction('arraysubs_card_expiring', $subscription_id, $payload, self::GATEWAY_SLUG);

        return ['success' => true, 'message' => 'Card expiry notice recorded'];
    }

    public function handleRefundCreated(array $context): array
    {
        $payload         = $context['payload'] ?? [];
        $subscription_id = (int) ($context['subscription_id'] ?? 0);
        $order           = $context['order'] ?? null;

        if ($subscription_id > 0 && TwoWaySyncGuard::wasInitiatedLocally('refund', $subscription_id)) {
            TwoWaySyncGuard::clear('refund', $subscription_id);
            return ['success' => true, 'message' => 'Refund was initiated locally'];
        }

        $currency       = strtoupper((string) ($payload['currency'] ?? 'USD'));
        $refund_details = $this->extractStripeRefundDetails($payload, $currency);
        $amount         = $refund_details['amount'];

        if (! $order instanceof \WC_Order && ! empty($payload['payment_intent'])) {
            $order = $this->findOrderByGatewayTransactionId((string) $payload['payment_intent']);
        }

        if (! $order instanceof \WC_Order && ! empty($payload['id'])) {
            $order = $this->findOrderByGatewayTransactionId((string) $payload['id']);
        }

        if ($subscription_id <= 0 && $order instanceof \WC_Order && function_exists('arraysubs_get_subscription_ids_for_order')) {
            $subscription_ids = arraysubs_get_subscription_ids_for_order($order);
            $subscription_id  = ! empty($subscription_ids) ? (int) $subscription_ids[0] : 0;
        }

        if ($amount <= 0 && $order instanceof \WC_Order) {
            $amount = $this->inferRefundAmountFromOrder($order, $refund_details['refund_id']);
            $refund_details['amount'] = $amount;

            if ((float) ($refund_details['cumulative_amount'] ?? 0) <= 0) {
                $refund_details['cumulative_amount'] = $amount;
            }
        }

        if ($order instanceof \WC_Order) {
            $this->syncExternalStripeRefundToWooCommerce(
                $order,
                $subscription_id,
                $refund_details
            );

            $order->add_order_note(sprintf(
                /* translators: 1: refund amount, 2: currency */
                __('Stripe refund received via webhook: %1$s %2$s', 'arraysubspro'),
                wc_price($amount, ['currency' => $currency]),
                $currency
            ));
        }

        if ($subscription_id > 0) {
            PaymentLoggingService::logPayment(
                self::GATEWAY_SLUG,
                $subscription_id,
                sprintf(
                    /* translators: 1: amount, 2: currency */
                    __('External refund detected from Stripe dashboard: %1$s %2$s', 'arraysubspro'),
                    number_format($amount, 2),
                    $currency
                )
            );
        }

        $this->doAction('arraysubs_gateway_refund_created', $subscription_id, (int) ($context['order_id'] ?? 0), $amount, self::GATEWAY_SLUG);

        return ['success' => true, 'message' => 'Refund webhook processed'];
    }

    /**
     * Extract latest and cumulative refund data from a Stripe charge payload.
     *
     * @param array<string, mixed> $payload  Stripe charge payload.
     * @param string               $currency Currency code.
     * @return array{amount: float, cumulative_amount: float, refund_id: string}
     */
    private function extractStripeRefundDetails(array $payload, string $currency): array
    {
        if (is_array($payload['data']['object'] ?? null)) {
            $payload = $payload['data']['object'];
        }

        if (is_array($payload['charges']['data'][0] ?? null)) {
            $payload = $payload['charges']['data'][0];
        }

        $currency = strtoupper((string) ($payload['currency'] ?? $currency));
        $refunds           = is_array($payload['refunds']['data'] ?? null) ? $payload['refunds']['data'] : [];
        $amount            = 0.0;
        $cumulative_amount = 0.0;
        $refund_id         = '';

        if ($this->isStripeRefundObject($payload)) {
            $refund_id = (string) ($payload['id'] ?? '');

            if (isset($payload['amount']) && is_numeric($payload['amount'])) {
                $amount = self::fromSmallestUnit((int) $payload['amount'], $currency);
            }

            return [
                'amount'            => $amount,
                'cumulative_amount' => $amount,
                'refund_id'         => $refund_id,
            ];
        }

        if (! empty($refunds)) {
            $latest = $this->findLatestStripeRefund($refunds);
            if (is_array($latest)) {
                $amount    = self::fromSmallestUnit((int) ($latest['amount'] ?? 0), $currency);
                $refund_id = (string) ($latest['id'] ?? '');
            }
        }

        if (isset($payload['amount_refunded']) && is_numeric($payload['amount_refunded'])) {
            $cumulative_amount = self::fromSmallestUnit((int) $payload['amount_refunded'], $currency);
        }

        if ($amount <= 0 && $cumulative_amount > 0) {
            $amount = $cumulative_amount;
        }

        return [
            'amount'            => $amount,
            'cumulative_amount' => $cumulative_amount,
            'refund_id'         => $refund_id,
        ];
    }

    /**
     * Determine whether a Stripe payload is a refund object.
     *
     * @param array<string, mixed> $payload Stripe payload.
     * @return bool
     */
    private function isStripeRefundObject(array $payload): bool
    {
        $object = (string) ($payload['object'] ?? '');
        $id     = (string) ($payload['id'] ?? '');

        return 'refund' === $object || str_starts_with($id, 're_');
    }

    /**
     * Find the newest expanded refund object in a Stripe refunds list.
     *
     * @param array<int, mixed> $refunds Stripe refunds list.
     * @return array<string, mixed>|null
     */
    private function findLatestStripeRefund(array $refunds): ?array
    {
        $latest = null;

        foreach ($refunds as $refund) {
            if (! is_array($refund)) {
                continue;
            }

            if (! isset($refund['amount']) || ! is_numeric($refund['amount'])) {
                continue;
            }

            if (null === $latest) {
                $latest = $refund;
                continue;
            }

            $refund_created = (int) ($refund['created'] ?? 0);
            $latest_created = (int) ($latest['created'] ?? 0);

            if ($refund_created >= $latest_created) {
                $latest = $refund;
            }
        }

        return $latest;
    }

    /**
     * Infer a webhook refund amount from existing Woo refunds when Stripe omits amount fields.
     *
     * @param \WC_Order $order             WooCommerce order.
     * @param string    $gateway_refund_id Stripe refund ID.
     * @return float
     */
    private function inferRefundAmountFromOrder(\WC_Order $order, string $gateway_refund_id): float
    {
        $refunds = $order->get_refunds();
        if (empty($refunds)) {
            return 0.0;
        }

        foreach ($refunds as $refund) {
            if ('' === $gateway_refund_id) {
                continue;
            }

            if ((string) $refund->get_meta('_stripe_refund_id', true) === $gateway_refund_id) {
                return abs((float) $refund->get_amount());
            }

            if ((string) $refund->get_meta('_arraysubs_gateway_refund_id', true) === $gateway_refund_id) {
                return abs((float) $refund->get_amount());
            }
        }

        usort($refunds, static function ($a, $b) {
            $a_time = $a->get_date_created() ? $a->get_date_created()->getTimestamp() : 0;
            $b_time = $b->get_date_created() ? $b->get_date_created()->getTimestamp() : 0;

            return $b_time <=> $a_time;
        });

        return abs((float) $refunds[0]->get_amount());
    }

    /**
     * Mirror a Stripe-dashboard refund into WooCommerce if no local refund exists.
     *
     * WooCommerce only changes order status to Refunded after a local WC refund
     * exists. Stripe dashboard refunds arrive as webhooks, so create a
     * non-payment local refund and let core ArraySubs refund hooks cancel linked
     * subscriptions when the order is fully refunded.
     *
     * @param \WC_Order            $order           WooCommerce order.
     * @param int                  $subscription_id Subscription ID.
     * @param array<string, mixed> $refund_details  Refund details.
     * @return void
     */
    private function syncExternalStripeRefundToWooCommerce(\WC_Order $order, int $subscription_id, array $refund_details): void
    {
        $gateway_refund_id = (string) ($refund_details['refund_id'] ?? '');
        if ('' !== $gateway_refund_id && $this->orderHasGatewayRefund($order, $gateway_refund_id)) {
            return;
        }

        $order_total      = (float) $order->get_total();
        $current_refunded = (float) $order->get_total_refunded();
        $remaining        = max(0.0, $order_total - $current_refunded);

        if ($order_total <= 0 || $remaining <= 0) {
            return;
        }

        $cumulative_amount = (float) ($refund_details['cumulative_amount'] ?? 0);
        $latest_amount     = (float) ($refund_details['amount'] ?? 0);
        $refund_delta      = $latest_amount;

        if ($cumulative_amount > 0) {
            $refund_delta = min($order_total, $cumulative_amount) - $current_refunded;
        }

        $refund_amount = min($remaining, max(0.0, $refund_delta));
        if ($refund_amount <= 0) {
            return;
        }

        $refund = wc_create_refund([
            'amount'         => $refund_amount,
            'reason'         => sprintf(
                /* translators: %s: Stripe refund ID */
                __('External Stripe refund synced to WooCommerce. Stripe refund: %s', 'arraysubspro'),
                $gateway_refund_id ?: __('unknown', 'arraysubspro')
            ),
            'order_id'       => $order->get_id(),
            'refund_payment' => false,
            'restock_items'  => false,
        ]);

        if (is_wp_error($refund)) {
            $order->add_order_note(sprintf(
                /* translators: %s: error message */
                __('ArraySubs could not sync external Stripe refund into WooCommerce: %s', 'arraysubspro'),
                $refund->get_error_message()
            ));
            return;
        }

        if ('' !== $gateway_refund_id) {
            $refund->update_meta_data('_stripe_refund_id', $gateway_refund_id);
            $refund->update_meta_data('_arraysubs_gateway_refund_id', $gateway_refund_id);
        }

        if ($subscription_id > 0) {
            $refund->update_meta_data('_subscription_id', $subscription_id);
        }

        $refund->update_meta_data('_arraysubs_external_gateway_refund', self::GATEWAY_SLUG);
        $refund->save();
    }

    /**
     * Check whether a Stripe refund ID already has a local Woo refund record.
     *
     * @param \WC_Order $order             WooCommerce order.
     * @param string    $gateway_refund_id Stripe refund ID.
     * @return bool
     */
    private function orderHasGatewayRefund(\WC_Order $order, string $gateway_refund_id): bool
    {
        foreach ($order->get_refunds() as $refund) {
            if ((string) $refund->get_meta('_stripe_refund_id', true) === $gateway_refund_id) {
                return true;
            }

            if ((string) $refund->get_meta('_arraysubs_gateway_refund_id', true) === $gateway_refund_id) {
                return true;
            }
        }

        return false;
    }

    public function handleDisputeCreated(array $context): array
    {
        $payload         = $context['payload'] ?? [];
        $subscription_id = (int) ($context['subscription_id'] ?? 0);
        $order           = $context['order'] ?? null;
        $reason          = (string) ($payload['reason'] ?? __('unknown', 'arraysubspro'));
        $currency        = strtoupper((string) ($payload['currency'] ?? 'USD'));
        $amount          = isset($payload['amount']) ? self::fromSmallestUnit((int) $payload['amount'], $currency) : 0.0;

        if ($order instanceof \WC_Order) {
            $order->add_order_note(sprintf(
                /* translators: 1: dispute reason, 2: amount, 3: currency */
                __('Stripe dispute opened: %1$s (%2$s %3$s). Review in your Stripe Dashboard.', 'arraysubspro'),
                $reason,
                number_format($amount, 2),
                $currency
            ));
            $order->update_status('on-hold');
        }

        if ($subscription_id > 0) {
            PaymentLoggingService::logPayment(
                self::GATEWAY_SLUG,
                $subscription_id,
                sprintf(
                    /* translators: %s: dispute reason */
                    __('Stripe dispute/chargeback opened: %s. Subscription NOT auto-cancelled; admin review is required.', 'arraysubspro'),
                    $reason
                ),
                'warning'
            );
        }

        $this->doAction('arraysubs_gateway_dispute_created', $subscription_id, (int) ($context['order_id'] ?? 0), self::GATEWAY_SLUG, $payload);

        return ['success' => true, 'message' => 'Dispute created notice recorded'];
    }

    public function handleDisputeResolved(array $context): array
    {
        $payload         = $context['payload'] ?? [];
        $subscription_id = (int) ($context['subscription_id'] ?? 0);
        $order           = $context['order'] ?? null;
        $status          = (string) ($payload['status'] ?? 'unknown');
        $won             = in_array($status, ['won', 'warning_closed'], true);

        if ($order instanceof \WC_Order) {
            $order->add_order_note(
                $won
                    ? __('Stripe dispute resolved in your favor.', 'arraysubspro')
                    : sprintf(
                        /* translators: %s: dispute status */
                        __('Stripe dispute resolved: %s. Funds may have been deducted.', 'arraysubspro'),
                        $status
                    )
            );
        }

        if ($subscription_id > 0) {
            PaymentLoggingService::logPayment(
                self::GATEWAY_SLUG,
                $subscription_id,
                sprintf(
                    /* translators: %s: outcome */
                    __('Stripe dispute resolved: %s', 'arraysubspro'),
                    $won ? __('Won', 'arraysubspro') : $status
                )
            );
        }

        $this->doAction('arraysubs_gateway_dispute_resolved', $subscription_id, (int) ($context['order_id'] ?? 0), self::GATEWAY_SLUG, $payload);

        return ['success' => true, 'message' => 'Dispute resolved processed'];
    }

    public function handleSubscriptionCancelled(array $context): array
    {
        return ['success' => true, 'message' => 'Stripe Subscriptions are not used by ArraySubs'];
    }

    /**
     * Prepare renewal order meta before creating the PaymentIntent.
     *
     * @param \WC_Order $order           Renewal order.
     * @param int       $subscription_id Subscription ID.
     * @param array     $meta            Gateway meta.
     * @return void
     */
    private function prepareRenewalOrderMeta(\WC_Order $order, int $subscription_id, array $meta): void
    {
        $order->set_payment_method(self::GATEWAY_SLUG);
        $order->set_payment_method_title($this->getGatewayTitle());
        $order->update_meta_data('_payment_gateway', self::GATEWAY_SLUG);
        $order->update_meta_data('_gateway_customer_id', $meta['customer_id']);
        $order->update_meta_data('_gateway_payment_method_id', $meta['payment_method_id']);
        $order->update_meta_data('_stripe_customer_id', $meta['customer_id']);
        $order->update_meta_data('_stripe_source_id', $meta['payment_method_id']);
        $order->update_meta_data('_stripe_upe_payment_type', $meta['payment_method_type']);

        $mandate_id = MandateRegistry::getMandateForSubscription($subscription_id);
        if ($mandate_id && in_array($meta['payment_method_type'], $this->mandate_methods, true)) {
            $order->update_meta_data('_stripe_mandate_id', $mandate_id);
        }

        $order->save();
    }

    /**
     * Store Stripe PaymentIntent and charge IDs on the renewal order.
     *
     * @param \WC_Order $order     Order.
     * @param string    $intent_id Intent ID.
     * @param string    $charge_id Charge ID.
     * @return void
     */
    private function storeIntentMeta(\WC_Order $order, string $intent_id, string $charge_id = ''): void
    {
        $order->update_meta_data('_stripe_intent_id', sanitize_text_field($intent_id));
        $order->update_meta_data('_arraysubs_pending_transaction_id', sanitize_text_field($intent_id));

        if ('' !== $charge_id) {
            $order->set_transaction_id(sanitize_text_field($charge_id));
            $order->update_meta_data('_stripe_charge_id', sanitize_text_field($charge_id));
            $order->update_meta_data('_stripe_charge_captured', 'yes');
            $order->update_meta_data('_last_gateway_transaction_id', sanitize_text_field($charge_id));
        } else {
            $order->update_meta_data('_last_gateway_transaction_id', sanitize_text_field($intent_id));
        }

        $order->save();
    }

    /**
     * Resolve and persist a Stripe charge ID on an order if it only has a PaymentIntent ID.
     *
     * @param \WC_Order $order Order to normalize.
     * @return string Resolved charge ID, or empty string.
     */
    private function ensureStripeChargeTransactionForOrder(\WC_Order $order): string
    {
        $transaction_id = (string) $order->get_transaction_id();
        if (str_starts_with($transaction_id, 'ch_')) {
            if ('' === (string) $order->get_meta('_stripe_charge_id', true)) {
                $order->update_meta_data('_stripe_charge_id', sanitize_text_field($transaction_id));
            }

            $order->update_meta_data('_stripe_charge_captured', 'yes');
            $order->save();

            return $transaction_id;
        }

        $stored_charge_id = (string) $order->get_meta('_stripe_charge_id', true);
        if (str_starts_with($stored_charge_id, 'ch_')) {
            $order->set_transaction_id(sanitize_text_field($stored_charge_id));
            $order->update_meta_data('_stripe_charge_captured', 'yes');
            $order->update_meta_data('_last_gateway_transaction_id', sanitize_text_field($stored_charge_id));
            $order->save();

            return $stored_charge_id;
        }

        $intent_id = (string) (
            $order->get_meta('_stripe_intent_id', true)
            ?: $order->get_meta('_arraysubs_pending_transaction_id', true)
            ?: $order->get_meta('_last_gateway_transaction_id', true)
            ?: $transaction_id
        );

        if (!str_starts_with($intent_id, 'pi_')) {
            return '';
        }

        $intent = $this->stripeRetrieve('payment_intents/' . rawurlencode($intent_id));
        if (is_wp_error($intent)) {
            return '';
        }

        $charge_id = $this->extractChargeIdFromIntent($intent);
        if ('' === $charge_id) {
            return '';
        }

        $this->storeIntentMeta($order, (string) ($intent['id'] ?? $intent_id), $charge_id);

        return $charge_id;
    }

    /**
     * Extract a Stripe Charge ID from a PaymentIntent payload.
     *
     * @param array<string, mixed> $intent PaymentIntent payload.
     * @return string Charge ID, or empty string.
     */
    private function extractChargeIdFromIntent(array $intent): string
    {
        $latest_charge = $intent['latest_charge'] ?? '';

        if (is_string($latest_charge) && str_starts_with($latest_charge, 'ch_')) {
            return sanitize_text_field($latest_charge);
        }

        if (is_array($latest_charge) && isset($latest_charge['id']) && str_starts_with((string) $latest_charge['id'], 'ch_')) {
            return sanitize_text_field((string) $latest_charge['id']);
        }

        $charge = $intent['charges']['data'][0] ?? null;
        if (is_array($charge) && isset($charge['id']) && str_starts_with((string) $charge['id'], 'ch_')) {
            return sanitize_text_field((string) $charge['id']);
        }

        return '';
    }

    /**
     * Build requires-action result and fire customer email action.
     *
     * @param int       $subscription_id Subscription ID.
     * @param \WC_Order $order           Renewal order.
     * @param array     $intent          PaymentIntent data.
     * @return array
     */
    private function handleRequiresActionResult(int $subscription_id, \WC_Order $order, array $intent): array
    {
        $this->storeRequiresActionContext($subscription_id, $order, $intent);

        return [
            'success'         => false,
            'status'          => 'requires_action',
            'requires_action' => true,
            'error_code'      => 'requires_action',
            'transaction_id'  => (string) ($intent['id'] ?? ''),
            'message'         => __('Payment requires customer authentication.', 'arraysubspro'),
            'raw'             => $intent,
        ];
    }

    /**
     * Persist requires-action context.
     *
     * @param int       $subscription_id Subscription ID.
     * @param \WC_Order $order           Renewal order.
     * @param array     $intent          PaymentIntent payload.
     * @return void
     */
    private function storeRequiresActionContext(int $subscription_id, \WC_Order $order, array $intent): void
    {
        $intent_id  = (string) ($intent['id'] ?? '');
        $action_url = add_query_arg('wc-stripe-confirmation', 1, $order->get_checkout_payment_url(false));

        if ('' !== $intent_id) {
            $this->storeIntentMeta($order, $intent_id);
        }

        $order->update_meta_data('_arraysubs_payment_action_intent_id', $intent_id);
        $order->update_meta_data('_arraysubs_payment_action_required_at', current_time('mysql', true));
        $order->update_meta_data('_arraysubs_payment_action_url', esc_url_raw($action_url));
        $order->save();

        update_post_meta($subscription_id, '_arraysubs_payment_action_url', esc_url_raw($action_url));
        update_post_meta($subscription_id, '_arraysubs_payment_action_intent_id', sanitize_text_field($intent_id));

        PaymentLoggingService::logPayment(
            self::GATEWAY_SLUG,
            $subscription_id,
            __('Renewal payment requires customer authentication. Verification email queued.', 'arraysubspro'),
            'warning'
        );

        $this->doAction('arraysubs_renewal_requires_verification', $subscription_id, $order->get_id(), $intent_id, self::GATEWAY_SLUG);
    }

    private function hasOfficialCredentials(): bool
    {
        if (class_exists('\WC_Stripe_API') && method_exists('\WC_Stripe_API', 'get_secret_key')) {
            return '' !== (string) \WC_Stripe_API::get_secret_key();
        }

        $settings = get_option('woocommerce_stripe_settings', []);
        if (! is_array($settings)) {
            return false;
        }

        $test_mode = 'yes' === ($settings['testmode'] ?? 'no');
        $key       = $test_mode ? ($settings['test_secret_key'] ?? '') : ($settings['secret_key'] ?? '');

        return '' !== (string) $key;
    }

    private function stripeRequest(array $params, string $endpoint, string $method = 'POST')
    {
        if (! StripeAvailability::isAvailable() || ! class_exists('\WC_Stripe_API')) {
            return new \WP_Error('stripe_unavailable', __('WooCommerce Stripe Gateway is not available.', 'arraysubspro'));
        }

        try {
            $response = \WC_Stripe_API::request($params, $endpoint, $method);
        } catch (\Throwable $throwable) {
            return new \WP_Error('stripe_exception', $throwable->getMessage());
        }

        return $this->normalizeStripeResponse($response);
    }

    private function stripeRetrieve(string $endpoint)
    {
        if (! StripeAvailability::isAvailable() || ! class_exists('\WC_Stripe_API')) {
            return new \WP_Error('stripe_unavailable', __('WooCommerce Stripe Gateway is not available.', 'arraysubspro'));
        }

        try {
            $response = \WC_Stripe_API::retrieve($endpoint);
        } catch (\Throwable $throwable) {
            return new \WP_Error('stripe_exception', $throwable->getMessage());
        }

        return $this->normalizeStripeResponse($response);
    }

    private function normalizeStripeResponse($response)
    {
        if (is_wp_error($response)) {
            return $response;
        }

        $data = $this->objectToArray($response);
        if (! empty($data['error'])) {
            $error = is_array($data['error']) ? $data['error'] : [];
            return new \WP_Error(
                'stripe_api_error',
                (string) ($error['message'] ?? __('Stripe API error.', 'arraysubspro')),
                $error
            );
        }

        return $data;
    }

    /**
     * Dispatch a WordPress action.
     *
     * @param string $hook_name Hook name.
     * @param mixed  ...$args   Hook arguments.
     * @return void
     */
    private function doAction(string $hook_name, ...$args): void
    {
        if (! function_exists('do_action')) {
            return;
        }

        call_user_func('do_action', $hook_name, ...$args);
    }

    private function objectToArray($value): array
    {
        if (is_array($value)) {
            $result = [];
            foreach ($value as $key => $child) {
                $result[$key] = (is_array($child) || is_object($child)) ? $this->objectToArray($child) : $child;
            }
            return $result;
        }

        if (is_object($value)) {
            return $this->objectToArray(get_object_vars($value));
        }

        return [];
    }

    private function getGatewayMeta(int $subscription_id): array
    {
        return [
            'customer_id'         => (string) get_post_meta($subscription_id, '_gateway_customer_id', true),
            'payment_method_id'   => (string) get_post_meta($subscription_id, '_gateway_payment_method_id', true),
            'payment_method_type' => (string) (get_post_meta($subscription_id, '_payment_method_type', true) ?: 'card'),
            'brand'               => (string) get_post_meta($subscription_id, '_payment_method_brand', true),
            'last4'               => (string) get_post_meta($subscription_id, '_payment_method_last4', true),
            'expiry_month'        => (int) get_post_meta($subscription_id, '_payment_method_expiry_month', true),
            'expiry_year'         => (int) get_post_meta($subscription_id, '_payment_method_expiry_year', true),
        ];
    }

    private function getPaymentMethodHookData(int $subscription_id): array
    {
        $meta = $this->getGatewayMeta($subscription_id);

        return [
            'gateway_slug'        => self::GATEWAY_SLUG,
            'customer_id'         => $meta['customer_id'],
            'payment_method_id'   => $meta['payment_method_id'],
            'brand'               => $meta['brand'],
            'last4'               => $meta['last4'],
            'expiry_month'        => $meta['expiry_month'],
            'expiry_year'         => $meta['expiry_year'],
            'payment_method_type' => $meta['payment_method_type'],
        ];
    }

    private function buildFailure(string $code, string $message, string $transaction_id = '', array $raw = []): array
    {
        return [
            'success'        => false,
            'status'         => 'failed',
            'error_code'     => $code,
            'transaction_id' => $transaction_id,
            'message'        => $message,
            'raw'            => $raw,
        ];
    }

    private function buildSyncFailure(string $message): array
    {
        return [
            'success'           => false,
            'message'           => $message,
            'gateway_status'    => '',
            'next_payment_date' => '',
            'payment_method'    => [],
            'recent_charges'    => [],
            'raw'               => [],
        ];
    }

    private function dispatchNormalizedEvent(string $event, array $context): array
    {
        $map = [
            self::EVENT_PAYMENT_SUCCEEDED       => 'handlePaymentSucceeded',
            self::EVENT_PAYMENT_FAILED          => 'handlePaymentFailed',
            self::EVENT_PAYMENT_REQUIRES_ACTION => 'handlePaymentRequiresAction',
            self::EVENT_PAYMENT_METHOD_UPDATED  => 'handlePaymentMethodUpdated',
            self::EVENT_CARD_EXPIRING           => 'handleCardExpiring',
            self::EVENT_REFUND_CREATED          => 'handleRefundCreated',
            self::EVENT_DISPUTE_CREATED         => 'handleDisputeCreated',
            self::EVENT_DISPUTE_RESOLVED        => 'handleDisputeResolved',
        ];

        if (! isset($map[$event])) {
            return ['success' => false, 'message' => 'Unhandled event'];
        }

        return $this->{$map[$event]}($context);
    }

    private function extractObjectFromNotification($notification): array
    {
        $data = $this->objectToArray($notification);
        return is_array($data['data']['object'] ?? null) ? $data['data']['object'] : $data;
    }

    private function extractTransactionReference(array $payload): string
    {
        $candidates = [
            $payload['payment_intent'] ?? '',
            $payload['id'] ?? '',
        ];

        foreach ($candidates as $candidate) {
            if (is_array($candidate) && ! empty($candidate['id'])) {
                return (string) $candidate['id'];
            }
            if (is_string($candidate) && '' !== $candidate) {
                return $candidate;
            }
        }

        return '';
    }

    private function findOrderByGatewayTransactionId(string $transaction_id): ?\WC_Order
    {
        if ('' === $transaction_id) {
            return null;
        }

        $orders = wc_get_orders([
            'transaction_id' => $transaction_id,
            'limit'          => 1,
        ]);

        if (! empty($orders)) {
            return $orders[0];
        }

        $orders = wc_get_orders([
            'limit'      => 1,
            'meta_key'   => '_stripe_intent_id',
            'meta_value' => $transaction_id,
        ]);

        return ! empty($orders) ? $orders[0] : null;
    }

    /**
     * Resolve an order from a PaymentIntent webhook object.
     *
     * @param array<string, mixed> $payload PaymentIntent object.
     * @return \WC_Order|null
     */
    private function resolveOrderFromPaymentIntentPayload(array $payload): ?\WC_Order
    {
        $metadata = is_array($payload['metadata'] ?? null) ? $payload['metadata'] : [];
        if (! empty($metadata['order_id'])) {
            $order = wc_get_order(absint($metadata['order_id']));
            if ($order instanceof \WC_Order) {
                return $order;
            }
        }

        $intent_id = (string) ($payload['id'] ?? '');
        if ('' !== $intent_id) {
            $order = $this->findOrderByGatewayTransactionId($intent_id);
            if ($order instanceof \WC_Order) {
                return $order;
            }
        }

        $charge_id = $this->extractChargeIdFromIntent($payload);
        if ('' !== $charge_id) {
            return $this->findOrderByGatewayTransactionId($charge_id);
        }

        return null;
    }

    /**
     * Get the active official Woo Stripe webhook secret.
     *
     * @return string
     */
    private function getOfficialWebhookSecret(): string
    {
        $settings = get_option('woocommerce_stripe_settings', []);
        if (! is_array($settings)) {
            return '';
        }

        $test_mode = 'yes' === (string) ($settings['testmode'] ?? 'no');
        $primary   = $test_mode ? 'test_webhook_secret' : 'webhook_secret';
        $fallback  = $test_mode ? 'webhook_secret' : 'test_webhook_secret';

        return (string) ($settings[$primary] ?? $settings[$fallback] ?? '');
    }

    private function verifyStripeSignature(string $payload, string $signature, string $secret): bool
    {
        $parts = [];
        foreach (explode(',', $signature) as $part) {
            [$key, $value] = array_pad(explode('=', trim($part), 2), 2, '');
            if ('' !== $key && '' !== $value) {
                $parts[$key][] = $value;
            }
        }

        $timestamp = (int) ($parts['t'][0] ?? 0);
        if ($timestamp <= 0 || abs(time() - $timestamp) > 300) {
            return false;
        }

        $expected = hash_hmac('sha256', $timestamp . '.' . $payload, $secret);
        foreach ($parts['v1'] ?? [] as $candidate) {
            if (hash_equals($expected, $candidate)) {
                return true;
            }
        }

        return false;
    }

    private function isExpired(int $month, int $year): bool
    {
        if ($month <= 0 || $year <= 0) {
            return false;
        }

        if ($year < 100) {
            $year += 2000;
        }

        $now_year  = (int) gmdate('Y');
        $now_month = (int) gmdate('m');

        return $year < $now_year || ($year === $now_year && $month < $now_month);
    }

    public static function toSmallestUnit(float $amount, string $currency): int
    {
        if (class_exists('\WC_Stripe_Helper') && method_exists('\WC_Stripe_Helper', 'get_stripe_amount')) {
            return (int) \WC_Stripe_Helper::get_stripe_amount($amount, $currency);
        }

        $currency = strtoupper($currency);
        return in_array($currency, self::zeroDecimalCurrencies(), true)
            ? (int) round($amount)
            : (int) round($amount * 100);
    }

    public static function fromSmallestUnit(int $amount, string $currency): float
    {
        if (class_exists('\WC_Stripe_Helper') && method_exists('\WC_Stripe_Helper', 'convert_from_stripe_amount')) {
            return (float) \WC_Stripe_Helper::convert_from_stripe_amount($amount, $currency);
        }

        $currency = strtoupper($currency);
        return in_array($currency, self::zeroDecimalCurrencies(), true)
            ? (float) $amount
            : round($amount / 100, 2);
    }

    private static function zeroDecimalCurrencies(): array
    {
        return [
            'BIF',
            'CLP',
            'DJF',
            'GNF',
            'JPY',
            'KMF',
            'KRW',
            'MGA',
            'PYG',
            'RWF',
            'UGX',
            'VND',
            'VUV',
            'XAF',
            'XOF',
            'XPF',
        ];
    }
}
