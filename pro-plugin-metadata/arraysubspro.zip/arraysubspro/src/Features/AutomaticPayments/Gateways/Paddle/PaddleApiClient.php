<?php

/**
 * Paddle API Client
 *
 * Thin wrapper around Paddle Billing API v2 using WordPress HTTP functions.
 * Handles API key management, environment switching, retry logic,
 * and webhook signature verification.
 *
 * @package ArraySubsPro\Features\AutomaticPayments\Gateways\Paddle
 * @since 1.0.0
 */

namespace ArraySubsPro\Features\AutomaticPayments\Gateways\Paddle;

defined('ABSPATH') || exit;

/**
 * Paddle API Client
 */
class PaddleApiClient
{
    /**
     * Paddle API base URLs.
     *
     * @var array<string, string>
     */
    const API_URLS = [
        'production' => 'https://api.paddle.com',
        'sandbox'    => 'https://sandbox-api.paddle.com',
    ];

    /**
     * Maximum retry attempts for transient failures.
     *
     * @var int
     */
    const MAX_RETRIES = 2;

    /**
     * The API key.
     *
     * @var string
     */
    private string $api_key;

    /**
     * The environment (sandbox or production).
     *
     * @var string
     */
    private string $environment;

    /**
     * WC Logger source.
     *
     * @var string
     */
    private string $log_source = 'arraysubs_paddle';

    /**
     * Constructor.
     *
     * @param string $api_key     Paddle API key.
     * @param string $environment 'sandbox' or 'production'.
     */
    public function __construct(string $api_key, string $environment = 'sandbox')
    {
        $this->api_key     = $api_key;
        $this->environment = $environment;
    }

    /**
     * Get the API base URL for the current environment.
     *
     * @return string
     */
    private function getBaseUrl(): string
    {
        return self::API_URLS[$this->environment] ?? self::API_URLS['sandbox'];
    }

    // ─── Products ────────────────────────────────────────────────────────

    /**
     * Create a Paddle Product.
     *
     * @param array $params Product data (name, description, tax_category, etc.).
     * @return array|\WP_Error
     */
    public function createProduct(array $params)
    {
        return $this->request('POST', '/products', $params);
    }

    /**
     * Update a Paddle Product.
     *
     * @param string $product_id Paddle product ID (pro_xxx).
     * @param array  $params     Updated fields.
     * @return array|\WP_Error
     */
    public function updateProduct(string $product_id, array $params)
    {
        return $this->request('PATCH', "/products/{$product_id}", $params);
    }

    /**
     * Get a Paddle Product.
     *
     * @param string $product_id Paddle product ID.
     * @return array|\WP_Error
     */
    public function getProduct(string $product_id)
    {
        return $this->request('GET', "/products/{$product_id}");
    }

    // ─── Prices ──────────────────────────────────────────────────────────

    /**
     * Create a Paddle Price on a Product.
     *
     * @param array $params Price data.
     * @return array|\WP_Error
     */
    public function createPrice(array $params)
    {
        return $this->request('POST', '/prices', $params);
    }

    /**
     * Update a Paddle Price.
     *
     * @param string $price_id Paddle price ID (pri_xxx).
     * @param array  $params   Updated fields.
     * @return array|\WP_Error
     */
    public function updatePrice(string $price_id, array $params)
    {
        return $this->request('PATCH', "/prices/{$price_id}", $params);
    }

    // ─── Customers ───────────────────────────────────────────────────────

    /**
     * Create a Paddle Customer.
     *
     * @param array $params Customer data (email, name, etc.).
     * @return array|\WP_Error
     */
    public function createCustomer(array $params)
    {
        return $this->request('POST', '/customers', $params);
    }

    /**
     * List customers (with optional filters).
     *
     * @param array $params Query params (email, search, etc.).
     * @return array|\WP_Error
     */
    public function listCustomers(array $params = [])
    {
        return $this->request('GET', '/customers', $params);
    }

    // ─── Transactions ────────────────────────────────────────────────────

    /**
     * Create a Paddle Transaction (checkout).
     *
     * @param array $params Transaction data.
     * @return array|\WP_Error
     */
    public function createTransaction(array $params)
    {
        return $this->request('POST', '/transactions', $params);
    }

    /**
     * Get a Paddle Transaction.
     *
     * @param string $transaction_id Paddle transaction ID (txn_xxx).
     * @return array|\WP_Error
     */
    public function getTransaction(string $transaction_id)
    {
        return $this->request('GET', "/transactions/{$transaction_id}");
    }

    // ─── Subscriptions ───────────────────────────────────────────────────

    /**
     * Get a Paddle Subscription.
     *
     * @param string $subscription_id Paddle subscription ID (sub_xxx).
     * @return array|\WP_Error
     */
    public function getSubscription(string $subscription_id)
    {
        return $this->request('GET', "/subscriptions/{$subscription_id}");
    }

    /**
     * Pause a Paddle Subscription.
     *
     * @param string $subscription_id Paddle subscription ID.
     * @return array|\WP_Error
     */
    public function pauseSubscription(string $subscription_id)
    {
        return $this->request('POST', "/subscriptions/{$subscription_id}/pause");
    }

    /**
     * Resume a paused Paddle Subscription.
     *
     * @param string $subscription_id Paddle subscription ID.
     * @return array|\WP_Error
     */
    public function resumeSubscription(string $subscription_id)
    {
        return $this->request('POST', "/subscriptions/{$subscription_id}/resume");
    }

    /**
     * Cancel a Paddle Subscription.
     *
     * @param string $subscription_id Paddle subscription ID.
     * @param bool   $effective_from  'immediately' or 'next_billing_period'.
     * @return array|\WP_Error
     */
    public function cancelSubscription(string $subscription_id, string $effective_from = 'immediately')
    {
        return $this->request('POST', "/subscriptions/{$subscription_id}/cancel", [
            'effective_from' => $effective_from,
        ]);
    }

    /**
     * Update a Paddle Subscription (e.g., change items/plan).
     *
     * @param string $subscription_id Paddle subscription ID.
     * @param array  $params          Updated fields.
     * @return array|\WP_Error
     */
    public function updateSubscription(string $subscription_id, array $params)
    {
        return $this->request('PATCH', "/subscriptions/{$subscription_id}", $params);
    }

    // ─── Adjustments (Refunds) ───────────────────────────────────────────

    /**
     * Create a Paddle Adjustment (refund).
     *
     * @param array $params Adjustment data.
     * @return array|\WP_Error
     */
    public function createAdjustment(array $params)
    {
        return $this->request('POST', '/adjustments', $params);
    }

    // ─── Customer Portal ─────────────────────────────────────────────────

    /**
     * Get a portal session URL for a customer.
     *
     * @param string $customer_id Paddle customer ID (ctm_xxx).
     * @return array|\WP_Error
     */
    public function createPortalSession(string $customer_id)
    {
        return $this->request('POST', "/customers/{$customer_id}/portal-sessions");
    }

    // ─── Webhook Signature Verification ──────────────────────────────────

    /**
     * Verify a Paddle webhook signature (v2 Billing API).
     *
     * @param string $payload         Raw request body.
     * @param string $signature       Paddle-Signature header value.
     * @param string $webhook_secret  Webhook secret key.
     * @param int    $max_age_seconds Maximum age tolerance (default 300 = 5 minutes).
     * @return array{valid: bool, error: string}
     */
    public function verifyWebhookSignature(string $payload, string $signature, string $webhook_secret, int $max_age_seconds = 300): array
    {
        // Parse the signature header (ts=xxx;h1=xxx format)
        $parts = $this->parseSignatureHeader($signature);

        if (empty($parts['ts']) || empty($parts['h1'])) {
            return ['valid' => false, 'error' => 'Invalid signature header format'];
        }

        $timestamp = $parts['ts'];

        // Check timestamp age
        if (abs(time() - (int) $timestamp) > $max_age_seconds) {
            return ['valid' => false, 'error' => 'Timestamp outside tolerance window'];
        }

        // Build signed payload: ts:payload
        $signed_payload = $timestamp . ':' . $payload;
        $expected_hash  = hash_hmac('sha256', $signed_payload, $webhook_secret);

        if (hash_equals($expected_hash, $parts['h1'])) {
            return ['valid' => true, 'error' => ''];
        }

        return ['valid' => false, 'error' => 'Signature mismatch'];
    }

    // ─── Internal HTTP Methods ───────────────────────────────────────────

    /**
     * Make an HTTP request to the Paddle API.
     *
     * @param string $method HTTP method (GET, POST, PATCH, DELETE).
     * @param string $path   API path (e.g., '/products').
     * @param array  $params Request parameters.
     * @param int    $retry  Current retry attempt.
     * @return array|\WP_Error Response data or WP_Error.
     */
    private function request(string $method, string $path, array $params = [], int $retry = 0)
    {
        $url = $this->getBaseUrl() . $path;

        $headers = [
            'Authorization' => 'Bearer ' . $this->api_key,
            'Content-Type'  => 'application/json',
        ];

        $args = [
            'method'  => $method,
            'headers' => $headers,
            'timeout' => 30,
        ];

        if ('GET' === $method && ! empty($params)) {
            $url = add_query_arg($params, $url);
        } elseif (! empty($params)) {
            $args['body'] = wp_json_encode($params);
        }

        $response = wp_remote_request($url, $args);

        if (is_wp_error($response)) {
            if ($retry < self::MAX_RETRIES) {
                usleep(500000 * ($retry + 1));
                return $this->request($method, $path, $params, $retry + 1);
            }
            $this->log('error', 'Paddle API request failed: ' . $response->get_error_message());
            return $response;
        }

        $status_code = wp_remote_retrieve_response_code($response);
        $body        = json_decode(wp_remote_retrieve_body($response), true);

        // Rate limited — retry with backoff
        if (429 === $status_code && $retry < self::MAX_RETRIES) {
            $retry_after = (int) wp_remote_retrieve_header($response, 'Retry-After');
            sleep(max($retry_after, 1));
            return $this->request($method, $path, $params, $retry + 1);
        }

        if ($status_code >= 400) {
            $error_detail = $body['error']['detail'] ?? ($body['error']['type'] ?? 'Unknown Paddle API error');
            $error_code   = $body['error']['code'] ?? 'api_error';

            $this->log('error', sprintf(
                'Paddle API error [%d]: %s (code: %s, path: %s)',
                $status_code,
                $error_detail,
                $error_code,
                $path
            ));

            return new \WP_Error(
                'paddle_api_error',
                $error_detail,
                [
                    'status_code' => $status_code,
                    'code'        => $error_code,
                    'body'        => $body,
                ]
            );
        }

        // Paddle v2 wraps response in 'data' key
        return $body['data'] ?? $body;
    }

    /**
     * Parse Paddle v2 signature header (ts=xxx;h1=xxx).
     *
     * @param string $header The Paddle-Signature header.
     * @return array{ts: string, h1: string}
     */
    private function parseSignatureHeader(string $header): array
    {
        $result = ['ts' => '', 'h1' => ''];
        $parts  = explode(';', $header);

        foreach ($parts as $part) {
            $kv = explode('=', trim($part), 2);
            if (2 !== count($kv)) {
                continue;
            }
            $key   = trim($kv[0]);
            $value = trim($kv[1]);

            if ('ts' === $key) {
                $result['ts'] = $value;
            } elseif ('h1' === $key) {
                $result['h1'] = $value;
            }
        }

        return $result;
    }

    /**
     * Log a message via WC logger.
     *
     * @param string $level   Log level.
     * @param string $message Log message.
     * @return void
     */
    private function log(string $level, string $message): void
    {
        if (function_exists('wc_get_logger')) {
            wc_get_logger()->log($level, $message, ['source' => $this->log_source]);
        }
    }
}
