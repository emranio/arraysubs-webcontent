<?php

/**
 * Paddle Product Sync
 *
 * Syncs WooCommerce subscription products to Paddle's catalog.
 * Paddle requires Product + Price objects to exist before checkout.
 * This service handles creation, archival, and price updates.
 *
 * Meta keys stored on WC products:
 * - _arraysubs_gateway_paddle_product_id  — Paddle Product ID (pro_xxx)
 * - _arraysubs_gateway_paddle_price_id    — Paddle Price ID (pri_xxx)
 * - _arraysubs_gateway_paddle_synced_at   — Last successful sync timestamp
 *
 * @package ArraySubsPro\Features\AutomaticPayments\Gateways\Paddle
 * @since 1.0.0
 */

namespace ArraySubsPro\Features\AutomaticPayments\Gateways\Paddle;

defined('ABSPATH') || exit;

/**
 * Paddle Product Sync Service
 */
class PaddleProductSync
{
    /**
     * Paddle API client.
     *
     * @var PaddleApiClient
     */
    private PaddleApiClient $api;

    /**
     * Constructor.
     *
     * @param PaddleApiClient $api The API client.
     */
    public function __construct(PaddleApiClient $api)
    {
        $this->api = $api;
    }

    /**
     * Sync a WooCommerce product to Paddle (create or update).
     *
     * @param \WC_Product $product The WooCommerce product.
     * @return array{success: bool, remote_product_id: string, remote_price_id: string, message: string}
     */
    public function syncProduct(\WC_Product $product): array
    {
        if (! function_exists('arraysubs_is_subscription_product') || ! arraysubs_is_subscription_product($product->get_id())) {
            return [
                'success'           => false,
                'remote_product_id' => '',
                'remote_price_id'   => '',
                'message'           => __('Product is not a subscription product.', 'arraysubspro'),
            ];
        }

        $paddle_product_id = $product->get_meta('_arraysubs_gateway_paddle_product_id');

        if (empty($paddle_product_id)) {
            return $this->createRemoteProduct($product);
        }

        return $this->updateRemoteProduct($product, $paddle_product_id);
    }

    /**
     * Create a new Paddle Product and Price for a WC product.
     *
     * @param \WC_Product $product The WooCommerce product.
     * @return array{success: bool, remote_product_id: string, remote_price_id: string, message: string}
     */
    private function createRemoteProduct(\WC_Product $product): array
    {
        // Create the Paddle Product
        $product_result = $this->api->createProduct([
            'name'         => $product->get_name(),
            'description'  => wp_strip_all_tags(substr($product->get_short_description() ?: $product->get_description(), 0, 1000)),
            'tax_category' => 'standard',
        ]);

        if (is_wp_error($product_result)) {
            return [
                'success'           => false,
                'remote_product_id' => '',
                'remote_price_id'   => '',
                'message'           => $product_result->get_error_message(),
            ];
        }

        $paddle_product_id = $product_result['id'] ?? '';

        if (empty($paddle_product_id)) {
            return [
                'success'           => false,
                'remote_product_id' => '',
                'remote_price_id'   => '',
                'message'           => __('Failed to retrieve Paddle Product ID.', 'arraysubspro'),
            ];
        }

        // Store the product ID immediately
        $product->update_meta_data('_arraysubs_gateway_paddle_product_id', sanitize_text_field($paddle_product_id));
        $product->save();

        // Create the price on the product
        $price_result = $this->createRemotePrice($product, $paddle_product_id);

        if (! $price_result['success']) {
            return $price_result;
        }

        // Store sync timestamp
        $product->update_meta_data('_arraysubs_gateway_paddle_synced_at', time());
        $product->save();

        return [
            'success'           => true,
            'remote_product_id' => $paddle_product_id,
            'remote_price_id'   => $price_result['remote_price_id'],
            'message'           => __('Product synced to Paddle successfully.', 'arraysubspro'),
        ];
    }

    /**
     * Update an existing Paddle Product and check if price needs updating.
     *
     * @param \WC_Product $product           The WooCommerce product.
     * @param string      $paddle_product_id Existing Paddle Product ID.
     * @return array{success: bool, remote_product_id: string, remote_price_id: string, message: string}
     */
    private function updateRemoteProduct(\WC_Product $product, string $paddle_product_id): array
    {
        // Update the product name/description at Paddle
        $update_result = $this->api->updateProduct($paddle_product_id, [
            'name'        => $product->get_name(),
            'description' => wp_strip_all_tags(substr($product->get_short_description() ?: $product->get_description(), 0, 1000)),
        ]);

        if (is_wp_error($update_result)) {
            $this->log('warning', sprintf(
                'Paddle product update failed for product %d: %s',
                $product->get_id(),
                $update_result->get_error_message()
            ));
        }

        // Check if price needs updating by comparing amount/interval
        $existing_price_id = $product->get_meta('_arraysubs_gateway_paddle_price_id');

        if (empty($existing_price_id)) {
            // No price exists — create one
            $price_result = $this->createRemotePrice($product, $paddle_product_id);
        } else {
            // Check if WC product price or billing period changed
            $price_result = $this->reconcilePrice($product, $paddle_product_id, $existing_price_id);
        }

        // Update sync timestamp
        $product->update_meta_data('_arraysubs_gateway_paddle_synced_at', time());
        $product->save();

        return [
            'success'           => $price_result['success'],
            'remote_product_id' => $paddle_product_id,
            'remote_price_id'   => $price_result['remote_price_id'] ?? $existing_price_id,
            'message'           => $price_result['message'] ?? __('Product updated at Paddle.', 'arraysubspro'),
        ];
    }

    /**
     * Create a Paddle Price on a Product.
     *
     * @param \WC_Product $product           The WooCommerce product.
     * @param string      $paddle_product_id Paddle Product ID.
     * @return array{success: bool, remote_price_id: string, message: string}
     */
    private function createRemotePrice(\WC_Product $product, string $paddle_product_id): array
    {
        $price     = (string) $product->get_price();
        $currency  = strtoupper(get_woocommerce_currency());
        $period    = get_post_meta($product->get_id(), '_subscription_period', true) ?: 'month';
        $interval  = (int) (get_post_meta($product->get_id(), '_subscription_period_interval', true) ?: 1);
        $trial_len = (int) get_post_meta($product->get_id(), '_subscription_trial_length', true);
        $trial_per = get_post_meta($product->get_id(), '_subscription_trial_period', true) ?: 'day';

        $price_data = [
            'product_id'    => $paddle_product_id,
            'description'   => sprintf(
                /* translators: 1: product name, 2: interval count, 3: period */
                __('%1$s — every %2$d %3$s', 'arraysubspro'),
                $product->get_name(),
                $interval,
                $period
            ),
            'billing_cycle' => [
                'interval'  => $this->mapPeriodToInterval($period),
                'frequency' => $interval,
            ],
            'unit_price'    => [
                'amount'        => $this->formatAmountForPaddle($price, $currency),
                'currency_code' => $currency,
            ],
        ];

        // Add trial period if configured
        if ($trial_len > 0) {
            $price_data['trial_period'] = [
                'interval'  => $this->mapPeriodToInterval($trial_per),
                'frequency' => $trial_len,
            ];
        }

        $result = $this->api->createPrice($price_data);

        if (is_wp_error($result)) {
            return [
                'success'         => false,
                'remote_price_id' => '',
                'message'         => $result->get_error_message(),
            ];
        }

        $paddle_price_id = $result['id'] ?? '';

        if (empty($paddle_price_id)) {
            return [
                'success'         => false,
                'remote_price_id' => '',
                'message'         => __('Failed to retrieve Paddle Price ID.', 'arraysubspro'),
            ];
        }

        $product->update_meta_data('_arraysubs_gateway_paddle_price_id', sanitize_text_field($paddle_price_id));
        $product->save();

        return [
            'success'         => true,
            'remote_price_id' => $paddle_price_id,
            'message'         => __('Paddle price created successfully.', 'arraysubspro'),
        ];
    }

    /**
     * Reconcile price: if WC price or billing period changed, archive old and create new.
     *
     * @param \WC_Product $product             The WooCommerce product.
     * @param string      $paddle_product_id   Paddle Product ID.
     * @param string      $existing_price_id   Current Paddle Price ID.
     * @return array{success: bool, remote_price_id: string, message: string}
     */
    private function reconcilePrice(\WC_Product $product, string $paddle_product_id, string $existing_price_id): array
    {
        // For simplicity and safety, always create a new price and archive the old one.
        // Paddle does not allow updating existing price amounts.
        // This handles any price/period/trial changes.
        $new_price = $this->createRemotePrice($product, $paddle_product_id);

        if (! $new_price['success']) {
            return $new_price;
        }

        // Archive the old price (don't delete — existing subscriptions reference it)
        $this->api->updatePrice($existing_price_id, ['status' => 'archived']);

        return $new_price;
    }

    /**
     * Archive a product at Paddle (called when WC product is trashed).
     *
     * @param \WC_Product $product The WooCommerce product.
     * @return array{success: bool, message: string}
     */
    public function archiveProduct(\WC_Product $product): array
    {
        $paddle_product_id = $product->get_meta('_arraysubs_gateway_paddle_product_id');

        if (empty($paddle_product_id)) {
            return [
                'success' => true,
                'message' => __('No Paddle product to archive.', 'arraysubspro'),
            ];
        }

        $result = $this->api->updateProduct($paddle_product_id, ['status' => 'archived']);

        if (is_wp_error($result)) {
            return [
                'success' => false,
                'message' => $result->get_error_message(),
            ];
        }

        return [
            'success' => true,
            'message' => __('Paddle product archived.', 'arraysubspro'),
        ];
    }

    /**
     * Check if a product has been synced to Paddle.
     *
     * @param \WC_Product $product The WooCommerce product.
     * @return bool
     */
    public function isProductSynced(\WC_Product $product): bool
    {
        $product_id = $product->get_meta('_arraysubs_gateway_paddle_product_id');
        $price_id   = $product->get_meta('_arraysubs_gateway_paddle_price_id');

        return ! empty($product_id) && ! empty($price_id);
    }

    /**
     * Map WooCommerce subscription period to Paddle interval.
     *
     * @param string $period WC period: day, week, month, year.
     * @return string Paddle interval: day, week, month, year.
     */
    private function mapPeriodToInterval(string $period): string
    {
        $map = [
            'day'   => 'day',
            'week'  => 'week',
            'month' => 'month',
            'year'  => 'year',
        ];

        return $map[$period] ?? 'month';
    }

    /**
     * Format a price amount for Paddle (string in minor units).
     *
     * Paddle expects amounts as strings in the smallest currency unit (e.g., "2999" for $29.99).
     *
     * @param string $amount   The decimal amount (e.g., "29.99").
     * @param string $currency The currency code.
     * @return string Amount in minor units as string.
     */
    private function formatAmountForPaddle(string $amount, string $currency): string
    {
        $zero_decimal = ['BIF', 'CLP', 'DJF', 'GNF', 'JPY', 'KMF', 'KRW', 'MGA', 'PYG', 'RWF', 'UGX', 'VND', 'VUV', 'XAF', 'XOF', 'XPF'];

        if (in_array(strtoupper($currency), $zero_decimal, true)) {
            return (string) (int) round((float) $amount);
        }

        return (string) (int) round((float) $amount * 100);
    }

    /**
     * Log a message via WC logger.
     *
     * @param string $level   Log level.
     * @param string $message Log message.
     * @return void
     */
    private function log(string $level, string $message): void
    {
        if (function_exists('wc_get_logger')) {
            wc_get_logger()->log($level, $message, ['source' => 'arraysubs_paddle_sync']);
        }
    }
}
