<?php

/**
 * Paddle Gateway
 *
 * Concrete implementation of AbstractArraySubsGateway for Paddle.
 * Paddle is the Merchant of Record (MoR) — it manages billing, tax, and invoicing.
 *
 * Key differences from Stripe:
 * - Paddle manages the recurring billing schedule (no off-session PI)
 * - Product/Price sync is REQUIRED before checkout
 * - Checkout uses Paddle.js overlay (not redirect)
 * - Native pause/resume support
 * - Refunds via Paddle Adjustment API
 * - Paddle handles tax, SCA, disputes internally
 *
 * Settings: WooCommerce > Settings > Payments > Paddle (ArraySubs)
 * Checkout: Paddle.js overlay via Transaction
 * Renewals: Paddle-managed (webhooks confirm charges)
 * Trials: Paddle native trial period on Price object
 *
 * @package ArraySubsPro\Features\AutomaticPayments\Gateways\Paddle
 * @since 1.0.0
 */

namespace ArraySubsPro\Features\AutomaticPayments\Gateways\Paddle;

defined('ABSPATH') || exit;

use ArraySubsPro\Features\AutomaticPayments\Abstracts\AbstractArraySubsGateway;
use ArraySubsPro\Features\AutomaticPayments\Services\PaymentMetaNormalizer;
use ArraySubsPro\Features\AutomaticPayments\Services\TwoWaySyncGuard;

/**
 * Paddle Gateway
 */
class PaddleGateway extends AbstractArraySubsGateway
{
    /**
     * Paddle API client instance.
     *
     * @var PaddleApiClient|null
     */
    private ?PaddleApiClient $api = null;

    /**
     * Product sync service.
     *
     * @var PaddleProductSync|null
     */
    private ?PaddleProductSync $product_sync = null;

    /**
     * Paddle subscription ID meta key.
     *
     * @var string
     */
    const META_PADDLE_SUBSCRIPTION_ID = '_gateway_paddle_subscription_id';

    /**
     * Paddle payout amount meta key (for MoR reconciliation).
     *
     * @var string
     */
    const META_PADDLE_PAYOUT_AMOUNT = '_gateway_paddle_payout_amount';

    /**
     * Constructor.
     */
    public function __construct()
    {
        $this->id                 = 'arraysubs_paddle';
        $this->method_title       = __('Paddle (ArraySubs)', 'arraysubspro');
        $this->method_description = __('Accept payments via Paddle for subscriptions managed by ArraySubs. Paddle is the Merchant of Record.', 'arraysubspro');
        $this->has_fields         = false;
        $this->icon               = '';

        $this->supports = [
            'products',
            'refunds',
            'subscriptions',
            'subscription_cancellation',
            'subscription_suspension',
            'subscription_reactivation',
        ];

        $this->subscriptionCapabilities = [
            'automatic_payments'                => true,
            'trials'                            => true,
            'pause'                             => true,
            'resume'                            => true,
            'cancel_at_period_end'              => true,
            'cancel_at_period_end_reversible'   => true,
            'retention_amount_update'           => false,
            'product_sync'                      => true,
            'payment_method_update'             => true,
            'card_auto_update'                  => true,
            'card_expiry_notice'                => false,
            'disputes'                          => false,
            'sca'                               => false,
            'refunds'                           => true,
            'hosted_payment_page'               => true,
            'customer_portal'                   => true,
            'mixed_cart'                        => true,
            'multiple_subscriptions'            => true,
            'different_billing_cycles'          => false,
            'supports_sync'                     => true,
        ];

        // Paddle v2 Billing API event types → normalized
        $this->eventMap = [
            'transaction.completed'       => self::EVENT_PAYMENT_SUCCEEDED,
            'transaction.payment_failed'  => self::EVENT_PAYMENT_FAILED,
            'subscription.canceled'       => self::EVENT_SUBSCRIPTION_CANCELLED,
            'subscription.updated'        => self::EVENT_PAYMENT_METHOD_UPDATED,
            'adjustment.created'          => self::EVENT_REFUND_CREATED,
            // Custom Paddle events handled in handleWebhookEvent
            'subscription.created'        => '',
            'subscription.paused'         => '',
            'subscription.resumed'        => '',
        ];

        $this->init_form_fields();
        $this->init_settings();

        $this->title       = $this->get_option('title', __('Paddle', 'arraysubspro'));
        $this->description = $this->get_option('description', __('Pay securely via Paddle.', 'arraysubspro'));
        $this->enabled     = $this->get_option('enabled', 'no');

        add_action('woocommerce_update_options_payment_gateways_' . $this->id, [$this, 'process_admin_options']);
    }

    // ─── Settings ────────────────────────────────────────────────────────

    /**
     * Define gateway settings fields.
     *
     * @return void
     */
    public function init_form_fields(): void
    {
        parent::init_form_fields();

        $webhook_url = rest_url('arraysubs/v1/webhooks/' . $this->getGatewaySlug());

        // Override test_mode label for Paddle
        $this->form_fields['test_mode']['label'] = __('Enable Paddle Sandbox mode', 'arraysubspro');

        $this->form_fields = array_merge($this->form_fields, [
            'api_key'        => [
                'title'       => __('API Key', 'arraysubspro'),
                'type'        => 'password',
                'description' => __('Your Paddle API key from Paddle Dashboard → Developer Tools → Authentication.', 'arraysubspro'),
                'default'     => '',
            ],
            'client_token'   => [
                'title'       => __('Client-Side Token', 'arraysubspro'),
                'type'        => 'text',
                'description' => __('Client-side token for Paddle.js frontend initialization.', 'arraysubspro'),
                'default'     => '',
            ],
            'seller_id'      => [
                'title'       => __('Seller ID', 'arraysubspro'),
                'type'        => 'text',
                'description' => __('Your Paddle Seller/Vendor ID from Paddle Dashboard.', 'arraysubspro'),
                'default'     => '',
            ],
            'webhook_secret' => [
                'title'       => __('Webhook Secret', 'arraysubspro'),
                'type'        => 'password',
                'description' => __('Notification destination secret key from Paddle Dashboard → Developer Tools → Notifications.', 'arraysubspro'),
                'default'     => '',
            ],
            'webhook_url'    => [
                'title'       => __('Webhook URL', 'arraysubspro'),
                'type'        => 'title',
                'description' => sprintf(
                    /* translators: %s: webhook endpoint URL */
                    __('Configure this URL as a notification destination in your Paddle Dashboard: %s', 'arraysubspro'),
                    '<code>' . esc_url($webhook_url) . '</code>'
                ),
            ],
            'checkout_restrictions' => [
                'title'       => __('Checkout Restrictions', 'arraysubspro'),
                'type'        => 'title',
                'description' => __('Paddle supports multiple subscriptions only with the same billing cycle. Different billing cycles are not supported. Use the arraysubs_arraysubs_paddle_allow_* filters to customize.', 'arraysubspro'),
            ],
        ]);
    }

    // ─── API Client & Services ───────────────────────────────────────────

    /**
     * Get or create the Paddle API client.
     *
     * @return PaddleApiClient
     */
    private function getApi(): PaddleApiClient
    {
        if (null === $this->api) {
            $api_key     = $this->get_option('api_key', '');
            $environment = $this->isTestMode() ? 'sandbox' : 'production';

            $this->api = new PaddleApiClient($api_key, $environment);
        }

        return $this->api;
    }

    /**
     * Get or create the product sync service.
     *
     * @return PaddleProductSync
     */
    private function getProductSync(): PaddleProductSync
    {
        if (null === $this->product_sync) {
            $this->product_sync = new PaddleProductSync($this->getApi());
        }

        return $this->product_sync;
    }

    // ─── WC Availability ─────────────────────────────────────────────────

    /**
     * Check if required Paddle API credentials are configured.
     *
     * @return bool
     */
    protected function hasRequiredCredentials(): bool
    {
        $api_key      = $this->get_option('api_key', '');
        $client_token = $this->get_option('client_token', '');

        return ! empty($api_key) && ! empty($client_token);
    }

    // ─── Checkout: Subscription Payment ──────────────────────────────────

    /**
     * Process a subscription order payment via Paddle.
     *
     * Creates a Paddle Transaction and returns Paddle.js overlay params
     * for the frontend to open the checkout overlay.
     *
     * @param \WC_Order $order The WooCommerce order.
     * @return array{result: string, redirect: string}
     */
    protected function processSubscriptionPayment(\WC_Order $order): array
    {
        $subscription_ids = $this->getSubscriptionsForOrder($order);

        if (empty($subscription_ids)) {
            wc_add_notice(__('No subscription found for this order.', 'arraysubspro'), 'error');
            return ['result' => 'failure', 'redirect' => ''];
        }

        $subscription_id = $subscription_ids[0];

        // Ensure product is synced to Paddle
        $sync_result = $this->ensureProductSynced($order);

        if (! $sync_result['success']) {
            wc_add_notice(
                sprintf(
                    /* translators: %s: error message */
                    __('Paddle product sync failed: %s', 'arraysubspro'),
                    $sync_result['message']
                ),
                'error'
            );
            return ['result' => 'failure', 'redirect' => ''];
        }

        $price_id = $sync_result['price_id'];

        // Find or create Paddle customer
        $customer_id = $this->findOrCreatePaddleCustomer($order);

        if (empty($customer_id)) {
            wc_add_notice(__('Failed to create Paddle customer.', 'arraysubspro'), 'error');
            return ['result' => 'failure', 'redirect' => ''];
        }

        // Create a Paddle Transaction for checkout
        $transaction_params = [
            'items'       => [
                [
                    'price_id' => $price_id,
                    'quantity' => 1,
                ],
            ],
            'customer_id' => $customer_id,
            'custom_data' => [
                'order_id'        => $order->get_id(),
                'subscription_id' => $subscription_id,
                'site_url'        => get_site_url(),
            ],
        ];

        $transaction = $this->getApi()->createTransaction($transaction_params);

        if (is_wp_error($transaction)) {
            $this->log('error', 'Paddle transaction creation failed: ' . $transaction->get_error_message());
            wc_add_notice(__('Payment setup failed. Please try again.', 'arraysubspro'), 'error');
            return ['result' => 'failure', 'redirect' => ''];
        }

        $transaction_id = $transaction['id'] ?? '';

        // Store the session/transaction ID for later resolution
        $this->persistGatewayMeta($subscription_id, [
            '_payment_gateway'    => $this->id,
            '_gateway_session_id' => $transaction_id,
            '_gateway_status'     => 'pending',
        ]);

        $this->persistOrderGatewayMeta($order, [
            '_paddle_transaction_id' => $transaction_id,
        ]);

        $order->update_status('pending', __('Awaiting Paddle checkout completion.', 'arraysubspro'));

        $this->log('info', sprintf(
            'Paddle transaction %s created for order %d, subscription %d',
            $transaction_id,
            $order->get_id(),
            $subscription_id
        ));

        // Return data for frontend JS to open Paddle.js overlay
        // WooCommerce processes the 'paddle_data' key via custom JS handler
        $thank_you_url = $this->get_return_url($order);

        return [
            'result'      => 'success',
            'redirect'    => false,
            'paddle_data' => [
                'transaction_id' => $transaction_id,
                'client_token'   => $this->get_option('client_token', ''),
                'environment'    => $this->isTestMode() ? 'sandbox' : 'production',
                'success_url'    => $thank_you_url,
            ],
        ];
    }

    /**
     * Process a standard (non-subscription) order payment via Paddle.
     *
     * @param \WC_Order $order The WooCommerce order.
     * @return array{result: string, redirect: string}
     */
    protected function processStandardPayment(\WC_Order $order): array
    {
        // For non-subscription orders, create a one-time transaction
        $customer_id = $this->findOrCreatePaddleCustomer($order);

        if (empty($customer_id)) {
            wc_add_notice(__('Failed to create Paddle customer.', 'arraysubspro'), 'error');
            return ['result' => 'failure', 'redirect' => ''];
        }

        // Build ad-hoc price items from order line items
        $items = [];
        foreach ($order->get_items() as $item) {
            $product = $item->get_product();
            if (! $product) {
                continue;
            }

            // Paddle requires prices to be on a product — for non-subscription
            // one-time purchases, we pass inline price data via the transaction
            $items[] = [
                'price' => [
                    'description'   => $product->get_name(),
                    'product_id'    => $this->getOrCreatePaddleProductId($product),
                    'unit_price'    => [
                        'amount'        => $this->formatAmountForPaddle((string) $item->get_total(), strtoupper(get_woocommerce_currency())),
                        'currency_code' => strtoupper(get_woocommerce_currency()),
                    ],
                ],
                'quantity' => $item->get_quantity(),
            ];
        }

        if (empty($items)) {
            wc_add_notice(__('No valid items for checkout.', 'arraysubspro'), 'error');
            return ['result' => 'failure', 'redirect' => ''];
        }

        $transaction = $this->getApi()->createTransaction([
            'items'       => $items,
            'customer_id' => $customer_id,
            'custom_data' => [
                'order_id' => $order->get_id(),
                'site_url' => get_site_url(),
            ],
        ]);

        if (is_wp_error($transaction)) {
            wc_add_notice(__('Payment setup failed. Please try again.', 'arraysubspro'), 'error');
            return ['result' => 'failure', 'redirect' => ''];
        }

        $transaction_id = $transaction['id'] ?? '';

        $this->persistOrderGatewayMeta($order, [
            '_paddle_transaction_id' => $transaction_id,
        ]);

        $order->update_status('pending', __('Awaiting Paddle checkout completion.', 'arraysubspro'));

        return [
            'result'      => 'success',
            'redirect'    => false,
            'paddle_data' => [
                'transaction_id' => $transaction_id,
                'client_token'   => $this->get_option('client_token', ''),
                'environment'    => $this->isTestMode() ? 'sandbox' : 'production',
                'success_url'    => $this->get_return_url($order),
            ],
        ];
    }

    // ─── Refund ──────────────────────────────────────────────────────────

    /**
     * Execute a refund at Paddle via the Adjustment API.
     *
     * @param int        $order_id The WooCommerce order ID.
     * @param float|null $amount   The refund amount.
     * @param string     $reason   The refund reason.
     * @return bool|\WP_Error
     */
    protected function processGatewayRefund(int $order_id, ?float $amount, string $reason)
    {
        $order = wc_get_order($order_id);

        if (! $order) {
            return new \WP_Error('invalid_order', __('Order not found.', 'arraysubspro'));
        }

        $transaction_id = $order->get_meta('_paddle_transaction_id');

        if (empty($transaction_id)) {
            return new \WP_Error('no_transaction', __('No Paddle transaction found for this order.', 'arraysubspro'));
        }

        // Mark refund as locally initiated (two-way sync guard)
        $subscription_ids = $this->getSubscriptionsForOrder($order);
        foreach ($subscription_ids as $sub_id) {
            TwoWaySyncGuard::markInitiated('refund', $sub_id);
        }

        $adjustment_params = [
            'action'         => 'refund',
            'transaction_id' => $transaction_id,
            'reason'         => ! empty($reason) ? $reason : __('Refund from store', 'arraysubspro'),
        ];

        // Partial refund: specify items/amounts
        if (null !== $amount && $amount > 0) {
            $currency = strtoupper($order->get_currency());
            $adjustment_params['items'] = [
                [
                    'item_id' => $transaction_id,
                    'type'    => 'partial',
                    'amount'  => $this->formatAmountForPaddle((string) $amount, $currency),
                ],
            ];
        }

        $result = $this->getApi()->createAdjustment($adjustment_params);

        if (is_wp_error($result)) {
            return $result;
        }

        $this->log('info', sprintf(
            'Paddle refund created for order %d, amount: %s',
            $order_id,
            null !== $amount ? wc_price($amount) : 'full'
        ));

        return true;
    }

    // ─── Recurring Payment ───────────────────────────────────────────────

    /**
     * Process a renewal payment.
     *
     * Paddle manages billing internally. This method is a no-op — the webhook
     * handler confirms actual charges when Paddle fires transaction.completed.
     *
     * @param int       $subscription_id The subscription post ID.
     * @param \WC_Order $order           The renewal order.
     * @return array{success: bool, transaction_id: string, message: string, raw: array}
     */
    public function processRenewalPayment(int $subscription_id, \WC_Order $order): array
    {
        // Paddle manages billing — we don't initiate charges
        // The order stays pending until Paddle's webhook confirms payment
        $paddle_sub_id = get_post_meta($subscription_id, self::META_PADDLE_SUBSCRIPTION_ID, true);

        if (empty($paddle_sub_id)) {
            return [
                'success'        => false,
                'transaction_id' => '',
                'message'        => __('No Paddle subscription ID found.', 'arraysubspro'),
                'raw'            => [],
            ];
        }

        $this->addSubscriptionPrivateNote(
            $subscription_id,
            sprintf(
                /* translators: 1: Paddle subscription ID, 2: order ID */
                __('Renewal order #%2$d pending — awaiting automatic charge from Paddle (subscription: %1$s).', 'arraysubspro'),
                $paddle_sub_id,
                $order->get_id()
            )
        );

        return [
            'success'        => true,
            'transaction_id' => '',
            'message'        => __('Paddle manages billing automatically. Awaiting webhook confirmation.', 'arraysubspro'),
            'raw'            => ['paddle_subscription_id' => $paddle_sub_id],
        ];
    }

    // ─── Trial Setup ─────────────────────────────────────────────────────

    /**
     * Set up payment method for a free trial.
     *
     * Paddle handles trials natively via the Price object's trial_period.
     * The checkout session collects the payment method during the initial
     * transaction. No separate setup intent needed.
     *
     * @param \WC_Order $order           The trial order.
     * @param int       $subscription_id The subscription ID.
     * @param array     $trial_data      Trial configuration.
     * @return array{success: bool, remote_customer_id: string, remote_payment_method_id: string, message: string, raw: array}
     */
    public function setupTrialPaymentMethod(\WC_Order $order, int $subscription_id, array $trial_data): array
    {
        // Paddle handles trials within the normal checkout flow
        // The Price object includes a trial_period, so the first charge is deferred
        // The subscription is created with the trial attached
        return [
            'success'                  => true,
            'remote_customer_id'       => get_post_meta($subscription_id, '_gateway_customer_id', true),
            'remote_payment_method_id' => get_post_meta($subscription_id, self::META_PADDLE_SUBSCRIPTION_ID, true),
            'message'                  => __('Paddle handles trial periods natively.', 'arraysubspro'),
            'raw'                      => [],
        ];
    }

    // ─── Payment Context Capture ─────────────────────────────────────────

    /**
     * Capture payment context after successful checkout.
     *
     * Called after the initial checkout webhook confirms payment.
     * Extracts Paddle customer, subscription, and transaction details.
     *
     * @param \WC_Order $order           The paid order.
     * @param int       $subscription_id The subscription ID.
     * @return array{success: bool, gateway_slug: string, remote_customer_id: string, remote_payment_method_id: string, remote_transaction_id: string, brand: string, last4: string, payment_method_type: string, message: string, raw: array}
     */
    public function capturePaymentContext(\WC_Order $order, int $subscription_id): array
    {
        $transaction_id = $order->get_meta('_paddle_transaction_id');

        if (empty($transaction_id)) {
            return $this->buildCaptureFailure(__('No Paddle transaction ID on order.', 'arraysubspro'));
        }

        $transaction = $this->getApi()->getTransaction($transaction_id);

        if (is_wp_error($transaction)) {
            return $this->buildCaptureFailure($transaction->get_error_message());
        }

        $customer_id     = $transaction['customer_id'] ?? '';
        $paddle_sub_id   = $transaction['subscription_id'] ?? '';
        $payment_details = $transaction['payments'][0] ?? [];
        $method_details  = $payment_details['method_details'] ?? [];

        // Extract payment method info (Paddle reports card details in transaction)
        $pm_type = $method_details['type'] ?? 'unknown';
        $brand   = '';
        $last4   = '';

        if ('card' === $pm_type && isset($method_details['card'])) {
            $brand = $method_details['card']['type'] ?? '';
            $last4 = $method_details['card']['last4'] ?? '';
        }

        // Store gateway meta on subscription
        $meta = [
            '_payment_gateway'           => $this->id,
            '_gateway_customer_id'       => $customer_id,
            '_gateway_payment_method_id' => $paddle_sub_id,
            '_gateway_status'            => 'active',
            '_payment_method_type'       => $pm_type,
            '_last_gateway_transaction_id' => $transaction_id,
        ];

        if (! empty($brand)) {
            $meta['_payment_method_brand'] = $brand;
        }

        if (! empty($last4)) {
            $meta['_payment_method_last4'] = $last4;
        }

        $this->persistGatewayMeta($subscription_id, $meta);

        // Store Paddle's own subscription ID separately (not in allowed_keys of persistGatewayMeta)
        update_post_meta($subscription_id, self::META_PADDLE_SUBSCRIPTION_ID, sanitize_text_field($paddle_sub_id));

        return [
            'success'                  => true,
            'gateway_slug'             => $this->id,
            'remote_customer_id'       => $customer_id,
            'remote_payment_method_id' => $paddle_sub_id,
            'remote_transaction_id'    => $transaction_id,
            'brand'                    => $brand,
            'last4'                    => $last4,
            'payment_method_type'      => $pm_type,
            'message'                  => __('Paddle payment context captured.', 'arraysubspro'),
            'raw'                      => $transaction,
        ];
    }

    // ─── Cancellation ────────────────────────────────────────────────────

    /**
     * Cancel the billing context at Paddle.
     *
     * @param int   $subscription_id The subscription ID.
     * @param array $context         Cancellation context.
     * @return array{success: bool, message: string, raw: array}
     */
    public function cancelRemoteBillingContext(int $subscription_id, array $context = []): array
    {
        $paddle_sub_id = get_post_meta($subscription_id, self::META_PADDLE_SUBSCRIPTION_ID, true);

        if (empty($paddle_sub_id)) {
            return [
                'success' => true,
                'message' => __('No Paddle subscription to cancel.', 'arraysubspro'),
                'raw'     => [],
            ];
        }

        TwoWaySyncGuard::markInitiated('cancel', $subscription_id);

        $effective_from = $context['effective_from'] ?? 'immediately';
        $result = $this->getApi()->cancelSubscription($paddle_sub_id, $effective_from);

        if (is_wp_error($result)) {
            return [
                'success' => false,
                'message' => $result->get_error_message(),
                'raw'     => [],
            ];
        }

        $this->persistGatewayMeta($subscription_id, [
            '_gateway_status' => 'cancelled',
        ]);

        $this->addSubscriptionPrivateNote(
            $subscription_id,
            sprintf(
                /* translators: %s: Paddle subscription ID */
                __('Paddle subscription %s cancelled.', 'arraysubspro'),
                $paddle_sub_id
            )
        );

        return [
            'success' => true,
            'message' => __('Paddle subscription cancelled.', 'arraysubspro'),
            'raw'     => $result,
        ];
    }

    /**
     * Pull authoritative subscription state from Paddle.
     *
     * Returns the Paddle subscription's status, next_billed_at, payment method
     * details, and any recent transactions for reconciliation. The caller
     * decides which fields to apply.
     *
     * @param int $subscription_id Subscription ID.
     * @return array
     */
    public function syncFromGateway(int $subscription_id): array
    {
        $paddle_sub_id = (string) get_post_meta($subscription_id, self::META_PADDLE_SUBSCRIPTION_ID, true);

        if ('' === $paddle_sub_id) {
            return [
                'success'           => false,
                'message'           => __('No Paddle subscription linked.', 'arraysubspro'),
                'gateway_status'    => '',
                'next_payment_date' => '',
                'payment_method'    => [],
                'recent_charges'    => [],
                'raw'               => [],
            ];
        }

        $sub = $this->getApi()->getSubscription($paddle_sub_id);
        if (is_wp_error($sub)) {
            return [
                'success'           => false,
                'message'           => $sub->get_error_message(),
                'gateway_status'    => '',
                'next_payment_date' => '',
                'payment_method'    => [],
                'recent_charges'    => [],
                'raw'               => [],
            ];
        }

        $payload = $sub['data'] ?? $sub;

        $status            = (string) ($payload['status'] ?? '');
        $next_billed_at    = (string) ($payload['next_billed_at'] ?? '');
        $next_payment_date = '';
        if ('' !== $next_billed_at) {
            $ts = strtotime($next_billed_at);
            if ($ts) {
                $next_payment_date = gmdate('Y-m-d H:i:s', $ts);
            }
        }

        $pm_data = [];
        $pm_block = $payload['payment_method'] ?? ($payload['default_payment_method'] ?? null);
        if (is_array($pm_block)) {
            $card = $pm_block['card'] ?? [];
            $pm_data = [
                'brand'        => (string) ($card['brand'] ?? ''),
                'last4'        => (string) ($card['last4'] ?? ''),
                'expiry_month' => (string) ($card['expiry_month'] ?? ''),
                'expiry_year'  => (string) ($card['expiry_year'] ?? ''),
                'detached'     => false,
            ];
        }

        return [
            'success'           => true,
            'message'           => __('Paddle state retrieved.', 'arraysubspro'),
            'gateway_status'    => 'active' === $status ? 'active' : ('paused' === $status ? 'paused' : 'inactive'),
            'next_payment_date' => $next_payment_date,
            'payment_method'    => $pm_data,
            'recent_charges'    => [],
            'raw'               => $payload,
        ];
    }

    /**
     * Reverse a Paddle scheduled cancellation. Used when the customer or admin
     * undoes an end-of-period cancel before it fires.
     *
     * Implementation: PATCH /subscriptions/{id} with scheduled_change=null clears
     * any scheduled change (including a scheduled cancel).
     *
     * @param int   $subscription_id The subscription ID.
     * @param array $context         Restore context (unused).
     * @return array{success: bool, message: string, raw: array}
     */
    public function restoreScheduledCancel(int $subscription_id, array $context = []): array
    {
        $paddle_sub_id = get_post_meta($subscription_id, self::META_PADDLE_SUBSCRIPTION_ID, true);

        if (empty($paddle_sub_id)) {
            return [
                'success' => true,
                'message' => __('No Paddle subscription to restore.', 'arraysubspro'),
                'raw'     => [],
            ];
        }

        $result = $this->getApi()->updateSubscription($paddle_sub_id, [
            'scheduled_change' => null,
        ]);

        if (is_wp_error($result)) {
            return [
                'success' => false,
                'message' => $result->get_error_message(),
                'raw'     => [],
            ];
        }

        $this->persistGatewayMeta($subscription_id, [
            '_gateway_status' => 'active',
        ]);

        return [
            'success' => true,
            'message' => __('Paddle scheduled cancellation reversed.', 'arraysubspro'),
            'raw'     => $result,
        ];
    }

    // ─── Pause / Resume (Paddle-Specific Overrides) ──────────────────────

    /**
     * Pause the subscription at Paddle.
     *
     * @param int   $subscription_id The subscription ID.
     * @param array $context         Pause context.
     * @return array{success: bool, message: string, raw: array}
     */
    public function pauseRemoteBillingContext(int $subscription_id, array $context = []): array
    {
        $paddle_sub_id = get_post_meta($subscription_id, self::META_PADDLE_SUBSCRIPTION_ID, true);

        if (empty($paddle_sub_id)) {
            return [
                'success' => false,
                'message' => __('No Paddle subscription to pause.', 'arraysubspro'),
                'raw'     => [],
            ];
        }

        TwoWaySyncGuard::markInitiated('pause', $subscription_id);

        $result = $this->getApi()->pauseSubscription($paddle_sub_id);

        if (is_wp_error($result)) {
            return [
                'success' => false,
                'message' => $result->get_error_message(),
                'raw'     => [],
            ];
        }

        $this->addSubscriptionPrivateNote(
            $subscription_id,
            sprintf(
                /* translators: %s: Paddle subscription ID */
                __('Paddle subscription %s paused.', 'arraysubspro'),
                $paddle_sub_id
            )
        );

        return [
            'success' => true,
            'message' => __('Paddle subscription paused.', 'arraysubspro'),
            'raw'     => $result,
        ];
    }

    /**
     * Resume the subscription at Paddle.
     *
     * @param int   $subscription_id The subscription ID.
     * @param array $context         Resume context.
     * @return array{success: bool, message: string, raw: array}
     */
    public function resumeRemoteBillingContext(int $subscription_id, array $context = []): array
    {
        $paddle_sub_id = get_post_meta($subscription_id, self::META_PADDLE_SUBSCRIPTION_ID, true);

        if (empty($paddle_sub_id)) {
            return [
                'success' => false,
                'message' => __('No Paddle subscription to resume.', 'arraysubspro'),
                'raw'     => [],
            ];
        }

        TwoWaySyncGuard::markInitiated('resume', $subscription_id);

        $result = $this->getApi()->resumeSubscription($paddle_sub_id);

        if (is_wp_error($result)) {
            return [
                'success' => false,
                'message' => $result->get_error_message(),
                'raw'     => [],
            ];
        }

        $this->addSubscriptionPrivateNote(
            $subscription_id,
            sprintf(
                /* translators: %s: Paddle subscription ID */
                __('Paddle subscription %s resumed.', 'arraysubspro'),
                $paddle_sub_id
            )
        );

        return [
            'success' => true,
            'message' => __('Paddle subscription resumed.', 'arraysubspro'),
            'raw'     => $result,
        ];
    }

    // ─── Product Sync (Paddle-Specific Override) ─────────────────────────

    /**
     * Sync a WooCommerce product to Paddle's catalog.
     *
     * @param \WC_Product $product The product to sync.
     * @return array{success: bool, remote_product_id: string, message: string, raw: array}
     */
    public function syncProduct(\WC_Product $product): array
    {
        $result = $this->getProductSync()->syncProduct($product);

        return [
            'success'           => $result['success'],
            'remote_product_id' => $result['remote_product_id'] ?? '',
            'message'           => $result['message'],
            'raw'               => [],
        ];
    }

    /**
     * Archive a product from Paddle's catalog.
     *
     * @param \WC_Product $product The product to delete remotely.
     * @return array{success: bool, message: string, raw: array}
     */
    public function deleteRemoteProduct(\WC_Product $product): array
    {
        $result = $this->getProductSync()->archiveProduct($product);

        return [
            'success' => $result['success'],
            'message' => $result['message'],
            'raw'     => [],
        ];
    }

    // ─── Payment Method Display ──────────────────────────────────────────

    /**
     * Format stored payment method for UI display.
     *
     * @param int $subscription_id The subscription ID.
     * @return array{gateway: string, title: string, brand: string, last4: string, expiry: string, is_expired: bool, can_update: bool, update_url: string, update_type: string}
     */
    public function formatPaymentMethodForDisplay(int $subscription_id): array
    {
        $meta = $this->getGatewayMeta($subscription_id);

        $brand = $meta['brand'] ? ucfirst(strtolower($meta['brand'])) : '';
        $last4 = $meta['last4'];
        $type  = $meta['payment_method_type'] ?: __('Paddle', 'arraysubspro');

        if (! empty($brand) && ! empty($last4)) {
            $title = sprintf(
                /* translators: 1: card brand, 2: last 4 digits */
                __('%1$s ending in %2$s', 'arraysubspro'),
                $brand,
                $last4
            );
        } elseif (! empty($last4)) {
            $title = sprintf(
                /* translators: %s: last 4 digits */
                __('Card ending in %s', 'arraysubspro'),
                $last4
            );
        } else {
            $title = sprintf(
                /* translators: %s: payment method type */
                __('Paddle (%s)', 'arraysubspro'),
                $type
            );
        }

        return [
            'gateway'     => $this->id,
            'title'       => $title,
            'brand'       => $brand,
            'last4'       => $last4,
            'expiry'      => '',
            'is_expired'  => false,
            'can_update'  => true,
            'update_url'  => '',
            'update_type' => 'portal',
        ];
    }

    // ─── Payment Method Update ───────────────────────────────────────────

    /**
     * Get the Paddle Customer Portal URL for payment method updates.
     *
     * @param int   $subscription_id The subscription ID.
     * @param array $context         Update context.
     * @return array{success: bool, type: string, url: string, message: string, raw: array}
     */
    public function getPaymentMethodUpdateMechanism(int $subscription_id, array $context = []): array
    {
        $customer_id = get_post_meta($subscription_id, '_gateway_customer_id', true);

        if (empty($customer_id)) {
            return [
                'success' => false,
                'type'    => 'portal',
                'url'     => '',
                'message' => __('No Paddle customer ID found.', 'arraysubspro'),
                'raw'     => [],
            ];
        }

        $result = $this->getApi()->createPortalSession($customer_id);

        if (is_wp_error($result)) {
            return [
                'success' => false,
                'type'    => 'portal',
                'url'     => '',
                'message' => $result->get_error_message(),
                'raw'     => [],
            ];
        }

        $portal_url = $result['urls']['general']['overview'] ?? ($result['url'] ?? '');

        return [
            'success' => true,
            'type'    => 'portal',
            'url'     => $portal_url,
            'message' => __('Paddle customer portal session created.', 'arraysubspro'),
            'raw'     => $result,
        ];
    }

    // ─── Webhook: Verify Signature ───────────────────────────────────────

    /**
     * Verify the Paddle webhook signature.
     *
     * @param \WP_REST_Request $request The incoming request.
     * @return bool
     */
    public function verifyWebhookSignature(\WP_REST_Request $request): bool
    {
        $webhook_secret = $this->get_option('webhook_secret', '');

        if (empty($webhook_secret)) {
            $this->log('error', 'Paddle webhook secret not configured.');
            return false;
        }

        $signature = $request->get_header('Paddle-Signature');

        if (empty($signature)) {
            $this->log('error', 'Missing Paddle-Signature header.');
            return false;
        }

        $raw_body = $request->get_body();
        $result   = $this->getApi()->verifyWebhookSignature($raw_body, $signature, $webhook_secret);

        if (! $result['valid']) {
            $this->log('error', 'Paddle webhook signature verification failed: ' . $result['error']);
            return false;
        }

        return true;
    }

    // ─── Webhook: Parse ──────────────────────────────────────────────────

    /**
     * Parse raw Paddle webhook payload into normalized structure.
     *
     * @param \WP_REST_Request $request The incoming request.
     * @return array{success: bool, gateway_event_id: string, gateway_event_type: string, normalized_event_type: string, occurred_at: int, payload: array, raw_body: string}
     */
    public function parseWebhook(\WP_REST_Request $request): array
    {
        $raw_body = $request->get_body();
        $data     = json_decode($raw_body, true);

        if (empty($data) || ! isset($data['event_type'])) {
            return [
                'success'              => false,
                'gateway_event_id'     => '',
                'gateway_event_type'   => '',
                'normalized_event_type' => '',
                'occurred_at'          => 0,
                'payload'              => [],
                'raw_body'             => $raw_body,
            ];
        }

        $event_type    = $data['event_type'] ?? '';
        $event_id      = $data['event_id'] ?? '';
        $occurred_at   = $data['occurred_at'] ?? '';
        $payload       = $data['data'] ?? [];

        return [
            'success'              => true,
            'gateway_event_id'     => $event_id,
            'gateway_event_type'   => $event_type,
            'normalized_event_type' => $this->normalizeEventType($event_type),
            'occurred_at'          => ! empty($occurred_at) ? strtotime($occurred_at) : time(),
            'payload'              => $payload,
            'raw_body'             => $raw_body,
        ];
    }

    // ─── Webhook: Resolve Entity IDs ─────────────────────────────────────

    /**
     * Resolve subscription, order, and customer IDs from a Paddle webhook.
     *
     * @param array $parsed_webhook Output from parseWebhook().
     * @return array{subscription_id: int, order_id: int, customer_id: int}
     */
    public function resolveEntityIds(array $parsed_webhook): array
    {
        $payload = $parsed_webhook['payload'] ?? [];
        $result  = [
            'subscription_id' => 0,
            'order_id'        => 0,
            'customer_id'     => 0,
        ];

        // 1. Try custom_data first (set during checkout)
        $custom_data = $payload['custom_data'] ?? [];

        if (! empty($custom_data['subscription_id'])) {
            $result['subscription_id'] = (int) $custom_data['subscription_id'];
        }

        if (! empty($custom_data['order_id'])) {
            $result['order_id'] = (int) $custom_data['order_id'];
        }

        // 2. Try to resolve via Paddle subscription ID
        $paddle_sub_id = $payload['subscription_id'] ?? ($payload['id'] ?? '');
        $event_type    = $parsed_webhook['gateway_event_type'] ?? '';

        // For subscription.* events, the data IS the subscription object
        if (str_starts_with($event_type, 'subscription.') && empty($paddle_sub_id)) {
            $paddle_sub_id = $payload['id'] ?? '';
        }

        if (! empty($paddle_sub_id) && 0 === $result['subscription_id']) {
            $result['subscription_id'] = $this->findSubscriptionByPaddleId($paddle_sub_id);
        }

        // 3. Cross-resolve: subscription → order or order → subscription
        if ($result['subscription_id'] > 0 && 0 === $result['order_id']) {
            $result['order_id'] = PaymentMetaNormalizer::findOrderForSubscription($result['subscription_id']);
        }

        if ($result['order_id'] > 0 && 0 === $result['subscription_id']) {
            $sub_ids = PaymentMetaNormalizer::findSubscriptionIdsForOrder($result['order_id']);
            if (! empty($sub_ids)) {
                $result['subscription_id'] = $sub_ids[0];
            }
        }

        // 4. Resolve WP customer user ID
        if ($result['subscription_id'] > 0) {
            $wp_customer_id = get_post_meta($result['subscription_id'], '_customer_id', true);
            if ($wp_customer_id) {
                $result['customer_id'] = (int) $wp_customer_id;
            }
        }

        return $result;
    }

    // ─── Webhook Event Handlers ──────────────────────────────────────────

    /**
     * Handle successful payment (initial checkout or renewal).
     *
     * Triggered by transaction.completed webhook.
     *
     * @param array $context Event context with parsed webhook + resolved entities.
     * @return array{success: bool, message: string}
     */
    public function handlePaymentSucceeded(array $context): array
    {
        $subscription_id = $context['subscription_id'] ?? 0;
        $order_id        = $context['order_id'] ?? 0;
        $payload         = $context['payload'] ?? [];

        if (0 === $subscription_id) {
            // Might be a non-subscription transaction
            if ($order_id > 0) {
                $order = wc_get_order($order_id);
                if ($order && ! $order->is_paid()) {
                    $txn_id = $payload['id'] ?? '';
                    $this->markOrderPaid($order, $txn_id);
                }
            }
            return ['success' => true, 'message' => 'Non-subscription payment processed.'];
        }

        $order = $order_id > 0 ? wc_get_order($order_id) : null;

        // Capture payment context on initial checkout
        if ($order && ! $order->is_paid()) {
            $txn_id = $payload['id'] ?? '';

            // Store Paddle subscription ID
            $paddle_sub_id = $payload['subscription_id'] ?? '';
            if (! empty($paddle_sub_id)) {
                update_post_meta($subscription_id, self::META_PADDLE_SUBSCRIPTION_ID, sanitize_text_field($paddle_sub_id));
            }

            // Store payout/earnings for MoR reconciliation
            $payout = $payload['details']['payout_totals']['total'] ?? null;
            if (null !== $payout) {
                $currency_code = $payload['details']['payout_totals']['currency_code'] ?? '';
                update_post_meta(
                    $subscription_id,
                    self::META_PADDLE_PAYOUT_AMOUNT,
                    sanitize_text_field($payout . ' ' . $currency_code)
                );
            }

            $this->capturePaymentContext($order, $subscription_id);
            $this->markOrderPaid($order, $payload['id'] ?? '');

            $this->addSubscriptionPrivateNote(
                $subscription_id,
                sprintf(
                    /* translators: 1: transaction ID, 2: order ID */
                    __('Paddle payment succeeded. Transaction: %1$s, Order: #%2$d', 'arraysubspro'),
                    $payload['id'] ?? 'N/A',
                    $order_id
                )
            );

            $this->emitWebhookAction('arraysubs_gateway_payment_succeeded', [
                $subscription_id,
                $order_id,
                $this->id,
                $payload,
            ]);

            return ['success' => true, 'message' => 'Initial payment completed.'];
        }

        // Renewal payment — find pending renewal order
        $renewal_order_id = PaymentMetaNormalizer::findOrderForSubscription($subscription_id, 'renewal');
        $renewal_order    = $renewal_order_id > 0 ? wc_get_order($renewal_order_id) : null;

        if (! $renewal_order || $renewal_order->is_paid()) {
            // No pending renewal order — create one retroactively
            $renewal_order = $this->createRetroactiveRenewalOrder($subscription_id, $payload);
        }

        if ($renewal_order && ! $renewal_order->is_paid()) {
            $txn_id = $payload['id'] ?? '';
            $this->markOrderPaid($renewal_order, $txn_id);

            // Update next payment date from Paddle's schedule
            $this->syncNextPaymentDate($subscription_id, $payload);

            $this->addSubscriptionPrivateNote(
                $subscription_id,
                sprintf(
                    /* translators: 1: transaction ID, 2: order ID */
                    __('Paddle renewal payment succeeded. Transaction: %1$s, Order: #%2$d', 'arraysubspro'),
                    $txn_id,
                    $renewal_order->get_id()
                )
            );

            $this->emitWebhookAction('arraysubs_gateway_payment_succeeded', [
                $subscription_id,
                $renewal_order->get_id(),
                $this->id,
                $payload,
            ]);
        }

        return ['success' => true, 'message' => 'Renewal payment completed.'];
    }

    /**
     * Handle payment failure.
     *
     * Triggered by transaction.payment_failed webhook.
     *
     * @param array $context Event context.
     * @return array{success: bool, message: string}
     */
    public function handlePaymentFailed(array $context): array
    {
        $subscription_id = $context['subscription_id'] ?? 0;
        $payload         = $context['payload'] ?? [];

        if (0 === $subscription_id) {
            return ['success' => false, 'message' => 'No subscription found for failed payment.'];
        }

        $error_code    = $payload['payments'][0]['error_code'] ?? 'unknown';
        $error_message = $payload['payments'][0]['method_details']['error']['type'] ?? __('Payment declined', 'arraysubspro');

        // Find the pending renewal order
        $renewal_order_id = PaymentMetaNormalizer::findOrderForSubscription($subscription_id, 'renewal');
        $renewal_order    = $renewal_order_id > 0 ? wc_get_order($renewal_order_id) : null;

        if ($renewal_order) {
            $this->recordPaymentFailure($renewal_order, $subscription_id, $error_code, $error_message);
        }

        update_post_meta($subscription_id, '_last_payment_failure', time());

        $this->addSubscriptionPrivateNote(
            $subscription_id,
            sprintf(
                /* translators: 1: error code, 2: error message */
                __('Paddle payment failed — %1$s: %2$s. Grace period will handle status transitions.', 'arraysubspro'),
                $error_code,
                $error_message
            )
        );

        $this->emitWebhookAction('arraysubs_gateway_payment_failed', [
            $subscription_id,
            $renewal_order_id,
            $this->id,
            ['error_code' => $error_code, 'error_message' => $error_message],
        ]);

        return ['success' => true, 'message' => 'Payment failure recorded.'];
    }

    /**
     * Handle payment requiring customer action.
     *
     * Paddle handles SCA/3DS internally — this is a no-op.
     *
     * @param array $context Event context.
     * @return array{success: bool, message: string}
     */
    public function handlePaymentRequiresAction(array $context): array
    {
        // Paddle handles SCA/3DS internally at checkout
        return ['success' => true, 'message' => 'Paddle handles SCA internally.'];
    }

    /**
     * Handle payment method updated.
     *
     * Triggered by subscription.updated webhook (which can include PM changes).
     *
     * @param array $context Event context.
     * @return array{success: bool, message: string}
     */
    public function handlePaymentMethodUpdated(array $context): array
    {
        $subscription_id = $context['subscription_id'] ?? 0;
        $payload         = $context['payload'] ?? [];

        if (0 === $subscription_id) {
            return ['success' => false, 'message' => 'No subscription found for payment method update.'];
        }

        // subscription.updated carries many state changes — check for next_billed_at
        $this->syncNextPaymentDate($subscription_id, $payload);

        // Sync subscription status
        $paddle_status = $payload['status'] ?? '';
        if (! empty($paddle_status)) {
            $this->syncStatusFromPaddle($subscription_id, $paddle_status);
        }

        $this->addSubscriptionPrivateNote(
            $subscription_id,
            __('Paddle subscription updated — state synchronized.', 'arraysubspro')
        );

        return ['success' => true, 'message' => 'Subscription state synced.'];
    }

    /**
     * Handle card expiration notice.
     *
     * Paddle handles card updates internally — no expiring event is sent.
     *
     * @param array $context Event context.
     * @return array{success: bool, message: string}
     */
    public function handleCardExpiring(array $context): array
    {
        return ['success' => true, 'message' => 'Paddle manages card updates internally.'];
    }

    /**
     * Handle external refund created at Paddle.
     *
     * Triggered by adjustment.created webhook with action=refund.
     *
     * @param array $context Event context.
     * @return array{success: bool, message: string}
     */
    public function handleRefundCreated(array $context): array
    {
        $subscription_id = $context['subscription_id'] ?? 0;
        $order_id        = $context['order_id'] ?? 0;
        $payload         = $context['payload'] ?? [];

        if (0 === $subscription_id) {
            return ['success' => false, 'message' => 'No subscription found for refund.'];
        }

        // Check two-way sync guard (skip if plugin-initiated)
        if (TwoWaySyncGuard::wasInitiatedLocally('refund', $subscription_id)) {
            TwoWaySyncGuard::clear('refund', $subscription_id);
            return ['success' => true, 'message' => 'Refund was plugin-initiated — skipping echo.'];
        }

        $action = $payload['action'] ?? '';
        if ('refund' !== $action) {
            return ['success' => true, 'message' => 'Adjustment is not a refund.'];
        }

        $adjustment_id = $payload['id'] ?? '';
        $refund_amount = $payload['totals']['total'] ?? '0';
        $currency_code = $payload['currency_code'] ?? '';

        $this->addSubscriptionPrivateNote(
            $subscription_id,
            sprintf(
                /* translators: 1: adjustment ID, 2: amount, 3: currency */
                __('External refund at Paddle. Adjustment: %1$s, Amount: %2$s %3$s', 'arraysubspro'),
                $adjustment_id,
                $refund_amount,
                $currency_code
            )
        );

        if ($order_id > 0) {
            $order = wc_get_order($order_id);
            if ($order) {
                $order->add_order_note(sprintf(
                    /* translators: 1: adjustment ID, 2: amount, 3: currency */
                    __('External refund from Paddle — Adjustment: %1$s, Amount: %2$s %3$s', 'arraysubspro'),
                    $adjustment_id,
                    $refund_amount,
                    $currency_code
                ));
            }
        }

        $this->emitWebhookAction('arraysubs_gateway_refund_created', [
            $subscription_id,
            $order_id,
            $this->id,
            $payload,
        ]);

        return ['success' => true, 'message' => 'External refund recorded.'];
    }

    /**
     * Handle dispute/chargeback.
     *
     * Paddle is the MoR and handles disputes internally. This is a no-op.
     *
     * @param array $context Event context.
     * @return array{success: bool, message: string}
     */
    public function handleDisputeCreated(array $context): array
    {
        // Paddle handles disputes as the MoR
        return ['success' => true, 'message' => 'Paddle handles disputes as the Merchant of Record.'];
    }

    /**
     * Handle dispute resolved.
     *
     * @param array $context Event context.
     * @return array{success: bool, message: string}
     */
    public function handleDisputeResolved(array $context): array
    {
        return ['success' => true, 'message' => 'Paddle handles dispute resolution as the MoR.'];
    }

    /**
     * Handle external subscription cancellation from Paddle.
     *
     * Triggered by subscription.canceled webhook.
     *
     * @param array $context Event context.
     * @return array{success: bool, message: string}
     */
    public function handleSubscriptionCancelled(array $context): array
    {
        $subscription_id = $context['subscription_id'] ?? 0;
        $payload         = $context['payload'] ?? [];

        if (0 === $subscription_id) {
            return ['success' => false, 'message' => 'No subscription found for cancellation.'];
        }

        // Two-way sync guard (skip if plugin-initiated)
        if (TwoWaySyncGuard::wasInitiatedLocally('cancel', $subscription_id)) {
            TwoWaySyncGuard::clear('cancel', $subscription_id);
            return ['success' => true, 'message' => 'Cancellation was plugin-initiated — skipping echo.'];
        }

        $this->persistGatewayMeta($subscription_id, [
            '_gateway_status'      => 'cancelled',
            '_cancellation_source' => 'gateway',
        ]);

        $this->addSubscriptionPrivateNote(
            $subscription_id,
            __('Subscription cancelled externally from Paddle Dashboard.', 'arraysubspro')
        );

        $this->emitWebhookAction('arraysubs_gateway_subscription_cancelled', [
            $subscription_id,
            $this->id,
            $payload,
        ]);

        return ['success' => true, 'message' => 'External cancellation processed.'];
    }

    // ─── Paddle-Specific Webhook Handlers ────────────────────────────────

    /**
     * Handle subscription.created webhook.
     *
     * Stores the Paddle subscription ID on the local subscription.
     *
     * @param array $context Event context.
     * @return array{success: bool, message: string}
     */
    public function handleSubscriptionCreated(array $context): array
    {
        $subscription_id = $context['subscription_id'] ?? 0;
        $payload         = $context['payload'] ?? [];

        if (0 === $subscription_id) {
            return ['success' => false, 'message' => 'No subscription found for subscription.created.'];
        }

        $paddle_sub_id = $payload['id'] ?? '';

        if (! empty($paddle_sub_id)) {
            update_post_meta($subscription_id, self::META_PADDLE_SUBSCRIPTION_ID, sanitize_text_field($paddle_sub_id));
        }

        // Sync next payment date from Paddle.
        $this->syncNextPaymentDate($subscription_id, $payload);

        $this->addSubscriptionPrivateNote(
            $subscription_id,
            sprintf(
                /* translators: %s: Paddle subscription ID */
                __('Paddle subscription created: %s', 'arraysubspro'),
                $paddle_sub_id
            )
        );

        return ['success' => true, 'message' => 'Paddle subscription ID stored.'];
    }

    /**
     * Handle subscription.paused webhook.
     *
     * @param array $context Event context.
     * @return array{success: bool, message: string}
     */
    public function handleSubscriptionPaused(array $context): array
    {
        $subscription_id = $context['subscription_id'] ?? 0;

        if (0 === $subscription_id) {
            return ['success' => false, 'message' => 'No subscription found for pause.'];
        }

        if (TwoWaySyncGuard::wasInitiatedLocally('pause', $subscription_id)) {
            TwoWaySyncGuard::clear('pause', $subscription_id);
            return ['success' => true, 'message' => 'Pause was plugin-initiated — skipping echo.'];
        }

        $this->persistGatewayMeta($subscription_id, [
            '_gateway_status' => 'paused',
        ]);

        $this->addSubscriptionPrivateNote(
            $subscription_id,
            __('Subscription paused externally from Paddle Dashboard.', 'arraysubspro')
        );

        $this->emitWebhookAction('arraysubs_gateway_subscription_paused', [
            $subscription_id,
            $this->id,
        ]);

        return ['success' => true, 'message' => 'Pause synced from Paddle.'];
    }

    /**
     * Handle subscription.resumed webhook.
     *
     * @param array $context Event context.
     * @return array{success: bool, message: string}
     */
    public function handleSubscriptionResumed(array $context): array
    {
        $subscription_id = $context['subscription_id'] ?? 0;

        if (0 === $subscription_id) {
            return ['success' => false, 'message' => 'No subscription found for resume.'];
        }

        if (TwoWaySyncGuard::wasInitiatedLocally('resume', $subscription_id)) {
            TwoWaySyncGuard::clear('resume', $subscription_id);
            return ['success' => true, 'message' => 'Resume was plugin-initiated — skipping echo.'];
        }

        $this->persistGatewayMeta($subscription_id, [
            '_gateway_status' => 'active',
        ]);

        $this->addSubscriptionPrivateNote(
            $subscription_id,
            __('Subscription resumed externally from Paddle Dashboard.', 'arraysubspro')
        );

        $this->emitWebhookAction('arraysubs_gateway_subscription_resumed', [
            $subscription_id,
            $this->id,
        ]);

        return ['success' => true, 'message' => 'Resume synced from Paddle.'];
    }

    // ─── Private Helpers ─────────────────────────────────────────────────

    /**
     * Ensure the subscription product is synced to Paddle.
     *
     * @param \WC_Order $order The order.
     * @return array{success: bool, price_id: string, message: string}
     */
    private function ensureProductSynced(\WC_Order $order): array
    {
        foreach ($order->get_items() as $item) {
            $product_id = $item->get_variation_id() ?: $item->get_product_id();

            if (! $product_id) {
                continue;
            }

            if (function_exists('arraysubs_is_subscription_product') && ! arraysubs_is_subscription_product($product_id)) {
                continue;
            }

            $product = wc_get_product($product_id);
            if (! $product) {
                continue;
            }

            // Check if already synced
            $price_id = $product->get_meta('_arraysubs_gateway_paddle_price_id');

            if (! empty($price_id)) {
                return [
                    'success'  => true,
                    'price_id' => $price_id,
                    'message'  => '',
                ];
            }

            // Sync now
            $sync_result = $this->getProductSync()->syncProduct($product);

            if (! $sync_result['success']) {
                return [
                    'success'  => false,
                    'price_id' => '',
                    'message'  => $sync_result['message'],
                ];
            }

            return [
                'success'  => true,
                'price_id' => $sync_result['remote_price_id'] ?? '',
                'message'  => '',
            ];
        }

        return [
            'success'  => false,
            'price_id' => '',
            'message'  => __('No subscription product found in order.', 'arraysubspro'),
        ];
    }

    /**
     * Find or create a Paddle customer from order data.
     *
     * @param \WC_Order $order The WooCommerce order.
     * @return string Paddle customer ID (ctm_xxx) or empty on failure.
     */
    private function findOrCreatePaddleCustomer(\WC_Order $order): string
    {
        $email   = $order->get_billing_email();
        $user_id = $order->get_user_id();

        // Check if user already has a Paddle customer stored
        if ($user_id > 0) {
            $stored_customer_id = get_user_meta($user_id, '_arraysubs_paddle_customer_id', true);
            if (! empty($stored_customer_id)) {
                return $stored_customer_id;
            }
        }

        // Search Paddle for existing customer by email
        $search_result = $this->getApi()->listCustomers(['email' => $email]);

        if (! is_wp_error($search_result) && ! empty($search_result) && is_array($search_result)) {
            // Paddle list response: array of customer objects
            $first = $search_result[0] ?? null;
            if ($first && ! empty($first['id'])) {
                $customer_id = $first['id'];
                if ($user_id > 0) {
                    update_user_meta($user_id, '_arraysubs_paddle_customer_id', sanitize_text_field($customer_id));
                }
                return $customer_id;
            }
        }

        // Create new Paddle customer
        $name = trim($order->get_billing_first_name() . ' ' . $order->get_billing_last_name());

        $create_result = $this->getApi()->createCustomer([
            'email' => $email,
            'name'  => ! empty($name) ? $name : $email,
        ]);

        if (is_wp_error($create_result)) {
            $this->log('error', 'Failed to create Paddle customer: ' . $create_result->get_error_message());
            return '';
        }

        $customer_id = $create_result['id'] ?? '';

        if (! empty($customer_id) && $user_id > 0) {
            update_user_meta($user_id, '_arraysubs_paddle_customer_id', sanitize_text_field($customer_id));
        }

        return $customer_id;
    }

    /**
     * Get or create a Paddle product ID for a WC product (for non-subscription one-time items).
     *
     * @param \WC_Product $product The WooCommerce product.
     * @return string Paddle product ID or empty string.
     */
    private function getOrCreatePaddleProductId(\WC_Product $product): string
    {
        $paddle_product_id = $product->get_meta('_arraysubs_gateway_paddle_product_id');

        if (! empty($paddle_product_id)) {
            return $paddle_product_id;
        }

        $result = $this->getApi()->createProduct([
            'name'         => $product->get_name(),
            'tax_category' => 'standard',
        ]);

        if (is_wp_error($result)) {
            return '';
        }

        $paddle_product_id = $result['id'] ?? '';

        if (! empty($paddle_product_id)) {
            $product->update_meta_data('_arraysubs_gateway_paddle_product_id', sanitize_text_field($paddle_product_id));
            $product->save();
        }

        return $paddle_product_id;
    }

    /**
     * Find a local subscription by Paddle subscription ID.
     *
     * @param string $paddle_sub_id Paddle subscription ID (sub_xxx).
     * @return int Subscription post ID or 0.
     */
    private function findSubscriptionByPaddleId(string $paddle_sub_id): int
    {
        $subscriptions = get_posts([
            'post_type'   => 'arraysubs_data',
            'post_status' => 'any',
            'meta_key'    => self::META_PADDLE_SUBSCRIPTION_ID, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
            'meta_value'  => $paddle_sub_id, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
            'fields'      => 'ids',
            'numberposts' => 1,
        ]);

        return ! empty($subscriptions) ? (int) $subscriptions[0] : 0;
    }

    /**
     * Sync the next payment date from Paddle's schedule.
     *
     * @param int   $subscription_id The subscription ID.
     * @param array $payload         Paddle webhook payload.
     * @return void
     */
    private function syncNextPaymentDate(int $subscription_id, array $payload): void
    {
        $next_billed_at = $payload['next_billed_at'] ?? '';

        if (empty($next_billed_at)) {
            return;
        }

        $timestamp = strtotime($next_billed_at);

        if ($timestamp <= 0) {
            return;
        }

        $formatted = gmdate('Y-m-d H:i:s', $timestamp);

        update_post_meta($subscription_id, '_next_payment_date', $formatted);
    }

    /**
     * Sync local subscription status from Paddle status.
     *
     * @param int    $subscription_id The subscription ID.
     * @param string $paddle_status   Paddle subscription status.
     * @return void
     */
    private function syncStatusFromPaddle(int $subscription_id, string $paddle_status): void
    {
        $status_map = [
            'active'   => 'active',
            'paused'   => 'paused',
            'canceled' => 'cancelled',
            'past_due' => 'active', // Grace period handles transitions
            'trialing' => 'active',
        ];

        $local_status = $status_map[$paddle_status] ?? '';

        if (! empty($local_status)) {
            $this->persistGatewayMeta($subscription_id, [
                '_gateway_status' => $local_status,
            ]);
        }
    }

    /**
     * Create a renewal order retroactively (when Paddle charges before our cron).
     *
     * @param int   $subscription_id The subscription ID.
     * @param array $payload         Paddle transaction payload.
     * @return \WC_Order|null The created order or null.
     */
    private function createRetroactiveRenewalOrder(int $subscription_id, array $payload): ?\WC_Order
    {
        $subscription = arraysubs_get_subscription($subscription_id);

        if (! $subscription instanceof \WP_Post) {
            return null;
        }

        $customer_id = (int) get_post_meta($subscription_id, '_customer_id', true);

        if ($customer_id <= 0) {
            return null;
        }

        $order = wc_create_order([
            'customer_id' => $customer_id,
            'status'      => 'pending',
        ]);

        if (is_wp_error($order)) {
            return null;
        }

        // Copy billing details from the canonical initial order when available.
        $original_order_id = PaymentMetaNormalizer::findOrderForSubscription($subscription_id, 'initial');
        $original_order    = $original_order_id > 0 ? wc_get_order($original_order_id) : null;

        if ($original_order) {
            $order->set_address($original_order->get_address('billing'), 'billing');
        }

        // Set order total from Paddle transaction
        $total    = $payload['details']['totals']['total'] ?? '0';
        $currency = $payload['currency_code'] ?? get_woocommerce_currency();

        // Paddle amounts are in smallest unit
        $decimal_total = $this->parseAmountFromPaddle($total, strtoupper($currency));
        $order->set_total($decimal_total);
        $order->set_currency($currency);
        $order->set_payment_method($this->id);
        $order->set_payment_method_title($this->method_title);
        $order->update_meta_data('_is_renewal_order', 'yes');
        $order->update_meta_data('_subscription_id', $subscription_id);
        $order->update_meta_data('_subscription_renewal', $subscription_id);
        $order->update_meta_data('_arraysubs_subscription_id', $subscription_id);

        $order->add_order_note(sprintf(
            /* translators: %d: subscription ID */
            __('Retroactive renewal order created for subscription #%d (Paddle charged before scheduled renewal).', 'arraysubspro'),
            $subscription_id
        ));

        $order->save();

        // Link the order to the subscription
        if (function_exists('update_post_meta')) {
            call_user_func('update_post_meta', $subscription_id, '_pending_renewal_order_id', $order->get_id());
        }

        return $order;
    }

    /**
     * Format an amount for Paddle (string in minor units).
     *
     * @param string $amount   Decimal amount (e.g., "29.99").
     * @param string $currency Currency code.
     * @return string Amount in minor units.
     */
    private function formatAmountForPaddle(string $amount, string $currency): string
    {
        $zero_decimal = ['BIF', 'CLP', 'DJF', 'GNF', 'JPY', 'KMF', 'KRW', 'MGA', 'PYG', 'RWF', 'UGX', 'VND', 'VUV', 'XAF', 'XOF', 'XPF'];

        if (in_array(strtoupper($currency), $zero_decimal, true)) {
            return (string) (int) round((float) $amount);
        }

        return (string) (int) round((float) $amount * 100);
    }

    /**
     * Parse an amount from Paddle minor units to decimal.
     *
     * @param string $amount   Amount in minor units.
     * @param string $currency Currency code.
     * @return string Decimal amount.
     */
    private function parseAmountFromPaddle(string $amount, string $currency): string
    {
        $zero_decimal = ['BIF', 'CLP', 'DJF', 'GNF', 'JPY', 'KMF', 'KRW', 'MGA', 'PYG', 'RWF', 'UGX', 'VND', 'VUV', 'XAF', 'XOF', 'XPF'];

        if (in_array(strtoupper($currency), $zero_decimal, true)) {
            return (string) (int) $amount;
        }

        return number_format((float) $amount / 100, 2, '.', '');
    }

    /**
     * Build a capture failure response.
     *
     * @param string $message Error message.
     * @return array
     */
    private function buildCaptureFailure(string $message): array
    {
        return [
            'success'                  => false,
            'gateway_slug'             => $this->id,
            'remote_customer_id'       => '',
            'remote_payment_method_id' => '',
            'remote_transaction_id'    => '',
            'brand'                    => '',
            'last4'                    => '',
            'payment_method_type'      => '',
            'message'                  => $message,
            'raw'                      => [],
        ];
    }
}
