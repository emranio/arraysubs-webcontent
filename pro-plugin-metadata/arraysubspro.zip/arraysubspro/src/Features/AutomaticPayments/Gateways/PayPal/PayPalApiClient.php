<?php

/**
 * PayPal API Client
 *
 * Thin wrapper around PayPal REST API v2 using WordPress HTTP functions.
 * Handles OAuth2 token management, environment switching, retry logic,
 * and webhook signature verification.
 *
 * Uses the PayPal Subscriptions API for recurring billing agreements.
 *
 * @package ArraySubsPro\Features\AutomaticPayments\Gateways\PayPal
 * @since 1.0.0
 */

namespace ArraySubsPro\Features\AutomaticPayments\Gateways\PayPal;

defined('ABSPATH') || exit;

/**
 * PayPal API Client
 */
class PayPalApiClient
{
    /**
     * PayPal API base URLs.
     *
     * @var array<string, string>
     */
    const API_URLS = [
        'production' => 'https://api-m.paypal.com',
        'sandbox'    => 'https://api-m.sandbox.paypal.com',
    ];

    /**
     * Maximum retry attempts.
     *
     * @var int
     */
    const MAX_RETRIES = 2;

    /**
     * OAuth2 token transient TTL (seconds). Slightly under PayPal's 9h token life.
     *
     * @var int
     */
    const TOKEN_TTL = 28800;

    /**
     * The client ID.
     *
     * @var string
     */
    private string $client_id;

    /**
     * The client secret.
     *
     * @var string
     */
    private string $client_secret;

    /**
     * The environment (sandbox or production).
     *
     * @var string
     */
    private string $environment;

    /**
     * Cached access token for the current request.
     *
     * @var string|null
     */
    private ?string $access_token = null;

    /**
     * WC Logger source.
     *
     * @var string
     */
    private string $log_source = 'arraysubs_paypal';

    /**
     * Constructor.
     *
     * @param string $client_id     PayPal client ID.
     * @param string $client_secret PayPal client secret.
     * @param string $environment   'sandbox' or 'production'.
     */
    public function __construct(string $client_id, string $client_secret, string $environment = 'sandbox')
    {
        $this->client_id     = $client_id;
        $this->client_secret = $client_secret;
        $this->environment   = $environment;
    }

    /**
     * Get the API base URL.
     *
     * @return string
     */
    private function getBaseUrl(): string
    {
        return self::API_URLS[$this->environment] ?? self::API_URLS['sandbox'];
    }

    // ─── OAuth2 Token ────────────────────────────────────────────────────

    /**
     * Get a valid OAuth2 access token.
     *
     * Cached in transient and in-memory for the duration of the request.
     *
     * @return string|\WP_Error Access token or WP_Error.
     */
    public function getAccessToken()
    {
        if (null !== $this->access_token) {
            return $this->access_token;
        }

        $transient_key = 'arraysubs_paypal_token_' . md5($this->client_id . $this->environment);
        $cached        = get_transient($transient_key);

        if (! empty($cached)) {
            $this->access_token = $cached;
            return $this->access_token;
        }

        $response = wp_remote_post($this->getBaseUrl() . '/v1/oauth2/token', [
            'headers' => [
                // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- Required for HTTP Basic auth
                'Authorization' => 'Basic ' . base64_encode($this->client_id . ':' . $this->client_secret),
                'Content-Type'  => 'application/x-www-form-urlencoded',
            ],
            'body'    => ['grant_type' => 'client_credentials'],
            'timeout' => 30,
        ]);

        if (is_wp_error($response)) {
            $this->log('error', 'PayPal OAuth token request failed: ' . $response->get_error_message());
            return $response;
        }

        $status = wp_remote_retrieve_response_code($response);
        $body   = json_decode(wp_remote_retrieve_body($response), true);

        if (200 !== $status || empty($body['access_token'])) {
            $error = $body['error_description'] ?? 'Unknown OAuth error';
            $this->log('error', 'PayPal OAuth failed: ' . $error);
            return new \WP_Error('paypal_auth_error', $error);
        }

        $this->access_token = $body['access_token'];
        $ttl                = min((int) ($body['expires_in'] ?? self::TOKEN_TTL) - 300, self::TOKEN_TTL);

        set_transient($transient_key, $this->access_token, max($ttl, 60));

        return $this->access_token;
    }

    // ─── Products ────────────────────────────────────────────────────────

    /**
     * Create a PayPal Catalog Product.
     *
     * @param array $params Product data.
     * @return array|\WP_Error
     */
    public function createProduct(array $params)
    {
        return $this->request('POST', '/v1/catalogs/products', $params);
    }

    // ─── Billing Plans ───────────────────────────────────────────────────

    /**
     * Create a PayPal Billing Plan.
     *
     * @param array $params Plan data.
     * @return array|\WP_Error
     */
    public function createPlan(array $params)
    {
        return $this->request('POST', '/v1/billing/plans', $params);
    }

    /**
     * Get a PayPal Billing Plan.
     *
     * @param string $plan_id PayPal Plan ID (P-xxx).
     * @return array|\WP_Error
     */
    public function getPlan(string $plan_id)
    {
        return $this->request('GET', "/v1/billing/plans/{$plan_id}");
    }

    /**
     * Deactivate a PayPal Billing Plan.
     *
     * @param string $plan_id PayPal Plan ID.
     * @return array|\WP_Error
     */
    public function deactivatePlan(string $plan_id)
    {
        return $this->request('POST', "/v1/billing/plans/{$plan_id}/deactivate");
    }

    // ─── Subscriptions ───────────────────────────────────────────────────

    /**
     * Create a PayPal Subscription.
     *
     * @param array $params Subscription data.
     * @return array|\WP_Error
     */
    public function createSubscription(array $params)
    {
        return $this->request('POST', '/v1/billing/subscriptions', $params);
    }

    /**
     * Get a PayPal Subscription.
     *
     * @param string $subscription_id PayPal Subscription ID (I-xxx).
     * @return array|\WP_Error
     */
    public function getSubscription(string $subscription_id)
    {
        return $this->request('GET', "/v1/billing/subscriptions/{$subscription_id}");
    }

    /**
     * Cancel a PayPal Subscription.
     *
     * @param string $subscription_id PayPal Subscription ID.
     * @param string $reason          Cancellation reason.
     * @return array|\WP_Error
     */
    public function cancelSubscription(string $subscription_id, string $reason = '')
    {
        return $this->request('POST', "/v1/billing/subscriptions/{$subscription_id}/cancel", [
            'reason' => ! empty($reason) ? $reason : 'Cancelled by merchant',
        ]);
    }

    // ─── Captures & Refunds ──────────────────────────────────────────────

    /**
     * Capture an authorized payment.
     *
     * @param string $authorization_id PayPal authorization ID.
     * @param array  $params           Capture params.
     * @return array|\WP_Error
     */
    public function capturePayment(string $authorization_id, array $params = [])
    {
        return $this->request('POST', "/v2/payments/authorizations/{$authorization_id}/capture", $params);
    }

    /**
     * Refund a captured payment.
     *
     * @param string $capture_id PayPal capture ID.
     * @param array  $params     Refund params (amount, note_to_payer).
     * @return array|\WP_Error
     */
    public function refundCapture(string $capture_id, array $params = [])
    {
        return $this->request('POST', "/v2/payments/captures/{$capture_id}/refund", $params);
    }

    /**
     * Get capture details.
     *
     * @param string $capture_id PayPal capture ID.
     * @return array|\WP_Error
     */
    public function getCapture(string $capture_id)
    {
        return $this->request('GET', "/v2/payments/captures/{$capture_id}");
    }

    // ─── Webhook Verification ────────────────────────────────────────────

    /**
     * Verify a PayPal webhook signature via PayPal API.
     *
     * PayPal uses their own API endpoint for webhook verification.
     *
     * @param string $webhook_id  PayPal Webhook ID.
     * @param array  $headers     Request headers (must include PAYPAL-TRANSMISSION-*).
     * @param string $raw_body    Raw request body.
     * @return array{valid: bool, error: string}
     */
    public function verifyWebhookSignature(string $webhook_id, array $headers, string $raw_body): array
    {
        $decoded_body = json_decode($raw_body, true);

        if (! is_array($decoded_body)) {
            return ['valid' => false, 'error' => 'Invalid webhook JSON payload'];
        }

        $verification_body = [
            'auth_algo'         => $headers['PAYPAL-AUTH-ALGO'] ?? '',
            'cert_url'          => $headers['PAYPAL-CERT-URL'] ?? '',
            'transmission_id'   => $headers['PAYPAL-TRANSMISSION-ID'] ?? '',
            'transmission_sig'  => $headers['PAYPAL-TRANSMISSION-SIG'] ?? '',
            'transmission_time' => $headers['PAYPAL-TRANSMISSION-TIME'] ?? '',
            'webhook_id'        => $webhook_id,
            'webhook_event'     => $decoded_body,
        ];

        $result = $this->request('POST', '/v1/notifications/verify-webhook-signature', $verification_body);

        if (is_wp_error($result)) {
            return ['valid' => false, 'error' => $result->get_error_message()];
        }

        $status = $result['verification_status'] ?? '';

        if ('SUCCESS' === $status) {
            return ['valid' => true, 'error' => ''];
        }

        return ['valid' => false, 'error' => 'Verification status: ' . $status];
    }

    // ─── Internal HTTP Methods ───────────────────────────────────────────

    /**
     * Make an authenticated HTTP request to the PayPal API.
     *
     * @param string $method HTTP method.
     * @param string $path   API path.
     * @param array  $params Request parameters.
     * @param int    $retry  Current retry attempt.
     * @return array|\WP_Error
     */
    private function request(string $method, string $path, array $params = [], int $retry = 0)
    {
        $token = $this->getAccessToken();

        if (is_wp_error($token)) {
            return $token;
        }

        $url = $this->getBaseUrl() . $path;

        $args = [
            'method'  => $method,
            'headers' => [
                'Authorization' => 'Bearer ' . $token,
                'Content-Type'  => 'application/json',
            ],
            'timeout' => 30,
        ];

        if ('GET' === $method && ! empty($params)) {
            $url = add_query_arg($params, $url);
        } elseif (! empty($params)) {
            $args['body'] = wp_json_encode($params);

            if ('POST' === $method) {
                $args['headers']['PayPal-Request-Id'] = $this->buildRequestId($path, $params);
            }
        }

        $response = wp_remote_request($url, $args);

        if (is_wp_error($response)) {
            if ($retry < self::MAX_RETRIES) {
                usleep(500000 * ($retry + 1));
                return $this->request($method, $path, $params, $retry + 1);
            }
            $this->log('error', 'PayPal API request failed: ' . $response->get_error_message());
            return $response;
        }

        $status_code = wp_remote_retrieve_response_code($response);
        $body        = json_decode(wp_remote_retrieve_body($response), true);

        // 204 No Content — success with no body (common for cancel/deactivate)
        if (204 === $status_code) {
            return [];
        }

        // Rate limited — retry
        if (429 === $status_code && $retry < self::MAX_RETRIES) {
            $retry_after = (int) wp_remote_retrieve_header($response, 'Retry-After');
            sleep(max($retry_after, 1));
            return $this->request($method, $path, $params, $retry + 1);
        }

        // Token expired — refresh and retry once
        if (401 === $status_code && 0 === $retry) {
            $this->access_token = null;
            $transient_key      = 'arraysubs_paypal_token_' . md5($this->client_id . $this->environment);
            delete_transient($transient_key);
            return $this->request($method, $path, $params, $retry + 1);
        }

        if ($status_code >= 400) {
            $error_name    = $body['name'] ?? 'UNKNOWN_ERROR';
            $error_message = $body['message'] ?? 'Unknown PayPal API error';
            $error_details = $body['details'] ?? [];

            $detail_str = '';
            if (! empty($error_details) && is_array($error_details)) {
                $first_detail = $error_details[0] ?? [];
                $detail_str   = $first_detail['description'] ?? ($first_detail['issue'] ?? '');
            }

            $full_error = $detail_str ? "{$error_message} — {$detail_str}" : $error_message;

            $this->log('error', sprintf(
                'PayPal API error [%d]: %s (name: %s, path: %s)',
                $status_code,
                $full_error,
                $error_name,
                $path
            ));

            return new \WP_Error(
                'paypal_api_error',
                $full_error,
                [
                    'status_code' => $status_code,
                    'name'        => $error_name,
                    'body'        => $body,
                ]
            );
        }

        return $body ?? [];
    }

    /**
     * Build a stable request identifier for PayPal POST idempotency.
     *
     * @param string $path   API path.
     * @param array  $params Request parameters.
     * @return string
     */
    private function buildRequestId(string $path, array $params): string
    {
        return substr(hash('sha256', $path . '|' . json_encode($params)), 0, 108);
    }

    /**
     * Log a message via WC logger.
     *
     * @param string $level   Log level.
     * @param string $message Log message.
     * @return void
     */
    private function log(string $level, string $message): void
    {
        if (function_exists('wc_get_logger')) {
            wc_get_logger()->log($level, $message, ['source' => $this->log_source]);
        }
    }
}
