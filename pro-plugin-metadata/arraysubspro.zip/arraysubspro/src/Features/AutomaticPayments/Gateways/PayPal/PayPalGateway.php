<?php

/**
 * PayPal Gateway
 *
 * Concrete implementation of AbstractArraySubsGateway for PayPal.
 * Uses PayPal Subscriptions API for recurring billing agreements.
 *
 * Key differences from Stripe/Paddle:
 * - PayPal manages the billing schedule (no off-session charges)
 * - Uses PayPal Billing Plans + Subscriptions API
 * - Product + Plan sync required before checkout
 * - Checkout via PayPal Smart Payment Buttons (JS SDK overlay)
 * - No native pause/resume support
 * - No card expiry notices (tied to PayPal account, not cards)
 * - Payment method update requires new Billing Agreement
 * - Disputes handled via PayPal Resolution Center
 * - Webhook verification via PayPal API endpoint (not HMAC)
 *
 * Settings: WooCommerce > Settings > Payments > PayPal (ArraySubs)
 * Checkout: PayPal Smart Payment Buttons (JS SDK)
 * Renewals: PayPal-managed (PAYMENT.SALE.COMPLETED webhooks)
 * Trials: PayPal Billing Cycle with tenure_type=TRIAL
 *
 * @package ArraySubsPro\Features\AutomaticPayments\Gateways\PayPal
 * @since 1.0.0
 */

namespace ArraySubsPro\Features\AutomaticPayments\Gateways\PayPal;

defined('ABSPATH') || exit;

use ArraySubsPro\Features\AutomaticPayments\Abstracts\AbstractArraySubsGateway;
use ArraySubsPro\Features\AutomaticPayments\Services\PaymentMetaNormalizer;
use ArraySubsPro\Features\AutomaticPayments\Services\TwoWaySyncGuard;

/**
 * PayPal Gateway
 */
class PayPalGateway extends AbstractArraySubsGateway
{
    /**
     * PayPal API client instance.
     *
     * @var PayPalApiClient|null
     */
    private ?PayPalApiClient $api = null;

    /**
     * PayPal subscription ID meta key.
     *
     * @var string
     */
    const META_PAYPAL_SUBSCRIPTION_ID = '_gateway_paypal_subscription_id';

    /**
     * PayPal plan ID meta key.
     *
     * @var string
     */
    const META_PAYPAL_PLAN_ID = '_gateway_paypal_plan_id';

    /**
     * PayPal product ID meta key (on WC product).
     *
     * @var string
     */
    const META_PAYPAL_PRODUCT_ID = '_arraysubs_gateway_paypal_product_id';

    /**
     * Constructor.
     */
    public function __construct()
    {
        $this->id                 = 'arraysubs_paypal';
        $this->method_title       = __('PayPal (ArraySubs)', 'arraysubspro');
        $this->method_description = __('Accept payments via PayPal for subscriptions managed by ArraySubs.', 'arraysubspro');
        $this->has_fields         = false;
        $this->icon               = '';

        $this->supports = [
            'products',
            'refunds',
            'subscriptions',
        ];

        $this->subscriptionCapabilities = [
            'automatic_payments'        => true,
            'trials'                    => false,
            'pause'                     => false,
            'resume'                    => false,
            'retention_amount_update'   => false,
            'product_sync'              => false,
            'payment_method_update'     => true,
            'card_auto_update'          => false,
            'card_expiry_notice'        => false,
            'disputes'                  => true,
            'sca'                       => false,
            'refunds'                   => true,
            'hosted_payment_page'       => false,
            'customer_portal'           => false,
            'mixed_cart'                => false,
            'multiple_subscriptions'    => false,
            'different_billing_cycles'  => false,
            'supports_sync'             => true,
        ];

        $this->eventMap = [
            'BILLING.SUBSCRIPTION.ACTIVATED'      => self::EVENT_PAYMENT_SUCCEEDED,
            'BILLING.SUBSCRIPTION.CANCELLED'      => self::EVENT_SUBSCRIPTION_CANCELLED,
            'BILLING.SUBSCRIPTION.SUSPENDED'      => self::EVENT_PAYMENT_FAILED,
            'BILLING.SUBSCRIPTION.PAYMENT.FAILED' => self::EVENT_PAYMENT_FAILED,
            'PAYMENT.SALE.COMPLETED'              => self::EVENT_PAYMENT_SUCCEEDED,
            'PAYMENT.SALE.REFUNDED'               => self::EVENT_REFUND_CREATED,
            'CUSTOMER.DISPUTE.CREATED'            => self::EVENT_DISPUTE_CREATED,
            'CUSTOMER.DISPUTE.RESOLVED'           => self::EVENT_DISPUTE_RESOLVED,
        ];

        $this->init_form_fields();
        $this->init_settings();

        $this->title       = $this->get_option('title', __('PayPal', 'arraysubspro'));
        $this->description = $this->get_option('description', __('Pay securely via PayPal.', 'arraysubspro'));
        $this->enabled     = $this->get_option('enabled', 'no');

        add_action('woocommerce_update_options_payment_gateways_' . $this->id, [$this, 'process_admin_options']);
    }

    // ─── Settings ────────────────────────────────────────────────────────

    /**
     * Define gateway settings fields.
     *
     * @return void
     */
    public function init_form_fields(): void
    {
        parent::init_form_fields();

        $webhook_url = rest_url('arraysubs/v1/webhooks/' . $this->getGatewaySlug());

        $this->form_fields['test_mode']['label'] = __('Enable PayPal Sandbox mode', 'arraysubspro');

        $this->form_fields = array_merge($this->form_fields, [
            'client_id'     => [
                'title'       => __('Client ID', 'arraysubspro'),
                'type'        => 'text',
                'description' => __('Get your credentials from the PayPal Developer Dashboard.', 'arraysubspro'),
                'default'     => '',
            ],
            'client_secret' => [
                'title'       => __('Client Secret', 'arraysubspro'),
                'type'        => 'password',
                'description' => __('Your PayPal REST API app secret.', 'arraysubspro'),
                'default'     => '',
            ],
            'webhook_id'    => [
                'title'       => __('Webhook ID', 'arraysubspro'),
                'type'        => 'text',
                'description' => __('The ID of the webhook configured in your PayPal Developer Dashboard.', 'arraysubspro'),
                'default'     => '',
            ],
            'webhook_url'   => [
                'title'       => __('Webhook URL', 'arraysubspro'),
                'type'        => 'title',
                'description' => sprintf(
                    /* translators: %s: webhook endpoint URL */
                    __('Configure this URL as a webhook in your PayPal Developer Dashboard: %s', 'arraysubspro'),
                    '<code>' . esc_url($webhook_url) . '</code>'
                ),
            ],
            'checkout_restrictions' => [
                'title'       => __('Checkout Restrictions', 'arraysubspro'),
                'type'        => 'title',
                'description' => __('PayPal supports only one subscription per checkout with no mixed items or different billing cycles. Use the arraysubs_arraysubs_paypal_allow_* filters to customize.', 'arraysubspro'),
            ],
        ]);
    }

    // ─── API Client ──────────────────────────────────────────────────────

    /**
     * Get or create the API client instance.
     *
     * @return PayPalApiClient
     */
    private function getApi(): PayPalApiClient
    {
        if (null === $this->api) {
            $environment = $this->isTestMode() ? 'sandbox' : 'production';

            $this->api = new PayPalApiClient(
                $this->get_option('client_id', ''),
                $this->get_option('client_secret', ''),
                $environment
            );
        }

        return $this->api;
    }

    /**
     * Check if sandbox mode is enabled.
     *
     * @return bool
     */
    public function isTestMode(): bool
    {
        return 'yes' === $this->get_option('test_mode', 'yes');
    }

    // ─── Credentials ─────────────────────────────────────────────────────

    /**
     * Check if required API credentials are configured.
     *
     * @return bool
     */
    protected function hasRequiredCredentials(): bool
    {
        $client_id     = $this->get_option('client_id', '');
        $client_secret = $this->get_option('client_secret', '');

        return ! empty($client_id) && ! empty($client_secret);
    }

    // ─── Checkout ────────────────────────────────────────────────────────

    /**
     * Process subscription payment via PayPal.
     *
     * Creates a PayPal Product + Plan + Subscription, then returns
     * data for the frontend to render the PayPal Smart Payment Buttons.
     *
     * @param \WC_Order $order The order.
     * @return array WC process_payment result.
     */
    protected function processSubscriptionPayment(\WC_Order $order): array
    {
        $subscription_ids = $this->getSubscriptionsForOrder($order);

        if (empty($subscription_ids)) {
            wc_add_notice(__('No subscription found for this order.', 'arraysubspro'), 'error');
            return ['result' => 'failure'];
        }

        $subscription_id = $subscription_ids[0];
        $subscription    = arraysubs_get_subscription($subscription_id);

        if (! $subscription instanceof \WP_Post) {
            wc_add_notice(__('Invalid subscription.', 'arraysubspro'), 'error');
            return ['result' => 'failure'];
        }

        // Create PayPal Plan for this subscription product
        $plan_result = $this->createPayPalPlan($order, $subscription);

        if (is_wp_error($plan_result)) {
            $this->log('error', 'PayPal plan creation failed: ' . $plan_result->get_error_message());
            wc_add_notice(__('Payment setup failed. Please try again.', 'arraysubspro'), 'error');
            return ['result' => 'failure'];
        }

        $plan_id = $plan_result['id'];

        // Store plan ID on subscription
        update_post_meta($subscription_id, self::META_PAYPAL_PLAN_ID, sanitize_text_field($plan_id));

        // Create PayPal Subscription
        $return_url  = $this->get_return_url($order);
        $cancel_url  = wc_get_checkout_url();
        $custom_data = wp_json_encode([
            'order_id'        => $order->get_id(),
            'subscription_id' => $subscription_id,
        ]);

        $paypal_sub = $this->getApi()->createSubscription([
            'plan_id'             => $plan_id,
            'custom_id'           => $custom_data,
            'application_context' => [
                'brand_name'          => get_bloginfo('name'),
                'return_url'          => $return_url,
                'cancel_url'          => $cancel_url,
                'shipping_preference' => 'NO_SHIPPING',
                'user_action'         => 'SUBSCRIBE_NOW',
            ],
        ]);

        if (is_wp_error($paypal_sub)) {
            $this->log('error', 'PayPal subscription creation failed: ' . $paypal_sub->get_error_message());
            wc_add_notice(__('Payment setup failed. Please try again.', 'arraysubspro'), 'error');
            return ['result' => 'failure'];
        }

        $paypal_subscription_id = $paypal_sub['id'] ?? '';
        $approve_url            = '';

        // Find the approval link
        foreach (($paypal_sub['links'] ?? []) as $link) {
            if ('approve' === ($link['rel'] ?? '')) {
                $approve_url = $link['href'] ?? '';
                break;
            }
        }

        if (empty($approve_url) || empty($paypal_subscription_id)) {
            $this->log('error', 'PayPal subscription response missing approval link or ID');
            wc_add_notice(__('Payment setup failed. Please try again.', 'arraysubspro'), 'error');
            return ['result' => 'failure'];
        }

        // Store PayPal subscription ID on our subscription
        update_post_meta($subscription_id, self::META_PAYPAL_SUBSCRIPTION_ID, sanitize_text_field($paypal_subscription_id));

        // Store session reference on order for later reconciliation
        $order->update_meta_data('_gateway_session_id', $paypal_subscription_id);
        $order->save();

        $this->log('info', sprintf(
            'PayPal subscription %s created for order %d, subscription %d',
            $paypal_subscription_id,
            $order->get_id(),
            $subscription_id
        ));

        // Redirect customer to PayPal for approval
        return [
            'result'   => 'success',
            'redirect' => $approve_url,
        ];
    }

    /**
     * Process standard (non-subscription) payment.
     *
     * Non-subscription orders are not supported by this gateway.
     * Uses standard WC order flow — redirect to PayPal for one-time payment.
     *
     * @param \WC_Order $order The order.
     * @return array WC process_payment result.
     */
    protected function processStandardPayment(\WC_Order $order): array
    {
        wc_add_notice(__('PayPal (ArraySubs) only supports subscription products.', 'arraysubspro'), 'error');
        return ['result' => 'failure'];
    }

    /**
     * Process a refund via PayPal.
     *
     * @param int        $order_id The WC order ID.
     * @param float|null $amount   Refund amount (null for full).
     * @param string     $reason   Refund reason.
     * @return bool|\WP_Error
     */
    protected function processGatewayRefund(int $order_id, ?float $amount, string $reason)
    {
        $order = wc_get_order($order_id);

        if (! $order) {
            return new \WP_Error('invalid_order', __('Order not found.', 'arraysubspro'));
        }

        $capture_id = $order->get_transaction_id();

        if (empty($capture_id)) {
            return new \WP_Error('no_transaction', __('No PayPal transaction ID found for this order.', 'arraysubspro'));
        }

        // Mark local refund initiation for echo-loop prevention
        $subscription_ids = $this->getSubscriptionsForOrder($order);
        foreach ($subscription_ids as $sub_id) {
            TwoWaySyncGuard::markInitiated('refund', $sub_id);
        }

        $params = [];

        if (null !== $amount) {
            $params['amount'] = [
                'value'         => number_format($amount, 2, '.', ''),
                'currency_code' => $order->get_currency(),
            ];
        }

        if (! empty($reason)) {
            $params['note_to_payer'] = substr($reason, 0, 255);
        }

        $result = $this->getApi()->refundCapture($capture_id, $params);

        if (is_wp_error($result)) {
            foreach ($subscription_ids as $sub_id) {
                TwoWaySyncGuard::clear('refund', $sub_id);
            }
            return $result;
        }

        $this->log('info', sprintf(
            'PayPal refund %s created for order %d (amount: %s)',
            $result['id'] ?? 'unknown',
            $order_id,
            $amount ?? 'full'
        ));

        return true;
    }

    // ─── Recurring Payment ───────────────────────────────────────────────

    /**
     * Process an automatic renewal payment.
     *
     * PayPal manages billing via its Subscriptions API. We do not initiate
     * charges — PayPal fires PAYMENT.SALE.COMPLETED webhooks. This method
     * acknowledges the pending state and waits for the webhook.
     *
     * @param int       $subscription_id The subscription post ID.
     * @param \WC_Order $order           The renewal order.
     * @return array{success: bool, transaction_id: string, message: string, raw: array}
     */
    public function processRenewalPayment(int $subscription_id, \WC_Order $order): array
    {
        $paypal_sub_id = get_post_meta($subscription_id, self::META_PAYPAL_SUBSCRIPTION_ID, true);

        if (empty($paypal_sub_id)) {
            return [
                'success'        => false,
                'transaction_id' => '',
                'message'        => 'No PayPal subscription ID found — cannot process renewal.',
                'raw'            => [],
            ];
        }

        $this->addSubscriptionPrivateNote($subscription_id, sprintf(
            /* translators: %s: PayPal subscription ID */
            __('Awaiting PayPal automatic renewal payment for subscription %s.', 'arraysubspro'),
            $paypal_sub_id
        ));

        return [
            'success'        => true,
            'transaction_id' => '',
            'message'        => 'PayPal manages billing. Awaiting PAYMENT.SALE.COMPLETED webhook.',
            'raw'            => ['paypal_subscription_id' => $paypal_sub_id],
        ];
    }

    // ─── Trial Setup ─────────────────────────────────────────────────────

    /**
     * Set up payment method for free trial.
     *
     * PayPal does not reliably support $0 authorization. Trials are handled
     * via the Billing Plan's trial billing cycle when creating the subscription.
     * This method returns failure since direct trial setup is not supported.
     *
     * @param \WC_Order $order           The order.
     * @param int       $subscription_id The subscription ID.
     * @param array     $trial_data      Trial configuration.
     * @return array{success: bool, remote_customer_id: string, remote_payment_method_id: string, message: string, raw: array}
     */
    public function setupTrialPaymentMethod(\WC_Order $order, int $subscription_id, array $trial_data): array
    {
        return [
            'success'                   => false,
            'remote_customer_id'        => '',
            'remote_payment_method_id'  => '',
            'message'                   => 'PayPal does not support $0 trial authorization. Trials are configured via PayPal Billing Plan.',
            'raw'                       => [],
        ];
    }

    // ─── Payment Context Capture ─────────────────────────────────────────

    /**
     * Capture payment context after successful PayPal approval.
     *
     * @param \WC_Order $order           The paid order.
     * @param int       $subscription_id The subscription ID.
     * @return array{success: bool, gateway_slug: string, remote_customer_id: string, remote_payment_method_id: string, remote_transaction_id: string, brand: string, last4: string, payment_method_type: string, message: string, raw: array}
     */
    public function capturePaymentContext(\WC_Order $order, int $subscription_id): array
    {
        $paypal_sub_id = get_post_meta($subscription_id, self::META_PAYPAL_SUBSCRIPTION_ID, true);

        if (empty($paypal_sub_id)) {
            return $this->buildCaptureFailure('No PayPal subscription ID found on subscription.');
        }

        // Retrieve the PayPal subscription to get subscriber details
        $paypal_sub = $this->getApi()->getSubscription($paypal_sub_id);

        if (is_wp_error($paypal_sub)) {
            return $this->buildCaptureFailure('Failed to retrieve PayPal subscription: ' . $paypal_sub->get_error_message());
        }

        $subscriber   = $paypal_sub['subscriber'] ?? [];
        $email        = $subscriber['email_address'] ?? '';
        $payer_id     = $subscriber['payer_id'] ?? '';
        $customer_id  = ! empty($payer_id) ? $payer_id : $email;
        $status       = $paypal_sub['status'] ?? '';

        // Extract payment source info
        $payment_source = $subscriber['payment_source'] ?? [];
        $card_info      = $payment_source['card'] ?? [];
        $brand          = $card_info['brand'] ?? '';
        $last4          = $card_info['last_digits'] ?? '';
        $pm_type        = ! empty($card_info) ? 'card' : 'paypal';

        if (empty($brand) && 'paypal' === $pm_type) {
            $brand = 'PayPal';
        }

        // Store gateway meta
        $this->persistGatewayMeta($subscription_id, [
            '_payment_gateway'           => $this->id,
            '_gateway_customer_id'       => $customer_id,
            '_gateway_payment_method_id' => $paypal_sub_id,
            '_gateway_status'            => 'ACTIVE' === $status ? 'active' : 'inactive',
            '_payment_method_brand'      => $brand,
            '_payment_method_last4'      => $last4,
            '_payment_method_type'       => $pm_type,
        ]);

        return [
            'success'                   => true,
            'gateway_slug'              => $this->id,
            'remote_customer_id'        => $customer_id,
            'remote_payment_method_id'  => $paypal_sub_id,
            'remote_transaction_id'     => '',
            'brand'                     => $brand,
            'last4'                     => $last4,
            'payment_method_type'       => $pm_type,
            'message'                   => 'PayPal payment context captured.',
            'raw'                       => $paypal_sub,
        ];
    }

    // ─── Cancellation ────────────────────────────────────────────────────

    /**
     * Cancel the remote PayPal subscription.
     *
     * @param int   $subscription_id The subscription ID.
     * @param array $context         Cancellation context.
     * @return array{success: bool, message: string, raw: array}
     */
    public function cancelRemoteBillingContext(int $subscription_id, array $context = []): array
    {
        $paypal_sub_id = get_post_meta($subscription_id, self::META_PAYPAL_SUBSCRIPTION_ID, true);

        if (empty($paypal_sub_id)) {
            return ['success' => true, 'message' => 'No PayPal subscription to cancel.', 'raw' => []];
        }

        TwoWaySyncGuard::markInitiated('cancel', $subscription_id);

        $reason = $context['reason'] ?? __('Cancelled by merchant.', 'arraysubspro');
        $result = $this->getApi()->cancelSubscription($paypal_sub_id, $reason);

        if (is_wp_error($result)) {
            TwoWaySyncGuard::clear('cancel', $subscription_id);
            return ['success' => false, 'message' => $result->get_error_message(), 'raw' => []];
        }

        $this->persistGatewayMeta($subscription_id, ['_gateway_status' => 'inactive']);

        $this->addSubscriptionPrivateNote($subscription_id, sprintf(
            /* translators: %s: PayPal subscription ID */
            __('PayPal subscription %s cancelled.', 'arraysubspro'),
            $paypal_sub_id
        ));

        return ['success' => true, 'message' => 'PayPal subscription cancelled.', 'raw' => []];
    }

    // ─── Payment Method Display ──────────────────────────────────────────

    /**
     * Format stored payment method for UI display.
     *
     * @param int $subscription_id The subscription ID.
     * @return array{gateway: string, title: string, brand: string, last4: string, expiry: string, is_expired: bool, can_update: bool, update_url: string, update_type: string}
     */
    /**
     * Pull authoritative subscription state from PayPal.
     *
     * @param int $subscription_id Subscription ID.
     * @return array
     */
    public function syncFromGateway(int $subscription_id): array
    {
        $paypal_sub_id = (string) get_post_meta($subscription_id, self::META_PAYPAL_SUBSCRIPTION_ID, true);

        if ('' === $paypal_sub_id) {
            return [
                'success'           => false,
                'message'           => __('No PayPal subscription linked.', 'arraysubspro'),
                'gateway_status'    => '',
                'next_payment_date' => '',
                'payment_method'    => [],
                'recent_charges'    => [],
                'raw'               => [],
            ];
        }

        $sub = $this->getApi()->getSubscription($paypal_sub_id);
        if (is_wp_error($sub)) {
            return [
                'success'           => false,
                'message'           => $sub->get_error_message(),
                'gateway_status'    => '',
                'next_payment_date' => '',
                'payment_method'    => [],
                'recent_charges'    => [],
                'raw'               => [],
            ];
        }

        $status            = strtoupper((string) ($sub['status'] ?? ''));
        $next_billing_time = (string) ($sub['billing_info']['next_billing_time'] ?? '');
        $next_payment_date = '';
        if ('' !== $next_billing_time) {
            $ts = strtotime($next_billing_time);
            if ($ts) {
                $next_payment_date = gmdate('Y-m-d H:i:s', $ts);
            }
        }

        $gateway_status = 'inactive';
        if ('ACTIVE' === $status) {
            $gateway_status = 'active';
        } elseif ('SUSPENDED' === $status) {
            $gateway_status = 'paused';
        } elseif ('CANCELLED' === $status || 'EXPIRED' === $status) {
            $gateway_status = 'inactive';
        }

        return [
            'success'           => true,
            'message'           => __('PayPal state retrieved.', 'arraysubspro'),
            'gateway_status'    => $gateway_status,
            'next_payment_date' => $next_payment_date,
            'payment_method'    => [],
            'recent_charges'    => [],
            'raw'               => $sub,
        ];
    }

    public function formatPaymentMethodForDisplay(int $subscription_id): array
    {
        $brand   = get_post_meta($subscription_id, '_payment_method_brand', true);
        $last4   = get_post_meta($subscription_id, '_payment_method_last4', true);
        $pm_type = get_post_meta($subscription_id, '_payment_method_type', true);

        $title = 'PayPal';
        if (! empty($brand) && ! empty($last4) && 'paypal' !== $pm_type) {
            $title = sprintf('%s ****%s', ucfirst($brand), $last4);
        }

        return [
            'gateway'     => $this->id,
            'title'       => $title,
            'brand'       => ! empty($brand) ? $brand : 'PayPal',
            'last4'       => $last4,
            'expiry'      => '',
            'is_expired'  => false,
            'can_update'  => true,
            'update_url'  => '',
            'update_type' => 'reauthorize',
        ];
    }

    // ─── Payment Method Update ───────────────────────────────────────────

    /**
     * Get payment method update mechanism.
     *
     * PayPal requires a new Billing Agreement approval. The existing PayPal
     * subscription must be cancelled and a new one created, which is
     * a disruptive process.
     *
     * @param int   $subscription_id The subscription ID.
     * @param array $context         Update context.
     * @return array{success: bool, type: string, url: string, message: string, raw: array}
     */
    public function getPaymentMethodUpdateMechanism(int $subscription_id, array $context = []): array
    {
        return [
            'success' => true,
            'type'    => 'reauthorize',
            'url'     => '',
            'message' => __('To update your PayPal payment method, a new PayPal authorization is required. Your current subscription will be migrated to the new payment source.', 'arraysubspro'),
            'raw'     => [],
        ];
    }

    // ─── Webhook Verification ────────────────────────────────────────────

    /**
     * Verify the PayPal webhook signature via PayPal API.
     *
     * @param \WP_REST_Request $request Incoming webhook request.
     * @return bool
     */
    public function verifyWebhookSignature(\WP_REST_Request $request): bool
    {
        $webhook_id = $this->get_option('webhook_id', '');

        if (empty($webhook_id)) {
            $this->log('warning', 'PayPal webhook ID not configured — skipping verification.');
            return false;
        }

        $headers = [
            'PAYPAL-AUTH-ALGO'         => $request->get_header('paypal-auth-algo') ?? '',
            'PAYPAL-CERT-URL'          => $request->get_header('paypal-cert-url') ?? '',
            'PAYPAL-TRANSMISSION-ID'   => $request->get_header('paypal-transmission-id') ?? '',
            'PAYPAL-TRANSMISSION-SIG'  => $request->get_header('paypal-transmission-sig') ?? '',
            'PAYPAL-TRANSMISSION-TIME' => $request->get_header('paypal-transmission-time') ?? '',
        ];

        $raw_body = $request->get_body();

        $verification = $this->getApi()->verifyWebhookSignature($webhook_id, $headers, $raw_body);

        if (! $verification['valid']) {
            $this->log('error', 'PayPal webhook verification failed: ' . $verification['error']);
            return false;
        }

        return true;
    }

    // ─── Webhook Parsing ─────────────────────────────────────────────────

    /**
     * Parse raw PayPal webhook payload into normalized structure.
     *
     * @param \WP_REST_Request $request The incoming request.
     * @return array{success: bool, gateway_event_id: string, gateway_event_type: string, normalized_event_type: string, occurred_at: int, payload: array, raw_body: string}
     */
    public function parseWebhook(\WP_REST_Request $request): array
    {
        $raw_body = $request->get_body();
        $data     = json_decode($raw_body, true);

        if (empty($data) || ! is_array($data)) {
            return [
                'success'              => false,
                'gateway_event_id'     => '',
                'gateway_event_type'   => '',
                'normalized_event_type' => '',
                'occurred_at'          => 0,
                'payload'              => [],
                'raw_body'             => $raw_body,
            ];
        }

        $event_type = $data['event_type'] ?? '';
        $event_id   = $data['id'] ?? '';
        $resource   = $data['resource'] ?? [];

        // Parse create time
        $occurred_at = 0;
        if (! empty($data['create_time'])) {
            $occurred_at = strtotime($data['create_time']);
        }

        return [
            'success'              => true,
            'gateway_event_id'     => $event_id,
            'gateway_event_type'   => $event_type,
            'normalized_event_type' => $this->normalizeEventType($event_type),
            'occurred_at'          => $occurred_at,
            'payload'              => $resource,
            'raw_body'             => $raw_body,
        ];
    }

    // ─── Entity Resolution ───────────────────────────────────────────────

    /**
     * Resolve local subscription, order, and customer from PayPal webhook data.
     *
     * Strategy:
     * 1. Parse custom_id from resource for direct mapping
     * 2. Fall back to PayPal subscription ID → local subscription meta lookup
     * 3. Cross-resolve via PaymentMetaNormalizer
     *
     * @param array $parsed_webhook Output from parseWebhook().
     * @return array{subscription_id: int, order_id: int, customer_id: int}
     */
    public function resolveEntityIds(array $parsed_webhook): array
    {
        $result   = ['subscription_id' => 0, 'order_id' => 0, 'customer_id' => 0];
        $resource = $parsed_webhook['payload'] ?? [];

        // 1. Try custom_id (set during subscription creation)
        $custom_id = $resource['custom_id'] ?? '';

        if (! empty($custom_id)) {
            $custom_data = json_decode($custom_id, true);

            if (is_array($custom_data)) {
                $result['order_id']        = absint($custom_data['order_id'] ?? 0);
                $result['subscription_id'] = absint($custom_data['subscription_id'] ?? 0);
            }
        }

        // 2. Try PayPal subscription ID lookup
        if (empty($result['subscription_id'])) {
            $paypal_sub_id = $this->extractPayPalSubscriptionId($resource);

            if (! empty($paypal_sub_id)) {
                $found = $this->findSubscriptionByPayPalId($paypal_sub_id);
                if ($found > 0) {
                    $result['subscription_id'] = $found;
                }
            }
        }

        // 3. Cross-resolve via PaymentMetaNormalizer
        if (0 === $result['subscription_id'] || 0 === $result['order_id']) {
            $normalizer = new PaymentMetaNormalizer();
            $resolved   = $normalizer->resolve($result);

            if (0 === $result['subscription_id'] && ! empty($resolved['subscription_id'])) {
                $result['subscription_id'] = $resolved['subscription_id'];
            }
            if (0 === $result['order_id'] && ! empty($resolved['order_id'])) {
                $result['order_id'] = $resolved['order_id'];
            }
        }

        // Resolve customer_id from subscription
        if ($result['subscription_id'] > 0 && 0 === $result['customer_id']) {
            $result['customer_id'] = (int) get_post_meta($result['subscription_id'], '_customer_id', true);
        }

        return $result;
    }

    // ─── Webhook Event Handlers ──────────────────────────────────────────

    /**
     * Handle successful payment.
     *
     * Handles both initial activation (BILLING.SUBSCRIPTION.ACTIVATED)
     * and renewal payments (PAYMENT.SALE.COMPLETED).
     *
     * @param array $context Event context.
     * @return array{success: bool, message: string}
     */
    public function handlePaymentSucceeded(array $context): array
    {
        $subscription_id = $context['subscription_id'] ?? 0;
        $order_id        = $context['order_id'] ?? 0;
        $resource        = $context['payload'] ?? [];
        $event_type      = $context['gateway_event_type'] ?? '';

        if (0 === $subscription_id) {
            $this->log('warning', 'PayPal payment succeeded but no subscription resolved.');
            return ['success' => false, 'message' => 'No subscription resolved.'];
        }

        // Handle initial activation
        if ('BILLING.SUBSCRIPTION.ACTIVATED' === $event_type) {
            return $this->handleSubscriptionActivated($subscription_id, $order_id, $resource);
        }

        // Handle renewal payment (PAYMENT.SALE.COMPLETED)
        return $this->handleRenewalPayment($subscription_id, $order_id, $resource);
    }

    /**
     * Handle payment failure.
     *
     * @param array $context Event context.
     * @return array{success: bool, message: string}
     */
    public function handlePaymentFailed(array $context): array
    {
        $subscription_id = $context['subscription_id'] ?? 0;
        $order_id        = $context['order_id'] ?? 0;
        $resource        = $context['payload'] ?? [];

        if (0 === $subscription_id) {
            return ['success' => false, 'message' => 'No subscription resolved for payment failure.'];
        }

        $reason = $resource['status_change_note'] ?? __('Payment failed at PayPal.', 'arraysubspro');

        $this->addSubscriptionPrivateNote($subscription_id, sprintf(
            /* translators: %s: failure reason */
            __('PayPal payment failed: %s', 'arraysubspro'),
            $reason
        ));

        // Record failure on the order if we have one
        if ($order_id > 0) {
            $order = wc_get_order($order_id);
            if ($order) {
                $this->recordPaymentFailure($order, $subscription_id, 'payment_failed', $reason);
            }
        }

        $this->persistGatewayMeta($subscription_id, ['_gateway_status' => 'errored']);
        $this->emitWebhookAction('arraysubs_gateway_payment_failed', [
            $subscription_id,
            $order_id,
            $this->id,
            $resource,
        ]);

        return ['success' => true, 'message' => 'Payment failure recorded.'];
    }

    /**
     * Handle payment requiring customer action.
     *
     * PayPal handles SCA/3DS internally. This is a no-op.
     *
     * @param array $context Event context.
     * @return array{success: bool, message: string}
     */
    public function handlePaymentRequiresAction(array $context): array
    {
        return ['success' => true, 'message' => 'PayPal handles authentication internally.'];
    }

    /**
     * Handle payment method updated.
     *
     * PayPal does not send card-update style webhooks. Payment method changes
     * require a full re-authorization. This is effectively a no-op for
     * ongoing subscriptions.
     *
     * @param array $context Event context.
     * @return array{success: bool, message: string}
     */
    public function handlePaymentMethodUpdated(array $context): array
    {
        return ['success' => true, 'message' => 'PayPal does not send payment method update webhooks.'];
    }

    /**
     * Handle card expiring notice.
     *
     * PayPal manages the payment source internally. No card expiry
     * notifications are sent.
     *
     * @param array $context Event context.
     * @return array{success: bool, message: string}
     */
    public function handleCardExpiring(array $context): array
    {
        return ['success' => true, 'message' => 'PayPal manages payment sources internally.'];
    }

    /**
     * Handle refund created externally at PayPal.
     *
     * @param array $context Event context.
     * @return array{success: bool, message: string}
     */
    public function handleRefundCreated(array $context): array
    {
        $subscription_id = $context['subscription_id'] ?? 0;
        $order_id        = $context['order_id'] ?? 0;
        $resource        = $context['payload'] ?? [];

        if (0 === $subscription_id) {
            return ['success' => false, 'message' => 'No subscription resolved for refund.'];
        }

        // Check for echo loop — was this refund initiated by us?
        if (TwoWaySyncGuard::wasInitiatedLocally('refund', $subscription_id)) {
            TwoWaySyncGuard::clear('refund', $subscription_id);
            return ['success' => true, 'message' => 'Skipped echo — refund was locally initiated.'];
        }

        $refund_amount = $resource['amount']['total'] ?? ($resource['total_refunded_amount']['value'] ?? '');

        $this->addSubscriptionPrivateNote($subscription_id, sprintf(
            /* translators: %s: refund amount */
            __('External refund received from PayPal: %s', 'arraysubspro'),
            $refund_amount
        ));

        // Try to record the refund on the WC order
        if ($order_id > 0) {
            $order = wc_get_order($order_id);
            if ($order && ! empty($refund_amount)) {
                $order->add_order_note(sprintf(
                    /* translators: %s: refund amount */
                    __('PayPal refund processed externally: %s', 'arraysubspro'),
                    $refund_amount
                ));
            }
        }

        $this->emitWebhookAction('arraysubs_gateway_refund_created', [
            $subscription_id,
            $order_id,
            $this->id,
            $resource,
        ]);

        return ['success' => true, 'message' => 'External refund recorded.'];
    }

    /**
     * Handle dispute/chargeback opened.
     *
     * @param array $context Event context.
     * @return array{success: bool, message: string}
     */
    public function handleDisputeCreated(array $context): array
    {
        $subscription_id = $context['subscription_id'] ?? 0;
        $order_id        = $context['order_id'] ?? 0;
        $resource        = $context['payload'] ?? [];

        if (0 === $subscription_id) {
            return ['success' => false, 'message' => 'No subscription resolved for dispute.'];
        }

        $dispute_id = $resource['dispute_id'] ?? '';
        $reason     = $resource['reason'] ?? 'unknown';

        $this->addSubscriptionPrivateNote($subscription_id, sprintf(
            /* translators: 1: dispute ID, 2: reason */
            __('PayPal dispute opened (ID: %1$s, reason: %2$s). Review in PayPal Resolution Center.', 'arraysubspro'),
            $dispute_id,
            $reason
        ));

        $this->emitWebhookAction('arraysubs_gateway_dispute_created', [
            $subscription_id,
            $order_id,
            $this->id,
            $resource,
        ]);

        return ['success' => true, 'message' => 'Dispute logged.'];
    }

    /**
     * Handle dispute resolved.
     *
     * @param array $context Event context.
     * @return array{success: bool, message: string}
     */
    public function handleDisputeResolved(array $context): array
    {
        $subscription_id = $context['subscription_id'] ?? 0;
        $order_id        = $context['order_id'] ?? 0;
        $resource        = $context['payload'] ?? [];

        if (0 === $subscription_id) {
            return ['success' => false, 'message' => 'No subscription resolved for dispute resolution.'];
        }

        $dispute_id = $resource['dispute_id'] ?? '';
        $outcome    = $resource['dispute_outcome']['outcome_code'] ?? 'unknown';

        $this->addSubscriptionPrivateNote($subscription_id, sprintf(
            /* translators: 1: dispute ID, 2: outcome */
            __('PayPal dispute resolved (ID: %1$s, outcome: %2$s).', 'arraysubspro'),
            $dispute_id,
            $outcome
        ));

        $this->emitWebhookAction('arraysubs_gateway_dispute_resolved', [
            $subscription_id,
            $order_id,
            $this->id,
            $resource,
        ]);

        return ['success' => true, 'message' => 'Dispute resolution recorded.'];
    }

    /**
     * Handle external subscription cancellation from PayPal.
     *
     * @param array $context Event context.
     * @return array{success: bool, message: string}
     */
    public function handleSubscriptionCancelled(array $context): array
    {
        $subscription_id = $context['subscription_id'] ?? 0;
        $resource        = $context['payload'] ?? [];

        if (0 === $subscription_id) {
            return ['success' => false, 'message' => 'No subscription resolved for cancellation.'];
        }

        // Check echo loop — was the cancellation initiated by us?
        if (TwoWaySyncGuard::wasInitiatedLocally('cancel', $subscription_id)) {
            TwoWaySyncGuard::clear('cancel', $subscription_id);
            return ['success' => true, 'message' => 'Skipped echo — cancellation was locally initiated.'];
        }

        $this->persistGatewayMeta($subscription_id, [
            '_gateway_status'      => 'inactive',
            '_cancellation_source' => 'gateway',
        ]);

        $this->addSubscriptionPrivateNote($subscription_id, __('Subscription cancelled externally at PayPal.', 'arraysubspro'));
        $this->emitWebhookAction('arraysubs_gateway_subscription_cancelled', [
            $subscription_id,
            $this->id,
            $resource,
        ]);

        return ['success' => true, 'message' => 'External cancellation processed.'];
    }

    // ─── Private Helpers ─────────────────────────────────────────────────

    /**
     * Create a PayPal Product + Billing Plan for the subscription.
     *
     * @param \WC_Order $order        The order.
     * @param \WP_Post  $subscription The subscription.
     * @return array|\WP_Error Plan data or error.
     */
    private function createPayPalPlan(\WC_Order $order, \WP_Post $subscription)
    {
        $subscription_id = $subscription->ID;
        $product_id      = (int) get_post_meta($subscription_id, '_product_id', true);
        $product         = wc_get_product($product_id);

        if (! $product) {
            return new \WP_Error('invalid_product', __('Subscription product not found.', 'arraysubspro'));
        }

        // Get or create PayPal product
        $paypal_product_id = $this->getOrCreatePayPalProduct($product);

        if (is_wp_error($paypal_product_id)) {
            return $paypal_product_id;
        }

        // Build billing cycles
        $billing_period   = get_post_meta($subscription_id, '_billing_period', true);
        $billing_interval = (int) get_post_meta($subscription_id, '_billing_interval', true);
        $recurring_amount = get_post_meta($subscription_id, '_recurring_amount', true);
        $signup_fee       = get_post_meta($subscription_id, '_signup_fee', true);
        $currency         = $order->get_currency();

        if (empty($billing_period) || $billing_interval <= 0) {
            return new \WP_Error('invalid_billing', __('Invalid subscription billing configuration.', 'arraysubspro'));
        }

        $interval_unit = $this->mapBillingPeriodToPayPal($billing_period);

        if (empty($interval_unit)) {
            return new \WP_Error('unsupported_period', sprintf(
                /* translators: %s: billing period */
                __('Unsupported billing period for PayPal: %s', 'arraysubspro'),
                $billing_period
            ));
        }

        $billing_cycles = [
            [
                'tenure_type'    => 'REGULAR',
                'sequence'       => 1,
                'total_cycles'   => 0,
                'frequency'      => [
                    'interval_unit'  => $interval_unit,
                    'interval_count' => $billing_interval,
                ],
                'pricing_scheme' => [
                    'fixed_price' => [
                        'value'         => number_format((float) $recurring_amount, 2, '.', ''),
                        'currency_code' => $currency,
                    ],
                ],
            ],
        ];

        $payment_preferences = [
            'auto_bill_outstanding'     => true,
            'payment_failure_threshold' => 3,
        ];

        // Add setup fee if present
        if (! empty($signup_fee) && (float) $signup_fee > 0) {
            $payment_preferences['setup_fee'] = [
                'value'         => number_format((float) $signup_fee, 2, '.', ''),
                'currency_code' => $currency,
            ];
        }

        $plan_data = [
            'product_id'          => $paypal_product_id,
            'name'                => sprintf(
                /* translators: 1: product name, 2: billing interval, 3: billing period */
                __('%1$s — every %2$d %3$s', 'arraysubspro'),
                $product->get_name(),
                $billing_interval,
                $billing_period
            ),
            'description'         => substr($product->get_short_description(), 0, 127),
            'billing_cycles'      => $billing_cycles,
            'payment_preferences' => $payment_preferences,
        ];

        return $this->getApi()->createPlan($plan_data);
    }

    /**
     * Get or create a PayPal Catalog Product for a WC product.
     *
     * @param \WC_Product $product WC product.
     * @return string|\WP_Error PayPal product ID or error.
     */
    private function getOrCreatePayPalProduct(\WC_Product $product)
    {
        $product_id        = $product->get_id();
        $paypal_product_id = get_post_meta($product_id, self::META_PAYPAL_PRODUCT_ID, true);

        if (! empty($paypal_product_id)) {
            return $paypal_product_id;
        }

        $result = $this->getApi()->createProduct([
            'name'        => $product->get_name(),
            'description' => substr($product->get_short_description(), 0, 255),
            'type'        => 'SERVICE',
            'category'    => 'SOFTWARE',
        ]);

        if (is_wp_error($result)) {
            return $result;
        }

        $paypal_product_id = $result['id'] ?? '';

        if (empty($paypal_product_id)) {
            return new \WP_Error('product_creation_failed', __('PayPal product creation returned no ID.', 'arraysubspro'));
        }

        update_post_meta($product_id, self::META_PAYPAL_PRODUCT_ID, sanitize_text_field($paypal_product_id));

        $this->log('info', sprintf('PayPal product %s created for WC product %d', $paypal_product_id, $product_id));

        return $paypal_product_id;
    }

    /**
     * Map WC billing period to PayPal interval unit.
     *
     * @param string $period WC billing period.
     * @return string PayPal interval unit or empty if unsupported.
     */
    private function mapBillingPeriodToPayPal(string $period): string
    {
        $map = [
            'day'   => 'DAY',
            'week'  => 'WEEK',
            'month' => 'MONTH',
            'year'  => 'YEAR',
        ];

        return $map[$period] ?? '';
    }

    /**
     * Handle initial subscription activation.
     *
     * @param int   $subscription_id Local subscription ID.
     * @param int   $order_id        Order ID.
     * @param array $resource        PayPal resource data.
     * @return array{success: bool, message: string}
     */
    private function handleSubscriptionActivated(int $subscription_id, int $order_id, array $resource): array
    {
        $paypal_sub_id = $resource['id'] ?? '';

        // Store the PayPal subscription ID
        if (! empty($paypal_sub_id)) {
            update_post_meta($subscription_id, self::META_PAYPAL_SUBSCRIPTION_ID, sanitize_text_field($paypal_sub_id));
        }

        // Capture payment context
        if ($order_id > 0) {
            $order = wc_get_order($order_id);
            if ($order) {
                $this->capturePaymentContext($order, $subscription_id);
                $this->markOrderPaid($order, $paypal_sub_id);
                $this->persistOrderGatewayMeta($order, [
                    '_last_gateway_transaction_id' => $paypal_sub_id,
                ]);
            }
        }

        $this->persistGatewayMeta($subscription_id, [
            '_gateway_status'              => 'active',
            '_last_gateway_transaction_id' => $paypal_sub_id,
        ]);

        $this->addSubscriptionPrivateNote($subscription_id, sprintf(
            /* translators: %s: PayPal subscription ID */
            __('PayPal subscription %s activated.', 'arraysubspro'),
            $paypal_sub_id
        ));

        // Sync the next billing date from PayPal
        $this->syncNextPaymentDate($subscription_id, $resource);

        $this->emitWebhookAction('arraysubs_gateway_payment_succeeded', [
            $subscription_id,
            $order_id,
            $this->id,
            $resource,
        ]);

        return ['success' => true, 'message' => 'Subscription activated and order completed.'];
    }

    /**
     * Handle a renewal payment (PAYMENT.SALE.COMPLETED).
     *
     * @param int   $subscription_id Local subscription ID.
     * @param int   $order_id        Order ID.
     * @param array $resource        PayPal sale resource data.
     * @return array{success: bool, message: string}
     */
    private function handleRenewalPayment(int $subscription_id, int $order_id, array $resource): array
    {
        $sale_id = $resource['id'] ?? '';

        // If no order found, try to find a pending renewal order
        if (0 === $order_id) {
            $order_id = $this->findPendingRenewalOrder($subscription_id);
        }

        // If still no order, create a retroactive renewal order
        if (0 === $order_id) {
            $order_id = $this->createRetroactiveRenewalOrder($subscription_id, $resource);
        }

        if ($order_id > 0) {
            $order = wc_get_order($order_id);
            if ($order) {
                $this->markOrderPaid($order, $sale_id);
                $this->persistOrderGatewayMeta($order, [
                    '_last_gateway_transaction_id' => $sale_id,
                ]);
            }
        }

        // Store the transaction ID on subscription
        $this->persistGatewayMeta($subscription_id, ['_last_gateway_transaction_id' => $sale_id]);

        $amount = $resource['amount']['total'] ?? '';

        $this->addSubscriptionPrivateNote($subscription_id, sprintf(
            /* translators: 1: amount, 2: sale/transaction ID */
            __('PayPal renewal payment received: %1$s (Sale: %2$s)', 'arraysubspro'),
            $amount,
            $sale_id
        ));

        // Sync next payment date from PayPal subscription data
        $this->syncNextPaymentDateFromSubscription($subscription_id);

        $this->emitWebhookAction('arraysubs_gateway_payment_succeeded', [
            $subscription_id,
            $order_id,
            $this->id,
            $resource,
        ]);

        return ['success' => true, 'message' => 'Renewal payment processed.'];
    }

    /**
     * Extract PayPal subscription ID from a webhook resource.
     *
     * @param array $resource The resource data.
     * @return string PayPal subscription ID or empty string.
     */
    private function extractPayPalSubscriptionId(array $resource): string
    {
        // For subscription events, the ID is the subscription ID
        if (! empty($resource['id']) && 0 === strpos(($resource['id'] ?? ''), 'I-')) {
            return $resource['id'];
        }

        // For sale events, billing_agreement_id contains the subscription ID
        if (! empty($resource['billing_agreement_id'])) {
            return $resource['billing_agreement_id'];
        }

        // For dispute events, there may be no direct subscription reference.
        // We'd need to look up the disputed transaction.
        return '';
    }

    /**
     * Find a local subscription by PayPal subscription ID.
     *
     * @param string $paypal_sub_id PayPal subscription ID (I-xxx).
     * @return int Local subscription ID or 0.
     */
    private function findSubscriptionByPayPalId(string $paypal_sub_id): int
    {
        $posts = get_posts([
            'post_type'   => 'arraysubs_data',
            'post_status' => 'any',
            'meta_key'    => self::META_PAYPAL_SUBSCRIPTION_ID, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
            'meta_value'  => $paypal_sub_id, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
            'fields'      => 'ids',
            'numberposts' => 1,
        ]);

        return ! empty($posts) ? (int) $posts[0] : 0;
    }

    /**
     * Find a pending renewal order for a subscription.
     *
     * @param int $subscription_id The subscription ID.
     * @return int Renewal order ID or 0.
     */
    private function findPendingRenewalOrder(int $subscription_id): int
    {
        $pending_order_id = (int) get_post_meta($subscription_id, '_pending_renewal_order_id', true);

        if ($pending_order_id > 0) {
            $order = wc_get_order($pending_order_id);
            if ($order && 'pending' === $order->get_status()) {
                return $pending_order_id;
            }
        }

        return 0;
    }

    /**
     * Create a retroactive renewal order when PayPal charges before our cron.
     *
     * @param int   $subscription_id The subscription ID.
     * @param array $resource        PayPal sale resource.
     * @return int New order ID or 0 on failure.
     */
    private function createRetroactiveRenewalOrder(int $subscription_id, array $resource): int
    {
        $subscription = arraysubs_get_subscription($subscription_id);

        if (! $subscription instanceof \WP_Post) {
            return 0;
        }

        $customer_id = (int) get_post_meta($subscription_id, '_customer_id', true);
        $amount      = $resource['amount']['total'] ?? '';
        $currency    = $resource['amount']['currency'] ?? get_woocommerce_currency();
        $sale_id     = $resource['id'] ?? '';

        if (empty($amount) || $customer_id <= 0) {
            return 0;
        }

        $order = wc_create_order([
            'customer_id' => $customer_id,
            'status'      => 'pending',
        ]);

        if (is_wp_error($order)) {
            $this->log('error', 'Failed to create retroactive renewal order: ' . $order->get_error_message());
            return 0;
        }

        $order->set_currency($currency);
        $order->set_total($amount);
        $order->set_payment_method($this->id);
        $order->set_payment_method_title($this->title);
        $order->update_meta_data('_subscription_id', $subscription_id);
        $order->update_meta_data('_is_renewal_order', 'yes');
        $order->update_meta_data('_subscription_renewal', $subscription_id);
        $order->update_meta_data('_arraysubs_subscription_id', $subscription_id);
        $order->update_meta_data('_gateway_session_id', $sale_id);
        $order->add_order_note(sprintf(
            /* translators: 1: subscription ID, 2: sale ID */
            __('Retroactive renewal order created for subscription #%1$d (PayPal Sale: %2$s).', 'arraysubspro'),
            $subscription_id,
            $sale_id
        ));
        $order->save();

        $this->log('info', sprintf(
            'Created retroactive renewal order %d for subscription %d',
            $order->get_id(),
            $subscription_id
        ));

        if (function_exists('update_post_meta')) {
            call_user_func('update_post_meta', $subscription_id, '_pending_renewal_order_id', $order->get_id());
        }

        return $order->get_id();
    }

    /**
     * Sync next payment date from PayPal subscription activation resource.
     *
     * @param int   $subscription_id Subscription ID.
     * @param array $resource        PayPal subscription resource.
     * @return void
     */
    private function syncNextPaymentDate(int $subscription_id, array $resource): void
    {
        $billing_info    = $resource['billing_info'] ?? [];
        $next_billing_at = $billing_info['next_billing_time'] ?? '';

        if (! empty($next_billing_at)) {
            $timestamp = strtotime($next_billing_at);
            if ($timestamp > 0) {
                update_post_meta(
                    $subscription_id,
                    '_next_payment_date',
                    gmdate('Y-m-d H:i:s', $timestamp)
                );
            }
        }
    }

    /**
     * Sync next payment date by fetching the PayPal subscription status.
     *
     * Used after renewal payments when the resource doesn't include billing info.
     *
     * @param int $subscription_id The subscription ID.
     * @return void
     */
    private function syncNextPaymentDateFromSubscription(int $subscription_id): void
    {
        $paypal_sub_id = get_post_meta($subscription_id, self::META_PAYPAL_SUBSCRIPTION_ID, true);

        if (empty($paypal_sub_id)) {
            return;
        }

        $paypal_sub = $this->getApi()->getSubscription($paypal_sub_id);

        if (is_wp_error($paypal_sub)) {
            $this->log('warning', 'Failed to fetch PayPal subscription for next billing date sync.');
            return;
        }

        $this->syncNextPaymentDate($subscription_id, $paypal_sub);
    }

    /**
     * Build a standardized capture failure response.
     *
     * @param string $message Failure message.
     * @return array
     */
    private function buildCaptureFailure(string $message): array
    {
        return [
            'success'                   => false,
            'gateway_slug'              => $this->id,
            'remote_customer_id'        => '',
            'remote_payment_method_id'  => '',
            'remote_transaction_id'     => '',
            'brand'                     => '',
            'last4'                     => '',
            'payment_method_type'       => '',
            'message'                   => $message,
            'raw'                       => [],
        ];
    }
}
