<?php

/**
 * Database Migration
 *
 * Creates and manages the webhook events idempotency table.
 * Ensures webhook events are processed exactly once.
 *
 * @package ArraySubsPro\Features\AutomaticPayments\Services
 * @since 1.0.0
 */

namespace ArraySubsPro\Features\AutomaticPayments\Services;

defined('ABSPATH') || exit;

/**
 * Database Migration Service
 */
class DatabaseMigration
{
    /**
     * Database version for migration tracking.
     *
     * @var string
     */
    const DB_VERSION = '1.0.1';

    /**
     * Option name for tracking migration version.
     *
     * @var string
     */
    const VERSION_OPTION = 'arraysubs_gateway_db_version';

    /**
     * Whether the webhook events table exists (cached per-request).
     *
     * @var bool|null
     */
    private static ?bool $table_exists = null;

    /**
     * Check whether the webhook events table exists.
     *
     * @return bool
     */
    public static function tableExists(): bool
    {
        if (null !== self::$table_exists) {
            return self::$table_exists;
        }

        global $wpdb;

        $table = $wpdb->prefix . 'arraysubs_webhook_events';

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        self::$table_exists = $wpdb->get_var(
            $wpdb->prepare('SHOW TABLES LIKE %s', $table)
        ) === $table;

        return self::$table_exists;
    }

    /**
     * Run migrations if needed.
     *
     * @return void
     */
    public static function maybeRunMigrations(): void
    {
        $current_version = get_option(self::VERSION_OPTION, '');

        self::maybeRunStripeSlugMigration();

        if (self::DB_VERSION === $current_version) {
            return;
        }

        self::createWebhookEventsTable();

        update_option(self::VERSION_OPTION, self::DB_VERSION);
    }

    /**
     * One-shot closed-preview Stripe slug cleanup.
     *
     * @return void
     */
    private static function maybeRunStripeSlugMigration(): void
    {
        if (get_option('arraysubs_stripe_migration_v1_complete')) {
            return;
        }

        global $wpdb;

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $wpdb->query(
            $wpdb->prepare(
                "UPDATE {$wpdb->postmeta} pm
                INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
                SET pm.meta_value = %s
                WHERE pm.meta_key IN ('_payment_gateway', '_payment_method')
                AND pm.meta_value = %s
                AND p.post_type IN ('arraysubs_data', 'shop_order', 'shop_order_placehold')",
                'stripe',
                'arraysubs_stripe'
            )
        );

        $hpos_order_meta_table = esc_sql($wpdb->prefix . 'wc_orders_meta');
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $hpos_table_exists = $wpdb->get_var(
            $wpdb->prepare('SHOW TABLES LIKE %s', $hpos_order_meta_table)
        );

        if ($hpos_table_exists === $hpos_order_meta_table) {
            foreach (['_payment_gateway', '_payment_method'] as $meta_key) {
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                $wpdb->update(
                    $hpos_order_meta_table,
                    ['meta_value' => 'stripe'],
                    [
                        'meta_key'   => $meta_key,
                        'meta_value' => 'arraysubs_stripe',
                    ],
                    ['%s'],
                    ['%s', '%s']
                );
            }
        }

        delete_option('woocommerce_arraysubs_stripe_settings');

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $wpdb->delete(
            $wpdb->usermeta,
            ['meta_key' => '_arraysubs_stripe_customer_id'],
            ['%s']
        );

        update_option('arraysubs_stripe_migration_v1_complete', 'yes');
    }

    /**
     * Create the webhook events idempotency table.
     *
     * @return void
     */
    private static function createWebhookEventsTable(): void
    {
        global $wpdb;

        $table_name      = $wpdb->prefix . 'arraysubs_webhook_events';
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE {$table_name} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			gateway_slug varchar(50) NOT NULL,
			event_id varchar(255) NOT NULL,
			event_type varchar(100) NOT NULL DEFAULT '',
			processed_at datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
			PRIMARY KEY  (id),
			UNIQUE KEY gateway_event (gateway_slug, event_id)
		) {$charset_collate};";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }

    /**
     * Clean up old webhook events (older than 30 days).
     * Called by the scheduled cleanup job.
     *
     * @return int Number of rows deleted.
     */
    public static function cleanupOldEvents(): int
    {
        if (! self::tableExists()) {
            return 0;
        }

        global $wpdb;

        $table    = $wpdb->prefix . 'arraysubs_webhook_events';
        $cutoff   = gmdate('Y-m-d H:i:s', time() - (30 * DAY_IN_SECONDS));

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $deleted = $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM {$table} WHERE processed_at < %s", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
                $cutoff
            )
        );

        return (int) $deleted;
    }
}
