<?php

/**
 * Stripe Mandate Registry
 *
 * Caches Stripe mandate IDs on subscriptions and exposes them for off-session
 * bank-debit renewals.
 *
 * @package ArraySubsPro\Features\AutomaticPayments\Services
 */

namespace ArraySubsPro\Features\AutomaticPayments\Services;

defined('ABSPATH') || exit;

/**
 * Mandate registry.
 */
class MandateRegistry
{
    /**
     * Cache the mandate from a WooCommerce order.
     *
     * @param \WC_Order $order           Source order.
     * @param int       $subscription_id Subscription ID.
     * @return string
     */
    public static function cacheFromOrder(\WC_Order $order, int $subscription_id): string
    {
        $mandate_id = (string) $order->get_meta('_stripe_mandate_id', true);

        if ('' === $mandate_id && class_exists('\WC_Stripe_Order_Helper')) {
            try {
                $helper     = \WC_Stripe_Order_Helper::get_instance();
                $mandate_id = (string) $helper->get_stripe_mandate_id($order);
            } catch (\Throwable $throwable) {
                $mandate_id = '';
            }
        }

        if ('' !== $mandate_id) {
            update_post_meta($subscription_id, '_gateway_mandate_id', sanitize_text_field($mandate_id));
        }

        return $mandate_id;
    }

    /**
     * Get a cached mandate for a subscription.
     *
     * @param int $subscription_id Subscription ID.
     * @return string|null
     */
    public static function getMandateForSubscription(int $subscription_id): ?string
    {
        $mandate_id = (string) get_post_meta($subscription_id, '_gateway_mandate_id', true);

        return '' !== $mandate_id ? $mandate_id : null;
    }
}
