<?php

/**
 * Stripe Settings Section
 *
 * Adds a Stripe-adjacent WooCommerce settings section for ArraySubs-only Stripe
 * settings such as the secondary webhook signing secret.
 *
 * @package ArraySubsPro\Features\AutomaticPayments\Services
 */

namespace ArraySubsPro\Features\AutomaticPayments\Services;

defined('ABSPATH') || exit;

/**
 * Stripe settings section.
 */
class StripeSettingsTab
{
    /**
     * Enable auto-loading.
     *
     * @var bool
     */
    public static $loadable = true;

    /**
     * Option key.
     *
     * @var string
     */
    const OPTION_KEY = 'arraysubs_stripe_extras';

    /**
     * Constructor.
     */
    public function __construct()
    {
        add_filter('woocommerce_get_sections_checkout', [$this, 'addSection']);
        add_filter('woocommerce_get_settings_checkout', [$this, 'getSettings'], 10, 2);
        add_action('woocommerce_update_options_checkout_arraysubs_stripe', [$this, 'saveSettings']);
    }

    /**
     * Add checkout settings section.
     *
     * @param array $sections Existing sections.
     * @return array
     */
    public function addSection(array $sections): array
    {
        $sections['arraysubs_stripe'] = __('ArraySubs Stripe Configs', 'arraysubspro');
        return $sections;
    }

    /**
     * Get settings for the ArraySubs Stripe section.
     *
     * @param array  $settings        Existing settings.
     * @param string $current_section Current section.
     * @return array
     */
    public function getSettings(array $settings, string $current_section): array
    {
        if ('arraysubs_stripe' !== $current_section) {
            return $settings;
        }

        $mode   = StripeWebhookProvisioner::getCurrentMode();
        $option = self::getOptions();
        $status = StripeWebhookProvisioner::getStoredStatus();

        return [
            [
                'title' => __('ArraySubs Stripe Configs', 'arraysubspro'),
                'type'  => 'title',
                'id'    => 'arraysubs_stripe_configs_title',
                'desc'  => $this->getHelpHtml(),
            ],
            [
                'title'    => __('Secondary webhook signing secret', 'arraysubspro'),
                'id'       => self::OPTION_KEY . '[secondary_webhook_secret]',
                'type'     => 'password',
                'default'  => '',
                'value'    => self::getSecondaryWebhookSecret($mode),
                'desc_tip' => __('Auto-managed from the active WooCommerce Stripe connection. Paste a whsec_ value only when manually repairing the endpoint.', 'arraysubspro'),
            ],
            [
                'title'             => __('Secondary webhook endpoint ID', 'arraysubspro'),
                'id'                => self::OPTION_KEY . '[secondary_webhook_endpoint_id]',
                'type'              => 'text',
                'default'           => '',
                'value'             => $status['endpoint_id'] ?? '',
                'desc_tip'          => __('Created automatically in the Stripe account connected through WooCommerce Stripe.', 'arraysubspro'),
                'custom_attributes' => [
                    'readonly' => 'readonly',
                ],
            ],
            [
                'type' => 'sectionend',
                'id'   => 'arraysubs_stripe_configs_end',
            ],
        ];
    }

    /**
     * Save settings.
     *
     * @return void
     */
    public function saveSettings(): void
    {
        if (! current_user_can('manage_woocommerce')) {
            return;
        }

        check_admin_referer('woocommerce-settings');

        $raw = isset($_POST[self::OPTION_KEY]) && is_array($_POST[self::OPTION_KEY])
            ? wc_clean(wp_unslash($_POST[self::OPTION_KEY]))
            : [];

        $settings = self::getOptions();
        $mode     = StripeWebhookProvisioner::getCurrentMode();
        $secret   = sanitize_text_field((string) ($raw['secondary_webhook_secret'] ?? ''));

        if ('' !== $secret) {
            $settings[self::modeKey($mode, 'secondary_webhook_secret')] = $secret;
            $settings['secondary_webhook_secret']                       = $secret;
            $settings['secondary_webhook_mode']                         = $mode;
        }

        update_option(self::OPTION_KEY, $settings);
    }

    /**
     * Get stored settings.
     *
     * @return array
     */
    public static function getOptions(): array
    {
        $option = get_option(self::OPTION_KEY, []);
        return is_array($option) ? $option : [];
    }

    /**
     * Get secondary webhook secret.
     *
     * @return string
     */
    public static function getSecondaryWebhookSecret(?string $mode = null): string
    {
        $options = self::getOptions();
        $mode    = $mode ?: StripeWebhookProvisioner::getCurrentMode();
        $secret  = (string) ($options[self::modeKey($mode, 'secondary_webhook_secret')] ?? '');

        if ('' !== $secret) {
            return $secret;
        }

        $legacy_mode = (string) ($options['secondary_webhook_mode'] ?? '');
        if ('' !== $legacy_mode && $legacy_mode !== $mode) {
            return '';
        }

        return (string) ($options['secondary_webhook_secret'] ?? '');
    }

    /**
     * Get secondary webhook endpoint ID.
     *
     * @param string|null $mode Stripe mode.
     * @return string
     */
    public static function getSecondaryWebhookEndpointId(?string $mode = null): string
    {
        $options = self::getOptions();
        $mode    = $mode ?: StripeWebhookProvisioner::getCurrentMode();
        $id      = (string) ($options[self::modeKey($mode, 'secondary_webhook_endpoint_id')] ?? '');

        if ('' !== $id) {
            return $id;
        }

        $legacy_mode = (string) ($options['secondary_webhook_mode'] ?? '');
        if ('' !== $legacy_mode && $legacy_mode !== $mode) {
            return '';
        }

        return (string) ($options['secondary_webhook_endpoint_id'] ?? '');
    }

    /**
     * Build a mode-prefixed option key.
     *
     * @param string $mode Stripe mode.
     * @param string $key  Base key.
     * @return string
     */
    private static function modeKey(string $mode, string $key): string
    {
        return StripeWebhookProvisioner::modeKey($mode, $key);
    }

    /**
     * Build help text.
     *
     * @return string
     */
    private function getHelpHtml(): string
    {
        $webhook_url = StripeWebhookProvisioner::getEndpointUrl();
        $last_event  = $this->getLastEventLabel();
        $status      = StripeWebhookProvisioner::getStoredStatus();
        $mode_label  = 'test' === ($status['mode'] ?? 'test') ? __('Test mode', 'arraysubspro') : __('Live mode', 'arraysubspro');
        $last_error  = (string) ($status['last_error'] ?? '');

        return wp_kses_post(
            '<p>' . esc_html__('Used by ArraySubs to receive Stripe events that the official Stripe plugin does not internally process for ArraySubs subscriptions.', 'arraysubspro') . '</p>' .
            '<p>' . esc_html__('ArraySubs now creates and repairs this endpoint automatically using the active WooCommerce Stripe connection. Test mode and live mode keep separate endpoint secrets.', 'arraysubspro') . '</p>' .
            '<ol>' .
            '<li>' . esc_html__('Configure WooCommerce Stripe first, then save the Stripe settings or visit this page while logged in as a store manager.', 'arraysubspro') . '</li>' .
            '<li>' . sprintf(
                /* translators: %s: webhook URL */
                esc_html__('Endpoint URL: %s', 'arraysubspro'),
                '<code>' . esc_url($webhook_url) . '</code>'
            ) . '</li>' .
            '<li>' . esc_html__('Manual setup is only needed if Stripe API permissions are unavailable. In that case, create the endpoint in Stripe and paste the whsec_ signing secret below.', 'arraysubspro') . '</li>' .
            '</ol>' .
            '<p><strong>' . esc_html__('Active mode:', 'arraysubspro') . '</strong> ' . esc_html($mode_label) . '</p>' .
            '<p><strong>' . esc_html__('Last received event:', 'arraysubspro') . '</strong> ' . esc_html($last_event) . '</p>'
            . ('' !== $last_error ? '<p><strong>' . esc_html__('Last automatic setup error:', 'arraysubspro') . '</strong> ' . esc_html($last_error) . '</p>' : '')
        );
    }

    /**
     * Get last secondary webhook event label.
     *
     * @return string
     */
    private function getLastEventLabel(): string
    {
        global $wpdb;

        $table = $wpdb->prefix . 'arraysubs_webhook_events';

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $table_exists = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table));
        if (! $table_exists) {
            return __('No events received yet.', 'arraysubspro');
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $event = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT event_type, processed_at FROM {$table} WHERE gateway_slug = %s ORDER BY processed_at DESC LIMIT 1", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
                'arraysubs_stripe'
            ),
            ARRAY_A
        );

        if (empty($event)) {
            return __('No events received yet.', 'arraysubspro');
        }

        return sprintf(
            /* translators: 1: timestamp, 2: event type */
            __('%1$s (event: %2$s)', 'arraysubspro'),
            $event['processed_at'],
            $event['event_type']
        );
    }
}
