<?php

/**
 * Stripe secondary webhook provisioning.
 *
 * Creates and repairs the ArraySubs Stripe webhook endpoint using the active
 * WooCommerce Stripe Gateway API connection.
 *
 * @package ArraySubsPro\Features\AutomaticPayments\Services
 */

namespace ArraySubsPro\Features\AutomaticPayments\Services;

defined('ABSPATH') || exit;

/**
 * Stripe webhook provisioning service.
 */
class StripeWebhookProvisioner
{
    /**
     * Enable auto-loading.
     *
     * @var bool
     */
    public static $loadable = true;

    /**
     * Auto-check transient prefix.
     *
     * @var string
     */
    private const AUTO_CHECK_TRANSIENT = 'arraysubs_stripe_secondary_webhook_checked_';

    /**
     * Constructor.
     */
    public function __construct()
    {
        add_action('admin_init', [$this, 'maybeEnsureWebhook']);
        add_action('woocommerce_update_options_checkout_stripe', [$this, 'ensureWebhookAfterSettingsSave'], 90);
        add_action('woocommerce_update_options_checkout_arraysubs_stripe', [$this, 'ensureWebhookAfterSettingsSave'], 90);
    }

    /**
     * Provision the webhook after Woo/ArraySubs Stripe settings are saved.
     *
     * @return void
     */
    public function ensureWebhookAfterSettingsSave(): void
    {
        if (! current_user_can('manage_woocommerce')) {
            return;
        }

        self::ensureEndpoint(['force_check' => true]);
    }

    /**
     * Ensure the webhook exists after Stripe credentials become available.
     *
     * @return void
     */
    public function maybeEnsureWebhook(): void
    {
        if (! is_admin() || wp_doing_ajax() || ! current_user_can('manage_woocommerce')) {
            return;
        }

        if (self::isActiveEndpointStored()) {
            return;
        }

        $mode          = self::getCurrentMode();
        $transient_key = self::AUTO_CHECK_TRANSIENT . $mode;

        if (get_transient($transient_key)) {
            return;
        }

        set_transient($transient_key, '1', 15 * MINUTE_IN_SECONDS);

        self::ensureEndpoint();
    }

    /**
     * Create or repair the ArraySubs secondary Stripe webhook endpoint.
     *
     * @param array<string, mixed> $args Provisioning args.
     * @return array<string, mixed>
     */
    public static function ensureEndpoint(array $args = []): array
    {
        $force_check = ! empty($args['force_check']);
        $mode        = self::getCurrentMode();
        $url         = self::getEndpointUrl();

        if (! StripeAvailability::isAvailable() || ! class_exists('\WC_Stripe_API')) {
            return self::recordFailure(
                __('WooCommerce Stripe Gateway is not available.', 'arraysubspro'),
                $mode
            );
        }

        self::setWooStripeMode($mode);

        if ('' === self::getActiveSecretKey()) {
            return self::recordFailure(
                __('WooCommerce Stripe API credentials are not configured for the active mode.', 'arraysubspro'),
                $mode
            );
        }

        $stored_secret = StripeSettingsTab::getSecondaryWebhookSecret($mode);
        $stored_id     = StripeSettingsTab::getSecondaryWebhookEndpointId($mode);

        if (! $force_check && '' !== $stored_secret && '' !== $stored_id) {
            return self::buildResult(true, __('ArraySubs Stripe webhook is already configured.', 'arraysubspro'), [
                'configured' => true,
                'created'    => false,
                'endpoint_id' => $stored_id,
                'mode'        => $mode,
                'url'         => $url,
            ]);
        }

        $list = self::listWebhookEndpoints();
        if (is_wp_error($list)) {
            return self::recordFailure($list->get_error_message(), $mode);
        }

        $matching = self::filterMatchingEndpoints($list, $url);

        if ('' !== $stored_secret && ! empty($matching)) {
            $endpoint = reset($matching);
            self::storeEndpointMetadata($endpoint, $mode, $stored_secret);

            return self::buildResult(true, __('ArraySubs Stripe webhook endpoint already exists.', 'arraysubspro'), [
                'configured' => true,
                'created'    => false,
                'endpoint_id' => (string) ($endpoint['id'] ?? ''),
                'mode'        => $mode,
                'url'         => $url,
            ]);
        }

        if ('' === $stored_secret && ! empty($matching)) {
            foreach ($matching as $endpoint) {
                if (! empty($endpoint['id'])) {
                    self::deleteWebhookEndpoint((string) $endpoint['id']);
                }
            }
        }

        $created = self::createWebhookEndpoint($url);
        if (is_wp_error($created)) {
            return self::recordFailure($created->get_error_message(), $mode);
        }

        $secret = (string) ($created['secret'] ?? '');
        if ('' === $secret) {
            return self::recordFailure(
                __('Stripe did not return a webhook signing secret for the new endpoint.', 'arraysubspro'),
                $mode
            );
        }

        self::storeEndpointMetadata($created, $mode, $secret);

        return self::buildResult(true, __('ArraySubs Stripe webhook endpoint created.', 'arraysubspro'), [
            'configured'   => true,
            'created'      => true,
            'endpoint_id'  => (string) ($created['id'] ?? ''),
            'mode'         => $mode,
            'secret_saved' => true,
            'url'          => $url,
        ]);
    }

    /**
     * Get current Woo Stripe mode.
     *
     * @return string test|live
     */
    public static function getCurrentMode(): string
    {
        if (class_exists('\WC_Stripe_Mode')) {
            return \WC_Stripe_Mode::is_test() ? 'test' : 'live';
        }

        $settings = get_option('woocommerce_stripe_settings', []);
        $settings = is_array($settings) ? $settings : [];

        return 'yes' === (string) ($settings['testmode'] ?? 'no') ? 'test' : 'live';
    }

    /**
     * Get the endpoint URL.
     *
     * @return string
     */
    public static function getEndpointUrl(): string
    {
        return rest_url('arraysubs/v1/webhooks/arraysubs_stripe');
    }

    /**
     * Get stored status for the active webhook endpoint.
     *
     * @return array<string, mixed>
     */
    public static function getStoredStatus(): array
    {
        $mode    = self::getCurrentMode();
        $options = StripeSettingsTab::getOptions();

        return [
            'mode'           => $mode,
            'endpoint_id'    => StripeSettingsTab::getSecondaryWebhookEndpointId($mode),
            'url'            => (string) ($options[self::modeKey($mode, 'secondary_webhook_url')] ?? self::getEndpointUrl()),
            'secret_present' => '' !== StripeSettingsTab::getSecondaryWebhookSecret($mode),
            'last_error'     => (string) ($options[self::modeKey($mode, 'secondary_webhook_last_error')] ?? ''),
            'updated_at'     => (string) ($options[self::modeKey($mode, 'secondary_webhook_updated_at')] ?? ''),
        ];
    }

    /**
     * Get required Stripe events for the secondary endpoint.
     *
     * @return array<int, string>
     */
    public static function getRequiredEvents(): array
    {
        return [
            'payment_intent.succeeded',
            'payment_intent.payment_failed',
            'payment_intent.requires_action',
            'invoice.payment_succeeded',
            'invoice.payment_failed',
            'charge.succeeded',
            'charge.refunded',
            'charge.dispute.created',
            'charge.dispute.closed',
            'setup_intent.succeeded',
            'customer.source.expiring',
            'payment_method.updated',
            'payment_method.automatically_updated',
            'payment_method.card_automatically_updated',
        ];
    }

    /**
     * Check whether the active endpoint appears fully stored locally.
     *
     * @return bool
     */
    private static function isActiveEndpointStored(): bool
    {
        $mode = self::getCurrentMode();

        return '' !== StripeSettingsTab::getSecondaryWebhookSecret($mode)
            && '' !== StripeSettingsTab::getSecondaryWebhookEndpointId($mode);
    }

    /**
     * Set Woo Stripe API to the active mode before making Stripe API calls.
     *
     * @param string $mode Stripe mode.
     * @return void
     */
    private static function setWooStripeMode(string $mode): void
    {
        if (method_exists('\WC_Stripe_API', 'set_secret_key_for_mode')) {
            \WC_Stripe_API::set_secret_key_for_mode($mode);
        }
    }

    /**
     * Get the active Woo Stripe secret API key.
     *
     * @return string
     */
    private static function getActiveSecretKey(): string
    {
        if (method_exists('\WC_Stripe_API', 'get_secret_key')) {
            return trim((string) \WC_Stripe_API::get_secret_key());
        }

        $settings = get_option('woocommerce_stripe_settings', []);
        $settings = is_array($settings) ? $settings : [];
        $mode     = self::getCurrentMode();

        return trim((string) ($settings['test' === $mode ? 'test_secret_key' : 'secret_key'] ?? ''));
    }

    /**
     * List Stripe webhook endpoints for the active account/mode.
     *
     * @return array<int, array<string, mixed>>|\WP_Error
     */
    private static function listWebhookEndpoints()
    {
        $response = self::stripeRetrieve('webhook_endpoints?limit=100');
        if (is_wp_error($response)) {
            return $response;
        }

        return is_array($response['data'] ?? null) ? $response['data'] : [];
    }

    /**
     * Create a Stripe webhook endpoint.
     *
     * @param string $url Endpoint URL.
     * @return array<string, mixed>|\WP_Error
     */
    private static function createWebhookEndpoint(string $url)
    {
        $params = [
            'url'            => esc_url_raw($url),
            'enabled_events' => self::getRequiredEvents(),
            'description'    => 'ArraySubs secondary Stripe webhook',
        ];

        if (defined('WC_Stripe_API::STRIPE_API_VERSION')) {
            $params['api_version'] = \WC_Stripe_API::STRIPE_API_VERSION;
        }

        return self::stripeRequest($params, 'webhook_endpoints', 'POST');
    }

    /**
     * Delete a Stripe webhook endpoint.
     *
     * @param string $endpoint_id Endpoint ID.
     * @return array<string, mixed>|\WP_Error
     */
    private static function deleteWebhookEndpoint(string $endpoint_id)
    {
        return self::stripeRequest([], 'webhook_endpoints/' . rawurlencode($endpoint_id), 'DELETE');
    }

    /**
     * Filter endpoint list down to active ArraySubs endpoint URL matches.
     *
     * @param array<int, array<string, mixed>> $endpoints Endpoint list.
     * @param string                           $url       Endpoint URL.
     * @return array<int, array<string, mixed>>
     */
    private static function filterMatchingEndpoints(array $endpoints, string $url): array
    {
        return array_values(array_filter($endpoints, static function (array $endpoint) use ($url): bool {
            return $url === (string) ($endpoint['url'] ?? '')
                && 'deleted' !== (string) ($endpoint['status'] ?? '');
        }));
    }

    /**
     * Store endpoint metadata and signing secret.
     *
     * @param array<string, mixed> $endpoint Endpoint data.
     * @param string               $mode     Stripe mode.
     * @param string               $secret   Signing secret.
     * @return void
     */
    private static function storeEndpointMetadata(array $endpoint, string $mode, string $secret): void
    {
        $options = StripeSettingsTab::getOptions();

        $options[self::modeKey($mode, 'secondary_webhook_secret')]     = sanitize_text_field($secret);
        $options[self::modeKey($mode, 'secondary_webhook_endpoint_id')] = sanitize_text_field((string) ($endpoint['id'] ?? ''));
        $options[self::modeKey($mode, 'secondary_webhook_url')]         = esc_url_raw((string) ($endpoint['url'] ?? self::getEndpointUrl()));
        $options[self::modeKey($mode, 'secondary_webhook_updated_at')]  = current_time('mysql', true);
        unset($options[self::modeKey($mode, 'secondary_webhook_last_error')]);

        $options['secondary_webhook_secret']      = $options[self::modeKey($mode, 'secondary_webhook_secret')];
        $options['secondary_webhook_endpoint_id'] = $options[self::modeKey($mode, 'secondary_webhook_endpoint_id')];
        $options['secondary_webhook_url']         = $options[self::modeKey($mode, 'secondary_webhook_url')];
        $options['secondary_webhook_mode']        = $mode;

        update_option(StripeSettingsTab::OPTION_KEY, $options);
    }

    /**
     * Store last provisioning failure.
     *
     * @param string $message Error message.
     * @param string $mode    Stripe mode.
     * @return array<string, mixed>
     */
    private static function recordFailure(string $message, string $mode): array
    {
        $options = StripeSettingsTab::getOptions();
        $options[self::modeKey($mode, 'secondary_webhook_last_error')] = sanitize_text_field($message);
        update_option(StripeSettingsTab::OPTION_KEY, $options);

        return self::buildResult(false, $message, [
            'configured' => false,
            'mode'       => $mode,
            'url'        => self::getEndpointUrl(),
        ]);
    }

    /**
     * Retrieve from Stripe via Woo Stripe API.
     *
     * @param string $endpoint Endpoint path.
     * @return array<string, mixed>|\WP_Error
     */
    private static function stripeRetrieve(string $endpoint)
    {
        try {
            $response = \WC_Stripe_API::retrieve($endpoint);
        } catch (\Throwable $throwable) {
            return new \WP_Error('stripe_exception', $throwable->getMessage());
        }

        return self::normalizeStripeResponse($response);
    }

    /**
     * Request Stripe via Woo Stripe API.
     *
     * @param array<string, mixed> $params   Request params.
     * @param string               $endpoint Endpoint path.
     * @param string               $method   HTTP method.
     * @return array<string, mixed>|\WP_Error
     */
    private static function stripeRequest(array $params, string $endpoint, string $method)
    {
        try {
            $response = \WC_Stripe_API::request($params, $endpoint, $method);
        } catch (\Throwable $throwable) {
            return new \WP_Error('stripe_exception', $throwable->getMessage());
        }

        return self::normalizeStripeResponse($response);
    }

    /**
     * Normalize Stripe API response.
     *
     * @param mixed $response Stripe response.
     * @return array<string, mixed>|\WP_Error
     */
    private static function normalizeStripeResponse($response)
    {
        if (is_wp_error($response)) {
            return $response;
        }

        $data = json_decode(wp_json_encode($response), true);
        $data = is_array($data) ? $data : [];

        if (! empty($data['error']) && is_array($data['error'])) {
            return new \WP_Error(
                'stripe_api_error',
                (string) ($data['error']['message'] ?? __('Stripe API error.', 'arraysubspro')),
                $data['error']
            );
        }

        return $data;
    }

    /**
     * Build result payload.
     *
     * @param bool                 $success Success flag.
     * @param string               $message Message.
     * @param array<string, mixed> $extra   Extra result fields.
     * @return array<string, mixed>
     */
    private static function buildResult(bool $success, string $message, array $extra = []): array
    {
        return array_merge(
            [
                'success' => $success,
                'message' => $message,
            ],
            $extra
        );
    }

    /**
     * Build a mode-prefixed option key.
     *
     * @param string $mode Stripe mode.
     * @param string $key  Base key.
     * @return string
     */
    public static function modeKey(string $mode, string $key): string
    {
        return ('live' === $mode ? 'live' : 'test') . '_' . $key;
    }
}
