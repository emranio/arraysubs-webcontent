<?php

/**
 * Payment Logging Service
 *
 * Centralized logging for gateway operations. Adds subscription notes,
 * order notes, and WooCommerce logger entries with consistent formatting.
 *
 * @package ArraySubsPro\Features\AutomaticPayments\Services
 * @since 1.0.0
 */

namespace ArraySubsPro\Features\AutomaticPayments\Services;

defined('ABSPATH') || exit;

/**
 * Payment Logging Service
 */
class PaymentLoggingService
{
    /**
     * WC Logger source name.
     *
     * @var string
     */
    const LOG_SOURCE = 'arraysubs-gateway';

    /**
     * Log a gateway operation to the WooCommerce logger.
     *
     * @param string $gateway_slug The gateway slug.
     * @param string $level        Log level: debug, info, notice, warning, error, critical.
     * @param string $message      The log message.
     * @param array  $context      Additional context data.
     * @return void
     */
    public static function log(string $gateway_slug, string $level, string $message, array $context = []): void
    {
        if (! function_exists('wc_get_logger')) {
            return;
        }

        $formatted = sprintf('[Gateway: %s] %s', $gateway_slug, $message);

        $logger = wc_get_logger();
        $logger->log(
            $level,
            $formatted,
            array_merge($context, ['source' => self::LOG_SOURCE])
        );
    }

    /**
     * Log a webhook event.
     *
     * @param string $gateway_slug The gateway slug.
     * @param string $level        Log level.
     * @param string $message      The log message.
     * @return void
     */
    public static function logWebhook(string $gateway_slug, string $level, string $message): void
    {
        self::log($gateway_slug, $level, '[Webhook] ' . $message);
    }

    /**
     * Log a payment operation and add subscription note.
     *
     * @param string $gateway_slug    The gateway slug.
     * @param int    $subscription_id The subscription post ID.
     * @param string $message         The message.
     * @param string $level           Log level.
     * @return void
     */
    public static function logPayment(string $gateway_slug, int $subscription_id, string $message, string $level = 'info'): void
    {
        $formatted = sprintf('[Gateway: %s] %s', $gateway_slug, $message);

        self::log($gateway_slug, $level, $message);

        if ($subscription_id > 0 && function_exists('arraysubs_add_subscription_note')) {
            arraysubs_add_subscription_note($subscription_id, $formatted, 'private', 0, [], 'subscription');
        }
    }

    /**
     * Log a payment failure with subscription and order notes.
     *
     * @param string         $gateway_slug    The gateway slug.
     * @param int            $subscription_id The subscription post ID.
     * @param \WC_Order|null $order           The WooCommerce order.
     * @param string         $error_code      Error code.
     * @param string         $error_message   Error message.
     * @return void
     */
    public static function logPaymentFailure(
        string $gateway_slug,
        int $subscription_id,
        $order,
        string $error_code,
        string $error_message
    ): void {
        $note = sprintf(
            /* translators: 1: gateway slug, 2: error code, 3: error message */
            __('[Gateway: %1$s] Payment failed — %2$s: %3$s', 'arraysubspro'),
            esc_html($gateway_slug),
            esc_html($error_code),
            esc_html($error_message)
        );

        // Always log to WC logger (cheap and good for debugging).
        self::log($gateway_slug, 'error', $note);

        // De-duplicate the subscription note so a tight retry/webhook
        // loop does not spam the timeline. The same exact message within
        // the dedupe window is suppressed; a different error code or
        // message goes through.
        if ($subscription_id > 0 && function_exists('arraysubs_add_subscription_note')) {
            if (!self::recentDuplicateNote($subscription_id, $note)) {
                arraysubs_add_subscription_note($subscription_id, $note, 'private', 0, [], 'subscription');
            }
        }

        if ($order instanceof \WC_Order) {
            $order->add_order_note($note);
        }
    }

    /**
     * Whether an identical subscription note was added in the recent
     * past. Used by logPaymentFailure() to avoid duplicate failure notes
     * when a webhook + AS retry both fire for the same payment attempt.
     *
     * Window is short (60s) so legitimate "still failing on next retry"
     * notes a few minutes apart still appear.
     *
     * @param int    $subscription_id Subscription ID.
     * @param string $note            The candidate note text.
     * @param int    $window_seconds  Dedupe window. Default 60s.
     * @return bool True if the same note exists within the window.
     */
    private static function recentDuplicateNote(int $subscription_id, string $note, int $window_seconds = 60): bool
    {
        if (!function_exists('arraysubs_get_subscription_notes')) {
            return false;
        }

        $recent = arraysubs_get_subscription_notes($subscription_id, [
            'per_page' => 5,
            'page'     => 1,
            'orderby'  => 'date',
            'order'    => 'DESC',
        ]);

        if (empty($recent) || !is_array($recent)) {
            return false;
        }

        $cutoff = time() - max(1, $window_seconds);

        foreach ($recent as $existing_note) {
            if (!$existing_note instanceof \WP_Post) {
                continue;
            }
            $note_time = strtotime((string) $existing_note->post_date_gmt);
            if (!$note_time || $note_time < $cutoff) {
                continue;
            }
            // Compare on raw content; sanitization is consistent.
            if (trim((string) $existing_note->post_content) === trim($note)) {
                return true;
            }
        }

        return false;
    }
}
