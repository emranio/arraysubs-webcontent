<?php

/**
 * Payment Meta Normalizer
 *
 * Canonical lookup service for finding subscriptions and orders
 * across all meta key variants. Resolves relationships between
 * subscriptions and orders regardless of how they are stored.
 *
 * @package ArraySubsPro\Features\AutomaticPayments\Services
 * @since 1.0.0
 */

namespace ArraySubsPro\Features\AutomaticPayments\Services;

defined('ABSPATH') || exit;

/**
 * Payment Meta Normalizer Service
 */
class PaymentMetaNormalizer
{
    /**
     * Find subscription IDs linked to a WooCommerce order.
     *
     * @param int $order_id The WooCommerce order ID.
     * @return array Array of subscription post IDs.
     */
    public static function findSubscriptionIdsForOrder(int $order_id): array
    {
        $subscription_ids = [];

        $order = \wc_get_order($order_id);

        if ($order) {
            $order_subscription_ids = self::getPostMeta($order_id, '_subscription_ids');

            if (\is_array($order_subscription_ids)) {
                $subscription_ids = \array_merge($subscription_ids, \array_map('intval', $order_subscription_ids));
            }

            $direct_subscription_id = (int) $order->get_meta('_subscription_id', true);
            if ($direct_subscription_id > 0) {
                $subscription_ids[] = $direct_subscription_id;
            }

            $arraysubs_subscription_id = (int) $order->get_meta('_arraysubs_subscription_id', true);
            if ($arraysubs_subscription_id > 0) {
                $subscription_ids[] = $arraysubs_subscription_id;
            }

            foreach ($order->get_items() as $item) {
                $item_subscription_id = (int) $item->get_meta('_subscription_id', true);

                if ($item_subscription_id > 0) {
                    $subscription_ids[] = $item_subscription_id;
                }
            }
        }

        // Check parent order linkage on subscriptions.
        $by_order = self::getPosts([
            'post_type'   => 'arraysubs_data',
            'post_status' => 'any',
            'meta_query'  => [ // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
                [
                    'key'   => '_parent_order_id',
                    'value' => $order_id,
                ],
            ],
            'fields'      => 'ids',
            'numberposts' => 50,
        ]);

        if (! empty($by_order)) {
            $subscription_ids = \array_merge($subscription_ids, \array_map('intval', $by_order));
        }

        // Check _pending_renewal_order_id meta on subscriptions
        $by_renewal = self::getPosts([
            'post_type'   => 'arraysubs_data',
            'post_status' => 'any',
            'meta_query'  => [ // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
                [
                    'key'   => '_pending_renewal_order_id',
                    'value' => $order_id,
                ],
            ],
            'fields'      => 'ids',
            'numberposts' => 50,
        ]);

        if (! empty($by_renewal)) {
            $subscription_ids = \array_merge($subscription_ids, \array_map('intval', $by_renewal));
        }

        return \array_values(\array_unique(\array_filter(\array_map('intval', $subscription_ids))));
    }

    /**
     * Find the WooCommerce order linked to a subscription.
     *
     * @param int    $subscription_id The subscription post ID.
     * @param string $type            Order type: 'initial' or 'renewal'.
     * @return int Order ID or 0 if not found.
     */
    public static function findOrderForSubscription(int $subscription_id, string $type = 'initial'): int
    {
        if ('renewal' === $type) {
            $renewal_order = self::getPostMeta($subscription_id, '_pending_renewal_order_id');
            return $renewal_order ? (int) $renewal_order : 0;
        }

        $parent_order_id = self::getPostMeta($subscription_id, '_parent_order_id');
        if ($parent_order_id) {
            return (int) $parent_order_id;
        }

        $order_id = self::getPostMeta($subscription_id, '_order_id');
        if ($order_id) {
            return (int) $order_id;
        }

        $original_order_id = self::getPostMeta($subscription_id, '_original_order_id');
        if ($original_order_id) {
            return (int) $original_order_id;
        }

        $order_ids_json = self::getPostMeta($subscription_id, '_order_ids');
        $order_ids      = ! empty($order_ids_json) ? \json_decode($order_ids_json, true) : [];

        if (\is_array($order_ids) && ! empty($order_ids)) {
            return (int) \reset($order_ids);
        }

        return 0;
    }

    /**
     * Get the full gateway context for a subscription.
     *
     * @param int $subscription_id The subscription post ID.
     * @return array Gateway context data.
     */
    public static function getGatewayContext(int $subscription_id): array
    {
        return [
            'gateway_slug'        => self::getPostMeta($subscription_id, '_payment_gateway'),
            'customer_id'         => self::getPostMeta($subscription_id, '_gateway_customer_id'),
            'payment_method_id'   => self::getPostMeta($subscription_id, '_gateway_payment_method_id'),
            'session_id'          => self::getPostMeta($subscription_id, '_gateway_session_id'),
            'gateway_status'      => self::getPostMeta($subscription_id, '_gateway_status'),
            'transaction_id'      => self::getPostMeta($subscription_id, '_last_gateway_transaction_id'),
            'brand'               => self::getPostMeta($subscription_id, '_payment_method_brand'),
            'last4'               => self::getPostMeta($subscription_id, '_payment_method_last4'),
            'expiry_month'        => (int) self::getPostMeta($subscription_id, '_payment_method_expiry_month'),
            'expiry_year'         => (int) self::getPostMeta($subscription_id, '_payment_method_expiry_year'),
            'payment_method_type' => self::getPostMeta($subscription_id, '_payment_method_type'),
            'cancellation_source' => self::getPostMeta($subscription_id, '_cancellation_source'),
            'order_id'            => self::findOrderForSubscription($subscription_id),
        ];
    }

    /**
     * Find a subscription by gateway customer ID and gateway slug.
     *
     * @param string $gateway_customer_id The remote customer ID.
     * @param string $gateway_slug        The gateway slug.
     * @return int Subscription ID or 0 if not found.
     */
    public static function findSubscriptionByGatewayCustomer(string $gateway_customer_id, string $gateway_slug): int
    {
        $subscriptions = self::getPosts([
            'post_type'   => 'arraysubs_data',
            'post_status' => 'any',
            'meta_query'  => [ // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
                'relation' => 'AND',
                [
                    'key'   => '_gateway_customer_id',
                    'value' => $gateway_customer_id,
                ],
                [
                    'key'   => '_payment_gateway',
                    'value' => $gateway_slug,
                ],
            ],
            'fields'      => 'ids',
            'numberposts' => 1,
        ]);

        return ! empty($subscriptions) ? (int) $subscriptions[0] : 0;
    }

    /**
     * Find a subscription by gateway session ID.
     *
     * @param string $session_id The gateway checkout session ID.
     * @return int Subscription ID or 0 if not found.
     */
    public static function findSubscriptionByGatewaySession(string $session_id): int
    {
        $subscriptions = self::getPosts([
            'post_type'   => 'arraysubs_data',
            'post_status' => 'any',
            'meta_key'    => '_gateway_session_id', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
            'meta_value'  => $session_id, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
            'fields'      => 'ids',
            'numberposts' => 1,
        ]);

        return ! empty($subscriptions) ? (int) $subscriptions[0] : 0;
    }

    /**
     * Cross-resolve missing order/subscription/customer identifiers.
     *
     * @param array{subscription_id?: int, order_id?: int, customer_id?: int} $resolved Current IDs.
     * @return array{subscription_id: int, order_id: int, customer_id: int}
     */
    public function resolve(array $resolved): array
    {
        $result = [
            'subscription_id' => (int) ($resolved['subscription_id'] ?? 0),
            'order_id'        => (int) ($resolved['order_id'] ?? 0),
            'customer_id'     => (int) ($resolved['customer_id'] ?? 0),
        ];

        if ($result['subscription_id'] <= 0 && $result['order_id'] > 0) {
            $subscription_ids = self::findSubscriptionIdsForOrder($result['order_id']);

            if (! empty($subscription_ids)) {
                $result['subscription_id'] = (int) $subscription_ids[0];
            }
        }

        if ($result['order_id'] <= 0 && $result['subscription_id'] > 0) {
            $result['order_id'] = self::findOrderForSubscription($result['subscription_id'], 'renewal')
                ?: self::findOrderForSubscription($result['subscription_id'], 'initial');
        }

        if ($result['customer_id'] <= 0 && $result['subscription_id'] > 0) {
            $result['customer_id'] = (int) self::getPostMeta($result['subscription_id'], '_customer_id');
        }

        return $result;
    }

    /**
     * Read a single post meta value.
     *
     * @param int    $post_id  Post ID.
     * @param string $meta_key Meta key.
     * @return mixed
     */
    private static function getPostMeta(int $post_id, string $meta_key)
    {
        if (! \function_exists('get_post_meta')) {
            return '';
        }

        return \call_user_func('get_post_meta', $post_id, $meta_key, true);
    }

    /**
     * Query posts via a local wrapper for static-analysis safety.
     *
     * @param array $args Query arguments.
     * @return array
     */
    private static function getPosts(array $args): array
    {
        if (! \function_exists('get_posts')) {
            return [];
        }

        $posts = \call_user_func('get_posts', $args);

        return \is_array($posts) ? $posts : [];
    }
}
