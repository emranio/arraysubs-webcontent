<?php

/**
 * Gateway Registry
 *
 * Collects ArraySubs automatic payment gateways and delegates.
 *
 * @package ArraySubsPro\Features\AutomaticPayments\Services
 * @since 1.0.0
 */

namespace ArraySubsPro\Features\AutomaticPayments\Services;

defined('ABSPATH') || exit;

use ArraySubsPro\Features\AutomaticPayments\Abstracts\AbstractArraySubsGateway;
use ArraySubsPro\Features\AutomaticPayments\Contracts\AutomaticGatewayContract;

/**
 * Gateway Registry Service
 */
class GatewayRegistry
{
    /**
     * Cached gateway instances for current request.
     *
     * @var array<string, AutomaticGatewayContract>|null
     */
    private static ?array $cache = null;

    /**
     * Get all registered ArraySubs gateways.
     *
     * @return array<string, AutomaticGatewayContract>
     */
    public static function getAll(): array
    {
        if (null !== self::$cache) {
            return self::$cache;
        }

        self::$cache = [];

        $wc_gateways = \function_exists('WC') && \WC()->payment_gateways()
            ? \WC()->payment_gateways()->payment_gateways()
            : [];

        foreach ($wc_gateways as $gateway) {
            if ($gateway instanceof AbstractArraySubsGateway) {
                self::$cache[$gateway->id] = $gateway;
            }
        }

        /**
         * Register non-WooCommerce automatic gateway delegates.
         *
         * The first argument is intentionally passed by reference so delegates
         * can add themselves without maintaining a parallel global registry.
         *
         * @param array<string, AutomaticGatewayContract> $gateways Registered gateways.
         */
        $registered_gateways =& self::$cache;
        \call_user_func('do_action_ref_array', 'arraysubs_register_automatic_gateway', [&$registered_gateways]);

        return self::$cache;
    }

    /**
     * Get a specific ArraySubs gateway by slug.
     *
     * @param string $slug The gateway ID/slug.
     * @return AutomaticGatewayContract|null
     */
    public static function get(string $slug): ?AutomaticGatewayContract
    {
        $gateways = self::getAll();
        $normalized_slug = self::normalizeSlug($slug, $gateways);

        return $normalized_slug ? ($gateways[$normalized_slug] ?? null) : null;
    }

    /**
     * Check if a specific gateway is registered and enabled.
     *
     * @param string $slug The gateway ID/slug.
     * @return bool
     */
    public static function isRegistered(string $slug): bool
    {
        $gateway = self::get($slug);
        return null !== $gateway && $gateway->isGatewayEnabled();
    }

    /**
     * Check if any ArraySubs gateways are registered and enabled.
     *
     * @return bool
     */
    public static function hasEnabledGateways(): bool
    {
        foreach (self::getAll() as $gateway) {
            if ($gateway->isGatewayEnabled()) {
                return true;
            }
        }

        return false;
    }

    /**
     * Clear the cached gateway list.
     * Useful for testing or after gateway configuration changes.
     *
     * @return void
     */
    public static function clearCache(): void
    {
        self::$cache = null;
    }

    /**
     * Normalize a requested slug to a registered gateway ID.
     *
     * Supports current slugs such as `stripe` alongside legacy IDs like
     * older prefixed Stripe IDs.
     *
     * @param string                                  $slug     Requested slug.
     * @param array<string, AutomaticGatewayContract> $gateways Registered gateways.
     * @return string
     */
    private static function normalizeSlug(string $slug, array $gateways): string
    {
        $slug = self::sanitizeKey($slug);

        if (isset($gateways[$slug])) {
            return $slug;
        }

        if (0 === \strpos($slug, 'arraysubs_')) {
            $unprefixed_slug = \substr($slug, 10);
            return isset($gateways[$unprefixed_slug]) ? $unprefixed_slug : '';
        }

        $prefixed_slug = 'arraysubs_' . $slug;

        return isset($gateways[$prefixed_slug]) ? $prefixed_slug : '';
    }

    /**
     * Sanitize a gateway key using WordPress when available.
     *
     * @param string $value Raw key value.
     * @return string
     */
    private static function sanitizeKey(string $value): string
    {
        if (! \function_exists('sanitize_key')) {
            return \strtolower(\preg_replace('/[^a-z0-9_\-]/', '', $value) ?? '');
        }

        return (string) \call_user_func('sanitize_key', $value);
    }
}
