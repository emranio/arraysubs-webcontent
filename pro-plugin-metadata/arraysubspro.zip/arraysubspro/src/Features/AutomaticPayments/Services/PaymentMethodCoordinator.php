<?php

/**
 * Payment Method Coordinator
 *
 * Handles payment method display, update flows, and gateway delegation
 * for the customer portal and admin views.
 *
 * @package ArraySubsPro\Features\AutomaticPayments\Services
 * @since 1.0.0
 */

namespace ArraySubsPro\Features\AutomaticPayments\Services;

defined('ABSPATH') || exit;

/**
 * Payment Method Coordinator Service
 */
class PaymentMethodCoordinator
{
    /**
     * Get formatted payment method display data for a subscription.
     *
     * @param int $subscription_id The subscription post ID.
     * @return array|null Payment method display data or null if no gateway.
     */
    public static function getDisplayData(int $subscription_id): ?array
    {
        $gateway = GatewayResolver::resolveForSubscription($subscription_id);

        if (! $gateway) {
            return null;
        }

        return $gateway->formatPaymentMethodForDisplay($subscription_id);
    }

    /**
     * Get the payment method update mechanism for a subscription.
     *
     * @param int   $subscription_id The subscription post ID.
     * @param array $context         Update context (customer_id, return_url).
     * @return array|null Update mechanism data or null if not supported.
     */
    public static function getUpdateMechanism(int $subscription_id, array $context = []): ?array
    {
        $gateway = GatewayResolver::resolveForSubscription($subscription_id);

        if (! $gateway) {
            return null;
        }

        if (! $gateway->supportsSubscriptionCapability('payment_method_update')) {
            return null;
        }

        return $gateway->getPaymentMethodUpdateMechanism($subscription_id, $context);
    }

    /**
     * Check if a subscription's payment method can be updated by the customer.
     *
     * @param int $subscription_id The subscription post ID.
     * @return bool
     */
    public static function canUpdatePaymentMethod(int $subscription_id): bool
    {
        if (! self::isPaymentMethodUpdateLifecycleAllowed($subscription_id)) {
            return false;
        }

        $gateway = GatewayResolver::resolveForSubscription($subscription_id);

        if (! $gateway) {
            return false;
        }

        return $gateway->supportsSubscriptionCapability('payment_method_update');
    }

    /**
     * Check whether the subscription lifecycle allows customer payment method updates.
     *
     * @param int $subscription_id The subscription post ID.
     * @return bool
     */
    private static function isPaymentMethodUpdateLifecycleAllowed(int $subscription_id): bool
    {
        $subscription = function_exists('arraysubs_get_subscription')
            ? arraysubs_get_subscription($subscription_id)
            : get_post($subscription_id);

        if (! $subscription instanceof \WP_Post) {
            return false;
        }

        $allowed_statuses = [
            'arraysubs-active',
            'arraysubs-on-hold',
            'arraysubs-trial',
        ];

        if (! in_array($subscription->post_status, $allowed_statuses, true)) {
            return false;
        }

        return '' === (string) get_post_meta($subscription_id, '_waiting_cancellation', true);
    }

    /**
     * Check if a payment method is expired.
     *
     * @param int $subscription_id The subscription post ID.
     * @return bool
     */
    public static function isPaymentMethodExpired(int $subscription_id): bool
    {
        $expiry_month = (int) get_post_meta($subscription_id, '_payment_method_expiry_month', true);
        $expiry_year  = (int) get_post_meta($subscription_id, '_payment_method_expiry_year', true);

        if (0 === $expiry_month || 0 === $expiry_year) {
            return false;
        }

        // Normalize 2-digit year to 4-digit.
        if ($expiry_year > 0 && $expiry_year < 100) {
            $expiry_year += 2000;
        }

        $now           = new \DateTimeImmutable('now', wp_timezone());
        $current_month = (int) $now->format('n');
        $current_year  = (int) $now->format('Y');

        if ($expiry_year < $current_year) {
            return true;
        }

        if ($expiry_year === $current_year && $expiry_month < $current_month) {
            return true;
        }

        return false;
    }
}
