<?php

/**
 * Automatic Payments Hooks
 *
 * WordPress lifecycle integration for the gateway system.
 * Registers gateways via WooCommerce, responds to core filters,
 * listens to core subscription lifecycle hooks.
 *
 * @package ArraySubsPro\Features\AutomaticPayments\Services
 * @since 1.0.0
 */

namespace ArraySubsPro\Features\AutomaticPayments\Services;

defined('ABSPATH') || exit;

use ArraySubs\Supports\ActionScheduler;
use ArraySubsPro\Features\AutomaticPayments\Gateways\Stripe\StripeDelegate;

/**
 * Automatic Payments Hooks
 */
class Hooks
{
    /**
     * Enable auto-loading via AbstractLoader.
     *
     * @var bool
     */
    public static $loadable = true;

    /**
     * Initialize hooks.
     */
    public function __construct()
    {
        // Run database migrations
        add_action('init', [DatabaseMigration::class, 'maybeRunMigrations']);

        new StripeDelegate();

        // ─── Gateway Registration via WooCommerce ────────────────────────
        add_filter('woocommerce_payment_gateways', [$this, 'registerGateways']);

        // ─── Core Filter Responses ───────────────────────────────────────
        add_filter('arraysubs_is_automatic_payment', [$this, 'filterIsAutomaticPayment'], 10, 2);
        add_filter('arraysubs_should_process_automatic_payment', [$this, 'filterShouldProcessPayment'], 10, 3);
        add_filter('arraysubs_has_automatic_gateways', [$this, 'filterHasAutomaticGateways']);
        add_filter('arraysubs_subscription_supports_retention_offers', [$this, 'filterRetentionOfferSupport'], 10, 3);
        add_filter('arraysubs_pre_retry_charge_verification', [$this, 'filterPreRetryChargeVerification'], 10, 3);
        add_filter('arraysubs_gateway_sync_subscription', [$this, 'filterGatewaySyncSubscription'], 10, 2);

        // ─── Core Subscription Lifecycle Hooks ───────────────────────────
        add_filter('arraysubs_process_automatic_renewal_payment', [$this, 'processAutomaticRenewalPayment'], 10, 3);
        add_action('arraysubs_data_cancelled', [$this, 'onSubscriptionCancelled'], 10, 3);

        // Webhook-independent gateway context capture. The free plugin
        // fires this synchronously when a paid order is linked to a
        // subscription (initial or renewal). Mirroring the webhook capture
        // here ensures the gateway customer/PM IDs are persisted on the
        // subscription even if the webhook is delayed or missed.
        add_action('arraysubs_gateway_context_captured', [$this, 'onGatewayContextCaptured'], 10, 3);
        add_action('arraysubs_data_cancelled_overdue', [$this, 'onSubscriptionCancelledOverdue'], 10, 2);
        add_action('arraysubs_gateway_subscription_cancelled', [$this, 'onGatewaySubscriptionCancelled'], 10, 2);

        // Pending cancellation gateway-side handling (PayPal/Paddle): the
        // free-plugin layers prevent the local renewal pipeline from charging,
        // but for gateway-controlled subscriptions (PayPal billing agreements,
        // Paddle subscriptions) the gateway runs its own billing schedule and
        // would still charge during the pending-cancel window unless told to
        // stop. Stripe is plugin-controlled and is already covered by the
        // free-plugin layers.
        add_action('arraysubs_data_waiting_cancellation', [$this, 'onPendingCancellationScheduled'], 10, 2);
        add_action('arraysubs_data_cancellation_undone', [$this, 'onPendingCancellationUndone'], 10, 1);

        // Future lifecycle hooks (wired now, core will fire them when features are implemented)
        add_action('arraysubs_subscription_paused', [$this, 'onSubscriptionPaused'], 10, 2);
        add_action('arraysubs_subscription_resumed', [$this, 'onSubscriptionResumed'], 10, 2);
        add_action('arraysubs_plan_switch_completed', [$this, 'onPlanSwitchCompleted'], 10, 4);

        // ─── Scheduled Jobs ──────────────────────────────────────────────
        add_action(ActionScheduler::HOOK_CLEANUP_WEBHOOK_EVENTS, [$this, 'cleanupWebhookEvents']);
        add_action(ActionScheduler::HOOK_GATEWAY_RECONCILE, [$this, 'reconcileGateways']);

        // Schedule recurring cleanup job only after Action Scheduler is initialized.
        \add_action('action_scheduler_init', [$this, 'scheduleRecurringJobs'], 20);
    }

	// ─── Gateway Registration ────────────────────────────────────────────

    /**
     * Register ArraySubs payment gateways with WooCommerce.
     * Concrete gateway classes are added here as they are implemented (Phase D+).
     *
     * @param array $gateways Existing WC gateways.
     * @return array
     */
    public function registerGateways(array $gateways): array
    {
        $gateways[] = \ArraySubsPro\Features\AutomaticPayments\Gateways\Paddle\PaddleGateway::class;
        $gateways[] = \ArraySubsPro\Features\AutomaticPayments\Gateways\PayPal\PayPalGateway::class;

        return $gateways;
    }

	// ─── Filter Responses ────────────────────────────────────────────────

    /**
     * Respond to arraysubs_is_automatic_payment filter.
     * Returns true if the subscription has a registered and enabled gateway.
     *
     * @param bool $is_automatic Current filter value.
     * @param int  $subscription_id The subscription post ID.
     * @return bool
     */
    public function filterIsAutomaticPayment(bool $is_automatic, int $subscription_id): bool
    {
        if ($is_automatic) {
            return true;
        }

        $gateway_slug = get_post_meta($subscription_id, '_payment_gateway', true);

        if (empty($gateway_slug)) {
            return false;
        }

        return GatewayRegistry::isRegistered($gateway_slug);
    }

    /**
     * Respond to arraysubs_should_process_automatic_payment filter.
     * Validates that the gateway is available and the subscription has valid tokens.
     *
     * @param bool      $should_process Current filter value.
     * @param int       $subscription_id The subscription post ID.
     * @param \WC_Order $order          The renewal order.
     * @return bool
     */
    public function filterShouldProcessPayment(bool $should_process, int $subscription_id, $order): bool
    {
        if (! $should_process) {
            return false;
        }

        $gateway = GatewayResolver::resolveForSubscription($subscription_id);

        if (! $gateway) {
            PaymentLoggingService::logPayment(
                'unknown',
                $subscription_id,
                'Cannot process automatic payment: gateway not found or disabled',
                'warning'
            );
            return false;
        }

        // Check if customer has disabled auto-renew for this subscription
        if (
            function_exists('arraysubs_is_auto_renew_enabled')
            && ! arraysubs_is_auto_renew_enabled($subscription_id)
        ) {
            PaymentLoggingService::logPayment(
                $gateway->getGatewaySlug(),
                $subscription_id,
                'Automatic payment skipped: customer disabled auto-renew. Falling back to manual renewal invoice.',
                'info'
            );
            return false;
        }

        // Only an active gateway billing context should auto-charge renewals.
        $gateway_status = strtolower((string) get_post_meta($subscription_id, '_gateway_status', true));
        if (! empty($gateway_status) && 'active' !== $gateway_status) {
            PaymentLoggingService::logPayment(
                $gateway->getGatewaySlug(),
                $subscription_id,
                sprintf('Cannot process automatic payment: gateway status is %s', $gateway_status),
                'warning'
            );
            return false;
        }

        // Check that payment method is stored
        $pm_id = get_post_meta($subscription_id, '_gateway_payment_method_id', true);
        if (empty($pm_id)) {
            PaymentLoggingService::logPayment(
                $gateway->getGatewaySlug(),
                $subscription_id,
                'Cannot process automatic payment: no payment method stored',
                'warning'
            );
            return false;
        }

        return true;
    }

    /**
     * Respond to arraysubs_has_automatic_gateways filter.
     *
     * @param bool $has_gateways Current filter value.
     * @return bool
     */
    public function filterHasAutomaticGateways(bool $has_gateways): bool
    {
        if ($has_gateways) {
            return true;
        }

        return GatewayRegistry::hasEnabledGateways();
    }

    /**
     * Check whether an automatic-payment subscription supports retention offers.
     *
     * Current support matrix:
     * - Manual renewals: supported in core (handled before this filter runs)
     * - Stripe: supported
     * - PayPal/Paddle: unsupported
     *
     * @param bool   $supports        Current support state.
     * @param int    $subscription_id Subscription post ID.
     * @param string $gateway_slug    Resolved gateway slug.
     * @return bool
     */
    public function filterRetentionOfferSupport(bool $supports, int $subscription_id, string $gateway_slug): bool
    {
        if ($supports) {
            return true;
        }

        $gateway = GatewayRegistry::get($gateway_slug);

        if (! $gateway || ! $gateway->isGatewayEnabled()) {
            return false;
        }

        return $gateway->supportsSubscriptionCapability('retention_amount_update');
    }

    /**
     * Delegate the pre-retry charge verification to the resolved gateway. If
     * any earlier filter already determined the customer was charged (e.g.
     * test fixtures), short-circuit.
     *
     * @param array     $verification Current verification result.
     * @param int       $subscription_id Subscription ID.
     * @param \WC_Order $order           Renewal order.
     * @return array
     */
    /**
     * Reconcile a subscription's local state with the gateway's authoritative
     * state. Triggered by the admin "Sync from Gateway" action.
     *
     * Reads via the gateway's `syncFromGateway()` method and applies safe
     * corrections to local meta. Reports the diff so the admin sees what
     * changed.
     *
     * @param array $result          Default result from the free plugin.
     * @param int   $subscription_id Subscription ID.
     * @return array
     */
    public function filterGatewaySyncSubscription(array $result, int $subscription_id): array
    {
        $gateway = GatewayResolver::resolveForSubscription($subscription_id);

        if (! $gateway) {
            return $result;
        }

        $capabilities = $gateway->getSubscriptionCapabilities();
        if (empty($capabilities['supports_sync'])) {
            return [
                'success'  => false,
                'changes'  => [],
                'message'  => __('This gateway does not support subscription sync.', 'arraysubspro'),
                'gateway'  => $gateway->getGatewaySlug(),
            ];
        }

        $gateway_slug = $gateway->getGatewaySlug();
        $state        = $gateway->syncFromGateway($subscription_id);

        if (empty($state['success'])) {
            return [
                'success'  => false,
                'changes'  => [],
                'message'  => $state['message'] ?? __('Gateway sync failed.', 'arraysubspro'),
                'gateway'  => $gateway_slug,
            ];
        }

        $changes = [];

        // Reconcile gateway status (active/paused/inactive).
        $remote_status = (string) ($state['gateway_status'] ?? '');
        if ('' !== $remote_status) {
            $local_status = (string) get_post_meta($subscription_id, '_gateway_status', true);
            if ($remote_status !== $local_status) {
                update_post_meta($subscription_id, '_gateway_status', $remote_status);
                $changes[] = sprintf('gateway_status: %s → %s', $local_status ?: '(empty)', $remote_status);
            }
        }

        // Reconcile next payment date when the gateway reports one.
        $remote_next = (string) ($state['next_payment_date'] ?? '');
        if ('' !== $remote_next) {
            $local_next = (string) get_post_meta($subscription_id, '_next_payment_date', true);
            if ($remote_next !== $local_next) {
                update_post_meta($subscription_id, '_next_payment_date', $remote_next);
                $changes[] = sprintf('next_payment_date: %s → %s', $local_next ?: '(empty)', $remote_next);
            }
        }

        // Reconcile payment method display fields.
        $pm = $state['payment_method'] ?? [];
        if (is_array($pm) && ! empty($pm)) {
            $pm_keys = [
                '_payment_method_brand'        => $pm['brand'] ?? '',
                '_payment_method_last4'        => $pm['last4'] ?? '',
                '_payment_method_expiry_month' => $pm['expiry_month'] ?? '',
                '_payment_method_expiry_year'  => $pm['expiry_year'] ?? '',
            ];
            foreach ($pm_keys as $meta_key => $remote_value) {
                $remote_value = (string) $remote_value;
                if ('' === $remote_value) {
                    continue;
                }
                $local_value = (string) get_post_meta($subscription_id, $meta_key, true);
                if ($remote_value !== $local_value) {
                    update_post_meta($subscription_id, $meta_key, sanitize_text_field($remote_value));
                    $changes[] = sprintf('%s: %s → %s', $meta_key, $local_value ?: '(empty)', $remote_value);
                }
            }
        }

        // Reconcile recent charges: for any charge that succeeded at the
        // gateway but our matching renewal order is still failed/pending, mark
        // it paid. This is the missed-webhook recovery path.
        $reconciled_orders = [];
        $charges           = $state['recent_charges'] ?? [];
        if (is_array($charges)) {
            foreach ($charges as $charge) {
                if (empty($charge['order_id']) || (string) ($charge['status'] ?? '') !== 'succeeded') {
                    continue;
                }
                $order = wc_get_order((int) $charge['order_id']);
                if (! $order instanceof \WC_Order) {
                    continue;
                }
                if ($order->is_paid()) {
                    continue;
                }
                $tx = (string) ($charge['transaction_id'] ?? '');
                $order->add_order_note(sprintf(
                    /* translators: 1: gateway slug, 2: transaction id */
                    __('Reconciled from %1$s gateway sync — charge %2$s succeeded but local order was not paid (likely missed webhook).', 'arraysubspro'),
                    $gateway_slug,
                    $tx
                ));
                $order->payment_complete($tx);
                $reconciled_orders[] = $order->get_id();
            }
        }
        if (! empty($reconciled_orders)) {
            $changes[] = 'reconciled_orders: ' . implode(', ', $reconciled_orders);
        }

        PaymentLoggingService::logPayment(
            $gateway_slug,
            $subscription_id,
            empty($changes)
                ? 'Gateway sync completed: no changes required.'
                : sprintf('Gateway sync applied %d change(s): %s', count($changes), implode('; ', $changes))
        );

        return [
            'success' => true,
            'changes' => $changes,
            'message' => empty($changes)
                ? __('Local state already matches gateway. No changes were applied.', 'arraysubspro')
                : sprintf(
                    /* translators: %d: number of changes applied */
                    _n('%d change applied from gateway state.', '%d changes applied from gateway state.', count($changes), 'arraysubspro'),
                    count($changes)
                ),
            'gateway' => $gateway_slug,
        ];
    }

    public function filterPreRetryChargeVerification(array $verification, int $subscription_id, $order): array
    {
        if (! empty($verification['charged'])) {
            return $verification;
        }

        if (! $order instanceof \WC_Order) {
            return $verification;
        }

        $gateway = GatewayResolver::resolveForSubscription($subscription_id);
        if (! $gateway) {
            return $verification;
        }

        $result = $gateway->verifyRecentChargeForOrder($subscription_id, $order);

        // Always merge so callers see the gateway's diagnostic message even
        // when no charge was found.
        return array_merge($verification, $result);
    }

	// ─── Subscription Lifecycle Handlers ─────────────────────────────────

    /**
     * Handle automatic renewal payment.
     *
     * Core calls this filter when auto payment is detected. Returning a
     * structured result lets core decide whether the order is paid, pending
     * customer action, or failed.
     *
     * @param array     $result          Existing filter result.
     * @param int       $subscription_id The subscription post ID.
     * @param \WC_Order $order           The renewal order.
     * @return array Payment result.
     */
    public function processAutomaticRenewalPayment(array $result, int $subscription_id, $order): array
    {
        if (! $order instanceof \WC_Order) {
            PaymentLoggingService::logPayment(
                'unknown',
                $subscription_id,
                'Automatic renewal failed: invalid order object',
                'error'
            );

            return $this->failedAutomaticRenewalResult(__('Invalid renewal order.', 'arraysubspro'), $order, 'invalid_order');
        }

        $gateway = GatewayResolver::resolveForSubscription($subscription_id);

        if (! $gateway) {
            PaymentLoggingService::logPayment(
                'unknown',
                $subscription_id,
                'Automatic renewal failed: no gateway found for subscription',
                'error'
            );

            return $this->failedAutomaticRenewalResult(__('Payment gateway is not available or configured.', 'arraysubspro'), $order, 'gateway_unavailable');
        }

        try {
            $payment_result = $gateway->processRenewalPayment($subscription_id, $order);
        } catch (\Exception $e) {
            PaymentLoggingService::logPaymentFailure(
                $gateway->getGatewaySlug(),
                $subscription_id,
                $order,
                'renewal_exception',
                $e->getMessage()
            );

            return $this->failedAutomaticRenewalResult($e->getMessage(), $order, 'exception');
        }

        if (! empty($payment_result['success'])) {
            return $this->successfulAutomaticRenewalResult($payment_result, $order);
        }

        $error_message = $payment_result['message'] ?? __('Unknown payment error', 'arraysubspro');

        PaymentLoggingService::logPaymentFailure(
            $gateway->getGatewaySlug(),
            $subscription_id,
            $order,
            $payment_result['error_code'] ?? 'renewal_failed',
            $error_message
        );

        return $this->failedAutomaticRenewalResult(
            $error_message,
            $order,
            $payment_result['error_code'] ?? 'payment_failed',
            $payment_result
        );
    }

    /**
     * Handle automatic renewal action calls from manual invocations.
     *
     * @param int       $subscription_id Subscription ID.
     * @param \WC_Order $order           Renewal order.
     * @return void
     */
    public function handleAutomaticRenewal(int $subscription_id, $order): void
    {
        $this->processAutomaticRenewalPayment([], $subscription_id, $order);
    }

    /**
     * Normalize a successful automatic renewal result.
     *
     * @param array     $payment_result Gateway result.
     * @param \WC_Order $order          Renewal order.
     * @return array Normalized result.
     */
    private function successfulAutomaticRenewalResult(array $payment_result, $order): array
    {
        $status = $order instanceof \WC_Order && $order->is_paid() ? 'paid' : 'pending';

        // The gateway accepted the request, but until the order is actually
        // paid we cannot claim the money was captured. Distinguish the two
        // states so any UI surfacing this message does not flash "Success"
        // before a webhook / off-session confirmation has landed.
        $message = 'paid' === $status
            ? __('Renewal payment captured.', 'arraysubspro')
            : __('Renewal charge submitted to gateway; awaiting confirmation.', 'arraysubspro');

        return array_merge([
            'success'                 => true,
            'status'                  => $status,
            'message'                 => $message,
            'order_id'                => $order instanceof \WC_Order ? $order->get_id() : 0,
            'requires_manual_payment' => false,
            'payment_mode'            => 'automatic',
        ], $payment_result, ['status' => $status]);
    }

    /**
     * Normalize a failed automatic renewal result.
     *
     * @param string    $message        Failure message.
     * @param \WC_Order $order          Renewal order.
     * @param string    $error_code     Error code.
     * @param array     $payment_result Raw gateway result.
     * @return array Normalized result.
     */
    private function failedAutomaticRenewalResult(string $message, $order, string $error_code = 'payment_failed', array $payment_result = []): array
    {
        $status = ! empty($payment_result['requires_action']) ? 'requires_action' : 'failed';

        return array_merge([
            'success'                 => false,
            'status'                  => $status,
            'error_code'              => $error_code,
            'message'                 => $message,
            'order_id'                => $order instanceof \WC_Order ? $order->get_id() : 0,
            'requires_action'         => ! empty($payment_result['requires_action']),
            'requires_manual_payment' => false,
            'payment_mode'            => 'automatic',
        ], $payment_result, ['status' => $status, 'message' => $message]);
    }

    /**
     * Handle subscription cancellation — clean up remote billing context.
     *
     * @param int      $subscription_id The subscription post ID.
     * @param \WP_Post $subscription    Subscription post.
     * @param string   $cancel_type     Cancellation type.
     * @return void
     */
    public function onSubscriptionCancelled(int $subscription_id, \WP_Post $subscription, string $cancel_type): void
    {
        $this->cleanupRemoteBillingContext($subscription_id, 'cancelled');
    }

    /**
     * Handle overdue subscription cancellation.
     *
     * @param int   $subscription_id The subscription post ID.
     * @param mixed $data            Subscription data.
     * @return void
     */
    public function onSubscriptionCancelledOverdue(int $subscription_id, $data = null): void
    {
        $this->cleanupRemoteBillingContext($subscription_id, 'cancelled_overdue');
    }

    /**
     * Handle explicit remote-billing cancellation requests from core flows such
     * as auto-downgrade before the subscription is switched back to a manual
     * renewal model.
     *
     * @param int    $subscription_id The subscription post ID.
     * @param string $gateway_slug    Gateway slug passed by core.
     * @return void
     */
    public function onGatewaySubscriptionCancelled(int $subscription_id, string $gateway_slug = ''): void
    {
        $this->cleanupRemoteBillingContext($subscription_id, 'gateway_cancelled');
    }

    /**
     * Handle a scheduled (end-of-period) cancellation.
     *
     * Stripe is plugin-controlled — the free plugin's renewal-pipeline layers
     * already block charges during the pending-cancel window, so no gateway
     * call is needed.
     *
     * Paddle natively supports a reversible cancel-at-period-end via
     * `effective_from='next_billing_period'`. We use that.
     *
     * PayPal does not support scheduling a cancel; cancelling its billing
     * agreement is terminal. To avoid a double charge during the pending-cancel
     * window we cancel the agreement immediately. The local subscription stays
     * active until the scheduled date. If the customer undoes the cancellation
     * a clear note is added explaining that auto-renewal must be re-authorized.
     *
     * Hook signature: arraysubs_data_waiting_cancellation ($subscription_id, $reason)
     *
     * The actor (`_cancelled_by`) is read from subscription meta which is
     * populated by the canonical helper before this action fires. The
     * second action argument is the cancellation reason, not the actor.
     *
     * @param int    $subscription_id The subscription ID.
     * @param string $reason          Cancellation reason text (informational).
     * @return void
     */
    public function onPendingCancellationScheduled(int $subscription_id, string $reason = ''): void
    {
        $gateway = GatewayResolver::resolveForSubscription($subscription_id);

        if (! $gateway) {
            return;
        }

        // Avoid acting twice if the gateway was already cancelled (e.g. by an
        // admin who clicked schedule then immediate-cancel within the same
        // session, or by a webhook echo).
        $already_handled = get_post_meta($subscription_id, '_gateway_pending_cancel_handled', true);
        if (! empty($already_handled)) {
            return;
        }

        // Plugin-controlled gateways (Stripe today): the free plugin's renewal
        // pipeline already blocks charges during pending-cancel via Action
        // Scheduler unschedule + the `arraysubs_should_generate_renewal_invoice`
        // filter. There is no remote billing schedule to stop.
        $supports_period_end = $gateway->supportsSubscriptionCapability('cancel_at_period_end');
        $has_remote_billing  = $this->hasRemoteBillingAgreement($gateway, $subscription_id);

        if (! $supports_period_end && ! $has_remote_billing) {
            return;
        }

        if (TwoWaySyncGuard::wasInitiatedLocally('cancel', $subscription_id)) {
            return;
        }

        TwoWaySyncGuard::markInitiated('cancel', $subscription_id);

        // Read the actual actor from canonical meta (set by the helper
        // before this action fires).
        $cancelled_by = (string) get_post_meta($subscription_id, '_cancelled_by', true);

        // Paddle: cancel at next billing period (reversible).
        if ($supports_period_end) {
            $result = $gateway->cancelRemoteBillingContext($subscription_id, [
                'reason'         => 'scheduled_end_of_period',
                'source'         => $cancelled_by ?: 'system',
                'effective_from' => 'next_billing_period',
            ]);

            if (! empty($result['success'])) {
                update_post_meta($subscription_id, '_gateway_pending_cancel_handled', 'scheduled');
                update_post_meta($subscription_id, '_gateway_pending_cancel_handled_at', current_time('mysql', true));

                PaymentLoggingService::logPayment(
                    $gateway->getGatewaySlug(),
                    $subscription_id,
                    'Gateway scheduled to cancel at next billing period.'
                );
                return;
            }

            PaymentLoggingService::logPayment(
                $gateway->getGatewaySlug(),
                $subscription_id,
                sprintf('Failed to schedule gateway cancellation: %s', $result['message'] ?? 'unknown error'),
                'error'
            );
            return;
        }

        // PayPal (gateway-controlled, non-reversible): cancel the billing
        // agreement immediately. The local subscription stays active until the
        // scheduled date. Auto-renew is set to off so the local pipeline never
        // tries to charge a cancelled agreement.
        $result = $gateway->cancelRemoteBillingContext($subscription_id, [
            'reason' => 'scheduled_end_of_period',
            'source' => $cancelled_by ?: 'system',
        ]);

        if (! empty($result['success'])) {
            update_post_meta($subscription_id, '_gateway_pending_cancel_handled', 'cancelled_eagerly');
            update_post_meta($subscription_id, '_gateway_pending_cancel_handled_at', current_time('mysql', true));
            update_post_meta($subscription_id, '_auto_renew', 'off');

            PaymentLoggingService::logPayment(
                $gateway->getGatewaySlug(),
                $subscription_id,
                'Gateway billing agreement cancelled immediately to prevent charges during pending-cancel window. Auto-renew disabled locally.'
            );
            return;
        }

        PaymentLoggingService::logPayment(
            $gateway->getGatewaySlug(),
            $subscription_id,
            sprintf('Failed to cancel gateway billing agreement during pending-cancel: %s', $result['message'] ?? 'unknown error'),
            'error'
        );
    }

    /**
     * Handle reversal of a scheduled cancellation.
     *
     * For gateways where the gateway-side cancellation was reversible (Paddle),
     * reverse it. For non-reversible gateways (PayPal) log a clear note that
     * the customer must re-authorize auto-renewal.
     *
     * @param int $subscription_id The subscription ID.
     * @return void
     */
    public function onPendingCancellationUndone(int $subscription_id): void
    {
        $handled = (string) get_post_meta($subscription_id, '_gateway_pending_cancel_handled', true);

        if ('' === $handled) {
            return;
        }

        $gateway = GatewayResolver::resolveForSubscription($subscription_id);

        delete_post_meta($subscription_id, '_gateway_pending_cancel_handled');
        delete_post_meta($subscription_id, '_gateway_pending_cancel_handled_at');

        if (! $gateway) {
            return;
        }

        if ('scheduled' === $handled && $gateway->supportsSubscriptionCapability('cancel_at_period_end_reversible')) {
            $result = $gateway->restoreScheduledCancel($subscription_id);

            if (! empty($result['success'])) {
                PaymentLoggingService::logPayment(
                    $gateway->getGatewaySlug(),
                    $subscription_id,
                    'Gateway scheduled cancellation reversed; renewals will resume on the original schedule.'
                );
                return;
            }

            PaymentLoggingService::logPayment(
                $gateway->getGatewaySlug(),
                $subscription_id,
                sprintf('Failed to reverse gateway scheduled cancellation: %s. Customer may need to update payment method.', $result['message'] ?? 'unknown error'),
                'error'
            );
            return;
        }

        if ('cancelled_eagerly' === $handled) {
            // PayPal-style: gateway billing agreement is gone for good. Mark
            // the gateway inactive and leave a clear note. Auto-renew remains
            // off so the local pipeline does not attempt automatic charges.
            update_post_meta($subscription_id, '_gateway_status', 'inactive');

            PaymentLoggingService::logPayment(
                $gateway->getGatewaySlug(),
                $subscription_id,
                'Cancellation undone, but the gateway billing agreement was already cancelled and cannot be reactivated. The customer must re-authorize automatic payments to resume auto-renewal.',
                'warning'
            );
        }
    }

    /**
     * Handle subscription paused.
     * Calls pauseRemoteBillingContext() on the gateway if it supports pause.
     *
     * @param int   $subscription_id The subscription post ID.
     * @param mixed $data            Subscription data.
     * @return void
     */
    public function onSubscriptionPaused(int $subscription_id, $data = null): void
    {
        $gateway = GatewayResolver::resolveForSubscription($subscription_id);

        if (! $gateway || ! $gateway->supportsSubscriptionCapability('pause')) {
            return;
        }

        if (TwoWaySyncGuard::wasInitiatedLocally('pause', $subscription_id)) {
            return;
        }

        TwoWaySyncGuard::markInitiated('pause', $subscription_id);

        $result = $gateway->pauseRemoteBillingContext($subscription_id);

        PaymentLoggingService::logPayment(
            $gateway->getGatewaySlug(),
            $subscription_id,
            ! empty($result['success'])
                ? 'Remote billing paused'
                : sprintf('Failed to pause remote billing: %s', $result['message'] ?? 'unknown error'),
            ! empty($result['success']) ? 'info' : 'error'
        );
    }

    /**
     * Handle subscription resumed.
     * Calls resumeRemoteBillingContext() on the gateway if it supports resume.
     *
     * @param int   $subscription_id The subscription post ID.
     * @param mixed $data            Subscription data.
     * @return void
     */
    public function onSubscriptionResumed(int $subscription_id, $data = null): void
    {
        $gateway = GatewayResolver::resolveForSubscription($subscription_id);

        if (! $gateway || ! $gateway->supportsSubscriptionCapability('resume')) {
            return;
        }

        if (TwoWaySyncGuard::wasInitiatedLocally('resume', $subscription_id)) {
            return;
        }

        TwoWaySyncGuard::markInitiated('resume', $subscription_id);

        $result = $gateway->resumeRemoteBillingContext($subscription_id);

        PaymentLoggingService::logPayment(
            $gateway->getGatewaySlug(),
            $subscription_id,
            ! empty($result['success'])
                ? 'Remote billing resumed'
                : sprintf('Failed to resume remote billing: %s', $result['message'] ?? 'unknown error'),
            ! empty($result['success']) ? 'info' : 'error'
        );
    }

    /**
     * Handle plan switch completed.
     * Re-captures payment context after a subscription product switch.
     *
     * Core fires: do_action('arraysubs_plan_switch_completed', $subscription_id, $old_product_id, $new_product_id, $switch_type)
     *
     * @param int    $subscription_id The subscription post ID.
     * @param int    $old_product_id  The previous product ID.
     * @param int    $new_product_id  The new product ID.
     * @param string $switch_type     Switch type (upgrade, downgrade, crossgrade).
     * @return void
     */
    public function onPlanSwitchCompleted(int $subscription_id, int $old_product_id = 0, int $new_product_id = 0, string $switch_type = ''): void
    {
        if ($switch_type === 'auto_downgrade') {
            return;
        }

        $gateway = GatewayResolver::resolveForSubscription($subscription_id);

        if (! $gateway) {
            return;
        }

        // Look up the subscription's current order to re-capture payment context.
        $order_id = PaymentMetaNormalizer::findOrderForSubscription($subscription_id);
        $order    = $order_id > 0 ? wc_get_order($order_id) : null;

        if (! $order) {
            return;
        }

        // Re-capture payment context from the existing order.
        $gateway->captureContextFromOrder($order, $subscription_id);

        PaymentLoggingService::logPayment(
            $gateway->getGatewaySlug(),
            $subscription_id,
            sprintf(
                'Payment context updated after plan switch (%s): product %d → %d',
                $switch_type,
                $old_product_id,
                $new_product_id
            )
        );
    }

    /**
     * Clean up remote billing context when subscription ends.
     *
     * @param int    $subscription_id The subscription post ID.
     * @param string $reason          Cancellation reason.
     * @return void
     */
    private function cleanupRemoteBillingContext(int $subscription_id, string $reason): void
    {
        $gateway = GatewayResolver::resolveForSubscription($subscription_id);

        if (! $gateway) {
            return;
        }

        // Check TwoWaySyncGuard to avoid echo loops
        if (TwoWaySyncGuard::wasInitiatedLocally('cancel', $subscription_id)) {
            return;
        }

        $cancellation_source = get_post_meta($subscription_id, '_cancellation_source', true);

        // If gateway initiated this cancellation, don't call back to gateway
        if ('gateway' === $cancellation_source) {
            return;
        }

        // If we already handled the gateway side at pending-cancel scheduling
        // (PayPal eager cancel) the billing agreement is already terminated;
        // calling cancel again will return an error or a no-op. Treat the
        // gateway side as already done and just clear the sentinel meta.
        $pending_handled = (string) get_post_meta($subscription_id, '_gateway_pending_cancel_handled', true);
        if ('cancelled_eagerly' === $pending_handled) {
            delete_post_meta($subscription_id, '_gateway_pending_cancel_handled');
            delete_post_meta($subscription_id, '_gateway_pending_cancel_handled_at');
            update_post_meta($subscription_id, '_gateway_status', 'inactive');
            return;
        }
        // For Paddle scheduled-cancel: the gateway will cancel itself when its
        // own scheduled change fires; clear our sentinel and let the webhook
        // confirm the final state. If the cron beats Paddle's schedule we still
        // call cancel here as a safety net.
        if ('scheduled' === $pending_handled) {
            delete_post_meta($subscription_id, '_gateway_pending_cancel_handled');
            delete_post_meta($subscription_id, '_gateway_pending_cancel_handled_at');
        }

        // Mark that we're initiating this action locally
        TwoWaySyncGuard::markInitiated('cancel', $subscription_id);

        $context = [
            'reason'             => $reason,
            'source'             => $cancellation_source ?: 'system',
            'remote_customer_id' => get_post_meta($subscription_id, '_gateway_customer_id', true),
            'remote_pm_id'       => get_post_meta($subscription_id, '_gateway_payment_method_id', true),
        ];

        $result = $gateway->cancelRemoteBillingContext($subscription_id, $context);

        if (! empty($result['success'])) {
            update_post_meta($subscription_id, '_gateway_status', 'inactive');

            PaymentLoggingService::logPayment(
                $gateway->getGatewaySlug(),
                $subscription_id,
                sprintf('Remote billing context cancelled: %s', $result['message'] ?? 'success')
            );
        } else {
            PaymentLoggingService::logPayment(
                $gateway->getGatewaySlug(),
                $subscription_id,
                sprintf('Failed to cancel remote billing context: %s', $result['message'] ?? 'unknown error'),
                'error'
            );
        }
    }

	// ─── Scheduled Jobs ──────────────────────────────────────────────────

    /**
     * Schedule recurring maintenance jobs.
     *
     * @return void
     */
    public function scheduleRecurringJobs(): void
    {
        if (!ActionScheduler::isAvailable()) {
            return;
        }

        ActionScheduler::scheduleRecurring(
            ActionScheduler::HOOK_CLEANUP_WEBHOOK_EVENTS,
            strtotime('tomorrow 2:00am'),
            86400,
            [],
            ActionScheduler::GROUP_GATEWAY
        );
    }

    /**
     * Clean up old webhook events.
     *
     * @return void
     */
    public function cleanupWebhookEvents(): void
    {
        $deleted = DatabaseMigration::cleanupOldEvents();

        if ($deleted > 0) {
            PaymentLoggingService::log(
                'system',
                'info',
                sprintf('Cleaned up %d old webhook events', $deleted)
            );
        }
    }

    /**
     * Reconcile gateway statuses.
     * Placeholder for future reconciliation logic.
     *
     * @return void
     */
    public function reconcileGateways(): void
    {
        // Future: check gateway health, verify stored payment methods, etc.
    }

    /**
     * Determine whether the subscription has a gateway-side billing context
     * (remote subscription or billing agreement) that runs its own schedule.
     *
     * Stripe stores only customer/payment-method IDs, not a remote subscription —
     * the plugin owns the schedule. PayPal stores a billing-agreement ID and
     * Paddle stores a subscription ID; both run on the gateway's schedule.
     *
     * @param \ArraySubsPro\Features\AutomaticPayments\Contracts\AutomaticGatewayContract $gateway         Gateway instance.
     * @param int                                                                         $subscription_id Subscription ID.
     * @return bool
     */
    private function hasRemoteBillingAgreement($gateway, int $subscription_id): bool
    {
        $candidates = [
            '_gateway_paypal_subscription_id',
            '_gateway_paddle_subscription_id',
            '_gateway_remote_subscription_id',
        ];

        foreach ($candidates as $key) {
            $value = (string) get_post_meta($subscription_id, $key, true);
            if ('' !== $value) {
                return true;
            }
        }

        return false;
    }

    /**
     * Persist gateway context (customer ID, payment method, brand/last4)
     * onto the subscription whenever a paid order links to it. Mirrors the
     * webhook capture path so the data is available even if the webhook
     * arrives late or not at all (e.g. server unreachable for 24h).
     *
     * Hook signature: arraysubs_gateway_context_captured ($subscription_id, $order_id, $context)
     *
     * @param int   $subscription_id The subscription post ID.
     * @param int   $order_id        The WC order ID that was just paid.
     * @param array $context         Lightweight payload from the firing hook.
     * @return void
     */
    public function onGatewayContextCaptured(int $subscription_id, int $order_id, array $context): void
    {
        if ($subscription_id <= 0 || $order_id <= 0) {
            return;
        }

        $order = wc_get_order($order_id);
        if (!$order instanceof \WC_Order) {
            return;
        }

        $payment_method = $context['payment_method'] ?? $order->get_payment_method();
        if (empty($payment_method)) {
            return;
        }

        // Resolve the registered ArraySubs gateway for this payment method.
        // GatewayResolver uses the payment_method slug, falling back to
        // already-stored `_payment_gateway` meta when available.
        update_post_meta($subscription_id, '_payment_gateway', sanitize_text_field((string) $payment_method));
        $gateway = GatewayResolver::resolveForSubscription($subscription_id);

        if (!$gateway) {
            // Not one of our automatic gateways — nothing further to capture.
            return;
        }

        // Each gateway knows where its IDs live on the WC order. The
        // canonical capture method is `captureContextFromOrder` —
        // implementations that don't override it fall back to a no-op
        // (Stripe/Paddle/PayPal each implement it). Webhook handlers also
        // call persistGatewayMeta(), so this is idempotent — if the
        // webhook already fired, we just re-store the same values.
        if (method_exists($gateway, 'captureContextFromOrder')) {
            $gateway->captureContextFromOrder($order, $subscription_id);
        }
    }
}
