<?php

/**
 * Stripe Subscription Method Filter
 *
 * Restricts official Stripe UPE methods to reusable methods when checkout
 * contains ArraySubs subscription products.
 *
 * @package ArraySubsPro\Features\AutomaticPayments\Services
 */

namespace ArraySubsPro\Features\AutomaticPayments\Services;

defined('ABSPATH') || exit;

/**
 * Subscription method filter.
 */
class SubscriptionMethodFilter
{
    /**
     * Enable auto-loading.
     *
     * @var bool
     */
    public static $loadable = true;

    /**
     * Reusable Stripe UPE method whitelist.
     *
     * @var array<string>
     */
    private array $reusable_methods = [
        'card',
        'link',
        'apple_pay',
        'google_pay',
        'sepa_debit',
        'us_bank_account',
        'bacs_debit',
        'au_becs_debit',
        'acss_debit',
    ];

    /**
     * Constructor.
     */
    public function __construct()
    {
        add_filter('woocommerce_available_payment_gateways', [$this, 'filterAvailableGateways']);
        add_filter('wc_stripe_upe_params', [$this, 'filterStripeParams']);
        add_filter('wc_stripe_params', [$this, 'filterStripeParams']);
        add_filter('wc_stripe_express_checkout_params', [$this, 'filterStripeParams']);
        add_action('woocommerce_after_checkout_validation', [$this, 'validateClassicCheckout'], 10, 2);
        add_action('woocommerce_store_api_checkout_order_processed', [$this, 'validateStoreApiCheckout'], 1, 1);
        add_action('wc_ajax_wc_stripe_create_payment_intent', [$this, 'validatePaymentIntentRequest'], 1);
        add_filter('arraysubs_renewal_sync_gateway_minimum_amount', [$this, 'getRenewalSyncStripeMinimumAmount'], 10, 4);
    }

    /**
     * Keep the official Stripe gateway available; detailed method filtering happens in UPE params.
     *
     * @param array $gateways Available gateways.
     * @return array
     */
    public function filterAvailableGateways(array $gateways): array
    {
        return $gateways;
    }

    /**
     * Filter UPE params recursively.
     *
     * @param array $params Stripe params.
     * @return array
     */
    public function filterStripeParams(array $params): array
    {
        if (! $this->cartContainsSubscription()) {
            return $params;
        }

        return $this->filterPaymentMethodArrays($params);
    }

    /**
     * Validate classic checkout.
     *
     * @param array     $data   Posted data.
     * @param \WP_Error $errors Error collector.
     * @return void
     */
    public function validateClassicCheckout(array $data, \WP_Error $errors): void
    {
        if (! $this->cartContainsSubscription()) {
            return;
        }

        $payment_method = sanitize_text_field((string) ($data['payment_method'] ?? ''));
        if ('stripe' !== $payment_method) {
            return;
        }

        if (! $this->cartMeetsStripeMinimumAmount()) {
            $errors->add(
                'arraysubs_stripe_minimum_amount',
                $this->getStripeMinimumAmountMessage((float) WC()->cart->get_total('edit'), get_woocommerce_currency())
            );
            return;
        }

        $stripe_payment_type = $this->extractSubmittedPaymentType($data);
        if ('' !== $stripe_payment_type && ! in_array($stripe_payment_type, $this->reusable_methods, true)) {
            $errors->add(
                'arraysubs_stripe_non_reusable_method',
                __('This Stripe payment method cannot be used for subscriptions because it does not support automatic renewals. Choose a reusable method such as card, Link, a supported wallet, or bank debit.', 'arraysubspro')
            );
        }
    }

    /**
     * Validate Store API checkout.
     *
     * @param \WC_Order             $order   Order object.
     * @param \WP_REST_Request|null $request Store API request.
     * @throws \Automattic\WooCommerce\StoreApi\Exceptions\RouteException When method is not reusable.
     * @throws \Exception When method is not reusable and Store API exception class is unavailable.
     * @return void
     */
    public function validateStoreApiCheckout(\WC_Order $order, $request = null): void
    {
        if (! $this->orderContainsSubscriptionProduct($order)) {
            return;
        }

        $payment_method = $order->get_payment_method();
        if ('stripe' !== $payment_method) {
            return;
        }

        if (! $this->orderMeetsStripeMinimumAmount($order)) {
            $message = $this->getStripeMinimumAmountMessage((float) $order->get_total('edit'), $order->get_currency());
            if (class_exists('\Automattic\WooCommerce\StoreApi\Exceptions\RouteException')) {
                throw new \Automattic\WooCommerce\StoreApi\Exceptions\RouteException(
                    'arraysubs_stripe_minimum_amount',
                    esc_html($message),
                    400
                );
            }

            throw new \Exception(esc_html($message));
        }

        $params              = $request instanceof \WP_REST_Request ? (array) $request->get_param('payment_data') : [];
        $stripe_payment_type = $this->extractSubmittedPaymentType($params);
        if ('' !== $stripe_payment_type && ! in_array($stripe_payment_type, $this->reusable_methods, true)) {
            $message = __('This Stripe payment method cannot be used for subscriptions because it does not support automatic renewals.', 'arraysubspro');
            if (class_exists('\Automattic\WooCommerce\StoreApi\Exceptions\RouteException')) {
                throw new \Automattic\WooCommerce\StoreApi\Exceptions\RouteException(
                    'arraysubs_stripe_non_reusable_method',
                    esc_html($message),
                    400
                );
            }

            throw new \Exception(esc_html($message));
        }
    }

    /**
     * Block Stripe's Payment Element intent bootstrap before Stripe returns a raw configuration error.
     *
     * @return void
     */
    public function validatePaymentIntentRequest(): void
    {
        $order_id = absint(filter_input(INPUT_POST, 'stripe_order_id', FILTER_SANITIZE_NUMBER_INT));

        if ($order_id > 0) {
            $order = wc_get_order($order_id);
            if (! $order instanceof \WC_Order || ! $this->orderContainsSubscriptionProduct($order)) {
                return;
            }

            if ($this->orderMeetsStripeMinimumAmount($order)) {
                return;
            }

            $message = $this->getStripeMinimumAmountMessage((float) $order->get_total('edit'), $order->get_currency());
        } else {
            if (! $this->cartContainsSubscription() || $this->cartMeetsStripeMinimumAmount()) {
                return;
            }

            $message = $this->getStripeMinimumAmountMessage((float) WC()->cart->get_total('edit'), get_woocommerce_currency());
        }

        wp_send_json_error(
            [
                'error' => [
                    'message' => $message,
                ],
            ],
            400
        );
    }

    /**
     * Provide Stripe's real minimum charge amount to Renewal Sync.
     *
     * @param float  $minimum_amount Current minimum amount.
     * @param string $gateway_id      Gateway ID.
     * @param string $currency        Currency code.
     * @param mixed  $gateway         Gateway object.
     * @return float
     */
    public function getRenewalSyncStripeMinimumAmount(float $minimum_amount, string $gateway_id, string $currency, $gateway): float
    {
        if (! in_array(sanitize_key($gateway_id), ['stripe', 'arraysubs_stripe'], true)) {
            return $minimum_amount;
        }

        return $this->convertFromStripeAmount(
            $this->getStripeMinimumAmount($currency),
            $currency
        );
    }

    /**
     * Recursively filter known Stripe payment-method arrays.
     *
     * @param array $value Value.
     * @return array
     */
    private function filterPaymentMethodArrays(array $value): array
    {
        foreach ($value as $key => $child) {
            if (is_array($child)) {
                if ($this->looksLikeMethodList($key, $child)) {
                    $value[$key] = array_values(array_intersect($child, $this->reusable_methods));
                    continue;
                }

                $value[$key] = $this->filterPaymentMethodArrays($child);
            }
        }

        return $value;
    }

    /**
     * Check whether an array is a payment method id list.
     *
     * @param string|int $key   Array key.
     * @param array      $value Array value.
     * @return bool
     */
    private function looksLikeMethodList($key, array $value): bool
    {
        $key = (string) $key;
        if (! preg_match('/payment.*method|upe.*method|available.*method|enabled.*method/i', $key)) {
            return false;
        }

        foreach ($value as $item) {
            if (! is_string($item)) {
                return false;
            }
        }

        return true;
    }

    /**
     * Extract submitted Stripe UPE payment type from classic/block payloads.
     *
     * @param array $data Submitted data.
     * @return string
     */
    private function extractSubmittedPaymentType(array $data): string
    {
        $data = $this->normalizePaymentData($data);

        $candidates = [
            'wc-stripe-payment-method-type',
            'wc-stripe-upe-payment-method-type',
            'stripe_payment_method_type',
            'payment_method_type',
            'upe_payment_type',
            'stripe_upe_payment_type',
        ];

        foreach ($candidates as $key) {
            if (! empty($data[$key])) {
                return sanitize_key((string) $data[$key]);
            }
        }

        return '';
    }

    /**
     * Normalize classic associative payloads and Store API key/value lists.
     *
     * @param array $data Submitted data.
     * @return array
     */
    private function normalizePaymentData(array $data): array
    {
        $normalized = $data;

        foreach ($data as $entry) {
            if (! is_array($entry) || ! isset($entry['key'])) {
                continue;
            }

            $normalized[(string) $entry['key']] = $entry['value'] ?? '';
        }

        return $normalized;
    }

    /**
     * Check current cart for subscription products.
     *
     * @return bool
     */
    private function cartContainsSubscription(): bool
    {
        return function_exists('arraysubs_cart_contains_subscription') && arraysubs_cart_contains_subscription();
    }

    /**
     * Check whether the current subscription cart can be charged by Stripe.
     *
     * @return bool
     */
    private function cartMeetsStripeMinimumAmount(): bool
    {
        if (! WC()->cart) {
            return true;
        }

        return ! $this->isAmountBelowStripeMinimum(
            (float) WC()->cart->get_total('edit'),
            get_woocommerce_currency()
        );
    }

    /**
     * Check whether an order can be charged by Stripe.
     *
     * @param \WC_Order $order Order object.
     * @return bool
     */
    private function orderMeetsStripeMinimumAmount(\WC_Order $order): bool
    {
        return ! $this->isAmountBelowStripeMinimum(
            (float) $order->get_total('edit'),
            $order->get_currency()
        );
    }

    /**
     * Check whether an amount is below Stripe's minimum charge for the currency.
     *
     * @param float  $amount   WooCommerce amount.
     * @param string $currency Currency code.
     * @return bool
     */
    private function isAmountBelowStripeMinimum(float $amount, string $currency): bool
    {
        if ($amount <= 0) {
            return false;
        }

        return $this->getStripeAmount($amount, $currency) < $this->getStripeMinimumAmount($currency);
    }

    /**
     * Convert a WooCommerce amount to Stripe's smallest currency unit.
     *
     * @param float  $amount   WooCommerce amount.
     * @param string $currency Currency code.
     * @return int
     */
    private function getStripeAmount(float $amount, string $currency): int
    {
        if (class_exists('\WC_Stripe_Helper')) {
            return (int) \WC_Stripe_Helper::get_stripe_amount($amount, $currency);
        }

        return absint(round($amount * 100));
    }

    /**
     * Get Stripe's minimum charge amount in the smallest currency unit.
     *
     * @param string $currency Currency code.
     * @return int
     */
    private function getStripeMinimumAmount(string $currency): int
    {
        $currency = strtoupper($currency);
        $minimums = [
            'BDT' => 6500,
        ];

        $minimum_amount = $minimums[$currency]
            ?? (class_exists('\WC_Stripe_Helper') ? (int) \WC_Stripe_Helper::get_minimum_amount() : 50);

        /**
         * Filter Stripe's minimum amount for a currency.
         *
         * The amount is expressed in Stripe's smallest currency unit.
         *
         * @param int    $minimum_amount Minimum amount.
         * @param string $currency       Currency code.
         */
        return (int) apply_filters('arraysubspro_stripe_minimum_amount', $minimum_amount, $currency);
    }

    /**
     * Convert a Stripe smallest-unit amount to a WooCommerce decimal amount.
     *
     * @param int    $amount   Stripe amount.
     * @param string $currency Currency code.
     * @return float
     */
    private function convertFromStripeAmount(int $amount, string $currency): float
    {
        if (
            class_exists('\WC_Stripe_Helper')
            && method_exists('\WC_Stripe_Helper', 'convert_from_stripe_amount')
        ) {
            return (float) \WC_Stripe_Helper::convert_from_stripe_amount($amount, $currency);
        }

        return round($amount / 100, 2);
    }

    /**
     * Build Stripe minimum amount validation message.
     *
     * @param float  $amount   WooCommerce amount.
     * @param string $currency Currency code.
     * @return string
     */
    private function getStripeMinimumAmountMessage(float $amount, string $currency): string
    {
        $minimum_amount = $this->convertFromStripeAmount($this->getStripeMinimumAmount($currency), $currency);

        return sprintf(
            /* translators: 1: cart/order total, 2: Stripe minimum charge amount */
            __(
                'Stripe cannot be used for this subscription because the first payment is %1$s, which is below the Stripe minimum charge guard of %2$s. Stripe error: amount_too_small - Amount must convert to at least 50 cents; for BDT this can be more than ৳50 depending on the exchange rate. Increase the first payment amount, review enabled payment methods for this currency in Stripe, or choose another payment method.',
                'arraysubspro'
            ),
            $this->formatPriceForMessage($amount, $currency),
            $this->formatPriceForMessage($minimum_amount, $currency)
        );
    }

    /**
     * Format a price for validation messages.
     *
     * @param float  $amount   WooCommerce amount.
     * @param string $currency Currency code.
     * @return string
     */
    private function formatPriceForMessage(float $amount, string $currency): string
    {
        $price = html_entity_decode(
            wp_strip_all_tags(wc_price($amount, ['currency' => $currency])),
            ENT_QUOTES | ENT_HTML5,
            get_bloginfo('charset') ?: 'UTF-8'
        );

        return trim(str_replace("\xc2\xa0", ' ', $price));
    }

    /**
     * Check order line items for subscription products.
     *
     * @param \WC_Order $order Order object.
     * @return bool
     */
    private function orderContainsSubscriptionProduct(\WC_Order $order): bool
    {
        if (! function_exists('arraysubs_is_subscription_product')) {
            return false;
        }

        foreach ($order->get_items() as $item) {
            $product_id = $item->get_variation_id() ?: $item->get_product_id();
            if ($product_id && arraysubs_is_subscription_product($product_id)) {
                return true;
            }
        }

        return false;
    }
}
