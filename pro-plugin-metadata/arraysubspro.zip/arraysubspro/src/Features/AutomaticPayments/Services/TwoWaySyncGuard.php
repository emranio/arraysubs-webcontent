<?php

/**
 * Two-Way Sync Guard
 *
 * Prevents infinite loops between local actions (cancel, refund) and
 * gateway webhooks that fire for the same action.
 *
 * Uses transients with short TTL to track plugin-initiated actions,
 * so when the corresponding webhook arrives, it can be skipped.
 *
 * @package ArraySubsPro\Features\AutomaticPayments\Services
 * @since 1.0.0
 */

namespace ArraySubsPro\Features\AutomaticPayments\Services;

defined('ABSPATH') || exit;

/**
 * Two-Way Sync Guard Service
 */
class TwoWaySyncGuard
{
    /**
     * TTL for sync guards in seconds (5 minutes).
     *
     * @var int
     */
    const GUARD_TTL = 300;

    /**
     * In-memory flags for current request.
     *
     * @var array<string, bool>
     */
    private static array $in_memory = [];

    /**
     * Mark that a local action was initiated for a subscription.
     * Webhooks arriving within the TTL for the same action will be skipped.
     *
     * @param string $action          The action type: 'cancel', 'refund', 'pause', 'resume'.
     * @param int    $subscription_id The subscription ID.
     * @return void
     */
    public static function markInitiated(string $action, int $subscription_id): void
    {
        $key = self::getTransientKey($action, $subscription_id);

        set_transient($key, time(), self::GUARD_TTL);

        self::$in_memory[$key] = true;
    }

    /**
     * Check if a local action was recently initiated for a subscription.
     * Used by webhook handlers to skip echo events.
     *
     * @param string $action          The action type.
     * @param int    $subscription_id The subscription ID.
     * @return bool True if the action was recently initiated locally.
     */
    public static function wasInitiatedLocally(string $action, int $subscription_id): bool
    {
        $key = self::getTransientKey($action, $subscription_id);

        // Check in-memory first (same request)
        if (isset(self::$in_memory[$key])) {
            return true;
        }

        // Check transient (cross-request)
        $initiated_at = get_transient($key);

        return false !== $initiated_at;
    }

    /**
     * Clear a sync guard after processing.
     *
     * @param string $action          The action type.
     * @param int    $subscription_id The subscription ID.
     * @return void
     */
    public static function clear(string $action, int $subscription_id): void
    {
        $key = self::getTransientKey($action, $subscription_id);

        delete_transient($key);
        unset(self::$in_memory[$key]);
    }

    /**
     * Generate the transient key for a sync guard.
     *
     * @param string $action          The action type.
     * @param int    $subscription_id The subscription ID.
     * @return string
     */
    private static function getTransientKey(string $action, int $subscription_id): string
    {
        return sprintf('arraysubs_sync_%s_%d', sanitize_key($action), $subscription_id);
    }
}
