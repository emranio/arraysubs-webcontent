<?php

/**
 * Gateway Resolver
 *
 * Resolves the correct gateway instance for a subscription or order.
 * Maps WC _payment_method meta to registered automatic payment gateways.
 *
 * @package ArraySubsPro\Features\AutomaticPayments\Services
 * @since 1.0.0
 */

namespace ArraySubsPro\Features\AutomaticPayments\Services;

defined('ABSPATH') || exit;

use ArraySubsPro\Features\AutomaticPayments\Contracts\AutomaticGatewayContract;

/**
 * Gateway Resolver Service
 */
class GatewayResolver
{
    /**
     * Resolve gateway for a subscription.
     *
     * @param int $subscription_id The subscription post ID.
     * @return AutomaticGatewayContract|null
     */
    public static function resolveForSubscription(int $subscription_id): ?AutomaticGatewayContract
    {
        $gateway_slug = self::getPostMeta($subscription_id, '_payment_gateway');

        if (empty($gateway_slug)) {
            $gateway_slug = self::getPostMeta($subscription_id, '_payment_method');
        }

        if (empty($gateway_slug)) {
            return null;
        }

        return GatewayRegistry::get($gateway_slug);
    }

    /**
     * Resolve gateway for a WooCommerce order.
     *
     * @param int $order_id The WooCommerce order ID.
     * @return AutomaticGatewayContract|null
     */
    public static function resolveForOrder(int $order_id): ?AutomaticGatewayContract
    {
        $order = \wc_get_order($order_id);

        if (! $order) {
            return null;
        }

        $payment_method = $order->get_payment_method();

        if (empty($payment_method)) {
            $payment_method = $order->get_meta('_arraysubs_gateway_slug', true);
        }

        if (empty($payment_method)) {
            return null;
        }

        return GatewayRegistry::get($payment_method);
    }

    /**
     * Resolve gateway by slug directly.
     *
     * @param string $gateway_slug The gateway slug.
     * @return AutomaticGatewayContract|null
     */
    public static function resolveBySlug(string $gateway_slug): ?AutomaticGatewayContract
    {
        return GatewayRegistry::get($gateway_slug);
    }

    /**
     * Read post meta with a local wrapper for static-analysis safety.
     *
     * @param int    $post_id  Post ID.
     * @param string $meta_key Meta key.
     * @return mixed
     */
    private static function getPostMeta(int $post_id, string $meta_key)
    {
        if (! \function_exists('get_post_meta')) {
            return '';
        }

        return \call_user_func('get_post_meta', $post_id, $meta_key, true);
    }
}
