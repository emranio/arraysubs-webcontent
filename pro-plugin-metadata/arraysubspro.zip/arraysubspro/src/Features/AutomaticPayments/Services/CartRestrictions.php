<?php

/**
 * Cart Restrictions Service
 *
 * Enforces checkout composition restrictions based on the capabilities
 * of enabled automatic payment gateways. Uses the "most restrictive
 * enabled gateway wins" strategy — if any enabled gateway lacks a
 * capability, that restriction is applied site-wide.
 *
 * Hooks into the three core filters at priority 20 so admin settings
 * (priority 10) are checked first and gateway overrides layer on top.
 *
 * @package ArraySubsPro\Features\AutomaticPayments\Services
 * @since 1.0.0
 */

namespace ArraySubsPro\Features\AutomaticPayments\Services;

defined('ABSPATH') || exit;

/**
 * Cart Restrictions
 */
class CartRestrictions
{
    /**
     * Enable auto-loading.
     *
     * @var bool
     */
    public static $loadable = true;

    /**
     * Constructor — register filter hooks.
     */
    public function __construct()
    {
        add_filter('arraysubs_allow_mixed_cart', [$this, 'enforceMixedCart'], 20);
        add_filter('arraysubs_allow_multiple_subscriptions', [$this, 'enforceMultipleSubscriptions'], 20);
        add_filter('arraysubs_allow_different_billing_cycles', [$this, 'enforceDifferentBillingCycles'], 20);

        // Checkout-time: validate the selected gateway's specific capabilities
        add_action('woocommerce_after_checkout_validation', [$this, 'validateCheckoutGateway'], 10, 2);
        add_action('woocommerce_checkout_validate_order_before_payment', [$this, 'validateCheckoutGatewayStoreApi'], 10, 2);
    }

    /**
     * Enforce mixed-cart restriction from gateways.
     *
     * @param bool $allowed Current filter value.
     * @return bool
     */
    public function enforceMixedCart(bool $allowed): bool
    {
        return $this->enforceCapability($allowed, 'mixed_cart');
    }

    /**
     * Enforce multiple-subscriptions restriction from gateways.
     *
     * @param bool $allowed Current filter value.
     * @return bool
     */
    public function enforceMultipleSubscriptions(bool $allowed): bool
    {
        return $this->enforceCapability($allowed, 'multiple_subscriptions');
    }

    /**
     * Enforce different-billing-cycles restriction from gateways.
     *
     * @param bool $allowed Current filter value.
     * @return bool
     */
    public function enforceDifferentBillingCycles(bool $allowed): bool
    {
        return $this->enforceCapability($allowed, 'different_billing_cycles');
    }

    /**
     * Check all enabled gateways for a specific capability.
     *
     * If any enabled gateway lacks the capability, the restriction
     * is applied — unless a per-gateway developer filter overrides it.
     *
     * @param bool   $allowed    Current filter value.
     * @param string $capability The capability key to check.
     * @return bool
     */
    private function enforceCapability(bool $allowed, string $capability): bool
    {
        if (!$allowed) {
            return false;
        }

        $gateways = GatewayRegistry::getAll();

        foreach ($gateways as $gateway) {
            if (! $gateway->isGatewayEnabled()) {
                continue;
            }

            if ($gateway->supportsSubscriptionCapability($capability)) {
                continue;
            }

            $gateway_slug   = $gateway->getGatewaySlug();
            $filter_name    = 'arraysubs_' . $gateway_slug . '_allow_' . $capability;
            $gateway_allows = $this->applyDynamicFilter($filter_name, false);

            if (!$gateway_allows) {
                return false;
            }
        }

        return $allowed;
    }

    /**
     * Validate the selected gateway's capabilities at classic checkout.
     *
     * @param array     $data   Posted checkout data.
     * @param \WP_Error $errors Checkout validation errors.
     */
    public function validateCheckoutGateway(array $data, \WP_Error $errors): void
    {
        $payment_method = $data['payment_method'] ?? '';

        if (empty($payment_method)) {
            return;
        }

        $this->checkSelectedGatewayCapabilities($payment_method, $errors);
    }

    /**
     * Validate the selected gateway's capabilities at Store API checkout.
     *
     * @param \WC_Order $order  The order being placed.
     * @param \WP_Error $errors Validation errors.
     */
    public function validateCheckoutGatewayStoreApi(\WC_Order $order, \WP_Error $errors): void
    {
        $payment_method = $order->get_payment_method();

        if (empty($payment_method)) {
            return;
        }

        $this->checkSelectedGatewayCapabilities($payment_method, $errors);
    }

    /**
     * Check the selected gateway's subscription capabilities against the current cart.
     *
     * @param string    $gateway_id Selected payment gateway ID.
     * @param \WP_Error $errors     Error collector.
     */
    private function checkSelectedGatewayCapabilities(string $gateway_id, \WP_Error $errors): void
    {
        if (!\function_exists('WC') || !WC()->cart) {
            return;
        }

        $gateway = GatewayRegistry::get($gateway_id);

        if (!$gateway) {
            return;
        }

        if (!\function_exists('arraysubs_is_subscription_product')) {
            return;
        }

        $subscription_count = 0;
        $regular_count      = 0;
        $cycles             = [];

        foreach (WC()->cart->get_cart() as $cart_item) {
            $variation_id = $cart_item['variation_id'] ?? 0;
            $check_id     = $variation_id > 0 ? $variation_id : $cart_item['product_id'];

            if (arraysubs_is_subscription_product($check_id)) {
                ++$subscription_count;

                if (\function_exists('arraysubs_get_product_subscription_data')) {
                    $sub_data = arraysubs_get_product_subscription_data($check_id);
                    if ($sub_data) {
                        $cycles[$sub_data['period'] . ':' . $sub_data['interval']] = true;
                    }
                }
            } else {
                ++$regular_count;
            }
        }

        if (0 === $subscription_count) {
            return;
        }

        $gateway_slug = $gateway->getGatewaySlug();

        // Mixed cart
        if ($subscription_count > 0 && $regular_count > 0) {
            $supports = $gateway->supportsSubscriptionCapability('mixed_cart');
            $filter_name = 'arraysubs_' . $gateway_slug . '_allow_mixed_cart';
            $supports    = (bool) $this->applyDynamicFilter($filter_name, $supports);

            if (!$supports) {
                $errors->add(
                    'arraysubs_gateway_mixed_cart',
                    sprintf(
                        /* translators: %s: Payment gateway title */
                        \__('%s cannot process subscription and regular products together in the same checkout. Remove the incompatible items or choose a different payment method.', 'arraysubspro'),
                        \esc_html($gateway->getGatewayTitle())
                    )
                );
            }
        }

        // Multiple subscriptions
        if ($subscription_count > 1) {
            $supports = $gateway->supportsSubscriptionCapability('multiple_subscriptions');
            $filter_name = 'arraysubs_' . $gateway_slug . '_allow_multiple_subscriptions';
            $supports    = (bool) $this->applyDynamicFilter($filter_name, $supports);

            if (!$supports) {
                $errors->add(
                    'arraysubs_gateway_multiple_subs',
                    sprintf(
                        /* translators: %s: Payment gateway title */
                        \__('%s can only process one subscription plan per checkout. Keep a single subscription in the cart or choose a different payment method.', 'arraysubspro'),
                        \esc_html($gateway->getGatewayTitle())
                    )
                );
            }
        }

        // Different billing cycles
        if (count($cycles) > 1) {
            $supports = $gateway->supportsSubscriptionCapability('different_billing_cycles');
            $filter_name = 'arraysubs_' . $gateway_slug . '_allow_different_billing_cycles';
            $supports    = (bool) $this->applyDynamicFilter($filter_name, $supports);

            if (!$supports) {
                $errors->add(
                    'arraysubs_gateway_diff_cycles',
                    sprintf(
                        /* translators: %s: Payment gateway title */
                        \__('%s cannot process subscription plans with different billing cycles in one checkout. Match the billing schedules or choose a different payment method.', 'arraysubspro'),
                        \esc_html($gateway->getGatewayTitle())
                    )
                );
            }
        }
    }

    /**
     * Apply a dynamically assembled gateway capability filter.
     *
     * @param string $filter_name Filter name.
     * @param mixed  $value       Default value.
     * @return mixed
     */
    private function applyDynamicFilter(string $filter_name, $value)
    {
        if (! function_exists('apply_filters')) {
            return $value;
        }

        return call_user_func('apply_filters', $filter_name, $value);
    }
}
