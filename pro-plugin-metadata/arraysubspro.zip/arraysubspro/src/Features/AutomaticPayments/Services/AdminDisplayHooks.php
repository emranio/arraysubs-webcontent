<?php

/**
 * Admin Display Hooks
 *
 * Extends core admin views with gateway-related information:
 * - Subscription detail REST response (payment method card, gateway status)
 * - Customer portal view-subscription template (payment method display)
 *
 * @package ArraySubsPro\Features\AutomaticPayments\Services
 * @since 1.0.0
 */

namespace ArraySubsPro\Features\AutomaticPayments\Services;

defined('ABSPATH') || exit;

use ArraySubs\Supports\Config;
use ArraySubsPro\Features\AutomaticPayments\Contracts\AutomaticGatewayContract;

/**
 * Admin Display Hooks
 */
class AdminDisplayHooks
{
    /**
     * Enable auto-loading via AbstractLoader.
     *
     * @var bool
     */
    public static $loadable = true;

    /**
     * Initialize hooks.
     */
    public function __construct()
    {
        // Extend subscription detail REST response with gateway data
        add_filter('arraysubs_subscription_detail_data', [$this, 'addGatewayDataToDetail'], 10, 2);

        // Customer portal: render gateway payment method info
        add_action('arraysubs_view_subscription_after_payment_method', [$this, 'renderCustomerPaymentMethodDetails'], 10, 2);

        // Customer portal: render auto-renew toggle inside the Subscription Actions section
        add_action('arraysubs_view_subscription_actions', [$this, 'renderAutoRenewToggle'], 20, 2);

        // Customer portal: force the Subscription Actions section to render when only the auto-renew toggle is available
        add_filter('arraysubs_view_subscription_force_show_actions', [$this, 'maybeForceShowActionsSection'], 10, 3);

        // Enqueue customer portal pro assets
        add_action('wp_enqueue_scripts', [$this, 'enqueueCustomerPortalAssets']);
    }

    /**
     * Add gateway-related data to the subscription detail REST response.
     *
     * This data is consumed by the React admin UI to render the
     * PaymentMethodCard and GatewayStatusBadge components.
     *
     * @param array $data            The subscription detail data.
     * @param int   $subscription_id The subscription post ID.
     * @return array Extended subscription detail data.
     */
    public function addGatewayDataToDetail(array $data, int $subscription_id): array
    {
        $gateway_slug = get_post_meta($subscription_id, '_payment_gateway', true);

        if (empty($gateway_slug)) {
            $data['gateway_info'] = null;
            return $data;
        }

        $gateway = GatewayResolver::resolveForSubscription($subscription_id);

        // is_automatic is the canonical signal for "this gateway has remote
        // state worth surfacing" — only automatic-pay gateways resolve here.
        // Manual gateways (bacs, cheque, cod) leave $gateway null and the
        // admin Payment Gateway card stays hidden.
        $is_automatic = $gateway instanceof AutomaticGatewayContract;

        $stored_status = (string) get_post_meta($subscription_id, '_gateway_status', true);

        if (! $is_automatic) {
            $gateway_status = 'manual';
        } elseif ('' === $stored_status) {
            $gateway_status = 'active';
        } else {
            $gateway_status = $stored_status;
        }

        $capabilities = $gateway ? $gateway->getSubscriptionCapabilities() : [];

        $data['gateway_info'] = [
            'slug'                  => $gateway_slug,
            'title'                 => $gateway ? $gateway->getGatewayTitle() : $gateway_slug,
            'status'                => $gateway_status,
            'is_automatic'          => $is_automatic,
            'customer_id'           => get_post_meta($subscription_id, '_gateway_customer_id', true),
            'payment_method_id'     => get_post_meta($subscription_id, '_gateway_payment_method_id', true),
            'session_id'            => get_post_meta($subscription_id, '_gateway_session_id', true),
            'last_transaction_id'   => get_post_meta($subscription_id, '_last_gateway_transaction_id', true),
            'payment_method'        => null,
            'capabilities'          => $capabilities,
            'supports_sync'         => ! empty($capabilities['supports_sync']),
            'can_detach'            => $is_automatic && 'detached' !== $gateway_status,
        ];

        // Get formatted payment method display data
        if ($gateway) {
            $pm_data = $gateway->formatPaymentMethodForDisplay($subscription_id);
            if (! empty($pm_data)) {
                $data['gateway_info']['payment_method'] = $pm_data;
            }
        }

        return $data;
    }

    /**
     * Render gateway payment method details in the customer portal
     * view-subscription template.
     *
     * Hooked to: arraysubs_view_subscription_after_payment_method
     *
     * @param int   $subscription_id   The subscription post ID.
     * @param array $subscription_data The subscription data array.
     * @return void
     */
    public function renderCustomerPaymentMethodDetails(int $subscription_id, array $subscription_data): void
    {
        $gateway_slug = get_post_meta($subscription_id, '_payment_gateway', true);

        if (empty($gateway_slug)) {
            return;
        }

        $gateway = GatewayResolver::resolveForSubscription($subscription_id);

        if (! $gateway) {
            return;
        }

        $pm_data    = $gateway->formatPaymentMethodForDisplay($subscription_id);
        $can_update = PaymentMethodCoordinator::canUpdatePaymentMethod($subscription_id);
        $is_expired = PaymentMethodCoordinator::isPaymentMethodExpired($subscription_id);

        if (empty($pm_data)) {
            return;
        }

        $payment_label = __('Billing Authorization:', 'arraysubspro');
        $card_display  = '';

        if (! empty($pm_data['last4'])) {
            $card_display = sprintf(
                /* translators: 1: card brand, 2: last 4 digits */
                __('%1$s ending in %2$s', 'arraysubspro'),
                ucfirst((string) ($pm_data['brand'] ?? __('Card', 'arraysubspro'))),
                (string) $pm_data['last4']
            );
            $payment_label = __('Card on File:', 'arraysubspro');
        } elseif (! empty($pm_data['title'])) {
            $card_display = (string) $pm_data['title'];
        } elseif (! empty($pm_data['brand'])) {
            $card_display = ucfirst((string) $pm_data['brand']);
        }

        if ('' === $card_display) {
            return;
        }

        $expiry_display = '';
        if (! empty($pm_data['expiry'])) {
            $expiry_display = sprintf(
                /* translators: %s: expiry date */
                __('Expires %s', 'arraysubspro'),
                esc_html($pm_data['expiry'])
            );
        }
?>
        <tr class="arraysubs-gateway-payment-details">
            <th><?php echo esc_html($payment_label); ?></th>
            <td>
                <span class="arraysubs-payment-method-card-display">
                    <?php echo esc_html($card_display); ?>
                </span>
                <?php if (! empty($expiry_display)) : ?>
                    <span class="arraysubs-payment-method-expiry <?php echo $is_expired ? 'arraysubs-payment-method-expiry--expired' : ''; ?>">
                        <?php echo esc_html($expiry_display); ?>
                        <?php if ($is_expired) : ?>
                            <span class="arraysubs-payment-method-expired-badge">
                                <?php esc_html_e('Expired', 'arraysubspro'); ?>
                            </span>
                        <?php endif; ?>
                    </span>
                <?php endif; ?>
                <?php if ($can_update) : ?>
                    <br>
                    <a href="#"
                        class="arraysubs-update-payment-method-link"
                        data-subscription-id="<?php echo esc_attr($subscription_id); ?>"
                        data-update-url="<?php echo esc_url(rest_url('arraysubs/v1/subscriptions/' . $subscription_id . '/payment-method/update')); ?>">
                        <?php esc_html_e('Update payment method', 'arraysubspro'); ?>
                    </a>
                <?php endif; ?>
            </td>
        </tr>
    <?php
    }

    /**
     * Render the auto-renew toggle in the customer portal.
     *
     * Hooked to: arraysubs_view_subscription_actions (priority 20)
     *
     * Only shown when:
     * - The toggle setting is enabled globally
     * - The subscription has an automatic payment gateway
     * - The subscription is in an eligible status
     * - The subscription is not pending cancellation
     * - The billing period is not lifetime
     *
     * @param int   $subscription_id   The subscription post ID.
     * @param array $subscription_data The subscription data array.
     * @return void
     */
    public function renderAutoRenewToggle(int $subscription_id, array $subscription_data): void
    {
        $gateway = $this->resolveAutoRenewToggleGateway($subscription_id, $subscription_data);

        if (! $gateway) {
            // The toggle is unavailable for this subscription. When the
            // global setting is on and the customer is otherwise on an
            // active manual-gateway subscription, render a passive line
            // explaining why no toggle is shown — so the merchant knows
            // the feature is wired and the customer is not left guessing.
            $this->maybeRenderAutoRenewUnavailableHint($subscription_id, $subscription_data);
            return;
        }

        $auto_renew_enabled = function_exists('arraysubs_is_auto_renew_enabled')
            ? arraysubs_is_auto_renew_enabled($subscription_id)
            : true;

        $toggle_label = $auto_renew_enabled
            ? __('On', 'arraysubspro')
            : __('Off', 'arraysubspro');

        $gateway_status = strtolower((string) get_post_meta($subscription_id, '_gateway_status', true));
        $pm_id          = get_post_meta($subscription_id, '_gateway_payment_method_id', true);
        $can_reenable   = ! empty($pm_id) && (empty($gateway_status) || 'active' === $gateway_status);

        if ('paused' === $gateway_status) {
            $can_reenable = $gateway->supportsSubscriptionCapability('resume') && ! empty($pm_id);
        }
    ?>
        <div class="subscription-actions__auto-renew arraysubs-auto-renew-row">
            <span class="subscription-actions__auto-renew-label">
                <?php esc_html_e('Auto-Renew:', 'arraysubspro'); ?>
            </span>
            <div class="arraysubs-auto-renew-toggle-wrapper">
                <button
                    type="button"
                    class="arraysubs-auto-renew-toggle <?php echo $auto_renew_enabled ? 'arraysubs-auto-renew-toggle--on' : 'arraysubs-auto-renew-toggle--off'; ?>"
                    data-subscription-id="<?php echo esc_attr($subscription_id); ?>"
                    data-enabled="<?php echo $auto_renew_enabled ? '1' : '0'; ?>"
                    data-can-reenable="<?php echo $can_reenable ? '1' : '0'; ?>"
                    aria-pressed="<?php echo $auto_renew_enabled ? 'true' : 'false'; ?>"
                    aria-label="<?php esc_attr_e('Toggle auto-renew', 'arraysubspro'); ?>">
                    <span class="arraysubs-auto-renew-toggle__track">
                        <span class="arraysubs-auto-renew-toggle__thumb"></span>
                    </span>
                    <span class="arraysubs-auto-renew-toggle__label">
                        <?php echo esc_html($toggle_label); ?>
                    </span>
                </button>
                <span class="arraysubs-auto-renew-toggle__status-text">
                    <?php if ($auto_renew_enabled) : ?>
                        <?php esc_html_e('Your subscription will be renewed automatically.', 'arraysubspro'); ?>
                    <?php elseif (! $can_reenable) : ?>
                        <?php esc_html_e('Auto-renew is off. To turn it back on, refresh your payment method or billing authorization first.', 'arraysubspro'); ?>
                    <?php else : ?>
                        <?php esc_html_e('You will receive an invoice for manual payment at your next renewal.', 'arraysubspro'); ?>
                    <?php endif; ?>
                </span>
            </div>
        </div>
<?php
    }

    /**
     * Render a read-only hint when the auto-renew toggle would otherwise
     * be silently absent. Surfaces specifically for active manual-gateway
     * subscriptions when the global "Allow Customers to Turn Off Auto-Renew"
     * setting is enabled — so customers don't see the empty Actions box
     * and assume the feature is broken.
     *
     * @param int   $subscription_id   Subscription ID.
     * @param array $subscription_data Subscription data array.
     * @return void
     */
    private function maybeRenderAutoRenewUnavailableHint(int $subscription_id, array $subscription_data): void
    {
        if (
            ! function_exists('arraysubs_is_auto_renew_toggle_allowed')
            || ! arraysubs_is_auto_renew_toggle_allowed()
        ) {
            return;
        }

        // Only show on subscriptions that are otherwise eligible — active /
        // trial, not paused/on-hold, pending cancel, or lifetime.
        $subscription = get_post($subscription_id);
        if (! $subscription instanceof \WP_Post) {
            return;
        }

        if (
            ! in_array(
                $subscription->post_status,
                ['arraysubs-active', 'arraysubs-trial'],
                true
            )
        ) {
            return;
        }

        if (! empty(get_post_meta($subscription_id, '_waiting_cancellation', true))) {
            return;
        }

        $billing_period = $subscription_data['billing_period'] ?? get_post_meta($subscription_id, '_billing_period', true);
        if ('lifetime' === $billing_period) {
            return;
        }

        // Only render the hint for manual-gateway subscriptions — automatic
        // gateways without the toggle (e.g. paused state) already have
        // gateway-specific messaging elsewhere.
        if (
            function_exists('arraysubs_is_automatic_payment_subscription')
            && arraysubs_is_automatic_payment_subscription($subscription_id)
        ) {
            return;
        }

        ?>
        <div class="subscription-actions__auto-renew arraysubs-auto-renew-row arraysubs-auto-renew-row--unavailable">
            <span class="subscription-actions__auto-renew-label">
                <?php esc_html_e('Auto-Renew:', 'arraysubspro'); ?>
            </span>
            <span class="arraysubs-auto-renew-unavailable">
                <?php esc_html_e('Not available for this payment method. You will receive an invoice for manual payment at each renewal.', 'arraysubspro'); ?>
            </span>
        </div>
        <?php
    }

    /**
     * Force the Subscription Actions section to render when only the
     * auto-renew toggle is available (i.e. no core action buttons apply).
     *
     * Hooked to: arraysubs_view_subscription_force_show_actions
     *
     * @param bool  $force_show        Current force-show value.
     * @param int   $subscription_id   The subscription post ID.
     * @param array $subscription_data The subscription data array.
     * @return bool
     */
    public function maybeForceShowActionsSection(bool $force_show, int $subscription_id, array $subscription_data): bool
    {
        if ($force_show) {
            return true;
        }

        if ($this->resolveAutoRenewToggleGateway($subscription_id, $subscription_data)) {
            return true;
        }

        // Force the section open when only the unavailable-hint would appear
        // — without this the customer sees an empty Actions area on a manual
        // gateway and the hint never gets rendered.
        return $this->shouldRenderAutoRenewUnavailableHint($subscription_id, $subscription_data);
    }

    /**
     * Mirrors the gating used by maybeRenderAutoRenewUnavailableHint() so
     * the force-show check stays consistent with the actual render path.
     *
     * @param int   $subscription_id   Subscription ID.
     * @param array $subscription_data Subscription data array.
     * @return bool True when the unavailable hint would render.
     */
    private function shouldRenderAutoRenewUnavailableHint(int $subscription_id, array $subscription_data): bool
    {
        if (
            ! function_exists('arraysubs_is_auto_renew_toggle_allowed')
            || ! arraysubs_is_auto_renew_toggle_allowed()
        ) {
            return false;
        }

        $subscription = get_post($subscription_id);
        if (! $subscription instanceof \WP_Post) {
            return false;
        }

        if (
            ! in_array(
                $subscription->post_status,
                ['arraysubs-active', 'arraysubs-trial'],
                true
            )
        ) {
            return false;
        }

        if (! empty(get_post_meta($subscription_id, '_waiting_cancellation', true))) {
            return false;
        }

        $billing_period = $subscription_data['billing_period'] ?? get_post_meta($subscription_id, '_billing_period', true);
        if ('lifetime' === $billing_period) {
            return false;
        }

        if (
            function_exists('arraysubs_is_automatic_payment_subscription')
            && arraysubs_is_automatic_payment_subscription($subscription_id)
        ) {
            return false;
        }

        return true;
    }

    /**
     * Resolve the gateway eligible for the auto-renew toggle on this
     * subscription, or null when the toggle should not be displayed.
     *
     * @param int   $subscription_id   The subscription post ID.
     * @param array $subscription_data The subscription data array.
     * @return \ArraySubsPro\Features\AutomaticPayments\Contracts\AutomaticGatewayContract|null
     */
    private function resolveAutoRenewToggleGateway(int $subscription_id, array $subscription_data)
    {
        // Check global setting
        if (
            ! function_exists('arraysubs_is_auto_renew_toggle_allowed')
            || ! arraysubs_is_auto_renew_toggle_allowed()
        ) {
            return null;
        }

        if (
            ! function_exists('arraysubs_is_automatic_payment_subscription')
            || ! arraysubs_is_automatic_payment_subscription($subscription_id)
        ) {
            return null;
        }

        // Must have a resolvable automatic gateway.
        $gateway = GatewayResolver::resolveForSubscription($subscription_id);

        if (! $gateway || ! $gateway->supportsSubscriptionCapability('automatic_payments')) {
            return null;
        }

        // Must be in an eligible status
        $subscription = get_post($subscription_id);
        if (! $subscription instanceof \WP_Post) {
            return null;
        }

        $allowed_statuses = [
            'arraysubs-active',
            'arraysubs-trial',
        ];

        if (! in_array($subscription->post_status, $allowed_statuses, true)) {
            return null;
        }

        // Skip if pending cancellation
        $waiting_cancellation = get_post_meta($subscription_id, '_waiting_cancellation', true);
        if (! empty($waiting_cancellation)) {
            return null;
        }

        // Skip for lifetime subscriptions
        $billing_period = $subscription_data['billing_period'] ?? get_post_meta($subscription_id, '_billing_period', true);
        if ('lifetime' === $billing_period) {
            return null;
        }

        return $gateway;
    }

    /**
     * Enqueue customer portal pro assets on account pages.
     *
     * @return void
     */
    public function enqueueCustomerPortalAssets(): void
    {
        if (! function_exists('is_account_page') || ! is_account_page()) {
            return;
        }

        // Only load on view-subscription endpoint
        if (! is_wc_endpoint_url('view-subscription')) {
            return;
        }

        // Only load if toggle setting is enabled
        if (
            ! function_exists('arraysubs_is_auto_renew_toggle_allowed')
            || ! arraysubs_is_auto_renew_toggle_allowed()
        ) {
            return;
        }

        $asset_file = Config::get('proplugin.public_path') . 'build/customer-portal-pro.asset.php';
        $asset      = file_exists($asset_file)
            ? require $asset_file
            : ['dependencies' => ['jquery'], 'version' => ARRAYSUBSPRO_VERSION];

        wp_enqueue_style(
            'arraysubspro-customer-portal-pro',
            Config::get('proplugin.public_url') . 'build/customer-portal-pro.css',
            ['arraysubs-customer-portal'],
            $asset['version']
        );

        $dependencies = array_unique(array_merge($asset['dependencies'], ['jquery']));

        wp_enqueue_script(
            'arraysubspro-customer-portal-pro',
            Config::get('proplugin.public_url') . 'build/customer-portal-pro.js',
            $dependencies,
            $asset['version'],
            true
        );

        $json_flags = JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT;

        wp_add_inline_script(
            'arraysubspro-customer-portal-pro',
            'window.arraySubsAutoRenew = ' . wp_json_encode(
                [
                    'restUrl' => rest_url('arraysubs/v1/'),
                    'nonce'   => wp_create_nonce('wp_rest'),
                    'i18n'    => [
                        'on'             => __('On', 'arraysubspro'),
                        'off'            => __('Off', 'arraysubspro'),
                        'enabling'       => __('Enabling...', 'arraysubspro'),
                        'disabling'      => __('Disabling...', 'arraysubspro'),
                        'enabledText'    => __('Your subscription will be renewed automatically.', 'arraysubspro'),
                        'disabledText'   => __('You will receive an invoice for manual payment at your next renewal.', 'arraysubspro'),
                        'disabledNeedsSetupText' => __('Auto-renew is off. To turn it back on, refresh your payment method or billing authorization first.', 'arraysubspro'),
                        'confirmDisable' => __('Are you sure you want to turn off auto-renew? Your next renewal will require manual payment.', 'arraysubspro'),
                        'errorGeneric'   => __('Failed to update auto-renew setting. Please try again.', 'arraysubspro'),
                        'noPaymentMethod' => __('Cannot enable auto-renew: your automatic payment setup is no longer active. Please update your payment method first.', 'arraysubspro'),
                    ],
                ],
                $json_flags
            ) . ';',
            'before'
        );
    }
}
