<?php

/**
 * Stripe Subscription Compatibility
 *
 * Bridges ArraySubs subscription carts/orders into the official Stripe plugin's
 * reusable-payment-method capture flow.
 *
 * @package ArraySubsPro\Features\AutomaticPayments\Services
 */

namespace ArraySubsPro\Features\AutomaticPayments\Services;

defined('ABSPATH') || exit;

/**
 * Stripe subscription compatibility service.
 */
class StripeSubscriptionCompatibility
{
    /**
     * Enable auto-loading.
     *
     * @var bool
     */
    public static $loadable = true;

    /**
     * Constructor.
     */
    public function __construct()
    {
        add_filter('wc_stripe_force_save_payment_method', [$this, 'forceSavePaymentMethod'], 10, 2);
        add_filter('wc_stripe_generate_create_intent_request', [$this, 'forceIntentOffSessionSetup'], 10, 4);
        add_filter('wc_stripe_request_body', [$this, 'forceRequestBodyOffSessionSetup'], 10, 2);
        add_filter('woocommerce_get_customer_payment_tokens', [$this, 'filterUnavailableStripeTokens'], 20, 3);
        add_action('wc_gateway_stripe_process_payment_error', [$this, 'handleStripePaymentError'], 10, 2);
    }

    /**
     * Force Stripe to save reusable payment methods for ArraySubs subscriptions.
     *
     * @param bool     $force_save Current force-save value.
     * @param int|null $order_id   Order ID.
     * @return bool
     */
    public function forceSavePaymentMethod(bool $force_save, $order_id = null): bool
    {
        if ($force_save || ! is_user_logged_in() || ! StripeAvailability::isAvailable()) {
            return $force_save;
        }

        if (! empty($order_id)) {
            $order = wc_get_order(absint($order_id));
            return $order instanceof \WC_Order && $this->orderContainsSubscriptionProduct($order);
        }

        return function_exists('arraysubs_cart_contains_subscription') && arraysubs_cart_contains_subscription();
    }

    /**
     * Ensure PaymentIntent create/update requests request off-session reuse.
     *
     * @param array     $request         Request body.
     * @param \WC_Order $order           Order object.
     * @param mixed     $prepared_source Prepared source data.
     * @param bool      $is_setup_intent Whether this request creates a SetupIntent.
     * @return array
     */
    public function forceIntentOffSessionSetup(array $request, $order, $prepared_source = null, bool $is_setup_intent = false): array
    {
        if (! $order instanceof \WC_Order || ! $this->orderContainsSubscriptionProduct($order)) {
            return $request;
        }

        if (! $is_setup_intent) {
            $request['setup_future_usage'] = 'off_session';
        }

        $request['metadata']['save_payment_method']       = 'true';
        $request['metadata']['arraysubs_subscription_cart'] = 'true';

        return $request;
    }

    /**
     * Last-resort official Stripe request body fallback.
     *
     * @param array  $request Request body.
     * @param string $api     Stripe API endpoint.
     * @return array
     */
    public function forceRequestBodyOffSessionSetup(array $request, string $api): array
    {
        if (
            ! in_array($api, ['payment_intents', 'setup_intents'], true)
            || ! function_exists('arraysubs_cart_contains_subscription')
            || ! arraysubs_cart_contains_subscription()
        ) {
            return $request;
        }

        if ('payment_intents' === $api) {
            $request['setup_future_usage'] = $request['setup_future_usage'] ?? 'off_session';
        }

        $request['metadata']['save_payment_method'] = 'true';

        return $request;
    }

    /**
     * Remove saved Stripe tokens that no longer exist in the connected Stripe account.
     *
     * @param array  $tokens      Customer payment tokens.
     * @param int    $customer_id Customer ID.
     * @param string $gateway_id  Gateway ID.
     * @return array
     */
    public function filterUnavailableStripeTokens(array $tokens, int $customer_id, string $gateway_id): array
    {
        if (
            'stripe' !== $gateway_id
            || $customer_id <= 0
            || ! $this->shouldValidateSavedTokens()
            || ! StripeAvailability::isAvailable()
            || ! class_exists('\WC_Stripe_API')
            || ! class_exists('\WC_Payment_Tokens')
        ) {
            return $tokens;
        }

        foreach ($tokens as $token_key => $token) {
            if (! $token instanceof \WC_Payment_Token || 'stripe' !== $token->get_gateway_id()) {
                continue;
            }

            $payment_method_id = (string) $token->get_token();
            if ('' === $payment_method_id || $this->stripePaymentMethodExists($payment_method_id)) {
                continue;
            }

            $this->deleteStripeToken($token, $customer_id, $payment_method_id, 0);
            unset($tokens[$token_key]);
        }

        return $tokens;
    }

    /**
     * Clean up stale saved payment methods when Stripe rejects them during checkout.
     *
     * @param \WC_Stripe_Exception|\Exception $exception Stripe exception.
     * @param \WC_Order                       $order     Order object.
     * @return void
     */
    public function handleStripePaymentError($exception, $order): void
    {
        if (
            ! $order instanceof \WC_Order
            || 'stripe' !== $order->get_payment_method()
            || ! class_exists('\WC_Payment_Tokens')
        ) {
            return;
        }

        $message           = method_exists($exception, 'getMessage') ? (string) $exception->getMessage() : '';
        $payment_method_id = $this->extractMissingPaymentMethodId($message);
        if ('' === $payment_method_id) {
            return;
        }

        $customer_id = (int) $order->get_customer_id();
        if ($customer_id <= 0) {
            return;
        }

        $tokens = \WC_Payment_Tokens::get_tokens([
            'user_id'    => $customer_id,
            'gateway_id' => 'stripe',
        ]);

        foreach ($tokens as $token) {
            if (! $token instanceof \WC_Payment_Token || $payment_method_id !== (string) $token->get_token()) {
                continue;
            }

            $this->deleteStripeToken($token, $customer_id, $payment_method_id, $order->get_id());
            $this->clearOrderStripePaymentMethod($order, $payment_method_id);
            break;
        }
    }

    /**
     * Check order line items for ArraySubs subscription products.
     *
     * @param \WC_Order $order Order object.
     * @return bool
     */
    private function orderContainsSubscriptionProduct(\WC_Order $order): bool
    {
        if (! function_exists('arraysubs_is_subscription_product')) {
            return false;
        }

        foreach ($order->get_items() as $item) {
            $product_id = $item->get_variation_id() ?: $item->get_product_id();
            if ($product_id && arraysubs_is_subscription_product($product_id)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Check whether saved token validation should run for the current request.
     *
     * @return bool
     */
    private function shouldValidateSavedTokens(): bool
    {
        return function_exists('arraysubs_cart_contains_subscription') && arraysubs_cart_contains_subscription();
    }

    /**
     * Check whether a Stripe payment method exists in the currently connected account.
     *
     * @param string $payment_method_id Payment method ID.
     * @return bool
     */
    private function stripePaymentMethodExists(string $payment_method_id): bool
    {
        try {
            $response = \WC_Stripe_API::get_payment_method($payment_method_id);
        } catch (\Throwable $throwable) {
            return true;
        }

        $response = $this->objectToArray($response);
        if (! isset($response['error']) || ! is_array($response['error'])) {
            return true;
        }

        return ! $this->isMissingPaymentMethodError($response['error'], $payment_method_id);
    }

    /**
     * Delete a stale WooCommerce Stripe token and clear its stale customer context.
     *
     * @param \WC_Payment_Token $token             Token object.
     * @param int               $customer_id       Customer ID.
     * @param string            $payment_method_id Stripe payment method ID.
     * @param int               $order_id          Related order ID.
     * @return void
     */
    private function deleteStripeToken(\WC_Payment_Token $token, int $customer_id, string $payment_method_id, int $order_id = 0): void
    {
        \WC_Payment_Tokens::delete($token->get_id());
        $this->clearUserStripeCustomerContext($customer_id);

        PaymentLoggingService::log(
            'stripe',
            'warning',
            sprintf(
                'Removed stale saved Stripe payment method %s because it does not exist in the connected Stripe account.',
                $this->maskStripeId($payment_method_id)
            ),
            [
                'customer_id' => $customer_id,
                'order_id'    => $order_id,
                'token_id'    => $token->get_id(),
            ]
        );
    }

    /**
     * Clear stale Stripe customer IDs so the official gateway can create a fresh customer.
     *
     * @param int $customer_id Customer ID.
     * @return void
     */
    private function clearUserStripeCustomerContext(int $customer_id): void
    {
        if ($customer_id <= 0) {
            return;
        }

        delete_user_option($customer_id, '_stripe_customer_id');
        delete_user_option($customer_id, '_stripe_customer_id_test');
        delete_user_option($customer_id, '_stripe_customer_id_live');
    }

    /**
     * Remove stale Stripe method metadata from the failed order.
     *
     * @param \WC_Order $order             Order object.
     * @param string    $payment_method_id Payment method ID.
     * @return void
     */
    private function clearOrderStripePaymentMethod(\WC_Order $order, string $payment_method_id): void
    {
        if ($payment_method_id !== (string) $order->get_meta('_stripe_source_id', true)) {
            return;
        }

        $order->delete_meta_data('_stripe_source_id');
        $order->delete_meta_data('_gateway_payment_method_id');
        $order->save();
    }

    /**
     * Extract a missing PaymentMethod ID from an official Stripe exception payload.
     *
     * @param string $message Exception message.
     * @return string
     */
    private function extractMissingPaymentMethodId(string $message): string
    {
        if (
            false === stripos($message, 'resource_missing')
            && false === stripos($message, 'No such PaymentMethod')
        ) {
            return '';
        }

        if (preg_match("/No such PaymentMethod:\\s*'([^']+)'/i", $message, $matches)) {
            return sanitize_text_field($matches[1]);
        }

        if (preg_match('/No such PaymentMethod:\s*([A-Za-z0-9_]+)/i', $message, $matches)) {
            return sanitize_text_field($matches[1]);
        }

        return '';
    }

    /**
     * Check whether a Stripe API error means the stored method is missing.
     *
     * @param array  $error             Stripe error array.
     * @param string $payment_method_id Payment method ID.
     * @return bool
     */
    private function isMissingPaymentMethodError(array $error, string $payment_method_id): bool
    {
        $code    = (string) ($error['code'] ?? '');
        $param   = (string) ($error['param'] ?? '');
        $message = (string) ($error['message'] ?? '');

        return 'resource_missing' === $code
            && 'payment_method' === $param
            && false !== strpos($message, $payment_method_id);
    }

    /**
     * Convert API response objects recursively to arrays.
     *
     * @param mixed $value Value.
     * @return array
     */
    private function objectToArray($value): array
    {
        if (is_array($value)) {
            return array_map([$this, 'objectToArrayValue'], $value);
        }

        if (is_object($value)) {
            return $this->objectToArray(get_object_vars($value));
        }

        return [];
    }

    /**
     * Convert nested response values.
     *
     * @param mixed $value Value.
     * @return mixed
     */
    private function objectToArrayValue($value)
    {
        if (is_array($value) || is_object($value)) {
            return $this->objectToArray($value);
        }

        return $value;
    }

    /**
     * Mask Stripe IDs before writing logs.
     *
     * @param string $id Stripe object ID.
     * @return string
     */
    private function maskStripeId(string $id): string
    {
        if (strlen($id) <= 12) {
            return $id;
        }

        return substr($id, 0, 8) . '...' . substr($id, -4);
    }
}
