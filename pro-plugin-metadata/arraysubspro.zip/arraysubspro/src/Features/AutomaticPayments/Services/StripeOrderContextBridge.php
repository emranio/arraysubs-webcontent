<?php

/**
 * Stripe Order Context Bridge
 *
 * Copies official WooCommerce Stripe order metadata onto ArraySubs
 * subscriptions for renewals, reporting, and customer portal display.
 *
 * @package ArraySubsPro\Features\AutomaticPayments\Services
 */

namespace ArraySubsPro\Features\AutomaticPayments\Services;

defined('ABSPATH') || exit;

/**
 * Stripe order context bridge.
 */
class StripeOrderContextBridge
{
    /**
     * Enable auto-loading.
     *
     * @var bool
     */
    public static $loadable = true;

    /**
     * Constructor.
     *
     * @param bool $register_hooks Whether hooks should be registered.
     */
    public function __construct(bool $register_hooks = true)
    {
        if (! $register_hooks) {
            return;
        }

        add_action('arraysubs_gateway_context_captured', [$this, 'captureFromLinkedOrder'], 20, 3);
        add_action('woocommerce_payment_complete', [$this, 'captureFromPaidOrder'], 20, 1);
        add_action('wc_stripe_webhook_received', [$this, 'handleOfficialStripeWebhook'], 20, 3);
    }

    /**
     * Capture context when core links a paid order to a subscription.
     *
     * @param int   $subscription_id Subscription ID.
     * @param int   $order_id        Order ID.
     * @param array $context         Context.
     * @return void
     */
    public function captureFromLinkedOrder(int $subscription_id, int $order_id, array $context = []): void
    {
        $order = wc_get_order($order_id);
        if ($order instanceof \WC_Order) {
            $this->capture($order, $subscription_id);
        }
    }

    /**
     * Capture context after WooCommerce marks an order paid.
     *
     * @param int $order_id Order ID.
     * @return void
     */
    public function captureFromPaidOrder(int $order_id): void
    {
        $order = wc_get_order($order_id);
        if (! $order instanceof \WC_Order || 'stripe' !== $order->get_payment_method()) {
            return;
        }

        foreach (PaymentMetaNormalizer::findSubscriptionIdsForOrder($order_id) as $subscription_id) {
            $this->capture($order, (int) $subscription_id);
        }
    }

    /**
     * Handle official Stripe setup/payment webhooks for final context refresh.
     *
     * @param string          $event_type    Stripe event type.
     * @param array|object    $notification  Notification payload.
     * @param \WC_Order|mixed $resolved_order Resolved order.
     * @return void
     */
    public function handleOfficialStripeWebhook(string $event_type, $notification, $resolved_order = null): void
    {
        if (! in_array($event_type, ['setup_intent.succeeded', 'payment_intent.succeeded'], true)) {
            return;
        }

        $payload = $this->extractObjectFromNotification($notification);
        $order   = $resolved_order instanceof \WC_Order ? $resolved_order : null;

        if (! $order && ! empty($payload['metadata']['order_id'])) {
            $order = wc_get_order(absint($payload['metadata']['order_id']));
        }

        $subscription_id = ! empty($payload['metadata']['subscription_id'])
            ? absint($payload['metadata']['subscription_id'])
            : 0;

        if ($subscription_id <= 0 && $order instanceof \WC_Order) {
            $subscription_ids = PaymentMetaNormalizer::findSubscriptionIdsForOrder($order->get_id());
            $subscription_id  = ! empty($subscription_ids) ? (int) $subscription_ids[0] : 0;
        }

        if ($subscription_id <= 0 && ! empty($payload['customer']) && is_string($payload['customer'])) {
            $subscription_id = PaymentMetaNormalizer::findSubscriptionByGatewayCustomer($payload['customer'], 'stripe');
        }

        if ($subscription_id <= 0) {
            return;
        }

        if ($order instanceof \WC_Order) {
            $this->capture($order, $subscription_id);
            return;
        }

        $pm_id       = is_string($payload['payment_method'] ?? null) ? $payload['payment_method'] : '';
        $customer_id = is_string($payload['customer'] ?? null) ? $payload['customer'] : '';
        if ('' !== $pm_id || '' !== $customer_id) {
            $this->persistPaymentMethod($subscription_id, $pm_id, $customer_id);
        }
    }

    /**
     * Capture official Stripe order metadata.
     *
     * @param \WC_Order $order           Order object.
     * @param int       $subscription_id Subscription ID.
     * @return array
     */
    public function capture(\WC_Order $order, int $subscription_id): array
    {
        if ('stripe' !== $order->get_payment_method()) {
            return [];
        }

        $customer_id = (string) $order->get_meta('_stripe_customer_id', true);
        $pm_id       = (string) $order->get_meta('_stripe_source_id', true);
        $type        = (string) $order->get_meta('_stripe_upe_payment_type', true);
        $brand       = (string) $order->get_meta('_stripe_card_brand', true);
        $intent_id   = (string) $order->get_meta('_stripe_intent_id', true);
        $charge_id   = (string) $order->get_meta('_stripe_charge_id', true);

        if ('' === $charge_id && str_starts_with((string) $order->get_transaction_id(), 'ch_')) {
            $charge_id = (string) $order->get_transaction_id();
        }

        $pm_details = [];
        if ('' !== $pm_id) {
            $pm_details = $this->getPaymentMethodDetails($pm_id);
            $type       = $type ?: (string) ($pm_details['type'] ?? '');
            $brand      = $brand ?: (string) ($pm_details['brand'] ?? '');
        }

        $meta = [
            '_payment_gateway'             => 'stripe',
            '_payment_method'              => 'stripe',
            '_payment_method_title'        => 'Stripe',
            '_gateway_status'              => '' !== $pm_id ? 'active' : 'errored',
            '_gateway_customer_id'         => $customer_id,
            '_gateway_payment_method_id'   => $pm_id,
            '_payment_method_type'         => $type ?: 'card',
            '_payment_method_brand'        => $brand,
            '_payment_method_last4'        => (string) ($pm_details['last4'] ?? ''),
            '_payment_method_expiry_month' => (string) ($pm_details['exp_month'] ?? ''),
            '_payment_method_expiry_year'  => (string) ($pm_details['exp_year'] ?? ''),
            '_payment_method_wallet'       => (string) ($pm_details['wallet'] ?? ''),
        ];

        if ('' !== $charge_id) {
            $meta['_last_gateway_transaction_id'] = $charge_id;
        } elseif ('' !== $intent_id) {
            $meta['_last_gateway_transaction_id'] = $intent_id;
        }

        foreach ($meta as $key => $value) {
            if ('' !== (string) $value) {
                update_post_meta($subscription_id, $key, sanitize_text_field((string) $value));
            }
        }

        MandateRegistry::cacheFromOrder($order, $subscription_id);

        if ('' === $pm_id) {
            PaymentLoggingService::logPayment(
                'stripe',
                $subscription_id,
                'Stripe checkout completed but no reusable payment method was saved. Auto-renewal requires the customer to update the payment method.',
                'error'
            );
        }

        return $meta;
    }

    /**
     * Persist payment method details from a SetupIntent.
     *
     * @param int    $subscription_id Subscription ID.
     * @param string $pm_id           Payment method ID.
     * @param string $customer_id     Stripe customer ID.
     * @return void
     */
    private function persistPaymentMethod(int $subscription_id, string $pm_id, string $customer_id): void
    {
        $details = '' !== $pm_id ? $this->getPaymentMethodDetails($pm_id) : [];

        $meta = [
            '_payment_gateway'             => 'stripe',
            '_payment_method'              => 'stripe',
            '_payment_method_title'        => 'Stripe',
            '_gateway_status'              => '' !== $pm_id ? 'active' : 'errored',
            '_gateway_customer_id'         => $customer_id,
            '_gateway_payment_method_id'   => $pm_id,
            '_payment_method_type'         => (string) ($details['type'] ?? 'card'),
            '_payment_method_brand'        => (string) ($details['brand'] ?? ''),
            '_payment_method_last4'        => (string) ($details['last4'] ?? ''),
            '_payment_method_expiry_month' => (string) ($details['exp_month'] ?? ''),
            '_payment_method_expiry_year'  => (string) ($details['exp_year'] ?? ''),
            '_payment_method_wallet'       => (string) ($details['wallet'] ?? ''),
        ];

        foreach ($meta as $key => $value) {
            if ('' !== (string) $value) {
                update_post_meta($subscription_id, $key, sanitize_text_field((string) $value));
            }
        }
    }

    /**
     * Retrieve normalized payment method details.
     *
     * @param string $pm_id Payment method ID.
     * @return array
     */
    private function getPaymentMethodDetails(string $pm_id): array
    {
        if (! StripeAvailability::isAvailable() || ! class_exists('\WC_Stripe_API')) {
            return [];
        }

        try {
            $pm = \WC_Stripe_API::retrieve('payment_methods/' . rawurlencode($pm_id));
        } catch (\Throwable $throwable) {
            return [];
        }

        $pm   = $this->objectToArray($pm);
        $type = (string) ($pm['type'] ?? 'card');
        $card = is_array($pm[$type] ?? null) ? $pm[$type] : ($pm['card'] ?? []);

        return [
            'type'      => $type,
            'brand'     => (string) ($card['brand'] ?? ''),
            'last4'     => (string) ($card['last4'] ?? ''),
            'exp_month' => (string) ($card['exp_month'] ?? ''),
            'exp_year'  => (string) ($card['exp_year'] ?? ''),
            'wallet'    => (string) ($card['wallet']['type'] ?? ('link' === $type ? 'link' : '')),
        ];
    }

    /**
     * Extract event data.object from official Stripe webhook notification.
     *
     * @param array|object $notification Notification.
     * @return array
     */
    private function extractObjectFromNotification($notification): array
    {
        $notification = $this->objectToArray($notification);

        return is_array($notification['data']['object'] ?? null)
            ? $notification['data']['object']
            : $notification;
    }

    /**
     * Convert API response objects recursively to arrays.
     *
     * @param mixed $value Value.
     * @return array
     */
    private function objectToArray($value): array
    {
        if (is_array($value)) {
            return array_map([$this, 'objectToArrayValue'], $value);
        }

        if (is_object($value)) {
            return $this->objectToArray(get_object_vars($value));
        }

        return [];
    }

    /**
     * Convert nested values.
     *
     * @param mixed $value Value.
     * @return mixed
     */
    private function objectToArrayValue($value)
    {
        if (is_array($value) || is_object($value)) {
            return $this->objectToArray($value);
        }

        return $value;
    }
}
