<?php

/**
 * Stripe Availability
 *
 * Soft-gates the ArraySubs Stripe bridge on the official WooCommerce Stripe
 * gateway plugin without blocking other Pro features.
 *
 * @package ArraySubsPro\Features\AutomaticPayments\Services
 */

namespace ArraySubsPro\Features\AutomaticPayments\Services;

defined('ABSPATH') || exit;

/**
 * Stripe availability service.
 */
class StripeAvailability
{
    /**
     * Enable auto-loading.
     *
     * @var bool
     */
    public static $loadable = true;

    /**
     * Minimum official Stripe gateway version.
     *
     * @var string
     */
    const MIN_VERSION = '9.8.0';

    /**
     * Version this bridge was tested against.
     *
     * @var string
     */
    const TESTED_VERSION = '10.6.1';

    /**
     * Constructor.
     */
    public function __construct()
    {
        add_action('admin_notices', [$this, 'renderAdminNotice']);
    }

    /**
     * Check whether the official Stripe plugin is available.
     *
     * @return bool
     */
    public static function isAvailable(): bool
    {
        return 'available' === self::getStatus();
    }

    /**
     * Get minimum version.
     *
     * @return string
     */
    public static function getMinVersion(): string
    {
        return self::MIN_VERSION;
    }

    /**
     * Get tested version.
     *
     * @return string
     */
    public static function getTestedVersion(): string
    {
        return self::TESTED_VERSION;
    }

    /**
     * Get installed official Stripe gateway version.
     *
     * @return string
     */
    public static function getInstalledVersion(): string
    {
        if (defined('WC_STRIPE_VERSION')) {
            return (string) WC_STRIPE_VERSION;
        }

        if (! function_exists('get_plugins')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        $plugins = get_plugins();
        foreach ($plugins as $plugin_file => $plugin_data) {
            if (
                false !== strpos($plugin_file, 'woocommerce-gateway-stripe')
                && ! empty($plugin_data['Version'])
            ) {
                return (string) $plugin_data['Version'];
            }
        }

        return '';
    }

    /**
     * Get availability status.
     *
     * @return string available|missing|too_old
     */
    public static function getStatus(): string
    {
        if (! class_exists('\WC_Stripe_API')) {
            return 'missing';
        }

        $version = self::getInstalledVersion();
        if ('' !== $version && version_compare($version, self::MIN_VERSION, '<')) {
            return 'too_old';
        }

        return 'available';
    }

    /**
     * Render a scoped admin notice when Stripe bridge dependencies are missing.
     *
     * @return void
     */
    public function renderAdminNotice(): void
    {
        $status = self::getStatus();
        if ('available' === $status) {
            return;
        }

        if (! current_user_can('manage_woocommerce')) {
            return;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Display-only admin screen detection.
        $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';
        if (! in_array($page, ['wc-settings', 'arraysubs'], true)) {
            return;
        }

        $message = 'missing' === $status
            ? sprintf(
                /* translators: %s: minimum version */
                __('ArraySubs Stripe automatic payments require the official WooCommerce Stripe Gateway plugin version %s or newer. Other ArraySubsPro gateways and features remain available.', 'arraysubspro'),
                self::MIN_VERSION
            )
            : sprintf(
                /* translators: 1: installed version, 2: minimum version */
                __('ArraySubs Stripe automatic payments require WooCommerce Stripe Gateway %2$s or newer. Installed version: %1$s. Other ArraySubsPro gateways and features remain available.', 'arraysubspro'),
                self::getInstalledVersion(),
                self::MIN_VERSION
            );

        printf(
            '<div class="notice notice-warning is-dismissible"><p>%s</p></div>',
            esc_html($message)
        );
    }
}
