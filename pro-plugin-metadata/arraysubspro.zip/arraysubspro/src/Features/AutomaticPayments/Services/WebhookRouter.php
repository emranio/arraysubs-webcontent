<?php

/**
 * Webhook Router
 *
 * Routes incoming webhooks to the correct gateway handler.
 * Handles signature verification, idempotency checks, event parsing,
 * entity resolution, and dispatching to the appropriate handler method.
 *
 * @package ArraySubsPro\Features\AutomaticPayments\Services
 * @since 1.0.0
 */

namespace ArraySubsPro\Features\AutomaticPayments\Services;

defined('ABSPATH') || exit;

use ArraySubsPro\Features\AutomaticPayments\Contracts\AutomaticGatewayContract;

/**
 * Webhook Router Service
 */
class WebhookRouter
{
    /**
     * Process an incoming webhook request.
     *
     * @param string           $gateway_slug The gateway slug from the URL.
     * @param \WP_REST_Request $request      The incoming request.
     * @return \WP_REST_Response
     */
    public static function process(string $gateway_slug, \WP_REST_Request $request): \WP_REST_Response
    {
        $gateway = GatewayResolver::resolveBySlug($gateway_slug);

        self::doAction('arraysubs_gateway_webhook_received', $gateway_slug, $request->get_body());

        if (! $gateway) {
            PaymentLoggingService::logWebhook(
                $gateway_slug,
                'error',
                'Webhook received for unknown gateway: ' . $gateway_slug
            );
            return new \WP_REST_Response(['error' => 'Unknown gateway'], 400);
        }

        // Step 1: Verify signature
        if (! $gateway->verifyWebhookSignature($request)) {
            PaymentLoggingService::logWebhook(
                $gateway_slug,
                'error',
                'Webhook signature verification failed'
            );

            self::doAction('arraysubs_gateway_webhook_rejected', $gateway_slug, 'invalid_signature');

            return new \WP_REST_Response(['error' => 'Invalid signature'], 401);
        }

        // Step 2: Parse webhook payload
        $parsed = $gateway->parseWebhook($request);

        if (empty($parsed['success'])) {
            PaymentLoggingService::logWebhook(
                $gateway_slug,
                'error',
                'Failed to parse webhook payload'
            );
            return new \WP_REST_Response(['error' => 'Parse failed'], 400);
        }

        self::doAction('arraysubs_gateway_webhook_verified', $gateway_slug, $parsed['gateway_event_id'] ?? '', $parsed['gateway_event_type'] ?? '');

        // Step 3: Idempotency check
        $event_id = $parsed['gateway_event_id'] ?? '';
        if (! empty($event_id) && $gateway->isDuplicateEvent($event_id)) {
            PaymentLoggingService::logWebhook(
                $gateway_slug,
                'info',
                sprintf('Duplicate webhook event skipped: %s', $event_id)
            );
            return new \WP_REST_Response(['received' => true, 'duplicate' => true], 200);
        }

        // Step 4: Resolve entities
        $entities = $gateway->resolveEntityIds($parsed);

        // Step 5: Build context
        $context = self::buildContext($parsed, $entities, $gateway);
        $context = self::applyFilters('arraysubs_gateway_webhook_context', $context, $parsed, $gateway->getGatewaySlug());

        // Step 6: Dispatch to handler
        $normalized_event = $parsed['normalized_event_type'] ?? '';

        try {
            $result = self::dispatch($gateway, $normalized_event, $context);
        } catch (\Throwable $throwable) {
            PaymentLoggingService::logWebhook(
                $gateway_slug,
                'error',
                'Webhook handler exception: ' . $throwable->getMessage()
            );

            return new \WP_REST_Response(['error' => 'Processing failed'], 500);
        }

        if (! empty($event_id) && ! empty($result['success'])) {
            $gateway->rememberEvent($event_id, $parsed['gateway_event_type'] ?? '');
        }

        PaymentLoggingService::logWebhook(
            $gateway_slug,
            'info',
            sprintf(
                'Webhook processed: %s → %s (subscription: %d, order: %d)',
                $parsed['gateway_event_type'] ?? 'unknown',
                $normalized_event,
                $entities['subscription_id'] ?? 0,
                $entities['order_id'] ?? 0
            )
        );

        return new \WP_REST_Response(['received' => true, 'processed' => $result['success'] ?? false], 200);
    }

    /**
     * Build event context for handler dispatch.
     *
     * @param array                    $parsed   Parsed webhook data.
     * @param array                    $entities Resolved entity IDs.
     * @param AutomaticGatewayContract $gateway  The gateway instance.
     * @return array
     */
    private static function buildContext(array $parsed, array $entities, AutomaticGatewayContract $gateway): array
    {
        $subscription_id = $entities['subscription_id'] ?? 0;
        $order_id        = $entities['order_id'] ?? 0;

        $subscription = null;
        if ($subscription_id > 0 && function_exists('arraysubs_get_subscription')) {
            $subscription = arraysubs_get_subscription($subscription_id);
        }

        $order = null;
        if ($order_id > 0) {
            $order = wc_get_order($order_id);
        }

        return [
            'parsed'             => $parsed,
            'payload'            => $parsed['payload'] ?? [],
            'gateway_event_type' => $parsed['gateway_event_type'] ?? '',
            'subscription_id'    => $subscription_id,
            'order_id'           => $order_id,
            'customer_id'        => $entities['customer_id'] ?? 0,
            'order'              => $order ?: null,
            'subscription'       => $subscription ?: null,
            'gateway_slug'       => $gateway->getGatewaySlug(),
        ];
    }

    /**
     * Dispatch a WordPress action when available.
     *
     * @param string $hook_name Action name.
     * @param mixed  ...$args   Action arguments.
     * @return void
     */
    private static function doAction(string $hook_name, ...$args): void
    {
        if (! \function_exists('do_action')) {
            return;
        }

        \call_user_func('do_action', $hook_name, ...$args);
    }

    /**
     * Apply a WordPress filter when available.
     *
     * @param string $hook_name Filter name.
     * @param mixed  $value     Filtered value.
     * @param mixed  ...$args   Additional filter arguments.
     * @return mixed
     */
    private static function applyFilters(string $hook_name, $value, ...$args)
    {
        if (! \function_exists('apply_filters')) {
            return $value;
        }

        return \call_user_func('apply_filters', $hook_name, $value, ...$args);
    }

    /**
     * Dispatch to the correct handler method on the gateway.
     *
     * @param AutomaticGatewayContract $gateway          The gateway instance.
     * @param string                   $normalized_event The normalized event type.
     * @param array                    $context          The event context.
     * @return array{success: bool, message: string}
     */
    private static function dispatch(AutomaticGatewayContract $gateway, string $normalized_event, array $context): array
    {
        $handler_map = [
            AutomaticGatewayContract::EVENT_PAYMENT_SUCCEEDED       => 'handlePaymentSucceeded',
            AutomaticGatewayContract::EVENT_PAYMENT_FAILED          => 'handlePaymentFailed',
            AutomaticGatewayContract::EVENT_PAYMENT_REQUIRES_ACTION => 'handlePaymentRequiresAction',
            AutomaticGatewayContract::EVENT_PAYMENT_METHOD_UPDATED  => 'handlePaymentMethodUpdated',
            AutomaticGatewayContract::EVENT_CARD_EXPIRING           => 'handleCardExpiring',
            AutomaticGatewayContract::EVENT_REFUND_CREATED          => 'handleRefundCreated',
            AutomaticGatewayContract::EVENT_DISPUTE_CREATED         => 'handleDisputeCreated',
            AutomaticGatewayContract::EVENT_DISPUTE_RESOLVED        => 'handleDisputeResolved',
            AutomaticGatewayContract::EVENT_SUBSCRIPTION_CANCELLED  => 'handleSubscriptionCancelled',
        ];

        // Standard normalized event — dispatch to known handler.
        if (isset($handler_map[$normalized_event])) {
            $method = $handler_map[$normalized_event];
            return $gateway->$method($context);
        }

        // Custom/gateway-specific event (normalized to empty string).
        // Derive handler from the raw gateway event type.
        // e.g. "subscription.created" → "handleSubscriptionCreated"
        $gateway_event_type = $context['gateway_event_type'] ?? '';

        if (! empty($gateway_event_type)) {
            $method = self::deriveHandlerMethod($gateway_event_type);

            if (! empty($method) && method_exists($gateway, $method)) {
                return $gateway->$method($context);
            }
        }

        PaymentLoggingService::logWebhook(
            $gateway->getGatewaySlug(),
            'warning',
            sprintf('No handler for event: %s (normalized: %s)', $gateway_event_type, $normalized_event)
        );

        return ['success' => false, 'message' => 'Unhandled event type'];
    }

    /**
     * Derive a handler method name from a raw gateway event type.
     *
     * Converts "subscription.created" → "handleSubscriptionCreated",
     * "transaction.payment_failed" → "handleTransactionPaymentFailed", etc.
     *
     * @param string $gateway_event_type Raw event type from the gateway.
     * @return string Handler method name.
     */
    private static function deriveHandlerMethod(string $gateway_event_type): string
    {
        // Replace dots and underscores with spaces, capitalize each word, remove spaces.
        $parts = preg_replace('/[^a-zA-Z0-9]/', ' ', $gateway_event_type);
        $parts = ucwords(strtolower($parts));
        $parts = str_replace(' ', '', $parts);

        return 'handle' . $parts;
    }
}
