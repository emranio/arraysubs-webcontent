<?php

/**
 * Subscription Shipping Hooks
 *
 * Main hooks class for subscription shipping functionality.
 * Handles shipping data capture, renewal shipping calculations,
 * and integration with WooCommerce shipping system.
 *
 * @package ArraySubsPro\Features\SubscriptionShipping\Services
 * @since 1.0.0
 */

namespace ArraySubsPro\Features\SubscriptionShipping\Services;

defined('ABSPATH') || exit;

/**
 * WordPress hooks for subscription shipping
 */
class Hooks
{
    /**
     * Initial shipping fee name prefix.
     *
     * @var string
     */
    private const INITIAL_SHIPPING_FEE_PREFIX = 'ArraySubs initial shipping';

    /**
     * Enable auto-loading
     *
     * @var bool
     */
    public static $loadable = true;

    /**
     * Constructor
     */
    public function __construct()
    {
        // Capture shipping data when subscription is created
        add_action('arraysubs_data_created_from_order', [$this, 'captureShippingFromOrder'], 10, 3);

        // Display shipping info on product page
        add_action('woocommerce_single_product_summary', [$this, 'displayProductShippingInfo'], 25);

        // Display shipping breakdown in cart
        add_action('woocommerce_cart_totals_after_shipping', [$this, 'displayCartShippingInfo']);
        add_action('woocommerce_review_order_after_shipping', [$this, 'displayCheckoutShippingInfo']);
        add_filter('arraysubs_subscription_cart_item_data', [$this, 'addShippingCartItemData'], 10, 4);

        // Charge configured initial subscription shipping before payment is taken.
        add_action('woocommerce_cart_calculate_fees', [$this, 'addInitialShippingFees'], 20, 1);
        add_action('woocommerce_checkout_create_order_fee_item', [$this, 'markInitialShippingFeeItem'], 10, 4);

        // Recalculate shipping settings when an in-place plan switch completes.
        add_action('arraysubs_plan_switch_completed', [$this, 'onPlanSwitchCompleted'], 10, 4);

        // Let deferred switch renewal orders charge target-plan shipping.
        add_filter('arraysubs_renewal_shipping_context', [$this, 'filterRenewalShippingContext'], 10, 4);
    }

    /**
     * Add initial shipping override fees for subscription products.
     *
     * This runs for both classic checkout and the WooCommerce Store API cart
     * calculation flow, ensuring the first subscription payment includes the
     * configured initial shipping amount.
     *
     * @param \WC_Cart $cart WooCommerce cart.
     * @return void
     */
    public function addInitialShippingFees($cart): void
    {
        if (is_admin() && !wp_doing_ajax()) {
            return;
        }

        if (!$cart instanceof \WC_Cart || $cart->is_empty()) {
            return;
        }

        $fees = $this->getCartInitialShippingFees($cart);

        foreach ($fees as $fee) {
            $cart->add_fee($fee['name'], $fee['amount'], false);
        }
    }

    /**
     * Mark generated initial shipping fee items for later capture.
     *
     * @param \WC_Order_Item_Fee $item    Fee item.
     * @param string             $fee_key Fee key.
     * @param object             $fee     Cart fee object.
     * @param \WC_Order          $order   Order object.
     * @return void
     */
    public function markInitialShippingFeeItem($item, string $fee_key, $fee, $order): void
    {
        if (!$item instanceof \WC_Order_Item_Fee || empty($fee->name)) {
            return;
        }

        if (strpos((string) $fee->name, self::INITIAL_SHIPPING_FEE_PREFIX) !== 0) {
            return;
        }

        $item->add_meta_data('_arraysubs_initial_shipping_fee', 'yes', true);
    }

    /**
     * Append shipping terms to subscription cart item metadata.
     *
     * @param array $details   Existing subscription item detail rows.
     * @param array $cart_item Cart item data.
     * @param array $data      Subscription product data.
     * @param int   $quantity  Cart item quantity.
     * @return array
     */
    public function addShippingCartItemData(array $details, array $cart_item, array $data, int $quantity): array
    {
        $product_id = !empty($cart_item['variation_id']) ? (int) $cart_item['variation_id'] : (int) ($cart_item['product_id'] ?? 0);

        if ($product_id <= 0) {
            return $details;
        }

        $product = wc_get_product($product_id);

        if (!$product || !$product->needs_shipping()) {
            return $details;
        }

        $shipping_type = get_post_meta($product_id, '_arraysubs_shipping_type', true);

        if (empty($shipping_type) && !empty($cart_item['variation_id'])) {
            $shipping_type = get_post_meta((int) $cart_item['product_id'], '_arraysubs_shipping_type', true);
        }

        $shipping_type = $shipping_type ?: 'recurring';

        $details[] = [
            'key'       => __('Shipping', 'arraysubspro'),
            'value'     => $shipping_type === 'one-time'
                ? __('📦 One-time shipping (first order only)', 'arraysubspro')
                : __('🔄 Shipping charged on every renewal', 'arraysubspro'),
            'className' => 'arraysubs-subscription-meta arraysubs-subscription-meta--shipping',
        ];

        return $details;
    }

    /**
     * Capture shipping data from parent order when subscription is created
     *
     * @param int   $subscription_id Subscription ID
     * @param int   $order_id        Parent order ID
     * @param mixed $item            Order item
     */
    public function captureShippingFromOrder(int $subscription_id, int $order_id, $item): void
    {
        $order = wc_get_order($order_id);
        if (!$order) {
            return;
        }

        // Get product to check if it needs shipping
        $product_id = $item->get_product_id();
        $variation_id = $item->get_variation_id();
        $check_product_id = $variation_id > 0 ? $variation_id : $product_id;

        $product = wc_get_product($check_product_id);
        if (!$product || !$product->needs_shipping()) {
            // Virtual or downloadable product - no shipping data needed
            return;
        }

        // Get shipping type from product settings
        $shipping_type = get_post_meta($check_product_id, '_arraysubs_shipping_type', true);
        if (empty($shipping_type)) {
            // Check parent product for variations
            if ($variation_id > 0) {
                $shipping_type = get_post_meta($product_id, '_arraysubs_shipping_type', true);
            }
        }
        // Default to recurring if not set
        $shipping_type = $shipping_type ?: 'recurring';

        // Get shipping methods from order
        $shipping_methods = $order->get_shipping_methods();
        $shipping_method_id = '';
        $shipping_method_title = '';
        $shipping_total = 0;

        foreach ($shipping_methods as $shipping_method) {
            $shipping_method_id = $shipping_method->get_method_id() . ':' . $shipping_method->get_instance_id();
            $shipping_method_title = $shipping_method->get_method_title();
            $shipping_total += floatval($shipping_method->get_total());
        }

        // Get override amounts from product if set
        $initial_shipping_override = get_post_meta($check_product_id, '_arraysubs_initial_shipping_override', true);
        $renewal_shipping_override = get_post_meta($check_product_id, '_arraysubs_renewal_shipping_override', true);

        // Check parent product for variations
        if ($variation_id > 0 && empty($initial_shipping_override)) {
            $initial_shipping_override = get_post_meta($product_id, '_arraysubs_initial_shipping_override', true);
        }
        if ($variation_id > 0 && empty($renewal_shipping_override)) {
            $renewal_shipping_override = get_post_meta($product_id, '_arraysubs_renewal_shipping_override', true);
        }

        $initial_shipping_fee_total = $this->getOrderInitialShippingFeeTotal($order);

        // Apply initial shipping override if set (charged during cart/checkout totals)
        if (!empty($initial_shipping_override) && is_numeric($initial_shipping_override)) {
            $shipping_total = floatval($initial_shipping_override);
        }

		$initial_shipping_charged = $initial_shipping_fee_total + $this->getOrderShippingTotal($order);
		// "Paid" means: either nothing was required, OR the order actually
		// has a fee/shipping line item that covers the configured amount.
		// We require evidence of an actual line item — a missing line is
		// reported as "no" so the admin sees the discrepancy instead of a
		// misleading "Yes" when shipping was never charged.
		$has_actual_shipping_line = $initial_shipping_fee_total > 0 || $this->getOrderShippingTotal($order) > 0;
		$initial_shipping_paid    = $shipping_total <= 0
			|| ($has_actual_shipping_line && ($initial_shipping_charged + 0.0001) >= $shipping_total);

        // Determine renewal shipping amount (defaults to initial shipping, possibly overridden)
        $renewal_shipping_total = $shipping_total;
        if (!empty($renewal_shipping_override) && is_numeric($renewal_shipping_override)) {
            $renewal_shipping_total = floatval($renewal_shipping_override);
        }

        // Store shipping data on subscription
        update_post_meta($subscription_id, '_arraysubs_shipping_type', $shipping_type);
        update_post_meta($subscription_id, '_arraysubs_shipping_method_id', $shipping_method_id);
        update_post_meta($subscription_id, '_arraysubs_shipping_method_title', $shipping_method_title);
        update_post_meta($subscription_id, '_arraysubs_shipping_total', $shipping_total);
        update_post_meta($subscription_id, '_arraysubs_initial_shipping_paid', $initial_shipping_paid ? 'yes' : 'no');
        update_post_meta($subscription_id, '_arraysubs_renewal_shipping_total', $renewal_shipping_total);
        update_post_meta($subscription_id, '_arraysubs_needs_shipping', 'yes');
    }

    /**
     * Get initial shipping fees to add to the current cart.
     *
     * @param \WC_Cart $cart WooCommerce cart.
     * @return array<int, array{name: string, amount: float}>
     */
    private function getCartInitialShippingFees(\WC_Cart $cart): array
    {
        $fees = [];

        foreach ($cart->get_cart() as $cart_item) {
            $product_id   = (int) ($cart_item['product_id'] ?? 0);
            $variation_id = (int) ($cart_item['variation_id'] ?? 0);
            $quantity     = max(1, (int) ($cart_item['quantity'] ?? 1));
            $check_id     = $variation_id > 0 ? $variation_id : $product_id;

            if ($check_id <= 0) {
                continue;
            }

            $product = wc_get_product($check_id);

            if (!$product || !$product->needs_shipping()) {
                continue;
            }

            if (!$this->isSubscriptionCartProduct($product, $product_id)) {
                continue;
            }

            $override = $this->getInitialShippingOverride($check_id, $product_id);

            if ($override <= 0) {
                continue;
            }

            $fees[] = [
                'name'   => sprintf(
                    /* translators: %s: product name. */
                    __('%1$s: %2$s', 'arraysubspro'),
                    self::INITIAL_SHIPPING_FEE_PREFIX,
                    $product->get_name()
                ),
                'amount' => $override * $quantity,
            ];
        }

        return $fees;
    }

    /**
     * Check whether a cart product/variation belongs to a subscription product.
     *
     * @param \WC_Product $product   Cart product or variation.
     * @param int         $parent_id Parent product ID.
     * @return bool True when the cart line is a subscription product.
     */
    private function isSubscriptionCartProduct(\WC_Product $product, int $parent_id): bool
    {
        if (!function_exists('arraysubs_is_subscription_product')) {
            return false;
        }

        if (arraysubs_is_subscription_product($product)) {
            return true;
        }

        return $parent_id > 0 && arraysubs_is_subscription_product($parent_id);
    }

    /**
     * Get configured initial shipping override for a product/variation.
     *
     * @param int $product_id Product or variation ID.
     * @param int $parent_id  Parent product ID.
     * @return float Override amount.
     */
    private function getInitialShippingOverride(int $product_id, int $parent_id = 0): float
    {
        $override = get_post_meta($product_id, '_arraysubs_initial_shipping_override', true);

        if (($override === '' || $override === null) && $parent_id > 0 && $parent_id !== $product_id) {
            $override = get_post_meta($parent_id, '_arraysubs_initial_shipping_override', true);
        }

        return is_numeric($override) ? max(0, (float) $override) : 0;
    }

    /**
     * Get the marked initial shipping fee total from an order.
     *
     * @param \WC_Order $order Order object.
     * @return float Fee total.
     */
    private function getOrderInitialShippingFeeTotal(\WC_Order $order): float
    {
        $total = 0;

        foreach ($order->get_fees() as $fee) {
            $is_initial_shipping = 'yes' === $fee->get_meta('_arraysubs_initial_shipping_fee', true)
                || strpos($fee->get_name(), self::INITIAL_SHIPPING_FEE_PREFIX) === 0;

            if ($is_initial_shipping) {
                $total += (float) $fee->get_total();
            }
        }

        return $total;
    }

    /**
     * Get order shipping method total.
     *
     * @param \WC_Order $order Order object.
     * @return float Shipping total.
     */
    private function getOrderShippingTotal(\WC_Order $order): float
    {
        $total = 0;

        foreach ($order->get_shipping_methods() as $shipping_method) {
            $total += (float) $shipping_method->get_total();
        }

        return $total;
    }

    /**
     * Display shipping info on product page for subscription products
     */
    public function displayProductShippingInfo(): void
    {
        global $product;

        if (!$product) {
            return;
        }

        // Check if subscription product
        if (!function_exists('arraysubs_is_subscription_product') || !arraysubs_is_subscription_product($product)) {
            return;
        }

        // Check if physical product
        if (!$product->needs_shipping()) {
            return;
        }

        $initial_override = (float) get_post_meta($product->get_id(), '_arraysubs_initial_shipping_override', true);
        $renewal_override = (float) get_post_meta($product->get_id(), '_arraysubs_renewal_shipping_override', true);

        if ($initial_override <= 0 && $renewal_override <= 0) {
            return;
        }

        $shipping_type = get_post_meta($product->get_id(), '_arraysubs_shipping_type', true);
        if (empty($shipping_type)) {
            $shipping_type = 'recurring'; // Default
        }

        $icon = $shipping_type === 'one-time' ? '📦' : '🔄';
        $text = $shipping_type === 'one-time'
            ? __('One-time shipping (first order only)', 'arraysubspro')
            : __('Shipping charged on every renewal', 'arraysubspro');

?>
        <div class="arraysubspro-shipping-info" style="margin-top: 10px; padding: 10px; background: #f8f8f8; border-radius: 4px;">
            <span class="shipping-type"><?php echo esc_html($icon . ' ' . $text); ?></span>
        </div>
<?php
    }

    /**
     * Display shipping info in cart for subscription products
     */
    public function displayCartShippingInfo(): void
    {
        $this->displayShippingTerms();
    }

    /**
     * Display shipping info in checkout for subscription products
     */
    public function displayCheckoutShippingInfo(): void
    {
        $this->displayShippingTerms();
    }

    /**
     * Display shipping terms for subscription products in cart
     */
    private function displayShippingTerms(): void
    {
        if (!function_exists('WC') || !WC()->cart) {
            return;
        }

        $has_one_time_shipping = false;
        $has_recurring_shipping = false;

        foreach (WC()->cart->get_cart() as $cart_item) {
            $product_id = !empty($cart_item['variation_id']) ? $cart_item['variation_id'] : $cart_item['product_id'];
            $product = wc_get_product($product_id);

            if (!$product || !$product->needs_shipping()) {
                continue;
            }

            if (function_exists('arraysubs_is_subscription_product') && arraysubs_is_subscription_product($product)) {
                $shipping_type = get_post_meta($product_id, '_arraysubs_shipping_type', true) ?: 'recurring';
                if ($shipping_type === 'one-time') {
                    $has_one_time_shipping = true;
                } else {
                    $has_recurring_shipping = true;
                }
            }
        }

        if ($has_one_time_shipping || $has_recurring_shipping) {
            echo '<tr class="arraysubspro-shipping-terms"><td colspan="2">';
            echo '<small class="arraysubspro-shipping-note" style="color: #666;">';
            if ($has_one_time_shipping && !$has_recurring_shipping) {
                echo esc_html__('* Shipping is charged one-time on the first order only.', 'arraysubspro');
            } elseif ($has_recurring_shipping && !$has_one_time_shipping) {
                echo esc_html__('* Shipping will be charged on each renewal order.', 'arraysubspro');
            } else {
                echo esc_html__('* Some items have one-time shipping, others have recurring shipping.', 'arraysubspro');
            }
            echo '</small></td></tr>';
        }
    }

    /**
     * Recalculate subscription shipping after an in-place plan switch.
     *
     * @param int    $subscription_id Subscription ID.
     * @param int    $old_product_id  Old product or variation ID.
     * @param int    $new_product_id  New product or variation ID.
     * @param string $switch_type     Switch type.
     * @return void
     */
    public function onPlanSwitchCompleted(int $subscription_id, int $old_product_id, int $new_product_id, string $switch_type): void
    {
        unset($old_product_id, $switch_type);

        $subscription = arraysubs_get_subscription($subscription_id);
        $target_product = $new_product_id > 0 ? wc_get_product($new_product_id) : null;

        if (!$subscription instanceof \WP_Post || !$target_product instanceof \WC_Product) {
            return;
        }

        $context = $this->getProductShippingContext($subscription_id, $target_product);
        $this->updateSubscriptionShippingContext($subscription_id, $context);

        if (function_exists('arraysubs_add_subscription_note')) {
            arraysubs_add_subscription_note(
                $subscription_id,
                __('Shipping settings recalculated after plan switch.', 'arraysubspro'),
                'private',
                0,
                [],
                'subscription'
            );
        }
    }

    /**
     * Override renewal shipping context for deferred pending-switch orders.
     *
     * @param array            $context        Default shipping context.
     * @param \WP_Post         $subscription   Subscription post.
     * @param array|null       $pending_switch Pending switch payload.
     * @param \WC_Product|null $target_product Target product.
     * @return array
     */
    public function filterRenewalShippingContext(
        array $context,
        \WP_Post $subscription,
        ?array $pending_switch = null,
        $target_product = null
    ): array {
        if (empty($pending_switch) || !$target_product instanceof \WC_Product) {
            return $context;
        }

        return $this->getProductShippingContext($subscription->ID, $target_product, $context);
    }

    /**
     * Build effective shipping context from a target product/variation.
     *
     * @param int         $subscription_id Subscription ID.
     * @param \WC_Product $product         Target product or variation.
     * @param array       $defaults        Default subscription shipping context.
     * @return array
     */
    private function getProductShippingContext(int $subscription_id, \WC_Product $product, array $defaults = []): array
    {
        if (!$product->needs_shipping()) {
            return [
                'needs_shipping' => false,
                'shipping_type' => '',
                'renewal_shipping_total' => 0.0,
                'shipping_method_id' => '',
                'shipping_method_title' => '',
            ];
        }

        $product_id = $product->get_id();
        $parent_id = $product->is_type('variation') ? $product->get_parent_id() : 0;
        $shipping_type = $this->getProductMetaWithParentFallback($product_id, $parent_id, '_arraysubs_shipping_type');
        $shipping_type = $shipping_type ?: 'recurring';

        $initial_override = $this->getProductMetaWithParentFallback($product_id, $parent_id, '_arraysubs_initial_shipping_override');
        $renewal_override = $this->getProductMetaWithParentFallback($product_id, $parent_id, '_arraysubs_renewal_shipping_override');

        $renewal_total = (float) ($defaults['renewal_shipping_total'] ?? get_post_meta($subscription_id, '_arraysubs_renewal_shipping_total', true));
        if ($shipping_type === 'one-time') {
            $renewal_total = 0.0;
        } elseif (is_numeric($renewal_override)) {
            $renewal_total = max(0.0, (float) $renewal_override);
        } elseif (is_numeric($initial_override)) {
            $renewal_total = max(0.0, (float) $initial_override);
        }

        $method_id = $defaults['shipping_method_id']
            ?? get_post_meta($subscription_id, '_arraysubs_shipping_method_id', true);
        $method_title = $defaults['shipping_method_title']
            ?? get_post_meta($subscription_id, '_arraysubs_shipping_method_title', true);

        return [
            'needs_shipping' => true,
            'shipping_type' => $shipping_type,
            'renewal_shipping_total' => $renewal_total,
            'shipping_method_id' => $method_id ?: 'flat_rate',
            'shipping_method_title' => $method_title ?: __('Subscription Shipping', 'arraysubspro'),
            'initial_shipping_total' => is_numeric($initial_override) ? max(0.0, (float) $initial_override) : null,
        ];
    }

    /**
     * Persist effective shipping context on a subscription.
     *
     * @param int   $subscription_id Subscription ID.
     * @param array $context         Shipping context.
     * @return void
     */
    private function updateSubscriptionShippingContext(int $subscription_id, array $context): void
    {
        if (empty($context['needs_shipping'])) {
            update_post_meta($subscription_id, '_arraysubs_needs_shipping', 'no');
            delete_post_meta($subscription_id, '_arraysubs_shipping_type');
            delete_post_meta($subscription_id, '_arraysubs_shipping_method_id');
            delete_post_meta($subscription_id, '_arraysubs_shipping_method_title');
            delete_post_meta($subscription_id, '_arraysubs_shipping_total');
            delete_post_meta($subscription_id, '_arraysubs_renewal_shipping_total');
            return;
        }

        update_post_meta($subscription_id, '_arraysubs_needs_shipping', 'yes');
        update_post_meta($subscription_id, '_arraysubs_shipping_type', sanitize_key($context['shipping_type'] ?? 'recurring'));
        update_post_meta($subscription_id, '_arraysubs_shipping_method_id', sanitize_text_field($context['shipping_method_id'] ?? 'flat_rate'));
        update_post_meta($subscription_id, '_arraysubs_shipping_method_title', sanitize_text_field($context['shipping_method_title'] ?? __('Subscription Shipping', 'arraysubspro')));
        update_post_meta($subscription_id, '_arraysubs_renewal_shipping_total', max(0.0, (float) ($context['renewal_shipping_total'] ?? 0)));

        if (isset($context['initial_shipping_total']) && $context['initial_shipping_total'] !== null) {
            update_post_meta($subscription_id, '_arraysubs_shipping_total', max(0.0, (float) $context['initial_shipping_total']));
        }
    }

    /**
     * Get product meta with variation-first, parent fallback lookup.
     *
     * @param int    $product_id Product or variation ID.
     * @param int    $parent_id  Parent product ID.
     * @param string $meta_key   Meta key.
     * @return mixed
     */
    private function getProductMetaWithParentFallback(int $product_id, int $parent_id, string $meta_key)
    {
        $value = get_post_meta($product_id, $meta_key, true);

        if (($value === '' || $value === null) && $parent_id > 0) {
            $value = get_post_meta($parent_id, $meta_key, true);
        }

        return $value;
    }
}
