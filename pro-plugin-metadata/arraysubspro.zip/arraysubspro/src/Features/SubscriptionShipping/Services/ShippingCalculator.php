<?php

/**
 * Shipping Calculator Service
 *
 * Calculates shipping costs for initial and renewal subscription orders.
 * Handles one-time vs recurring shipping logic.
 *
 * @package ArraySubsPro\Features\SubscriptionShipping\Services
 * @since 1.0.0
 */

namespace ArraySubsPro\Features\SubscriptionShipping\Services;

defined('ABSPATH') || exit;

/**
 * Shipping calculation service
 */
class ShippingCalculator
{
    /**
     * Check if shipping should be charged on renewal
     *
     * @param int $subscription_id Subscription ID
     * @return bool True if shipping should be charged
     */
    public function shouldChargeShippingOnRenewal(int $subscription_id): bool
    {
        // Check if subscription needs shipping at all
        $needs_shipping = get_post_meta($subscription_id, '_arraysubs_needs_shipping', true);
        if ($needs_shipping !== 'yes') {
            return false;
        }

        // Check shipping type
        $shipping_type = get_post_meta($subscription_id, '_arraysubs_shipping_type', true);

        // One-time shipping = no charge on renewals
        if ($shipping_type === 'one-time') {
            return false;
        }

        // Recurring shipping (default) = charge on every renewal
        return true;
    }

    /**
     * Get shipping data for renewal order
     *
     * @param int $subscription_id Subscription ID
     * @return array|null Shipping data or null if no shipping
     */
    public function getShippingDataForRenewal(int $subscription_id): ?array
    {
        if (!$this->shouldChargeShippingOnRenewal($subscription_id)) {
            return null;
        }

        $method_id = get_post_meta($subscription_id, '_arraysubs_shipping_method_id', true);
        $method_title = get_post_meta($subscription_id, '_arraysubs_shipping_method_title', true);
        $renewal_total = get_post_meta($subscription_id, '_arraysubs_renewal_shipping_total', true);

        // If no renewal total set, use initial shipping total
        if (empty($renewal_total) || !is_numeric($renewal_total)) {
            $renewal_total = get_post_meta($subscription_id, '_arraysubs_shipping_total', true);
        }

        // Validate we have required data
        if (empty($method_title) || !is_numeric($renewal_total)) {
            return null;
        }

        return [
            'method_id' => $method_id ?: 'flat_rate',
            'method_title' => $method_title,
            'total' => floatval($renewal_total),
        ];
    }

    /**
     * Calculate initial shipping for a product
     *
     * @param int   $product_id       Product ID
     * @param array $shipping_address Customer shipping address
     * @return float Shipping cost
     */
    public function calculateInitialShipping(int $product_id, array $shipping_address): float
    {
        $product = wc_get_product($product_id);
        if (!$product || !$product->needs_shipping()) {
            return 0.0;
        }

        // Check for override amount
        $override = get_post_meta($product_id, '_arraysubs_initial_shipping_override', true);
        if (!empty($override) && is_numeric($override)) {
            return floatval($override);
        }

        // Use WooCommerce shipping calculation
        // This would require cart context, so return 0 and let WC handle it
        return 0.0;
    }

    /**
     * Calculate renewal shipping for a subscription
     *
     * @param int $subscription_id Subscription ID
     * @return float Shipping cost for renewal
     */
    public function calculateRenewalShipping(int $subscription_id): float
    {
        if (!$this->shouldChargeShippingOnRenewal($subscription_id)) {
            return 0.0;
        }

        $data = $this->getShippingDataForRenewal($subscription_id);
        return $data ? $data['total'] : 0.0;
    }

    /**
     * Get shipping method details for a subscription
     *
     * @param int $subscription_id Subscription ID
     * @return array|null Shipping method info or null
     */
    public function getShippingMethod(int $subscription_id): ?array
    {
        $needs_shipping = get_post_meta($subscription_id, '_arraysubs_needs_shipping', true);
        if ($needs_shipping !== 'yes') {
            return null;
        }

        return [
            'method_id' => get_post_meta($subscription_id, '_arraysubs_shipping_method_id', true),
            'method_title' => get_post_meta($subscription_id, '_arraysubs_shipping_method_title', true),
            'type' => get_post_meta($subscription_id, '_arraysubs_shipping_type', true) ?: 'recurring',
            'initial_total' => floatval(get_post_meta($subscription_id, '_arraysubs_shipping_total', true)),
            'renewal_total' => floatval(get_post_meta($subscription_id, '_arraysubs_renewal_shipping_total', true)),
        ];
    }

    /**
     * Check if product needs shipping (physical product check)
     *
     * @param int|\WC_Product $product Product ID or object
     * @return bool True if product needs shipping
     */
    public function productNeedsShipping($product): bool
    {
        if (is_int($product)) {
            $product = wc_get_product($product);
        }

        if (!$product instanceof \WC_Product) {
            return false;
        }

        return $product->needs_shipping();
    }

    /**
     * Get shipping type label
     *
     * @param string $type Shipping type (one-time or recurring)
     * @return string Human-readable label
     */
    public function getShippingTypeLabel(string $type): string
    {
        switch ($type) {
            case 'one-time':
                return __('One-time (first order only)', 'arraysubspro');
            case 'recurring':
            default:
                return __('Recurring (every renewal)', 'arraysubspro');
        }
    }
}
