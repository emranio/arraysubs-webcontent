<?php

/**
 * Shipping Address Manager
 *
 * Manages shipping addresses for subscriptions including updates,
 * validation, and inheritance during plan switches.
 *
 * @package ArraySubsPro\Features\SubscriptionShipping\Services
 * @since 1.0.0
 */

namespace ArraySubsPro\Features\SubscriptionShipping\Services;

defined('ABSPATH') || exit;

/**
 * Address management service
 */
class AddressManager
{
    /**
     * Default cutoff days before renewal for address changes
     */
    const DEFAULT_CUTOFF_DAYS = 3;

    /**
     * Update shipping address for a subscription
     *
     * @param int   $subscription_id Subscription ID
     * @param array $address         New shipping address
     * @param int   $user_id         User making the change (0 for admin)
     * @return array Result with 'success' and 'message' keys
     */
    public function updateShippingAddress(int $subscription_id, array $address, int $user_id = 0): array
    {
        $subscription = arraysubs_get_subscription($subscription_id);
        if (!$subscription instanceof \WP_Post) {
            return [
                'success' => false,
                'message' => __('Subscription not found.', 'arraysubspro'),
            ];
        }

        // Check if subscription needs shipping
        $needs_shipping = get_post_meta($subscription_id, '_arraysubs_needs_shipping', true);
        if ($needs_shipping !== 'yes') {
            return [
                'success' => false,
                'message' => __('This subscription does not require shipping.', 'arraysubspro'),
            ];
        }

        // Get old address for comparison
        $old_address = $this->getShippingAddress($subscription_id);

        // Validate address
        $validation = $this->validateAddress($address);
        if (!$validation['valid']) {
            return [
                'success' => false,
                'message' => $validation['message'],
            ];
        }

        // Sanitize address fields
        $sanitized = $this->sanitizeAddress($address);

        // Store the address
        update_post_meta($subscription_id, '_shipping_address', wp_json_encode($sanitized));

        // Determine who made the change
        $changed_by = $user_id > 0 ? get_userdata($user_id)->display_name : __('Admin', 'arraysubspro');

        // Add subscription note
        if (function_exists('arraysubs_add_subscription_note')) {
            $formatted_address = $this->formatAddressForDisplay($sanitized);
            arraysubs_add_subscription_note(
                $subscription_id,
                sprintf(
                    /* translators: 1: user name, 2: formatted address */
                    __('Shipping address updated by %1$s. New address: %2$s', 'arraysubspro'),
                    $changed_by,
                    $formatted_address
                ),
                $user_id > 0 ? 'customer' : 'system',
                false,
                [],
                'subscription'
            );
        }
        return [
            'success' => true,
            'message' => __('Shipping address updated successfully.', 'arraysubspro'),
            'old_address' => $old_address,
            'new_address' => $sanitized,
        ];
    }

    /**
     * Get shipping address for a subscription
     *
     * @param int $subscription_id Subscription ID
     * @return array Address array
     */
    public function getShippingAddress(int $subscription_id): array
    {
        $address_json = get_post_meta($subscription_id, '_shipping_address', true);
        if (empty($address_json)) {
            return [];
        }

        $address = json_decode($address_json, true);
        return is_array($address) ? $address : [];
    }

    /**
     * Check if customer can update shipping address
     *
     * @param int $subscription_id Subscription ID
     * @param int $customer_id     Customer user ID
     * @return array Result with 'allowed' and optional 'message' keys
     */
    public function canCustomerUpdateAddress(int $subscription_id, int $customer_id): array
    {
        // Check subscription exists and belongs to customer
        $subscription = arraysubs_get_subscription($subscription_id);
        if (!$subscription instanceof \WP_Post) {
            return [
                'allowed' => false,
                'message' => __('Subscription not found.', 'arraysubspro'),
            ];
        }

        $subscription_customer = get_post_meta($subscription_id, '_customer_id', true);
        if ((int) $subscription_customer !== $customer_id) {
            return [
                'allowed' => false,
                'message' => __('You do not have permission to update this subscription.', 'arraysubspro'),
            ];
        }

        // Check if subscription needs shipping
        $needs_shipping = get_post_meta($subscription_id, '_arraysubs_needs_shipping', true);
        if ($needs_shipping !== 'yes') {
            return [
                'allowed' => false,
                'message' => __('This subscription does not require shipping.', 'arraysubspro'),
            ];
        }

        // Check subscription status
        $status = $subscription->post_status;
        $allowed_statuses = ['arraysubs-active', 'arraysubs-trial', 'arraysubs-on-hold', 'arraysubs-pending'];
        if (!in_array($status, $allowed_statuses, true)) {
            return [
                'allowed' => false,
                'message' => __('Cannot update shipping address for this subscription status.', 'arraysubspro'),
            ];
        }

        // Check cutoff period
        $cutoff_check = $this->checkCutoffPeriod($subscription_id);
        if (!$cutoff_check['allowed']) {
            return $cutoff_check;
        }

        return ['allowed' => true];
    }

    /**
     * Check if address change is within cutoff period
     *
     * @param int $subscription_id Subscription ID
     * @return array Result with 'allowed' and optional 'message' keys
     */
    public function checkCutoffPeriod(int $subscription_id): array
    {
        $cutoff_days = (int) get_option('arraysubs_shipping_address_cutoff_days', self::DEFAULT_CUTOFF_DAYS);

        if ($cutoff_days <= 0) {
            // No cutoff configured
            return ['allowed' => true];
        }

        $next_payment = get_post_meta($subscription_id, '_next_payment_date', true);
        if (empty($next_payment)) {
            return ['allowed' => true];
        }

        $next_payment_time = strtotime($next_payment);
        $cutoff_time = $next_payment_time - ($cutoff_days * DAY_IN_SECONDS);
        $current_time = time();

        if ($current_time >= $cutoff_time) {
            $cutoff_date = arraysubs_format_timestamp_local($cutoff_time, get_option('date_format'));
            return [
                'allowed' => false,
                'message' => sprintf(
                    /* translators: 1: cutoff date, 2: number of days */
                    __('Shipping address changes must be made at least %2$d days before renewal. The cutoff was %1$s.', 'arraysubspro'),
                    $cutoff_date,
                    $cutoff_days
                ),
                'cutoff_date' => $cutoff_date,
            ];
        }

        return ['allowed' => true];
    }

    /**
     * Validate address fields
     *
     * @param array $address Address data
     * @return array Result with 'valid' and optional 'message' keys
     */
    public function validateAddress(array $address): array
    {
        $required_fields = ['first_name', 'last_name', 'address_1', 'city', 'country'];

        foreach ($required_fields as $field) {
            if (empty($address[$field])) {
                return [
                    'valid' => false,
                    'message' => sprintf(
                        /* translators: %s: field name */
                        __('%s is required.', 'arraysubspro'),
                        $this->getFieldLabel($field)
                    ),
                ];
            }
        }

        // Validate country code
        if (!empty($address['country'])) {
            $countries = WC()->countries->get_countries();
            if (!isset($countries[$address['country']])) {
                return [
                    'valid' => false,
                    'message' => __('Invalid country selected.', 'arraysubspro'),
                ];
            }
        }

        return ['valid' => true];
    }

    /**
     * Sanitize address fields
     *
     * @param array $address Raw address data
     * @return array Sanitized address
     */
    public function sanitizeAddress(array $address): array
    {
        return [
            'first_name' => sanitize_text_field($address['first_name'] ?? ''),
            'last_name' => sanitize_text_field($address['last_name'] ?? ''),
            'company' => sanitize_text_field($address['company'] ?? ''),
            'address_1' => sanitize_text_field($address['address_1'] ?? ''),
            'address_2' => sanitize_text_field($address['address_2'] ?? ''),
            'city' => sanitize_text_field($address['city'] ?? ''),
            'state' => sanitize_text_field($address['state'] ?? ''),
            'postcode' => sanitize_text_field($address['postcode'] ?? ''),
            'country' => sanitize_text_field($address['country'] ?? ''),
        ];
    }

    /**
     * Inherit address from another subscription
     *
     * @param int $new_subscription_id New subscription ID
     * @param int $old_subscription_id Source subscription ID
     * @return bool Success
     */
    public function inheritAddressFromSubscription(int $new_subscription_id, int $old_subscription_id): bool
    {
        $old_address = $this->getShippingAddress($old_subscription_id);

        if (empty($old_address)) {
            return false;
        }

        update_post_meta($new_subscription_id, '_shipping_address', wp_json_encode($old_address));
        return true;
    }

    /**
     * Format address for display
     *
     * @param array $address Address data
     * @return string Formatted address
     */
    public function formatAddressForDisplay(array $address): string
    {
        $parts = [];

        if (!empty($address['first_name']) || !empty($address['last_name'])) {
            $parts[] = trim(($address['first_name'] ?? '') . ' ' . ($address['last_name'] ?? ''));
        }

        if (!empty($address['company'])) {
            $parts[] = $address['company'];
        }

        if (!empty($address['address_1'])) {
            $parts[] = $address['address_1'];
        }

        if (!empty($address['address_2'])) {
            $parts[] = $address['address_2'];
        }

        $city_line = [];
        if (!empty($address['city'])) {
            $city_line[] = $address['city'];
        }
        if (!empty($address['state'])) {
            $city_line[] = $address['state'];
        }
        if (!empty($address['postcode'])) {
            $city_line[] = $address['postcode'];
        }
        if (!empty($city_line)) {
            $parts[] = implode(', ', $city_line);
        }

        if (!empty($address['country'])) {
            $countries = WC()->countries->get_countries();
            $country_name = $countries[$address['country']] ?? $address['country'];
            $parts[] = $country_name;
        }

        return implode(', ', $parts);
    }

    /**
     * Get field label for validation messages
     *
     * @param string $field Field key
     * @return string Field label
     */
    private function getFieldLabel(string $field): string
    {
        $labels = [
            'first_name' => __('First name', 'arraysubspro'),
            'last_name' => __('Last name', 'arraysubspro'),
            'company' => __('Company', 'arraysubspro'),
            'address_1' => __('Address', 'arraysubspro'),
            'address_2' => __('Address line 2', 'arraysubspro'),
            'city' => __('City', 'arraysubspro'),
            'state' => __('State/Province', 'arraysubspro'),
            'postcode' => __('Postcode', 'arraysubspro'),
            'country' => __('Country', 'arraysubspro'),
        ];

        return $labels[$field] ?? $field;
    }
}
