<?php

/**
 * Subscription Shipping REST Controller
 *
 * REST API endpoints for subscription shipping address management.
 *
 * @package ArraySubsPro\Features\SubscriptionShipping\REST
 * @since 1.0.0
 */

namespace ArraySubsPro\Features\SubscriptionShipping\REST;

defined('ABSPATH') || exit;

use ArraySubs\Supports\BaseRestController;
use ArraySubsPro\Features\SubscriptionShipping\Services\AddressManager;
use ArraySubsPro\Features\SubscriptionShipping\Services\ShippingCalculator;
use WP_REST_Request;
use WP_REST_Response;
use WP_Error;

/**
 * Shipping REST controller
 */
class ShippingController extends BaseRestController
{
    /**
     * Enable auto-loading
     *
     * @var bool
     */
    public static $loadable = true;

    /**
     * Address manager instance
     *
     * @var AddressManager
     */
    private AddressManager $address_manager;

    /**
     * Shipping calculator instance
     *
     * @var ShippingCalculator
     */
    private ShippingCalculator $shipping_calculator;

    /**
     * Initialize controller
     */
    public function __construct()
    {
        parent::__construct();
        $this->address_manager = new AddressManager();
        $this->shipping_calculator = new ShippingCalculator();
    }

    /**
     * Register REST routes
     *
     * @return void
     */
    public function registerRoutes(): void
    {
        // Admin: Get shipping details for a subscription
        register_rest_route(
            $this->namespace,
            '/subscriptions/(?P<id>\d+)/shipping',
            [
                'methods' => 'GET',
                'callback' => [$this, 'getShippingDetails'],
                'permission_callback' => [$this, 'checkAdminPermission'],
                'args' => [
                    'id' => [
                        'required' => true,
                        'type' => 'integer',
                        'sanitize_callback' => 'absint',
                    ],
                ],
            ]
        );

        // Admin: Update shipping address
        register_rest_route(
            $this->namespace,
            '/subscriptions/(?P<id>\d+)/shipping-address',
            [
                'methods' => 'POST',
                'callback' => [$this, 'updateShippingAddress'],
                'permission_callback' => [$this, 'checkAdminPermission'],
                'args' => [
                    'id' => [
                        'required' => true,
                        'type' => 'integer',
                        'sanitize_callback' => 'absint',
                    ],
                    'shipping_address' => [
                        'required' => true,
                        'type' => 'object',
                    ],
                ],
            ]
        );

        // Customer: Get my subscription shipping details
        register_rest_route(
            $this->namespace,
            '/my-subscriptions/(?P<id>\d+)/shipping',
            [
                'methods' => 'GET',
                'callback' => [$this, 'getMyShippingDetails'],
                'permission_callback' => [$this, 'checkCustomerPermission'],
                'args' => [
                    'id' => [
                        'required' => true,
                        'type' => 'integer',
                        'sanitize_callback' => 'absint',
                    ],
                ],
            ]
        );

        // Customer: Update my subscription shipping address
        register_rest_route(
            $this->namespace,
            '/my-subscriptions/(?P<id>\d+)/shipping-address',
            [
                'methods' => 'POST',
                'callback' => [$this, 'updateMyShippingAddress'],
                'permission_callback' => [$this, 'checkCustomerPermission'],
                'args' => [
                    'id' => [
                        'required' => true,
                        'type' => 'integer',
                        'sanitize_callback' => 'absint',
                    ],
                    'shipping_address' => [
                        'required' => true,
                        'type' => 'object',
                    ],
                ],
            ]
        );
    }

    /**
     * Check admin permission for shipping management endpoints.
     *
     * @return bool
     */
    public function checkAdminPermission(): bool
    {
        if (!\is_user_logged_in()) {
            return false;
        }

        return \current_user_can('manage_woocommerce') || \current_user_can('manage_options');
    }

    /**
     * Get shipping details for a subscription (Admin)
     *
     * @param WP_REST_Request $request Request object
     * @return WP_REST_Response|WP_Error Response
     */
    public function getShippingDetails(WP_REST_Request $request)
    {
        $subscription_id = $request->get_param('id');
        $subscription = arraysubs_get_subscription($subscription_id);

        if (!$subscription instanceof \WP_Post) {
            return new WP_Error(
                'subscription_not_found',
                __('Subscription not found.', 'arraysubspro'),
                ['status' => 404]
            );
        }

        $shipping_data = $this->buildShippingResponse($subscription_id);

        return arraysubs_rest_response(
            $shipping_data,
            200,
            __('Shipping details retrieved.', 'arraysubspro')
        );
    }

    /**
     * Update shipping address for a subscription (Admin)
     *
     * @param WP_REST_Request $request Request object
     * @return WP_REST_Response|WP_Error Response
     */
    public function updateShippingAddress(WP_REST_Request $request)
    {
        $subscription_id = $request->get_param('id');
        $address = $request->get_param('shipping_address');

        if (!is_array($address)) {
            return new WP_Error(
                'invalid_address',
                __('Invalid shipping address format.', 'arraysubspro'),
                ['status' => 400]
            );
        }

        // Admin can update without cutoff restrictions
        $result = $this->address_manager->updateShippingAddress($subscription_id, $address, 0);

        if (!$result['success']) {
            return new WP_Error(
                'update_failed',
                $result['message'],
                ['status' => 400]
            );
        }

        // Trigger email notification if enabled
        do_action('arraysubs_shipping_address_updated', $subscription_id, $result['old_address'], $result['new_address'], 0);

        return arraysubs_rest_response(
            [
                'shipping_address' => $result['new_address'],
            ],
            200,
            $result['message']
        );
    }

    /**
     * Get shipping details for customer's subscription
     *
     * @param WP_REST_Request $request Request object
     * @return WP_REST_Response|WP_Error Response
     */
    public function getMyShippingDetails(WP_REST_Request $request)
    {
        $subscription_id = $request->get_param('id');
        $customer_id = get_current_user_id();

        // Verify ownership
        $subscription = arraysubs_get_subscription($subscription_id);
        if (!$subscription instanceof \WP_Post) {
            return new WP_Error(
                'subscription_not_found',
                __('Subscription not found.', 'arraysubspro'),
                ['status' => 404]
            );
        }

        $subscription_customer = get_post_meta($subscription_id, '_customer_id', true);
        if ((int) $subscription_customer !== $customer_id) {
            return new WP_Error(
                'permission_denied',
                __('You do not have permission to view this subscription.', 'arraysubspro'),
                ['status' => 403]
            );
        }

        $shipping_data = $this->buildShippingResponse($subscription_id);

        // Add permission info for customer
        $can_update = $this->address_manager->canCustomerUpdateAddress($subscription_id, $customer_id);
        $shipping_data['can_update'] = $can_update['allowed'];
        if (!$can_update['allowed']) {
            $shipping_data['update_message'] = $can_update['message'];
        }

        return arraysubs_rest_response(
            $shipping_data,
            200,
            __('Shipping details retrieved.', 'arraysubspro')
        );
    }

    /**
     * Update shipping address for customer's subscription
     *
     * @param WP_REST_Request $request Request object
     * @return WP_REST_Response|WP_Error Response
     */
    public function updateMyShippingAddress(WP_REST_Request $request)
    {
        $subscription_id = $request->get_param('id');
        $address = $request->get_param('shipping_address');
        $customer_id = get_current_user_id();

        if (!is_array($address)) {
            return new WP_Error(
                'invalid_address',
                __('Invalid shipping address format.', 'arraysubspro'),
                ['status' => 400]
            );
        }

        // Check customer permission and cutoff
        $can_update = $this->address_manager->canCustomerUpdateAddress($subscription_id, $customer_id);
        if (!$can_update['allowed']) {
            // Trigger failed notification
            do_action('arraysubs_shipping_address_update_failed', $subscription_id, $can_update['message'], $customer_id);

            return new WP_Error(
                'update_not_allowed',
                $can_update['message'],
                ['status' => 403]
            );
        }

        $result = $this->address_manager->updateShippingAddress($subscription_id, $address, $customer_id);

        if (!$result['success']) {
            // Trigger failed notification
            do_action('arraysubs_shipping_address_update_failed', $subscription_id, $result['message'], $customer_id);

            return new WP_Error(
                'update_failed',
                $result['message'],
                ['status' => 400]
            );
        }

        // Trigger email notification
        do_action('arraysubs_shipping_address_updated', $subscription_id, $result['old_address'], $result['new_address'], $customer_id);

        return arraysubs_rest_response(
            [
                'shipping_address' => $result['new_address'],
            ],
            200,
            $result['message']
        );
    }

    /**
     * Build shipping response data
     *
     * @param int $subscription_id Subscription ID
     * @return array Shipping data
     */
    private function buildShippingResponse(int $subscription_id): array
    {
        $needs_shipping = get_post_meta($subscription_id, '_arraysubs_needs_shipping', true) === 'yes';

        $data = [
            'needs_shipping' => $needs_shipping,
            'shipping_address' => [],
            'shipping_type' => '',
            'shipping_type_label' => '',
            'shipping_method' => null,
            'initial_shipping_total' => 0,
            'renewal_shipping_total' => 0,
            'formatted_initial_total' => '',
            'formatted_renewal_total' => '',
        ];

        if (!$needs_shipping) {
            return $data;
        }

        // Get address
        $data['shipping_address'] = $this->address_manager->getShippingAddress($subscription_id);
        $data['formatted_address'] = $this->address_manager->formatAddressForDisplay($data['shipping_address']);

        // Get shipping type
        $shipping_type = get_post_meta($subscription_id, '_arraysubs_shipping_type', true) ?: 'recurring';
        $data['shipping_type'] = $shipping_type;
        $data['shipping_type_label'] = $this->shipping_calculator->getShippingTypeLabel($shipping_type);

        // Get shipping method
        $method = $this->shipping_calculator->getShippingMethod($subscription_id);
        if ($method) {
            $data['shipping_method'] = [
                'id' => $method['method_id'],
                'title' => $method['method_title'],
            ];
            $data['initial_shipping_total'] = $method['initial_total'];
            $data['renewal_shipping_total'] = $method['renewal_total'];
            $data['formatted_initial_total'] = wc_price($method['initial_total']);
            $data['formatted_renewal_total'] = wc_price($method['renewal_total']);
        }

        // Check if initial shipping has been paid
        $data['initial_shipping_paid'] = get_post_meta($subscription_id, '_arraysubs_initial_shipping_paid', true) === 'yes';

        return $data;
    }

    /**
     * Check customer permission (logged in and owns subscription or is subscriber)
     *
     * @param WP_REST_Request $request Request object
     * @return bool|WP_Error True if permitted
     */
    public function checkCustomerPermission(WP_REST_Request $request)
    {
        if (!\is_user_logged_in()) {
            return new WP_Error(
                'not_logged_in',
                __('You must be logged in.', 'arraysubspro'),
                ['status' => 401]
            );
        }

        $subscription_id = \absint($request->get_param('id'));
        $subscription = arraysubs_get_subscription($subscription_id);

        if (!$subscription instanceof \WP_Post) {
            return new WP_Error(
                'subscription_not_found',
                __('Subscription not found.', 'arraysubspro'),
                ['status' => 404]
            );
        }

        $customer_id = \get_current_user_id();
        $subscription_customer_id = \absint(\get_post_meta($subscription_id, '_customer_id', true));

        if ($subscription_customer_id <= 0 || $subscription_customer_id !== $customer_id) {
            return new WP_Error(
                'permission_denied',
                __('You do not have permission to access this subscription.', 'arraysubspro'),
                ['status' => 403]
            );
        }

        return true;
    }
}
