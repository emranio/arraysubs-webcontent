<?php

/**
 * Subscription Shipping Provider
 *
 * Entry point for subscription-specific shipping functionality.
 * Handles one-time vs recurring shipping fees, shipping address management,
 * and integration with renewal order creation.
 *
 * @package ArraySubsPro\Features\SubscriptionShipping
 * @since 1.0.0
 */

namespace ArraySubsPro\Features\SubscriptionShipping;

defined('ABSPATH') || exit;

use ArraySubs\Supports\Abstracts\AbstractLoader;

/**
 * Subscription shipping feature entry point
 */
class Provider extends AbstractLoader
{
    /**
     * Initialize the subscription shipping feature
     */
    public function __construct()
    {
        $this->classLoader([
            plugin_dir_path(__FILE__) . 'Services',
            plugin_dir_path(__FILE__) . 'REST',
        ]);
    }
}
