<?php

/**
 * Checkout Builder Product Table REST Controller
 *
 * Handles guest-safe cart syncing for checkout product table rows.
 *
 * @package ArraySubsPro\Features\CheckoutBuilder\REST
 */

namespace ArraySubsPro\Features\CheckoutBuilder\REST;

defined('ABSPATH') || exit;

use ArraySubs\Supports\BaseRestController;
use ArraySubsPro\Features\CheckoutBuilder\Services\ProductTableHelper;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;

/**
 * Public controller for checkout product table cart actions.
 */
class ProductTableController extends BaseRestController
{

    /**
     * Enable auto-loading.
     *
     * @var bool
     */
    public static $loadable = true;

    /**
     * REST namespace.
     *
     * @var string
     */
    protected $namespace = 'arraysubs/v1';

    /**
     * Register routes.
     *
     * @return void
     */
    public function registerRoutes(): void
    {
        register_rest_route(
            $this->namespace,
            '/checkout-builder/product-table/cart',
            [
                [
                    'methods'             => WP_REST_Server::READABLE,
                    'callback'            => [$this, 'getCartStates'],
                    'permission_callback' => [$this, 'verifyRestNonce'],
                ],
                [
                    'methods'             => WP_REST_Server::CREATABLE,
                    'callback'            => [$this, 'syncCartItem'],
                    'permission_callback' => [$this, 'verifyRestNonce'],
                    'args'                => [
                        'product_id' => [
                            'type'              => 'integer',
                            'required'          => true,
                            'sanitize_callback' => 'absint',
                        ],
                        'quantity'   => [
                            'type'              => 'integer',
                            'required'          => true,
                            'sanitize_callback' => 'absint',
                        ],
                    ],
                ],
            ]
        );
    }

    /**
     * Verify the REST nonce for cart operations (CSRF protection).
     *
     * The checkout frontend localizes a `wp_rest` nonce and sends it via the
     * X-WP-Nonce header (see FieldRenderer). A valid nonce is issued for guests
     * and logged-in users alike, so guest carts keep working while cross-site
     * forged requests (which cannot read the nonce) are rejected.
     *
     * @param WP_REST_Request $request REST request.
     * @return bool
     */
    public function verifyRestNonce(WP_REST_Request $request): bool
    {
        $nonce = $request->get_header('X-WP-Nonce');

        return (bool) wp_verify_nonce($nonce, 'wp_rest');
    }

    /**
     * Get cart states for the provided product IDs.
     *
     * @param WP_REST_Request $request REST request.
     * @return WP_REST_Response
     */
    public function getCartStates(WP_REST_Request $request): WP_REST_Response
    {
        ProductTableHelper::ensureCartReady();

        $raw_ids = $request->get_param('product_ids');
        if (is_string($raw_ids)) {
            $raw_ids = array_map('trim', explode(',', $raw_ids));
        }

        $product_ids = is_array($raw_ids)
            ? array_values(array_filter(array_map('absint', $raw_ids)))
            : [];

        $states = [];

        foreach ($product_ids as $product_id) {
            $states[(string) $product_id] = ProductTableHelper::getCartProductState($product_id);
        }

        return new WP_REST_Response(
            [
                'success' => true,
                'states'  => $states,
            ],
            200
        );
    }

    /**
     * Sync a product's cart quantity from the checkout product table.
     *
     * @param WP_REST_Request $request REST request.
     * @return WP_REST_Response
     */
    public function syncCartItem(WP_REST_Request $request): WP_REST_Response
    {
        $product_id = absint($request->get_param('product_id'));
        $quantity   = absint($request->get_param('quantity'));
        $result     = ProductTableHelper::syncProductQuantity($product_id, $quantity);

        return new WP_REST_Response(
            $result,
            ! empty($result['success']) ? 200 : 400
        );
    }
}
