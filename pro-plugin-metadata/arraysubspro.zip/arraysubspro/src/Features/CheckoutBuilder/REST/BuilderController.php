<?php

/**
 * CheckoutBuilder REST Controller
 *
 * Handles the builder configuration CRUD via the REST API.
 *
 * @package ArraySubsPro\Features\CheckoutBuilder\REST
 * @since 1.0.0
 */

namespace ArraySubsPro\Features\CheckoutBuilder\REST;

defined('ABSPATH') || exit;

use ArraySubs\Supports\BaseRestController;
use ArraySubsPro\Features\CheckoutBuilder\Services\FieldRegistry;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;

/**
 * Builder configuration REST controller.
 */
class BuilderController extends BaseRestController
{

    /**
     * Enable auto-loading.
     *
     * @var bool
     */
    public static $loadable = true;

    /**
     * REST namespace.
     *
     * @var string
     */
    protected $namespace = 'arraysubs/v1';

    /**
     * Constructor.
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Register REST routes.
     *
     * @return void
     */
    public function registerRoutes(): void
    {
        // Get builder configuration.
        register_rest_route(
            $this->namespace,
            '/checkout-builder/config',
            [
                [
                    'methods'             => WP_REST_Server::READABLE,
                    'callback'            => [$this, 'getConfig'],
                    'permission_callback' => [$this, 'checkAdminPermission'],
                ],
                [
                    'methods'             => WP_REST_Server::CREATABLE,
                    'callback'            => [$this, 'saveConfig'],
                    'permission_callback' => [$this, 'checkAdminPermission'],
                    'args'                => [
                        'config' => [
                            'type'     => 'object',
                            'required' => true,
                        ],
                    ],
                ],
            ]
        );

        // Get WooCommerce default checkout fields.
        register_rest_route(
            $this->namespace,
            '/checkout-builder/defaults',
            [
                [
                    'methods'             => WP_REST_Server::READABLE,
                    'callback'            => [$this, 'getDefaults'],
                    'permission_callback' => [$this, 'checkAdminPermission'],
                ],
            ]
        );

        // Get available field types.
        register_rest_route(
            $this->namespace,
            '/checkout-builder/field-types',
            [
                [
                    'methods'             => WP_REST_Server::READABLE,
                    'callback'            => [$this, 'getFieldTypes'],
                    'permission_callback' => [$this, 'checkAdminPermission'],
                ],
            ]
        );
    }

    /**
     * Check admin permission.
     *
     * @return bool
     */
    public function checkAdminPermission(): bool
    {
        if (! is_user_logged_in()) {
            return false;
        }

        return current_user_can('manage_woocommerce') || current_user_can('manage_options');
    }

    /**
     * Get the saved builder configuration.
     *
     * @param WP_REST_Request $request Request object.
     * @return WP_REST_Response
     */
    public function getConfig(WP_REST_Request $request): WP_REST_Response
    {
        $settings = arraysubs_get_settings();
        $config   = $settings['checkout_builder'] ?? [];

        $defaults = self::getDefaultConfig();
        $config   = wp_parse_args($config, $defaults);
        $config   = $this->normalizeLegacyConfig($config);

        if (isset($config['multistep']['design']) && is_array($config['multistep']['design'])) {
            $config['multistep']['design'] = $this->sanitizeDesign($config['multistep']['design']);
        }

        return new WP_REST_Response(
            [
                'success' => true,
                'data'    => $config,
            ],
            200
        );
    }

    /**
     * Save the builder configuration.
     *
     * @param WP_REST_Request $request Request object.
     * @return WP_REST_Response
     */
    public function saveConfig(WP_REST_Request $request): WP_REST_Response
    {
        $config = $request->get_param('config');

        if (! is_array($config)) {
            return new WP_REST_Response(
                [
                    'success' => false,
                    'message' => __('Invalid configuration data.', 'arraysubspro'),
                ],
                400
            );
        }

        $sanitized = $this->sanitizeConfig($config);

        // Merge with existing checkout_builder settings so the builder editor
        // does not overwrite settings-page values (enabled, copy_to_*, etc.).
        $settings     = arraysubs_get_settings();
        $existing     = $settings['checkout_builder'] ?? [];
        $settings['checkout_builder'] = array_merge($existing, $sanitized);
        arraysubs_save_settings($settings);

        return new WP_REST_Response(
            [
                'success' => true,
                'message' => __('Configuration saved.', 'arraysubspro'),
                'data'    => $sanitized,
            ],
            200
        );
    }

    /**
     * Get WooCommerce default checkout fields for reset/reference.
     *
     * @param WP_REST_Request $request Request object.
     * @return WP_REST_Response
     */
    public function getDefaults(WP_REST_Request $request): WP_REST_Response
    {
        $wc_fields  = self::getWooCommerceDefaultFields();
        $locked     = FieldRegistry::getLockedFields();

        return new WP_REST_Response(
            [
                'success' => true,
                'data'    => [
                    'sections'      => $wc_fields,
                    'locked_fields' => $locked,
                ],
            ],
            200
        );
    }

    /**
     * Get available field types and their metadata.
     *
     * @param WP_REST_Request $request Request object.
     * @return WP_REST_Response
     */
    public function getFieldTypes(WP_REST_Request $request): WP_REST_Response
    {
        return new WP_REST_Response(
            [
                'success' => true,
                'data'    => FieldRegistry::getFieldTypes(),
            ],
            200
        );
    }

    /**
     * Get the default builder configuration.
     *
     * @return array<string, mixed>
     */
    public static function getDefaultConfig(): array
    {
        return [
            'mode'      => 'multistep',
            'default'   => [
                'sections' => [],
            ],
            'multistep' => [
                'design' => self::getDefaultDesign(),
                'steps'  => [],
            ],
        ];
    }

    /**
     * Get default design settings for multi-step mode.
     *
     * @return array<string, mixed>
     */
    public static function getDefaultDesign(): array
    {
        return [
            'color_scheme'        => 'light',
            'primary_color'       => '#2563eb',
            'secondary_color'     => '#64748b',
            'accent_color'        => '#10b981',
            'error_color'         => '#ef4444',
            'background_color'    => '#ffffff',
            'text_color'          => '#1e293b',
            'container_width'     => 'medium',
            'container_max_width' => '',
            'border_radius'       => 8,
            'step_position'       => 'top',
            'step_indicator_style' => 'numbers',
            'spacing'             => 'comfortable',
        ];
    }

    /**
     * Get WooCommerce default checkout fields organized by section.
     *
     * @return array<string, array<string, mixed>>
     */
    public static function getWooCommerceDefaultFields(): array
    {
        if (! function_exists('WC')) {
            return [];
        }

        $checkout = WC()->checkout();
        if (! $checkout) {
            return [];
        }

        $sections       = [];
        $locked_fields  = FieldRegistry::getLockedFields();
        $checkout_fields = $checkout->get_checkout_fields();

        foreach ($checkout_fields as $section_key => $fields) {
            $section_fields = [];

            foreach ($fields as $field_key => $field) {
                $section_fields[] = [
                    'key'          => $field_key,
                    'type'         => $field['type'] ?? 'text',
                    'label'        => $field['label'] ?? $field_key,
                    'placeholder'  => $field['placeholder'] ?? '',
                    'is_required'  => ! empty($field['required']),
                    'priority'     => $field['priority'] ?? 50,
                    'column_width' => self::mapWcClassToWidth($field['class'] ?? []),
                    'is_custom'    => false,
                    'is_builtin'   => true,
                    'is_locked'    => in_array($field_key, $locked_fields, true),
                ];
            }

            // Sort by priority.
            usort(
                $section_fields,
                static function ($a, $b) {
                    return ($a['priority'] ?? 50) - ($b['priority'] ?? 50);
                }
            );

            $sections[] = [
                'id'     => $section_key,
                'label'  => self::getSectionLabel($section_key),
                'fields' => $section_fields,
            ];
        }

        return $sections;
    }

    /**
     * Map WooCommerce CSS class array to column width.
     *
     * @param array<string> $classes WC field classes.
     * @return string
     */
    private static function mapWcClassToWidth(array $classes): string
    {
        if (in_array('form-row-first', $classes, true) || in_array('form-row-last', $classes, true)) {
            return '1/2';
        }

        return 'full';
    }

    /**
     * Get human-readable section label.
     *
     * @param string $key Section key.
     * @return string
     */
    private static function getSectionLabel(string $key): string
    {
        $labels = [
            'billing'  => __('Billing', 'arraysubspro'),
            'shipping' => __('Shipping', 'arraysubspro'),
            'account'  => __('Account', 'arraysubspro'),
            'order'    => __('Order', 'arraysubspro'),
        ];

        return $labels[$key] ?? ucfirst($key);
    }

    /**
     * Sanitize the builder configuration payload.
     *
     * @param array<string, mixed> $config Raw config from client.
     * @return array<string, mixed>
     */
    private function sanitizeConfig(array $config): array
    {
        $sanitized = [];

        $sanitized['mode'] = 'multistep';

        // Preserve builder-related settings only when they are explicitly provided.
        $setting_keys = [
            'enabled',
            'copy_to_subscription',
            'copy_to_renewal',
            'show_on_order_admin',
            'show_on_order_customer',
            'show_on_subscription_detail',
            'uploads_enabled',
        ];

        foreach ($setting_keys as $setting_key) {
            if (array_key_exists($setting_key, $config)) {
                $sanitized[$setting_key] = ! empty($config[$setting_key]);
            }
        }

        if (array_key_exists('uploads_max_size', $config)) {
            $sanitized['uploads_max_size'] = absint($config['uploads_max_size']);
        }

        $legacy_sections = $this->sanitizeSections($config['default']['sections'] ?? []);
        $multistep_steps = $this->sanitizeSteps($config['multistep']['steps'] ?? []);

        if (empty($multistep_steps) && ! empty($legacy_sections)) {
            $multistep_steps = [self::buildSingleStepFromSections($legacy_sections)];
        }

        $sanitized['default'] = [
            'sections' => [],
        ];

        // Multistep mode.
        $sanitized['multistep'] = [
            'design' => $this->sanitizeDesign($config['multistep']['design'] ?? []),
            'steps'  => $multistep_steps,
        ];

        return $sanitized;
    }

    /**
     * Normalize legacy single-page builder data into the step-based config.
     *
     * @param array<string, mixed> $config Raw builder config.
     * @return array<string, mixed>
     */
    private function normalizeLegacyConfig(array $config): array
    {
        $config['mode'] = 'multistep';

        if (empty($config['multistep']['steps']) && ! empty($config['default']['sections'])) {
            $config['multistep']['steps'] = [
                self::buildSingleStepFromSections($config['default']['sections']),
            ];
        }

        $config['default']['sections'] = [];

        return $config;
    }

    /**
     * Convert legacy sections into a single step builder config.
     *
     * @param array<int, array<string, mixed>> $sections Sanitized sections.
     * @return array<string, mixed>
     */
    private static function buildSingleStepFromSections(array $sections): array
    {
        $fields = [];

        foreach ($sections as $section) {
            $section_id = $section['id'] ?? '';

            // Collapse billing/shipping/order sections into group elements.
            if ('billing' === $section_id) {
                $fields[] = [
                    'key'               => 'arraysubs_billing_address',
                    'type'              => 'billing_address',
                    'label'             => __('Billing Address', 'arraysubspro'),
                    'column_width'      => 'full',
                    'is_required'       => false,
                    'is_builtin'        => true,
                    'is_custom'         => false,
                    'is_locked'         => false,
                    'address_countries' => [],
                    'fields_config'     => [],
                ];
                continue;
            }

            if ('shipping' === $section_id) {
                $fields[] = [
                    'key'               => 'arraysubs_shipping_address',
                    'type'              => 'shipping_address',
                    'label'             => __('Shipping Address', 'arraysubspro'),
                    'column_width'      => 'full',
                    'is_required'       => false,
                    'is_builtin'        => true,
                    'is_custom'         => false,
                    'is_locked'         => false,
                    'address_countries' => [],
                    'fields_config'     => [],
                ];
                continue;
            }

            if ('order' === $section_id) {
                $fields[] = [
                    'key'            => FieldRegistry::ORDER_NOTES_KEY,
                    'type'           => FieldRegistry::ORDER_NOTES_TYPE,
                    'label'          => __('Order Notes', 'arraysubspro'),
                    'column_width'   => 'full',
                    'is_required'    => false,
                    'is_builtin'     => true,
                    'is_custom'      => false,
                    'is_locked'      => false,
                    'fields_config'  => [],
                ];
                continue;
            }

            // Account and other sections: keep individual fields.
            if (! empty($section['fields']) && is_array($section['fields'])) {
                $fields = array_merge($fields, $section['fields']);
            }
        }

        $fields[] = [
            'key'           => FieldRegistry::ORDER_INFO_PAYMENT_KEY,
            'type'          => FieldRegistry::ORDER_INFO_PAYMENT_TYPE,
            'label'         => __('Order Info and Payment', 'arraysubspro'),
            'placeholder'   => '',
            'is_required'   => false,
            'help_text'     => '',
            'default_value' => '',
            'column_width'  => 'full',
            'css_class'     => '',
            'is_custom'     => false,
            'is_builtin'    => false,
            'is_locked'     => false,
        ];

        return [
            'id'     => 'step_checkout',
            'name'   => __('Checkout', 'arraysubspro'),
            'icon'   => 'shopping-cart',
            'fields' => $fields,
        ];
    }

    /**
     * Sanitize sections array.
     *
     * @param array $sections Raw sections.
     * @return array
     */
    private function sanitizeSections(array $sections): array
    {
        $sanitized = [];

        foreach ($sections as $section) {
            if (! is_array($section)) {
                continue;
            }

            $sanitized[] = [
                'id'     => sanitize_key($section['id'] ?? ''),
                'label'  => sanitize_text_field($section['label'] ?? ''),
                'fields' => $this->sanitizeFields($section['fields'] ?? []),
            ];
        }

        return $sanitized;
    }

    /**
     * Sanitize design settings.
     *
     * @param array $design Raw design settings.
     * @return array
     */
    private function sanitizeDesign(array $design): array
    {
        $defaults  = self::getDefaultDesign();
        $sanitized = [];

        // Color fields.
        $color_fields = [
            'primary_color',
            'secondary_color',
            'accent_color',
            'error_color',
            'background_color',
            'text_color',
        ];

        foreach ($color_fields as $field) {
            $value = $design[$field] ?? $defaults[$field];
            $sanitized[$field] = sanitize_hex_color($value) ?: $defaults[$field];
        }

        // Enum fields.
        $sanitized['color_scheme'] = in_array(($design['color_scheme'] ?? ''), ['light', 'dark', 'custom'], true)
            ? $design['color_scheme']
            : $defaults['color_scheme'];

        $sanitized['container_width'] = in_array(($design['container_width'] ?? ''), ['narrow', 'medium', 'wide', 'full', 'custom'], true)
            ? $design['container_width']
            : $defaults['container_width'];

        $sanitized['container_max_width'] = sanitize_text_field($design['container_max_width'] ?? '');

        $sanitized['step_position'] = in_array(($design['step_position'] ?? ''), ['top', 'left', 'hidden'], true)
            ? $design['step_position']
            : $defaults['step_position'];

        $sanitized['step_indicator_style'] = in_array(($design['step_indicator_style'] ?? ''), ['numbers', 'dots', 'progress-bar'], true)
            ? $design['step_indicator_style']
            : $defaults['step_indicator_style'];

        $sanitized['spacing'] = in_array(($design['spacing'] ?? ''), ['compact', 'comfortable', 'spacious'], true)
            ? $design['spacing']
            : $defaults['spacing'];

        // Numeric.
        $sanitized['border_radius'] = absint($design['border_radius'] ?? $defaults['border_radius']);

        return $sanitized;
    }

    /**
     * Sanitize multi-step steps array.
     *
     * @param array $steps Raw steps.
     * @return array
     */
    private function sanitizeSteps(array $steps): array
    {
        $sanitized = [];

        foreach ($steps as $step) {
            if (! is_array($step)) {
                continue;
            }

            $sanitized[] = [
                'id'     => sanitize_key($step['id'] ?? ''),
                'name'   => sanitize_text_field($step['name'] ?? ''),
                'icon'   => sanitize_text_field($step['icon'] ?? ''),
                'fields' => $this->sanitizeFields($step['fields'] ?? []),
            ];
        }

        return $sanitized;
    }

    /**
     * Sanitize a fields array.
     *
     * @param array $fields Raw fields.
     * @return array
     */
    private function sanitizeFields(array $fields): array
    {
        $sanitized     = [];
        $valid_types   = array_keys(FieldRegistry::getFieldTypes());

        foreach ($fields as $field) {
            if (! is_array($field)) {
                continue;
            }

            $type = $field['type'] ?? 'text';
            if (! in_array($type, $valid_types, true) && ! $this->isWcBuiltinType($type)) {
                $type = 'text';
            }

            $sanitized_field = [
                'key'          => sanitize_key($field['key'] ?? ''),
                'type'         => $type,
                'label'        => sanitize_text_field($field['label'] ?? ''),
                'placeholder'  => sanitize_text_field($field['placeholder'] ?? ''),
                'is_required'  => (bool) ($field['is_required'] ?? false),
                'help_text'    => sanitize_text_field($field['help_text'] ?? ''),
                'default_value' => sanitize_text_field($field['default_value'] ?? ''),
                'column_width' => in_array(($field['column_width'] ?? 'full'), ['full', '1/2', '1/3'], true)
                    ? $field['column_width']
                    : 'full',
                'css_class'    => sanitize_text_field($field['css_class'] ?? ''),
                'is_custom'    => (bool) ($field['is_custom'] ?? false),
                'is_builtin'   => (bool) ($field['is_builtin'] ?? false),
                'is_locked'    => (bool) ($field['is_locked'] ?? false),
            ];

            if (FieldRegistry::ORDER_INFO_PAYMENT_TYPE === $type) {
                $sanitized_field['key']           = FieldRegistry::ORDER_INFO_PAYMENT_KEY;
                $sanitized_field['label']         = __('Order Info and Payment', 'arraysubspro');
                $sanitized_field['placeholder']   = '';
                $sanitized_field['help_text']     = '';
                $sanitized_field['default_value'] = '';
                $sanitized_field['is_required']   = false;
                $sanitized_field['is_custom']     = false;
                $sanitized_field['is_builtin']    = false;
            }

            if (FieldRegistry::CHECKOUT_COUPON_NOTICES_TYPE === $type) {
                $sanitized_field['key']           = FieldRegistry::CHECKOUT_COUPON_NOTICES_KEY;
                $sanitized_field['label']         = __('Coupon and Notices', 'arraysubspro');
                $sanitized_field['placeholder']   = '';
                $sanitized_field['help_text']     = '';
                $sanitized_field['default_value'] = '';
                $sanitized_field['is_required']   = false;
                $sanitized_field['is_custom']     = false;
                $sanitized_field['is_builtin']    = false;
            }

            if (FieldRegistry::ORDER_NOTES_TYPE === $type) {
                $sanitized_field['key']           = FieldRegistry::ORDER_NOTES_KEY;
                $sanitized_field['label']         = __('Order Notes', 'arraysubspro');
                $sanitized_field['placeholder']   = '';
                $sanitized_field['help_text']     = '';
                $sanitized_field['default_value'] = '';
                $sanitized_field['is_required']   = false;
                $sanitized_field['is_custom']     = false;
                $sanitized_field['is_builtin']    = true;
            }

            // Sanitize visibility rules.
            if (! empty($field['visibility_rules']) && is_array($field['visibility_rules'])) {
                $sanitized_field['visibility_rules'] = $this->sanitizeVisibilityRules($field['visibility_rules']);
            }

            // Normalize options that may arrive nested inside type_settings from the editor.
            if (empty($field['options']) && ! empty($field['type_settings']['options']) && is_array($field['type_settings']['options'])) {
                $sanitized_field['options'] = $this->sanitizeOptions($field['type_settings']['options']);
            }

            // Normalize layout/editor values that may arrive inside type_settings.
            if (empty($field['content']) && isset($field['type_settings']['content'])) {
                $field['content'] = $field['type_settings']['content'];
            }

            if (empty($field['heading_level']) && isset($field['type_settings']['heading_level'])) {
                $field['heading_level'] = $field['type_settings']['heading_level'];
            }

            if (empty($field['alert_type']) && isset($field['type_settings']['alert_type'])) {
                $field['alert_type'] = $field['type_settings']['alert_type'];
            }

            // Sanitize type-specific settings.
            if (! empty($field['type_settings']) && is_array($field['type_settings'])) {
                $sanitized_field['type_settings'] = $this->sanitizeTypeSettings($type, $field['type_settings']);
            }

            // Sanitize options for select/multi_select/image_select/grid_select.
            if (! empty($field['options']) && is_array($field['options'])) {
                $sanitized_field['options'] = $this->sanitizeOptions($field['options']);
            }

            // Section children: array of column arrays, plus column count.
            if ('section' === $type) {
                $columns                       = max(1, min(3, absint($field['columns'] ?? 1)));
                $sanitized_field['columns']    = $columns;

                if (! empty($field['children']) && is_array($field['children'])) {
                    $sanitized_children = [];

                    // Detect whether children is already column-based (array of arrays)
                    // or legacy flat format (plain field list).
                    $is_column_based = isset($field['children'][0]) && is_array($field['children'][0])
                        && ! isset($field['children'][0]['key']);

                    if ($is_column_based) {
                        foreach ($field['children'] as $column) {
                            $sanitized_children[] = is_array($column)
                                ? $this->sanitizeFields($column)
                                : [];
                        }
                    } else {
                        // Legacy flat children — put all into the first column.
                        $sanitized_children[] = $this->sanitizeFields($field['children']);
                    }

                    // Pad or trim to match the column count.
                    while (count($sanitized_children) < $columns) {
                        $sanitized_children[] = [];
                    }

                    $sanitized_field['children'] = array_slice($sanitized_children, 0, $columns);
                } else {
                    $sanitized_field['children'] = array_fill(0, $columns, []);
                }
            }

            // Address group elements.
            if (in_array($type, ['billing_address', 'shipping_address'], true)) {
                $sanitized_field['is_builtin'] = true;
                $sanitized_field['is_custom']  = false;

                $raw_countries = $field['address_countries'] ?? [];
                if (is_array($raw_countries)) {
                    $sanitized_field['address_countries'] = array_values(
                        array_filter(
                            array_map('sanitize_text_field', $raw_countries)
                        )
                    );
                } elseif (is_string($raw_countries) && trim($raw_countries)) {
                    $sanitized_field['address_countries'] = array_values(
                        array_filter(
                            array_map(
                                'sanitize_text_field',
                                array_map('trim', explode(',', $raw_countries))
                            )
                        )
                    );
                } else {
                    $sanitized_field['address_countries'] = [];
                }

                $sanitized_field['fields_config'] = $this->sanitizeFieldsConfig($field['fields_config'] ?? []);
            }

            // Order notes — sanitize fields_config.
            if (FieldRegistry::ORDER_NOTES_TYPE === $type) {
                $sanitized_field['fields_config'] = $this->sanitizeFieldsConfig($field['fields_config'] ?? []);
            }

            // Layout-specific fields.
            if (FieldRegistry::isLayoutField($type)) {
                $sanitized_field['content'] = wp_kses_post($field['content'] ?? '');

                if ('heading' === $type) {
                    $sanitized_field['heading_level'] = in_array(($field['heading_level'] ?? ''), ['h2', 'h3', 'h4'], true)
                        ? $field['heading_level']
                        : 'h3';
                }

                if ('alert' === $type) {
                    $sanitized_field['alert_type'] = in_array(($field['alert_type'] ?? ''), ['info', 'warning', 'success', 'error'], true)
                        ? $field['alert_type']
                        : 'info';
                    $sanitized_field['dismissible'] = (bool) ($field['dismissible'] ?? false);
                }
            }

            $sanitized[] = $sanitized_field;
        }

        return $sanitized;
    }

    /**
     * Check if a type is a built-in WooCommerce field type.
     *
     * @param string $type Field type.
     * @return bool
     */
    private function isWcBuiltinType(string $type): bool
    {
        $wc_types = [
            'text',
            'password',
            'datetime',
            'datetime-local',
            'date',
            'month',
            'time',
            'week',
            'number',
            'email',
            'url',
            'tel',
            'color',
            'textarea',
            'select',
            'radio',
            'checkbox',
            'state',
            'country',
        ];

        return in_array($type, $wc_types, true);
    }

    /**
     * Sanitize visibility rules.
     *
     * @param array $rules Raw rules.
     * @return array
     */
    private function sanitizeVisibilityRules(array $rules): array
    {
        $sanitized       = [];
        $valid_operators = ['is', 'is_not', 'contains', 'is_empty', 'is_not_empty'];
        $valid_logic     = ['AND', 'OR'];

        foreach ($rules as $rule) {
            if (! is_array($rule)) {
                continue;
            }

            $operator = $rule['operator'] ?? 'is';
            if (! in_array($operator, $valid_operators, true)) {
                $operator = 'is';
            }

            $sanitized[] = [
                'field'    => sanitize_key($rule['field'] ?? ''),
                'operator' => $operator,
                'value'    => sanitize_text_field($rule['value'] ?? ''),
                'logic'    => in_array(($rule['logic'] ?? 'AND'), $valid_logic, true)
                    ? $rule['logic']
                    : 'AND',
            ];
        }

        return $sanitized;
    }

    /**
     * Sanitize type-specific settings.
     *
     * @param string $type     Field type.
     * @param array  $settings Raw type settings.
     * @return array
     */
    private function sanitizeTypeSettings(string $type, array $settings): array
    {
        $sanitized = [];

        switch ($type) {
            case 'number':
                $sanitized['min']  = isset($settings['min']) ? (float) $settings['min'] : null;
                $sanitized['max']  = isset($settings['max']) ? (float) $settings['max'] : null;
                $sanitized['step'] = isset($settings['step']) ? (float) $settings['step'] : 1;
                break;

            case 'upload':
                if (! empty($settings['allowed_types']) && is_array($settings['allowed_types'])) {
                    $allowed_types = array_map('sanitize_text_field', $settings['allowed_types']);
                } elseif (! empty($settings['allowed_types']) && is_string($settings['allowed_types'])) {
                    $allowed_types = array_map(
                        'sanitize_text_field',
                        array_filter(array_map('trim', explode(',', $settings['allowed_types'])))
                    );
                } else {
                    $allowed_types = ['image', 'pdf'];
                }

                $sanitized['allowed_types'] = $allowed_types;
                $sanitized['max_file_size']  = absint($settings['max_file_size'] ?? 5);
                $sanitized['max_file_count'] = absint($settings['max_file_count'] ?? 1);
                break;

            case 'image_select':
            case 'grid_select':
                $sanitized['multi']   = (bool) ($settings['multi'] ?? $settings['multiple'] ?? false);
                $sanitized['columns'] = in_array(absint($settings['columns'] ?? 3), [2, 3, 4], true)
                    ? absint($settings['columns'])
                    : 3;
                break;

            case 'date':
            case 'datetime':
            case 'calendar':
            case 'date_range':
                $sanitized['min_date'] = sanitize_text_field($settings['min_date'] ?? '');
                $sanitized['max_date'] = sanitize_text_field($settings['max_date'] ?? '');
                $sanitized['format']   = sanitize_text_field($settings['format'] ?? '');
                break;

            case 'time':
                $sanitized['format'] = in_array(($settings['format'] ?? ''), ['12h', '24h'], true)
                    ? $settings['format']
                    : '12h';
                $sanitized['step']   = absint($settings['step'] ?? 15);
                break;

            case 'product_table':
                $sanitized['product_ids'] = array_values(
                    array_filter(
                        array_map(
                            'absint',
                            is_array($settings['product_ids'] ?? null)
                                ? $settings['product_ids']
                                : []
                        )
                    )
                );

                $sanitized['category_ids'] = array_values(
                    array_filter(
                        array_map(
                            'absint',
                            is_array($settings['category_ids'] ?? null)
                                ? $settings['category_ids']
                                : []
                        )
                    )
                );

                $default_columns = [
                    'thumbnail'         => false,
                    'title'             => true,
                    'quantity'          => true,
                    'sku'               => false,
                    'price'             => true,
                    'sale_price'        => false,
                    'short_description' => false,
                ];

                $columns = is_array($settings['columns'] ?? null)
                    ? $settings['columns']
                    : [];

                $sanitized['columns'] = [];
                foreach ($default_columns as $column_key => $default_value) {
                    $sanitized['columns'][$column_key] = isset($columns[$column_key])
                        ? (bool) $columns[$column_key]
                        : $default_value;
                }

                $sanitized['product_options_data'] = $this->sanitizeOptions(
                    is_array($settings['product_options_data'] ?? null)
                        ? $settings['product_options_data']
                        : []
                );

                $sanitized['category_options_data'] = $this->sanitizeOptions(
                    is_array($settings['category_options_data'] ?? null)
                        ? $settings['category_options_data']
                        : []
                );
                break;

            case 'textarea':
                $sanitized['max_length'] = absint($settings['max_length'] ?? 0);
                $sanitized['rows']       = absint($settings['rows'] ?? 4);
                break;

            case 'phone':
                $sanitized['format_mask'] = sanitize_text_field($settings['format_mask'] ?? '');
                break;

            default:
                // Pass through sanitized.
                foreach ($settings as $key => $value) {
                    $sanitized[sanitize_key($key)] = sanitize_text_field((string) $value);
                }
                break;
        }

        return $sanitized;
    }

    /**
     * Sanitize select/option entries.
     *
     * @param array $options Raw options.
     * @return array
     */
    private function sanitizeOptions(array $options): array
    {
        $sanitized = [];

        foreach ($options as $option) {
            if (! is_array($option)) {
                continue;
            }

            $sanitized_option = [
                'value' => sanitize_text_field($option['value'] ?? ''),
                'label' => sanitize_text_field($option['label'] ?? ''),
            ];

            // Image select may have an image URL.
            $image = $option['image'] ?? $option['image_url'] ?? '';

            if (! empty($image)) {
                $sanitized_option['image'] = esc_url_raw($image);
            }

            // Grid select may have a description.
            if (! empty($option['description'])) {
                $sanitized_option['description'] = sanitize_text_field($option['description']);
            }

            $sanitized[] = $sanitized_option;
        }

        return $sanitized;
    }

    /**
     * Sanitize per-field configuration for group elements (address / order_notes).
     *
     * Each entry is keyed by a WooCommerce field key and may contain:
     * - hidden (bool)  Whether the field should be hidden.
     * - label  (string) Custom label override.
     *
     * @param array|mixed $fields_config Raw fields_config from client.
     * @return array<string, array{hidden?: bool, label?: string}>
     */
    private function sanitizeFieldsConfig($fields_config): array
    {
        if (! is_array($fields_config)) {
            return [];
        }

        $sanitized = [];

        foreach ($fields_config as $field_key => $config) {
            if (! is_string($field_key) || ! is_array($config)) {
                continue;
            }

            $clean_key = sanitize_key($field_key);
            if (empty($clean_key)) {
                continue;
            }

            $entry = [];

            if (isset($config['hidden'])) {
                $entry['hidden'] = (bool) $config['hidden'];
            }

            if (isset($config['label'])) {
                $entry['label'] = sanitize_text_field($config['label']);
            }

            if (! empty($entry)) {
                $sanitized[$clean_key] = $entry;
            }
        }

        return $sanitized;
    }
}
