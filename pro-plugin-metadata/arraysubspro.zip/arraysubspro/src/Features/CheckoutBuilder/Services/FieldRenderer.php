<?php

/**
 * CheckoutBuilder FieldRenderer
 *
 * Renders custom fields on the WooCommerce classic checkout.
 *
 * @package ArraySubsPro\Features\CheckoutBuilder\Services
 * @since 1.0.0
 */

namespace ArraySubsPro\Features\CheckoutBuilder\Services;

defined('ABSPATH') || exit;

use ArraySubs\Supports\Config;

/**
 * Handles rendering of custom checkout fields on the classic (shortcode) checkout.
 */
class FieldRenderer
{

    /**
     * Enable auto-loading.
     *
     * @var bool
     */
    public static $loadable = true;

    /**
     * Country restrictions collected from address elements.
     *
     * Keyed by section ('billing' or 'shipping') with an array of allowed country codes.
     *
     * @var array<string, array<int, string>>
     */
    private array $address_country_filters = [];

    /**
     * Constructor.
     */
    public function __construct()
    {
        // Modify WooCommerce checkout fields based on builder config.
        add_filter('woocommerce_checkout_fields', [$this, 'modifyCheckoutFields'], 999);
        add_filter('woocommerce_countries_allowed_countries', [$this, 'filterAllowedCountries'], 999);
        add_filter('woocommerce_countries_shipping_countries', [$this, 'filterShippingCountries'], 999);

        add_action('wp', [$this, 'maybeRelocateCouponAndNoticesHooks']);

        // Render custom field types that WooCommerce doesn't natively support.
        add_action('woocommerce_checkout_before_customer_details', [$this, 'renderCheckoutCouponNotices']);
        add_action('woocommerce_after_checkout_billing_form', [$this, 'renderCustomFieldsAfterBilling']);
        add_action('woocommerce_after_checkout_shipping_form', [$this, 'renderCustomFieldsAfterShipping']);
        add_action('woocommerce_after_checkout_registration_form', [$this, 'renderCustomFieldsAfterAccount']);
        add_action('woocommerce_before_order_notes', [$this, 'renderCustomFieldsBeforeOrderNotes']);
        add_action('woocommerce_checkout_before_order_review', [$this, 'renderOrderInfoAndPaymentPlaceholder']);

        // Enqueue frontend assets on checkout.
        add_action('wp_enqueue_scripts', [$this, 'enqueueFrontendAssets']);
    }

    /**
     * Modify WooCommerce checkout fields based on builder configuration.
     *
     * @param array $fields WooCommerce checkout fields.
     * @return array Modified fields.
     */
    public function modifyCheckoutFields(array $fields): array
    {
        $config = self::getActiveConfig();
        if (empty($config)) {
            return $fields;
        }

        // Reset country filters for this run.
        $this->address_country_filters = [];

        $fields = $this->applyMultistepModeFields($fields, $config);

        // Apply address country restrictions collected during field processing.
        $fields = $this->applyAddressCountryFilters($fields);

        return $fields;
    }

    /**
     * Apply multistep mode field configuration.
     *
     * In multistep mode, fields are organized by steps. WC fields are still
     * injected through the standard fields filter but with data attributes
     * denoting their step assignment. The step navigation is handled by JS.
     *
     * @param array $fields WC checkout fields.
     * @param array $config Builder config.
     * @return array
     */
    private function applyMultistepModeFields(array $fields, array $config): array
    {
        $steps = $this->getConfiguredSteps($config);

        if (empty($steps)) {
            return $fields;
        }

        // Collect all fields across steps with their step assignment.
        foreach ($steps as $step_index => $step) {
            $step_fields = $step['fields'] ?? [];
            $priority    = 10;
            $this->applyFieldConfigsToSection($fields, '', $step_fields, $priority, $step_index);
        }

        return $fields;
    }

    /**
     * Recursively apply field configs to WooCommerce checkout sections.
     *
     * @param array<string, array<string, mixed>> $fields          WooCommerce fields.
     * @param string                              $default_section Default section fallback.
     * @param array<int, array<string, mixed>>    $field_configs   Field configs.
     * @param int                                 $priority        Priority accumulator.
     * @param int|null                            $step_index      Optional multi-step index.
     * @return void
     */
    private function applyFieldConfigsToSection(array &$fields, string $default_section, array $field_configs, int &$priority, ?int $step_index = null): void
    {
        foreach ($field_configs as $field_config) {
            if (! is_array($field_config)) {
                continue;
            }

            if (! empty($field_config['children']) && is_array($field_config['children'])) {
                // Column-based structure: children is array of column arrays.
                // Flatten all columns into a single field list for WooCommerce,
                // preserving column metadata so the frontend can wrap them in a grid.
                $flat_children   = [];
                $is_column_based = isset($field_config['children'][0])
                    && is_array($field_config['children'][0])
                    && ! isset($field_config['children'][0]['key']);
                $section_key     = $field_config['key'] ?? '';

                if ($is_column_based) {
                    $num_columns = count($field_config['children']);
                    foreach ($field_config['children'] as $col_index => $column) {
                        if (! is_array($column)) {
                            continue;
                        }
                        foreach ($column as $child_field) {
                            if (! is_array($child_field)) {
                                continue;
                            }
                            $child_field['_section_key']  = $section_key;
                            $child_field['_section_cols'] = $num_columns;
                            $child_field['_section_col']  = $col_index;
                            $flat_children[]              = $child_field;
                        }
                    }
                } else {
                    // Legacy flat children.
                    $flat_children = $field_config['children'];
                }

                if (! empty($flat_children)) {
                    $this->applyFieldConfigsToSection($fields, $default_section, $flat_children, $priority, $step_index);
                }
            }

            $key = $field_config['key'] ?? '';
            $type = $field_config['type'] ?? '';

            // Address group elements: assign step class to all fields in the section
            // and store country restrictions for later filtering.
            if (in_array($type, ['billing_address', 'shipping_address'], true)) {
                $address_section = ('billing_address' === $type) ? 'billing' : 'shipping';
                $step_class      = null !== $step_index ? 'arraysubs-checkout-step-' . $step_index : '';
                $fc              = $field_config['fields_config'] ?? [];

                if (! empty($fields[$address_section]) && is_array($fields[$address_section])) {
                    // Remove hidden fields first.
                    foreach ($fc as $fc_key => $fc_value) {
                        if (! empty($fc_value['hidden']) && isset($fields[$address_section][$fc_key])) {
                            unset($fields[$address_section][$fc_key]);
                        }
                    }

                    // Apply label overrides and step assignment.
                    foreach ($fields[$address_section] as $field_key => &$wc_field) {
                        if (! empty($fc[$field_key]['label'])) {
                            $wc_field['label'] = $fc[$field_key]['label'];
                        }

                        $wc_field['priority'] = $priority;
                        $priority            += 10;

                        if ($step_class) {
                            $wc_field['class']   = $wc_field['class'] ?? [];
                            $wc_field['class'][] = $step_class;
                        }
                    }
                    unset($wc_field);
                }

                $countries = $field_config['address_countries'] ?? [];
                if (! empty($countries) && is_array($countries)) {
                    $this->address_country_filters[$address_section] = array_map('strtoupper', $countries);
                }

                continue;
            }

            // Order notes element: assign step class to all fields in the order section.
            if (FieldRegistry::ORDER_NOTES_TYPE === $type) {
                $step_class = null !== $step_index ? 'arraysubs-checkout-step-' . $step_index : '';
                $fc         = $field_config['fields_config'] ?? [];

                if (! empty($fields['order']) && is_array($fields['order'])) {
                    // Remove hidden fields first.
                    foreach ($fc as $fc_key => $fc_value) {
                        if (! empty($fc_value['hidden']) && isset($fields['order'][$fc_key])) {
                            unset($fields['order'][$fc_key]);
                        }
                    }

                    // Apply label overrides and step assignment.
                    foreach ($fields['order'] as $field_key => &$wc_field) {
                        if (! empty($fc[$field_key]['label'])) {
                            $wc_field['label'] = $fc[$field_key]['label'];
                        }

                        $wc_field['priority'] = $priority;
                        $priority            += 10;

                        if ($step_class) {
                            $wc_field['class']   = $wc_field['class'] ?? [];
                            $wc_field['class'][] = $step_class;
                        }
                    }
                    unset($wc_field);
                }

                continue;
            }

            if (empty($key) || FieldRegistry::isLayoutField($type)) {
                continue;
            }

            $section_id = $default_section ?: $this->detectFieldSection($key);
            $step_class = null !== $step_index ? 'arraysubs-checkout-step-' . $step_index : '';

            if (isset($fields[$section_id][$key])) {
                $fields[$section_id][$key] = $this->mergeFieldConfig(
                    $fields[$section_id][$key],
                    $field_config,
                    $priority
                );

                if ($step_class) {
                    $fields[$section_id][$key]['class'][] = $step_class;
                }
            } elseif (! empty($field_config['is_custom'])) {
                $wc_field = $this->buildWcField($field_config, $priority);

                if ($step_class) {
                    $wc_field['class'][] = $step_class;
                }

                $fields[$section_id ?: 'billing'][$key] = $wc_field;
            }

            $priority += 10;
        }
    }

    /**
     * Apply country restrictions to billing/shipping country fields.
     *
     * When an address element specifies address_countries, the country
     * select is filtered to only show those countries.
     *
     * @param array $fields WooCommerce checkout fields.
     * @return array Filtered fields.
     */
    private function applyAddressCountryFilters(array $fields): array
    {
        foreach ($this->address_country_filters as $section => $allowed_codes) {
            $country_key = $section . '_country';

            if (empty($fields[$section][$country_key])) {
                continue;
            }

            $wc_countries = WC()->countries;
            $all_countries = ('shipping' === $section)
                ? $wc_countries->get_shipping_countries()
                : $wc_countries->get_allowed_countries();

            $filtered = array_intersect_key(
                $all_countries,
                array_flip($allowed_codes)
            );

            if (! empty($filtered)) {
                $fields[$section][$country_key]['options'] = $filtered;
            }
        }

        return $fields;
    }

    /**
     * Filter WooCommerce billing/allowed countries using builder limits.
     *
     * WooCommerce country fields ignore the checkout field `options` value and
     * read directly from `WC_Countries`, so the builder must filter the source
     * country list through WooCommerce's dedicated country hooks.
     *
     * @param array<string, string> $countries Allowed countries.
     * @return array<string, string>
     */
    public function filterAllowedCountries(array $countries): array
    {
        return $this->getFilteredCountriesForSection('billing', $countries);
    }

    /**
     * Filter WooCommerce shipping countries using builder limits.
     *
     * @param array<string, string> $countries Shipping countries.
     * @return array<string, string>
     */
    public function filterShippingCountries(array $countries): array
    {
        return $this->getFilteredCountriesForSection('shipping', $countries);
    }

    /**
     * Intersect a WooCommerce country list with builder-configured country limits.
     *
     * Returns the original list when no valid builder limit is active so the
     * checkout never ends up with an empty country dropdown because of bad input.
     *
     * @param string                $section   Checkout section (`billing` or `shipping`).
     * @param array<string, string> $countries Source country list.
     * @return array<string, string>
     */
    private function getFilteredCountriesForSection(string $section, array $countries): array
    {
        $allowed_codes = $this->address_country_filters[$section] ?? [];

        if (empty($allowed_codes)) {
            return $countries;
        }

        $filtered = array_intersect_key(
            $countries,
            array_flip($allowed_codes)
        );

        return ! empty($filtered) ? $filtered : $countries;
    }

    /**
     * Merge builder field config into an existing WC field definition.
     *
     * @param array $wc_field      Existing WC field array.
     * @param array $field_config  Builder field config.
     * @param int   $priority      Field sort priority.
     * @return array
     */
    private function mergeFieldConfig(array $wc_field, array $field_config, int $priority): array
    {
        if (! empty($field_config['label'])) {
            $wc_field['label'] = $field_config['label'];
        }

        if (! empty($field_config['placeholder'])) {
            $wc_field['placeholder'] = $field_config['placeholder'];
        }

        if (isset($field_config['is_required'])) {
            // Only allow changing required if field is not locked.
            $locked = FieldRegistry::getLockedFields();
            $key    = $field_config['key'] ?? '';
            if (! in_array($key, $locked, true)) {
                $wc_field['required'] = (bool) $field_config['is_required'];
            }
        }

        // Apply column width as CSS class.
        $width_class = $this->getWidthClass($field_config['column_width'] ?? 'full');
        if ($width_class) {
            $wc_field['class'] = array_filter($wc_field['class'] ?? [], static function ($cls) {
                return ! in_array($cls, ['form-row-wide', 'form-row-first', 'form-row-last'], true);
            });
            $wc_field['class'][] = $width_class;
        }

        // Add section layout metadata when the field lives inside a builder section.
        if (! empty($field_config['_section_key'])) {
            $wc_field['class'][]                                    = 'arraysubs-in-section';
            $wc_field['class'][]                                    = 'arraysubs-section--' . sanitize_html_class($field_config['_section_key']);
            $wc_field['custom_attributes']                          = $wc_field['custom_attributes'] ?? [];
            $wc_field['custom_attributes']['data-section-key']      = sanitize_html_class($field_config['_section_key']);
            $wc_field['custom_attributes']['data-section-cols']     = absint($field_config['_section_cols'] ?? 1);
            $wc_field['custom_attributes']['data-section-col']      = absint($field_config['_section_col'] ?? 0);
        }

        $wc_field['priority'] = $priority;

        if (! empty($field_config['css_class'])) {
            $wc_field['class'][] = $field_config['css_class'];
        }

        if (! empty($field_config['help_text'])) {
            $wc_field['description'] = $field_config['help_text'];
        }

        // Add visibility rules as data attribute for frontend JS.
        if (! empty($field_config['visibility_rules'])) {
            $wc_field['custom_attributes']['data-visibility-rules'] = wp_json_encode($field_config['visibility_rules']);
        }

        return $wc_field;
    }

    /**
     * Build a WooCommerce field array from a builder field config.
     *
     * @param array $field_config Builder field config.
     * @param int   $priority     Field sort priority.
     * @return array WC-compatible field definition.
     */
    private function buildWcField(array $field_config, int $priority): array
    {
        $type = $this->mapToWcType($field_config['type'] ?? 'text');

        $wc_field = [
            'type'        => $type,
            'label'       => $field_config['label'] ?? '',
            'placeholder' => $field_config['placeholder'] ?? '',
            'required'    => (bool) ($field_config['is_required'] ?? false),
            'class'       => [$this->getWidthClass($field_config['column_width'] ?? 'full')],
            'priority'    => $priority,
        ];

        if (! empty($field_config['default_value'])) {
            $wc_field['default'] = $field_config['default_value'];
        }

        if (! empty($field_config['help_text'])) {
            $wc_field['description'] = $field_config['help_text'];
        }

        if (! empty($field_config['css_class'])) {
            $wc_field['class'][] = $field_config['css_class'];
        }

        // Add options for select-type fields (check type_settings.options first, then top-level).
        if (in_array($type, ['select'], true)) {
            $options = $field_config['type_settings']['options'] ?? $field_config['options'] ?? [];
            if (! empty($options)) {
                $wc_field['options'] = [];
                foreach ($options as $option) {
                    $wc_field['options'][$option['value']] = $option['label'];
                }
            }
        }

        // Add visibility rules as data attribute for frontend JS.
        if (! empty($field_config['visibility_rules'])) {
            $wc_field['custom_attributes']['data-visibility-rules'] = wp_json_encode($field_config['visibility_rules']);
        }

        // Add section layout metadata when the field lives inside a builder section.
        if (! empty($field_config['_section_key'])) {
            $wc_field['class'][]                                    = 'arraysubs-in-section';
            $wc_field['class'][]                                    = 'arraysubs-section--' . sanitize_html_class($field_config['_section_key']);
            $wc_field['custom_attributes']                          = $wc_field['custom_attributes'] ?? [];
            $wc_field['custom_attributes']['data-section-key']      = sanitize_html_class($field_config['_section_key']);
            $wc_field['custom_attributes']['data-section-cols']     = absint($field_config['_section_cols'] ?? 1);
            $wc_field['custom_attributes']['data-section-col']      = absint($field_config['_section_col'] ?? 0);
        }

        return $wc_field;
    }

    /**
     * Map a builder field type to a WooCommerce-supported type.
     *
     * @param string $type Builder field type.
     * @return string WC-compatible type.
     */
    private function mapToWcType(string $type): string
    {
        $map = [
            'text'         => 'text',
            'number'       => 'number',
            'email'        => 'email',
            'phone'        => 'tel',
            'select'       => 'select',
            'multi_select' => 'select',
            'textarea'     => 'textarea',
            'checkbox'     => 'checkbox',
            'toggle'       => 'checkbox',
            'date'         => 'date',
            'time'         => 'time',
            'datetime'     => 'datetime-local',
            'color_picker' => 'color',
        ];

        return $map[$type] ?? 'text';
    }

    /**
     * Convert column width spec to WC CSS class.
     *
     * @param string $width Column width (full, 1/2, 1/3).
     * @return string CSS class.
     */
    private function getWidthClass(string $width): string
    {
        static $half_toggle = false;

        if ('1/2' === $width) {
            $half_toggle = ! $half_toggle;
            return $half_toggle ? 'form-row-first' : 'form-row-last';
        }

        // Reset toggle when a full-width field appears.
        $half_toggle = false;

        return 'form-row-wide';
    }

    /**
     * Detect which WC section a field belongs to based on its key prefix.
     *
     * @param string $key Field key.
     * @return string Section key.
     */
    private function detectFieldSection(string $key): string
    {
        if (0 === strpos($key, 'billing_')) {
            return 'billing';
        }

        if (0 === strpos($key, 'shipping_')) {
            return 'shipping';
        }

        if (0 === strpos($key, 'account_')) {
            return 'account';
        }

        if (0 === strpos($key, 'order_')) {
            return 'order';
        }

        // Custom fields default to billing.
        return 'billing';
    }

    /**
     * Render custom (advanced) fields after billing section.
     *
     * @param \WC_Checkout $checkout Checkout object.
     * @return void
     */
    public function renderCustomFieldsAfterBilling($checkout): void
    {
        $this->renderAdvancedFieldsForSection('billing', $checkout);
    }

    /**
     * Render custom (advanced) fields after shipping section.
     *
     * @param \WC_Checkout $checkout Checkout object.
     * @return void
     */
    public function renderCustomFieldsAfterShipping($checkout): void
    {
        $this->renderAdvancedFieldsForSection('shipping', $checkout);
    }

    /**
     * Render custom (advanced/layout) fields after account section.
     *
     * @param \WC_Checkout $checkout Checkout object.
     * @return void
     */
    public function renderCustomFieldsAfterAccount($checkout): void
    {
        $this->renderAdvancedFieldsForSection('account', $checkout);
    }

    /**
     * Render the coupon and notices builder element before customer details.
     *
     * @return void
     */
    public function renderCheckoutCouponNotices(): void
    {
        $checkout = function_exists('WC') ? WC()->checkout() : null;

        $this->renderAdvancedFieldsForSection('checkout_coupon_notices', $checkout);
    }

    /**
     * Render custom (advanced) fields before order notes.
     *
     * @param \WC_Checkout $checkout Checkout object.
     * @return void
     */
    public function renderCustomFieldsBeforeOrderNotes($checkout): void
    {
        $this->renderAdvancedFieldsForSection('order', $checkout);
    }

    /**
     * Render advanced field types that WC cannot natively handle.
     *
     * @param string       $section  Section key.
     * @param \WC_Checkout $checkout Checkout object.
     * @return void
     */
    private function renderAdvancedFieldsForSection(string $section, $checkout): void
    {
        $config = self::getActiveConfig();
        if (empty($config)) {
            return;
        }

        $renderable_types = [
            'upload',
            'image_select',
            'grid_select',
            'multi_select',
            'calendar',
            'date_range',
            'heading',
            'paragraph',
            'alert',
            FieldRegistry::CHECKOUT_COUPON_NOTICES_TYPE,
            'product_table',
        ];

        $fields_to_render = [];

        foreach ($this->getConfiguredSteps($config) as $step_index => $step) {
            $this->collectRenderableFields($fields_to_render, $step['fields'] ?? [], $section, $renderable_types, $config, $step_index);
        }

        if (empty($fields_to_render)) {
            return;
        }

        foreach ($fields_to_render as $field) {
            $this->renderAdvancedField($field);
        }
    }

    /**
     * Recursively collect renderable advanced fields for a checkout section.
     *
     * @param array<int, array<string, mixed>> $collected        Renderable fields.
     * @param array<int, array<string, mixed>> $fields           Field tree.
     * @param string                           $section          Checkout section.
     * @param array<int, string>               $renderable_types Renderable types.
     * @param array<string, mixed>             $config           Builder config.
     * @param int                              $step_index       Current step index.
     * @return void
     */
    private function collectRenderableFields(array &$collected, array $fields, string $section, array $renderable_types, array $config, int $step_index): void
    {
        foreach ($fields as $field) {
            if (! is_array($field)) {
                continue;
            }

            if (! empty($field['children']) && is_array($field['children'])) {
                $is_column_based = isset($field['children'][0])
                    && is_array($field['children'][0])
                    && ! isset($field['children'][0]['key']);

                if ($is_column_based) {
                    $sec_key     = $field['key'] ?? '';
                    $num_columns = count($field['children']);
                    foreach ($field['children'] as $col_index => $column) {
                        if (! is_array($column)) {
                            continue;
                        }
                        foreach ($column as $child_field) {
                            if (! is_array($child_field)) {
                                continue;
                            }
                            $child_field['_section_key']  = $sec_key;
                            $child_field['_section_cols'] = $num_columns;
                            $child_field['_section_col']  = $col_index;
                            $this->collectRenderableFields($collected, [$child_field], $section, $renderable_types, $config, $step_index);
                        }
                    }
                } else {
                    $this->collectRenderableFields($collected, $field['children'], $section, $renderable_types, $config, $step_index);
                }
            }

            $field_section = $this->getFieldSection($field);

            if ($field_section !== $section) {
                continue;
            }

            if ('upload' === ($field['type'] ?? '') && empty($config['uploads_enabled'])) {
                continue;
            }

            if (in_array(($field['type'] ?? ''), $renderable_types, true)) {
                $field['step_index'] = $step_index;
                $collected[] = $field;
            }
        }
    }

    /**
     * Render a single advanced field type.
     *
     * @param array $field Field config.
     * @return void
     */
    private function renderAdvancedField(array $field): void
    {
        $type  = $field['type'] ?? '';
        $key   = esc_attr($field['key'] ?? '');
        $label = esc_html($field['label'] ?? '');

        $required_html = ! empty($field['is_required'])
            ? ' <abbr class="required" title="' . esc_attr__('required', 'arraysubspro') . '">*</abbr>'
            : '';

        $width_class = $this->getWidthClass($field['column_width'] ?? 'full');

        $css_class = 'form-row ' . $width_class;
        if (isset($field['step_index'])) {
            $css_class .= ' arraysubs-checkout-step-' . absint($field['step_index']);
        }

        if (! empty($field['css_class'])) {
            $css_class .= ' ' . esc_attr($field['css_class']);
        }

        if (! empty($field['_section_key'])) {
            $css_class .= ' arraysubs-in-section arraysubs-section--' . sanitize_html_class($field['_section_key']);
        }

        $visibility_rules = ! empty($field['visibility_rules'])
            ? wp_json_encode($field['visibility_rules'])
            : '';

        if (FieldRegistry::CHECKOUT_COUPON_NOTICES_TYPE === $type) {
?>
            <div
                class="<?php echo esc_attr($css_class); ?>"
                id="<?php echo esc_attr($key); ?>_field"
                <?php if ($visibility_rules) : ?>
                data-visibility-rules="<?php echo esc_attr($visibility_rules); ?>"
                <?php endif; ?>
                <?php if (! empty($field['_section_key'])) : ?>
                data-section-key="<?php echo esc_attr(sanitize_html_class($field['_section_key'])); ?>"
                data-section-cols="<?php echo esc_attr(absint($field['_section_cols'] ?? 1)); ?>"
                data-section-col="<?php echo esc_attr(absint($field['_section_col'] ?? 0)); ?>"
                <?php endif; ?>>
                <?php $this->renderCheckoutCouponNoticesElement(); ?>
            </div>
        <?php

            return;
        }

        if ('product_table' === $type) {
        ?>
            <div
                class="<?php echo esc_attr($css_class); ?>"
                id="<?php echo esc_attr($key); ?>_field"
                <?php if ($visibility_rules) : ?>
                data-visibility-rules="<?php echo esc_attr($visibility_rules); ?>"
                <?php endif; ?>
                <?php if (! empty($field['_section_key'])) : ?>
                data-section-key="<?php echo esc_attr(sanitize_html_class($field['_section_key'])); ?>"
                data-section-cols="<?php echo esc_attr(absint($field['_section_cols'] ?? 1)); ?>"
                data-section-col="<?php echo esc_attr(absint($field['_section_col'] ?? 0)); ?>"
                <?php endif; ?>>
                <?php if ('' !== $label) : ?>
                    <span class="arraysubs-product-table__field-label">
                        <?php
                        // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $label is already escaped, $required_html is hardcoded markup.
                        echo $label . $required_html;
                        ?>
                    </span>
                <?php endif; ?>
                <?php ProductTableHelper::render($field); ?>
                <?php if (! empty($field['help_text'])) : ?>
                    <span class="description"><?php echo esc_html($field['help_text']); ?></span>
                <?php endif; ?>
            </div>
        <?php

            return;
        }
        ?>
        <p
            class="<?php echo esc_attr($css_class); ?>"
            id="<?php echo esc_attr($key); ?>_field"
            <?php if ($visibility_rules) : ?>
            data-visibility-rules="<?php echo esc_attr($visibility_rules); ?>"
            <?php endif; ?>
            <?php if (! empty($field['_section_key'])) : ?>
            data-section-key="<?php echo esc_attr(sanitize_html_class($field['_section_key'])); ?>"
            data-section-cols="<?php echo esc_attr(absint($field['_section_cols'] ?? 1)); ?>"
            data-section-col="<?php echo esc_attr(absint($field['_section_col'] ?? 0)); ?>"
            <?php endif; ?>>
            <label for="<?php echo esc_attr($key); ?>">
                <?php
                // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $label is already escaped, $required_html is hardcoded markup.
                echo $label . $required_html;
                ?>
            </label>
            <?php
            switch ($type) {
                case 'heading':
                    $this->renderHeading($field);
                    break;

                case 'paragraph':
                    $this->renderParagraph($field);
                    break;

                case 'alert':
                    $this->renderAlert($field);
                    break;

                case 'multi_select':
                    $this->renderMultiSelect($field);
                    break;

                case 'image_select':
                    $this->renderImageSelect($field);
                    break;

                case 'grid_select':
                    $this->renderGridSelect($field);
                    break;

                case 'upload':
                    $this->renderFileUpload($field);
                    break;

                case 'calendar':
                case 'date_range':
                    $this->renderDatePicker($field);
                    break;

                case FieldRegistry::CHECKOUT_COUPON_NOTICES_TYPE:
                    break;

                case 'product_table':
                    break;
            }
            ?>
            <?php if (! empty($field['help_text'])) : ?>
                <span class="description"><?php echo esc_html($field['help_text']); ?></span>
            <?php endif; ?>
        </p>
    <?php
    }

    /**
     * Render a multi-select field.
     *
     * @param array $field Field config.
     * @return void
     */
    private function renderMultiSelect(array $field): void
    {
        $key     = esc_attr($field['key'] ?? '');
        $options = $this->getFieldOptions($field);
    ?>
        <select name="<?php echo esc_attr($key); ?>[]" id="<?php echo esc_attr($key); ?>" multiple class="arraysubs-multi-select">
            <?php foreach ($options as $option) : ?>
                <option value="<?php echo esc_attr($option['value'] ?? ''); ?>">
                    <?php echo esc_html($option['label'] ?? ''); ?>
                </option>
            <?php endforeach; ?>
        </select>
    <?php
    }

    /**
     * Render an image select field.
     *
     * @param array $field Field config.
     * @return void
     */
    private function renderImageSelect(array $field): void
    {
        $key     = esc_attr($field['key'] ?? '');
        $options = $this->getFieldOptions($field);
        $multi   = ! empty($field['type_settings']['multi']);
        $type    = $multi ? 'checkbox' : 'radio';
    ?>
        <div class="arraysubs-image-select" data-field="<?php echo esc_attr($key); ?>">
            <?php foreach ($options as $option) : ?>
                <label class="arraysubs-image-select__option">
                    <input
                        type="<?php echo esc_attr($type); ?>"
                        name="<?php echo esc_attr($key); ?><?php echo $multi ? '[]' : ''; ?>"
                        value="<?php echo esc_attr($option['value'] ?? ''); ?>" />
                    <?php if (! empty($option['image'])) : ?>
                        <img src="<?php echo esc_url($option['image']); ?>" alt="<?php echo esc_attr($option['label'] ?? ''); ?>" />
                    <?php endif; ?>
                    <span><?php echo esc_html($option['label'] ?? ''); ?></span>
                </label>
            <?php endforeach; ?>
        </div>
    <?php
    }

    /**
     * Render a grid select field.
     *
     * @param array $field Field config.
     * @return void
     */
    private function renderGridSelect(array $field): void
    {
        $key     = esc_attr($field['key'] ?? '');
        $options = $this->getFieldOptions($field);
        $multi   = ! empty($field['type_settings']['multi']);
        $columns = absint($field['type_settings']['columns'] ?? 3);
        $type    = $multi ? 'checkbox' : 'radio';
    ?>
        <div class="arraysubs-grid-select arraysubs-grid-select--cols-<?php echo esc_attr($columns); ?>" data-field="<?php echo esc_attr($key); ?>">
            <?php foreach ($options as $option) : ?>
                <label class="arraysubs-grid-select__card">
                    <input
                        type="<?php echo esc_attr($type); ?>"
                        name="<?php echo esc_attr($key); ?><?php echo $multi ? '[]' : ''; ?>"
                        value="<?php echo esc_attr($option['value'] ?? ''); ?>" />
                    <span class="arraysubs-grid-select__label"><?php echo esc_html($option['label'] ?? ''); ?></span>
                    <?php if (! empty($option['description'])) : ?>
                        <span class="arraysubs-grid-select__desc"><?php echo esc_html($option['description']); ?></span>
                    <?php endif; ?>
                </label>
            <?php endforeach; ?>
        </div>
    <?php
    }

    /**
     * Render a file upload field.
     *
     * @param array $field Field config.
     * @return void
     */
    private function renderFileUpload(array $field): void
    {
        $key       = esc_attr($field['key'] ?? '');
        $max_size  = absint($field['type_settings']['max_file_size'] ?? 5);
        $max_count = absint($field['type_settings']['max_file_count'] ?? 1);
        $accept    = '';

        if (! empty($field['type_settings']['allowed_types'])) {
            $mime_map = [
                'image' => 'image/*',
                'pdf'   => '.pdf',
                'doc'   => '.doc,.docx',
            ];

            $parts = [];
            foreach ($field['type_settings']['allowed_types'] as $atype) {
                if (isset($mime_map[$atype])) {
                    $parts[] = $mime_map[$atype];
                }
            }
            $accept = implode(',', $parts);
        }
    ?>
        <input
            type="file"
            name="<?php echo esc_attr($key); ?><?php echo ($max_count > 1) ? '[]' : ''; ?>"
            id="<?php echo esc_attr($key); ?>"
            class="arraysubs-file-upload"
            <?php echo $accept ? 'accept="' . esc_attr($accept) . '"' : ''; ?>
            <?php echo ($max_count > 1) ? 'multiple' : ''; ?>
            data-max-size="<?php echo esc_attr($max_size); ?>"
            data-max-count="<?php echo esc_attr($max_count); ?>" />
    <?php
    }

    /**
     * Render a heading layout field.
     *
     * @param array $field Field config.
     * @return void
     */
    private function renderHeading(array $field): void
    {
        $level = in_array(($field['heading_level'] ?? 'h3'), ['h2', 'h3', 'h4'], true)
            ? $field['heading_level']
            : 'h3';

        printf(
            '<%1$s class="arraysubs-checkout-builder-heading">%2$s</%1$s>',
            esc_attr($level),
            esc_html($field['label'] ?? '')
        );
    }

    /**
     * Render a paragraph layout field.
     *
     * @param array $field Field config.
     * @return void
     */
    private function renderParagraph(array $field): void
    {
        echo '<div class="arraysubs-checkout-builder-paragraph">' . wp_kses_post(wpautop($field['content'] ?? '')) . '</div>';
    }

    /**
     * Render an alert layout field.
     *
     * @param array $field Field config.
     * @return void
     */
    private function renderAlert(array $field): void
    {
        $alert_type = in_array(($field['alert_type'] ?? 'info'), ['info', 'warning', 'success', 'error'], true)
            ? $field['alert_type']
            : 'info';

        echo '<div class="arraysubs-checkout-builder-alert arraysubs-checkout-builder-alert--' . esc_attr($alert_type) . '">';
        echo wp_kses_post(wpautop($field['content'] ?? ''));
        echo '</div>';
    }

    /**
     * Render WooCommerce checkout notices and coupon UI inside a builder element.
     *
     * @return void
     */
    private function renderCheckoutCouponNoticesElement(): void
    {
    ?>
        <div class="arraysubs-checkout-coupon-notices" data-arraysubs-checkout-coupon-notices="1">
            <div class="arraysubs-checkout-coupon-notices__notices" data-arraysubs-checkout-notices-slot="1">
                <?php if (function_exists('woocommerce_output_all_notices')) : ?>
                    <?php woocommerce_output_all_notices(); ?>
                <?php endif; ?>
            </div>
            <div class="arraysubs-checkout-coupon-notices__coupon" data-arraysubs-checkout-coupon-slot="1">
                <?php if (function_exists('wc_coupons_enabled') && wc_coupons_enabled()) : ?>
                    <?php $this->renderInlineCheckoutCouponElement(); ?>
                <?php endif; ?>
            </div>
        </div>
    <?php
    }

    /**
     * Render a checkout-safe inline coupon UI inside the main checkout form.
     *
     * WooCommerce's native `woocommerce_checkout_coupon_form()` outputs its own
     * `<form>` element, which cannot be nested inside `form.checkout`. The
     * builder element therefore renders equivalent markup using a `<div>`
     * container and lets frontend JS submit to WooCommerce's AJAX coupon
     * endpoint.
     *
     * @return void
     */
    private function renderInlineCheckoutCouponElement(): void
    {
        $button_class = '';

        if (function_exists('wc_wp_theme_get_element_class_name')) {
            $button_class = wc_wp_theme_get_element_class_name('button');
        }

        $coupon_message = apply_filters(
            'woocommerce_checkout_coupon_message',
            esc_html__('Have a coupon?', 'woocommerce') . ' <a href="#" role="button" aria-label="' . esc_attr__('Enter your coupon code', 'woocommerce') . '" aria-controls="woocommerce-checkout-form-coupon" aria-expanded="false" class="showcoupon">' . esc_html__('Click here to enter your code', 'woocommerce') . '</a>'
        );
    ?>
        <div class="woocommerce-form-coupon-toggle">
            <?php wc_print_notice($coupon_message, 'notice'); ?>
        </div>

        <div class="checkout_coupon woocommerce-form-coupon arraysubs-inline-checkout-coupon" style="display:none" id="woocommerce-checkout-form-coupon" data-arraysubs-inline-coupon="1">
            <p class="form-row form-row-first">
                <label for="coupon_code" class="screen-reader-text"><?php esc_html_e('Coupon:', 'woocommerce'); ?></label>
                <input type="text" name="coupon_code" class="input-text" placeholder="<?php esc_attr_e('Coupon code', 'woocommerce'); ?>" id="coupon_code" value="" />
            </p>

            <p class="form-row form-row-last">
                <button type="button" class="button<?php echo $button_class ? esc_attr(' ' . $button_class) : ''; ?>" name="apply_coupon" value="<?php esc_attr_e('Apply coupon', 'woocommerce'); ?>" data-arraysubs-inline-coupon-apply="1"><?php esc_html_e('Apply coupon', 'woocommerce'); ?></button>
            </p>

            <div class="clear"></div>
        </div>
        <?php
    }

    /**
     * Get field options from top-level or nested type settings.
     *
     * @param array $field Field config.
     * @return array
     */
    private function getFieldOptions(array $field): array
    {
        if (! empty($field['options']) && is_array($field['options'])) {
            return $field['options'];
        }

        if (! empty($field['type_settings']['options']) && is_array($field['type_settings']['options'])) {
            return $field['type_settings']['options'];
        }

        return [];
    }

    /**
     * Render a date picker field.
     *
     * @param array $field Field config.
     * @return void
     */
    private function renderDatePicker(array $field): void
    {
        $key      = esc_attr($field['key'] ?? '');
        $type     = $field['type'] ?? 'calendar';
        $min_date = esc_attr($field['type_settings']['min_date'] ?? '');
        $max_date = esc_attr($field['type_settings']['max_date'] ?? '');

        if ('date_range' === $type) {
        ?>
            <span class="arraysubs-date-range">
                <input
                    type="date"
                    name="<?php echo esc_attr($key); ?>[start]"
                    class="arraysubs-date-range__start"
                    <?php echo $min_date ? 'min="' . esc_attr($min_date) . '"' : ''; ?>
                    <?php echo $max_date ? 'max="' . esc_attr($max_date) . '"' : ''; ?>
                    placeholder="<?php echo esc_attr__('Start date', 'arraysubspro'); ?>" />
                <span class="arraysubs-date-range__separator">&ndash;</span>
                <input
                    type="date"
                    name="<?php echo esc_attr($key); ?>[end]"
                    class="arraysubs-date-range__end"
                    <?php echo $min_date ? 'min="' . esc_attr($min_date) . '"' : ''; ?>
                    <?php echo $max_date ? 'max="' . esc_attr($max_date) . '"' : ''; ?>
                    placeholder="<?php echo esc_attr__('End date', 'arraysubspro'); ?>" />
            </span>
        <?php
        } else {
        ?>
            <input
                type="date"
                name="<?php echo esc_attr($key); ?>"
                id="<?php echo esc_attr($key); ?>"
                class="arraysubs-calendar"
                <?php echo $min_date ? 'min="' . esc_attr($min_date) . '"' : ''; ?>
                <?php echo $max_date ? 'max="' . esc_attr($max_date) . '"' : ''; ?> />
            <?php
        }
    }

    /**
     * Enqueue frontend CSS/JS on checkout page.
     *
     * @return void
     */
    public function enqueueFrontendAssets(): void
    {
        if (! function_exists('is_checkout') || ! is_checkout()) {
            return;
        }

        $config = self::getActiveConfig();
        if (empty($config)) {
            return;
        }

        $asset_file = Config::get('proplugin.public_path') . 'build/checkout-builder-frontend.asset.php';
        $asset      = file_exists($asset_file)
            ? require $asset_file
            : ['dependencies' => [], 'version' => ARRAYSUBSPRO_VERSION];

        wp_enqueue_style(
            'arraysubspro-checkout-builder-frontend',
            Config::get('proplugin.public_url') . 'build/checkout-builder-frontend.css',
            [],
            $asset['version']
        );

        wp_enqueue_script(
            'arraysubspro-checkout-builder-frontend',
            Config::get('proplugin.public_url') . 'build/checkout-builder-frontend.js',
            $asset['dependencies'],
            $asset['version'],
            true
        );

        // Pass config to frontend JS for step navigation and conditional visibility.
        $json_flags = JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT;
        $steps      = $this->getConfiguredSteps($config);

        $frontend_data = [
            'mode'   => 'multistep',
            'layout' => count($steps) > 1 ? 'multistep' : 'single-page',
            'design' => $config['multistep']['design'] ?? [],
            'nonce'  => wp_create_nonce('wp_rest'),
            'productTable' => [
                'syncUrl' => rest_url('arraysubs/v1/checkout-builder/product-table/cart'),
                'strings' => [
                    'requestFailed' => __('Unable to update the checkout products right now.', 'arraysubspro'),
                    'add'           => __('Add to Cart', 'arraysubspro'),
                    'update'        => __('Update', 'arraysubspro'),
                    'added'         => __('In Cart', 'arraysubspro'),
                    'remove'        => __('Remove', 'arraysubspro'),
                ],
            ],
            'blockFields' => $this->getBlockFrontendFields($config),
            'steps'  => array_map(
                static function ($step) {
                    return [
                        'id'   => $step['id'] ?? '',
                        'name' => $step['name'] ?? '',
                        'icon' => $step['icon'] ?? '',
                    ];
                },
                $steps
            ),
        ];

        wp_add_inline_script(
            'arraysubspro-checkout-builder-frontend',
            'window.arraySubsCheckout = ' . wp_json_encode($frontend_data, $json_flags) . ';',
            'before'
        );
    }

    /**
     * Build compact field metadata for block checkout frontend decoration.
     *
     * @param array<string, mixed> $config Builder config.
     * @return array<int, array<string, mixed>>
     */
    private function getBlockFrontendFields(array $config): array
    {
        $fields = [];

        foreach ($this->getConfiguredSteps($config) as $step_index => $step) {
            $this->collectBlockFrontendFields($fields, $step['fields'] ?? [], $step_index);
        }

        return $fields;
    }

    /**
     * Recursively collect fields for block checkout frontend decoration.
     *
     * @param array<int, array<string, mixed>> $collected  Collected fields.
     * @param array<int, array<string, mixed>> $fields     Builder field tree.
     * @param int                              $step_index Step index.
     * @return void
     */
    private function collectBlockFrontendFields(array &$collected, array $fields, int $step_index): void
    {
        foreach ($fields as $field) {
            if (! is_array($field)) {
                continue;
            }

            if (! empty($field['children']) && is_array($field['children'])) {
                $is_column_based = isset($field['children'][0])
                    && is_array($field['children'][0])
                    && ! isset($field['children'][0]['key']);

                if ($is_column_based) {
                    foreach ($field['children'] as $column) {
                        if (is_array($column)) {
                            $this->collectBlockFrontendFields($collected, $column, $step_index);
                        }
                    }
                } else {
                    $this->collectBlockFrontendFields($collected, $field['children'], $step_index);
                }
            }

            $type = (string) ($field['type'] ?? '');
            $key  = (string) ($field['key'] ?? '');

            if ('' === $type || in_array($type, [FieldRegistry::ORDER_INFO_PAYMENT_TYPE, FieldRegistry::CHECKOUT_COUPON_NOTICES_TYPE, FieldRegistry::ORDER_NOTES_TYPE, 'billing_address', 'shipping_address', 'section'], true)) {
                continue;
            }

            $collected[] = [
                'key'              => $key,
                'block_id'         => ! empty($field['is_custom']) ? MetaHandler::getBlockFieldIdForKey($key) : '',
                'type'             => $type,
                'label'            => (string) ($field['label'] ?? ''),
                'content'          => (string) ($field['content'] ?? ''),
                'heading_level'    => (string) ($field['heading_level'] ?? 'h3'),
                'options'          => $this->getFieldOptions($field),
                'visibility_rules' => is_array($field['visibility_rules'] ?? null) ? $field['visibility_rules'] : [],
                'step_index'       => $step_index,
            ];
        }
    }

    /**
     * Get the currently active builder configuration.
     *
     * @return array
     */
    private static function getActiveConfig(): array
    {
        $settings = arraysubs_get_settings();
        $config   = $settings['checkout_builder'] ?? [];

        if (empty($config['enabled'])) {
            return [];
        }

        return $config;
    }

    /**
     * Get the normalized configured checkout steps.
     *
     * @param array<string, mixed> $config Builder config.
     * @return array<int, array<string, mixed>>
     */
    private function getConfiguredSteps(array $config): array
    {
        $steps = $config['multistep']['steps'] ?? [];

        if (! empty($steps) && is_array($steps)) {
            return $steps;
        }

        $legacy_sections = $config['default']['sections'] ?? [];

        if (empty($legacy_sections) || ! is_array($legacy_sections)) {
            return [];
        }

        $fields = [];

        foreach ($legacy_sections as $section) {
            if (! empty($section['fields']) && is_array($section['fields'])) {
                $fields = array_merge($fields, $section['fields']);
            }
        }

        $fields[] = [
            'key'   => FieldRegistry::ORDER_INFO_PAYMENT_KEY,
            'type'  => FieldRegistry::ORDER_INFO_PAYMENT_TYPE,
            'label' => __('Order Info and Payment', 'arraysubspro'),
        ];

        return [
            [
                'id'     => 'step_checkout',
                'name'   => __('Checkout', 'arraysubspro'),
                'icon'   => 'shopping-cart',
                'fields' => $fields,
            ],
        ];
    }

    /**
     * Resolve the checkout section for a field or special layout element.
     *
     * @param array<string, mixed> $field Field config.
     * @return string
     */
    private function getFieldSection(array $field): string
    {
        if (FieldRegistry::CHECKOUT_COUPON_NOTICES_TYPE === ($field['type'] ?? '')) {
            return 'checkout_coupon_notices';
        }

        if (FieldRegistry::ORDER_INFO_PAYMENT_TYPE === ($field['type'] ?? '')) {
            return 'order_info_payment';
        }

        return $this->detectFieldSection($field['key'] ?? '');
    }

    /**
     * Render the special order info and payment placeholder.
     *
     * @return void
     */
    public function renderOrderInfoAndPaymentPlaceholder(): void
    {
        $config = self::getActiveConfig();

        if (empty($config)) {
            return;
        }

        foreach ($this->getConfiguredSteps($config) as $step_index => $step) {
            foreach (($step['fields'] ?? []) as $field) {
                if (! is_array($field) || FieldRegistry::ORDER_INFO_PAYMENT_TYPE !== ($field['type'] ?? '')) {
                    continue;
                }
            ?>
                <div
                    class="arraysubs-checkout-order-info-payment arraysubs-checkout-step-<?php echo esc_attr((string) $step_index); ?>"
                    data-arraysubs-order-info-payment="1"></div>
<?php
                return;
            }
        }
    }

    /**
     * Remove WooCommerce's default top-of-checkout coupon/notices output when
     * the builder contains a dedicated coupon/notices element.
     *
     * @return void
     */
    public function maybeRelocateCouponAndNoticesHooks(): void
    {
        if (! $this->hasCheckoutCouponNoticesElement()) {
            return;
        }

        remove_action('woocommerce_before_checkout_form', 'woocommerce_checkout_coupon_form', 10);
        remove_action('woocommerce_before_checkout_form', 'woocommerce_output_all_notices', 10);
        remove_action('woocommerce_before_checkout_form_cart_notices', 'woocommerce_output_all_notices', 10);
    }

    /**
     * Check whether the active builder config contains the coupon/notices element.
     *
     * @return bool
     */
    private function hasCheckoutCouponNoticesElement(): bool
    {
        if (! function_exists('is_checkout') || ! is_checkout() || ! function_exists('WC')) {
            return false;
        }

        if (! WC()->cart instanceof \WC_Cart || WC()->cart->is_empty()) {
            return false;
        }

        $config = self::getActiveConfig();
        if (empty($config)) {
            return false;
        }

        foreach ($this->getConfiguredSteps($config) as $step) {
            if ($this->fieldTreeHasType($step['fields'] ?? [], FieldRegistry::CHECKOUT_COUPON_NOTICES_TYPE)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Recursively determine whether a field tree contains a specific field type.
     *
     * @param array<int, array<string, mixed>> $fields Field tree.
     * @param string                           $type   Field type to look for.
     * @return bool
     */
    private function fieldTreeHasType(array $fields, string $type): bool
    {
        foreach ($fields as $field) {
            if (! is_array($field)) {
                continue;
            }

            if (($field['type'] ?? '') === $type) {
                return true;
            }

            if (empty($field['children']) || ! is_array($field['children'])) {
                continue;
            }

            $is_column_based = isset($field['children'][0])
                && is_array($field['children'][0])
                && ! isset($field['children'][0]['key']);

            if ($is_column_based) {
                foreach ($field['children'] as $column) {
                    if (is_array($column) && $this->fieldTreeHasType($column, $type)) {
                        return true;
                    }
                }

                continue;
            }

            if ($this->fieldTreeHasType($field['children'], $type)) {
                return true;
            }
        }

        return false;
    }
}
