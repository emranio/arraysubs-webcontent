<?php

/**
 * Checkout Builder Product Table Helper
 *
 * Handles configured product-table element rendering and cart syncing.
 *
 * @package ArraySubsPro\Features\CheckoutBuilder\Services
 */

namespace ArraySubsPro\Features\CheckoutBuilder\Services;

defined('ABSPATH') || exit;

/**
 * Shared product table helper for rendering and cart operations.
 */
class ProductTableHelper
{

    /**
     * Default visible column configuration.
     *
     * @return array<string, bool>
     */
    public static function getDefaultColumns(): array
    {
        return [
            'thumbnail'         => false,
            'title'             => true,
            'quantity'          => true,
            'sku'               => false,
            'price'             => true,
            'sale_price'        => false,
            'short_description' => false,
        ];
    }

    /**
     * Ensure the WooCommerce cart is ready for a public request.
     *
     * @return bool
     */
    public static function ensureCartReady(): bool
    {
        if (! function_exists('WC')) {
            return false;
        }

        if (function_exists('wc_load_cart')) {
            wc_load_cart();
        }

        return WC()->cart instanceof \WC_Cart;
    }

    /**
     * Resolve the configured columns for a product table field.
     *
     * @param array<string, mixed> $field Field configuration.
     * @return array<string, bool>
     */
    public static function getConfiguredColumns(array $field): array
    {
        $defaults = self::getDefaultColumns();
        $saved    = $field['type_settings']['columns'] ?? [];

        if (! is_array($saved)) {
            return $defaults;
        }

        foreach ($defaults as $column_key => $default_value) {
            $defaults[$column_key] = isset($saved[$column_key])
                ? (bool) $saved[$column_key]
                : $default_value;
        }

        return $defaults;
    }

    /**
     * Render the configured product table element.
     *
     * @param array<string, mixed> $field Field configuration.
     * @return void
     */
    public static function render(array $field): void
    {
        $products = self::resolveProductsForField($field);

        if (empty($products)) {
            return;
        }

        $columns       = self::getConfiguredColumns($field);
        $show_quantity = ! empty($columns['quantity']);
        $field_key     = sanitize_html_class($field['key'] ?? 'arraysubs_product_table');
?>
        <div class="arraysubs-product-table" id="<?php echo esc_attr($field_key); ?>" data-arraysubs-product-table="1">
            <div class="arraysubs-product-table__table-wrap">
                <table class="arraysubs-product-table__table shop_table shop_table_responsive">
                    <thead>
                        <tr>
                            <?php if (! empty($columns['thumbnail'])) : ?>
                                <th><?php esc_html_e('Thumbnail', 'arraysubspro'); ?></th>
                            <?php endif; ?>
                            <?php if (! empty($columns['title'])) : ?>
                                <th><?php esc_html_e('Title', 'arraysubspro'); ?></th>
                            <?php endif; ?>
                            <?php if (! empty($columns['quantity'])) : ?>
                                <th><?php esc_html_e('Quantity', 'arraysubspro'); ?></th>
                            <?php endif; ?>
                            <?php if (! empty($columns['sku'])) : ?>
                                <th><?php esc_html_e('SKU', 'arraysubspro'); ?></th>
                            <?php endif; ?>
                            <?php if (! empty($columns['price'])) : ?>
                                <th><?php esc_html_e('Price', 'arraysubspro'); ?></th>
                            <?php endif; ?>
                            <?php if (! empty($columns['sale_price'])) : ?>
                                <th><?php esc_html_e('Sale Price', 'arraysubspro'); ?></th>
                            <?php endif; ?>
                            <?php if (! empty($columns['short_description'])) : ?>
                                <th><?php esc_html_e('Short Description', 'arraysubspro'); ?></th>
                            <?php endif; ?>
                            <th><?php esc_html_e('Actions', 'arraysubspro'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($products as $product) : ?>
                            <?php
                            $product_id    = $product->get_id();
                            $cart_state    = self::getCartProductState($product_id);
                            $is_supported  = self::canAddProductFromCheckout($product);
                            $max_quantity  = $product->is_sold_individually() ? 1 : '';
                            $primary_label = $show_quantity
                                ? ($cart_state['in_cart'] ? __('Update', 'arraysubspro') : __('Add to Cart', 'arraysubspro'))
                                : ($cart_state['in_cart'] ? __('In Cart', 'arraysubspro') : __('Add to Cart', 'arraysubspro'));
                            $status_text   = $is_supported ? '' : self::getUnavailableMessage($product);
                            ?>
                            <tr
                                class="arraysubs-product-table__row<?php echo $cart_state['in_cart'] ? ' arraysubs-product-table__row--in-cart' : ''; ?><?php echo $is_supported ? '' : ' arraysubs-product-table__row--disabled'; ?>"
                                data-arraysubs-product-row="1"
                                data-product-id="<?php echo esc_attr((string) $product_id); ?>"
                                data-in-cart="<?php echo $cart_state['in_cart'] ? '1' : '0'; ?>"
                                data-in-cart-qty="<?php echo esc_attr((string) $cart_state['quantity']); ?>"
                                data-quantity-enabled="<?php echo $show_quantity ? '1' : '0'; ?>"
                                data-supported="<?php echo $is_supported ? '1' : '0'; ?>">
                                <?php if (! empty($columns['thumbnail'])) : ?>
                                    <td data-title="<?php esc_attr_e('Thumbnail', 'arraysubspro'); ?>" class="arraysubs-product-table__cell arraysubs-product-table__cell--thumbnail">
                                        <?php echo wp_kses_post($product->get_image('woocommerce_thumbnail')); ?>
                                    </td>
                                <?php endif; ?>
                                <?php if (! empty($columns['title'])) : ?>
                                    <td data-title="<?php esc_attr_e('Title', 'arraysubspro'); ?>" class="arraysubs-product-table__cell arraysubs-product-table__cell--title">
                                        <strong><?php echo esc_html($product->get_name()); ?></strong>
                                    </td>
                                <?php endif; ?>
                                <?php if (! empty($columns['quantity'])) : ?>
                                    <td data-title="<?php esc_attr_e('Quantity', 'arraysubspro'); ?>" class="arraysubs-product-table__cell arraysubs-product-table__cell--quantity">
                                        <input
                                            type="number"
                                            min="1"
                                            step="1"
                                            <?php echo '' !== $max_quantity ? 'max="' . esc_attr((string) $max_quantity) . '"' : ''; ?>
                                            value="<?php echo esc_attr((string) max(1, (int) $cart_state['quantity'] ?: 1)); ?>"
                                            class="input-text arraysubs-product-table__qty-input"
                                            data-arraysubs-product-qty="1"
                                            <?php disabled(! $is_supported); ?> />
                                    </td>
                                <?php endif; ?>
                                <?php if (! empty($columns['sku'])) : ?>
                                    <td data-title="<?php esc_attr_e('SKU', 'arraysubspro'); ?>" class="arraysubs-product-table__cell arraysubs-product-table__cell--sku">
                                        <?php echo $product->get_sku() ? esc_html($product->get_sku()) : '&mdash;'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped 
                                        ?>
                                    </td>
                                <?php endif; ?>
                                <?php if (! empty($columns['price'])) : ?>
                                    <td data-title="<?php esc_attr_e('Price', 'arraysubspro'); ?>" class="arraysubs-product-table__cell arraysubs-product-table__cell--price">
                                        <?php echo wp_kses_post(self::getRegularPriceHtml($product)); ?>
                                    </td>
                                <?php endif; ?>
                                <?php if (! empty($columns['sale_price'])) : ?>
                                    <td data-title="<?php esc_attr_e('Sale Price', 'arraysubspro'); ?>" class="arraysubs-product-table__cell arraysubs-product-table__cell--sale-price">
                                        <?php echo wp_kses_post(self::getSalePriceHtml($product)); ?>
                                    </td>
                                <?php endif; ?>
                                <?php if (! empty($columns['short_description'])) : ?>
                                    <td data-title="<?php esc_attr_e('Short Description', 'arraysubspro'); ?>" class="arraysubs-product-table__cell arraysubs-product-table__cell--description">
                                        <?php echo esc_html(wp_trim_words(wp_strip_all_tags($product->get_short_description()), 18)); ?>
                                    </td>
                                <?php endif; ?>
                                <td data-title="<?php esc_attr_e('Actions', 'arraysubspro'); ?>" class="arraysubs-product-table__cell arraysubs-product-table__cell--actions">
                                    <?php if ($is_supported) : ?>
                                        <div class="arraysubs-product-table__actions">
                                            <button
                                                type="button"
                                                class="button alt arraysubs-product-table__action-button"
                                                data-arraysubs-product-table-action="sync"
                                                data-label-add="<?php echo esc_attr__('Add to Cart', 'arraysubspro'); ?>"
                                                data-label-update="<?php echo esc_attr__('Update', 'arraysubspro'); ?>"
                                                data-label-added="<?php echo esc_attr__('In Cart', 'arraysubspro'); ?>"
                                                <?php disabled($cart_state['in_cart'] && ! $show_quantity); ?>>
                                                <?php echo esc_html($primary_label); ?>
                                            </button>
                                            <button
                                                type="button"
                                                class="button arraysubs-product-table__remove-button<?php echo $cart_state['in_cart'] ? '' : ' arraysubs-product-table__remove-button--hidden'; ?>"
                                                data-arraysubs-product-table-action="remove">
                                                <?php esc_html_e('Remove', 'arraysubspro'); ?>
                                            </button>
                                        </div>
                                    <?php else : ?>
                                        <span class="arraysubs-product-table__status"><?php echo esc_html($status_text); ?></span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
<?php
    }

    /**
     * Resolve all products configured for the field.
     *
     * @param array<string, mixed> $field Field configuration.
     * @return array<int, \WC_Product>
     */
    public static function resolveProductsForField(array $field): array
    {
        $settings     = is_array($field['type_settings'] ?? null) ? $field['type_settings'] : [];
        $product_ids  = self::normalizeIds($settings['product_ids'] ?? []);
        $category_ids = self::normalizeIds($settings['category_ids'] ?? []);
        $products     = [];
        $seen_ids     = [];

        if (! empty($product_ids)) {
            $specific_products = wc_get_products([
                'include' => $product_ids,
                'limit'   => -1,
                'status'  => 'publish',
            ]);

            $product_positions = array_flip($product_ids);

            usort(
                $specific_products,
                static function ($left, $right) use ($product_positions): int {
                    $left_position  = $product_positions[$left->get_id()] ?? PHP_INT_MAX;
                    $right_position = $product_positions[$right->get_id()] ?? PHP_INT_MAX;

                    return $left_position <=> $right_position;
                }
            );

            foreach ($specific_products as $product) {
                if (! $product instanceof \WC_Product) {
                    continue;
                }

                $seen_ids[$product->get_id()] = true;
                $products[]                   = $product;
            }
        }

        if (! empty($category_ids)) {
            $query = new \WP_Query([
                'post_type'      => 'product',
                'post_status'    => 'publish',
                'posts_per_page' => -1,
                'orderby'        => 'title',
                'order'          => 'ASC',
                'fields'         => 'ids',
                'tax_query'      => [ // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
                    [
                        'taxonomy' => 'product_cat',
                        'field'    => 'term_id',
                        'terms'    => $category_ids,
                    ],
                ],
            ]);

            foreach ($query->posts as $product_id) {
                $product_id = absint($product_id);

                if ($product_id <= 0 || isset($seen_ids[$product_id])) {
                    continue;
                }

                $product = wc_get_product($product_id);
                if (! $product instanceof \WC_Product) {
                    continue;
                }

                $seen_ids[$product_id] = true;
                $products[]            = $product;
            }

            wp_reset_postdata();
        }

        return $products;
    }

    /**
     * Get the cart state for a configured product.
     *
     * @param int $product_id Product ID.
     * @return array<string, mixed>
     */
    public static function getCartProductState(int $product_id): array
    {
        $state = [
            'product_id'     => $product_id,
            'in_cart'        => false,
            'quantity'       => 0,
            'cart_item_keys' => [],
        ];

        if ($product_id <= 0 || ! function_exists('WC') || ! WC()->cart instanceof \WC_Cart) {
            return $state;
        }

        foreach (WC()->cart->get_cart() as $cart_item_key => $cart_item) {
            $matched_product_id = ! empty($cart_item['variation_id'])
                ? (int) $cart_item['variation_id']
                : (int) ($cart_item['product_id'] ?? 0);

            if ($matched_product_id !== $product_id && (int) ($cart_item['product_id'] ?? 0) !== $product_id) {
                continue;
            }

            $state['in_cart']          = true;
            $state['quantity']        += max(1, absint($cart_item['quantity'] ?? 1));
            $state['cart_item_keys'][] = $cart_item_key;
        }

        return $state;
    }

    /**
     * Sync a product's quantity in the cart.
     *
     * @param int $product_id Product ID.
     * @param int $quantity   Desired quantity. Zero removes the product.
     * @return array<string, mixed>
     */
    public static function syncProductQuantity(int $product_id, int $quantity): array
    {
        wc_clear_notices();

        if (! self::ensureCartReady()) {
            wc_add_notice(__('The checkout cart is not available right now.', 'arraysubspro'), 'error');

            return [
                'success'      => false,
                'state'        => self::getCartProductState($product_id),
                'notices_html' => self::collectNoticesHtml(),
            ];
        }

        $product = wc_get_product($product_id);

        if (! $product instanceof \WC_Product) {
            wc_add_notice(__('The selected product could not be found.', 'arraysubspro'), 'error');

            return [
                'success'      => false,
                'state'        => self::getCartProductState($product_id),
                'notices_html' => self::collectNoticesHtml(),
            ];
        }

        $quantity     = max(0, absint($quantity));
        $current_state = self::getCartProductState($product_id);

        if ($quantity <= 0) {
            foreach ($current_state['cart_item_keys'] as $cart_item_key) {
                WC()->cart->remove_cart_item($cart_item_key);
            }

            WC()->cart->calculate_totals();

            return [
                'success'      => true,
                'state'        => self::getCartProductState($product_id),
                'notices_html' => self::collectNoticesHtml(),
            ];
        }

        if (! self::canAddProductFromCheckout($product)) {
            wc_add_notice(self::getUnavailableMessage($product), 'error');

            return [
                'success'      => false,
                'state'        => $current_state,
                'notices_html' => self::collectNoticesHtml(),
            ];
        }

        if (! empty($current_state['cart_item_keys'])) {
            $primary_item_key = array_shift($current_state['cart_item_keys']);
            $updated          = WC()->cart->set_quantity($primary_item_key, $quantity, true);

            if (! $updated) {
                wc_add_notice(__('The product quantity could not be updated.', 'arraysubspro'), 'error');

                return [
                    'success'      => false,
                    'state'        => self::getCartProductState($product_id),
                    'notices_html' => self::collectNoticesHtml(),
                ];
            }

            foreach ($current_state['cart_item_keys'] as $cart_item_key) {
                WC()->cart->remove_cart_item($cart_item_key);
            }

            WC()->cart->calculate_totals();

            return [
                'success'      => true,
                'state'        => self::getCartProductState($product_id),
                'notices_html' => self::collectNoticesHtml(),
            ];
        }

        $added_to_cart = WC()->cart->add_to_cart($product_id, $quantity);

        if (! $added_to_cart) {
            return [
                'success'      => false,
                'state'        => self::getCartProductState($product_id),
                'notices_html' => self::collectNoticesHtml(),
            ];
        }

        WC()->cart->calculate_totals();

        return [
            'success'      => true,
            'state'        => self::getCartProductState($product_id),
            'notices_html' => self::collectNoticesHtml(),
        ];
    }

    /**
     * Determine whether the product can be added directly from checkout.
     *
     * @param \WC_Product $product Product object.
     * @return bool
     */
    public static function canAddProductFromCheckout(\WC_Product $product): bool
    {
        if (! $product->exists() || ! $product->is_purchasable() || ! $product->is_in_stock()) {
            return false;
        }

        if ($product->is_type(['variable', 'grouped', 'external'])) {
            return false;
        }

        return true;
    }

    /**
     * Get an unavailable-product message for the checkout table.
     *
     * @param \WC_Product $product Product object.
     * @return string
     */
    public static function getUnavailableMessage(\WC_Product $product): string
    {
        if (! $product->is_in_stock()) {
            return __('Out of stock', 'arraysubspro');
        }

        if ($product->is_type(['variable', 'grouped'])) {
            return __('Choose options from the product page.', 'arraysubspro');
        }

        if ($product->is_type('external')) {
            return __('This product must be purchased from its product page.', 'arraysubspro');
        }

        return __('This product cannot be added from checkout.', 'arraysubspro');
    }

    /**
     * Get regular/current price HTML.
     *
     * @param \WC_Product $product Product object.
     * @return string
     */
    private static function getRegularPriceHtml(\WC_Product $product): string
    {
        $price = $product->get_regular_price();

        if ('' === $price || null === $price) {
            $price = $product->get_price();
        }

        if ('' === $price || null === $price) {
            return '&mdash;';
        }

        return wc_price(
            wc_get_price_to_display(
                $product,
                ['price' => (float) $price]
            )
        );
    }

    /**
     * Get sale price HTML.
     *
     * @param \WC_Product $product Product object.
     * @return string
     */
    private static function getSalePriceHtml(\WC_Product $product): string
    {
        if (! $product->is_on_sale()) {
            return '&mdash;';
        }

        $sale_price = $product->get_sale_price();

        if ('' === $sale_price || null === $sale_price) {
            return '&mdash;';
        }

        return wc_price(
            wc_get_price_to_display(
                $product,
                ['price' => (float) $sale_price]
            )
        );
    }

    /**
     * Normalize a saved list of numeric IDs.
     *
     * @param mixed $value Raw value.
     * @return array<int, int>
     */
    private static function normalizeIds($value): array
    {
        if (! is_array($value)) {
            return [];
        }

        return array_values(
            array_filter(
                array_map('absint', $value)
            )
        );
    }

    /**
     * Collect and clear WooCommerce notices as HTML.
     *
     * @return string
     */
    private static function collectNoticesHtml(): string
    {
        if (! function_exists('wc_notice_count') || ! function_exists('wc_print_notices')) {
            return '';
        }

        if (0 === wc_notice_count()) {
            return '';
        }

        $notices_html = wc_print_notices(true);
        wc_clear_notices();

        return is_string($notices_html) ? $notices_html : '';
    }
}
