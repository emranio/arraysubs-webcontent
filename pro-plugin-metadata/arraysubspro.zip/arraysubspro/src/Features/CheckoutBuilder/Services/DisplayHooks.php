<?php

/**
 * CheckoutBuilder Display Hooks
 *
 * Displays saved custom checkout field values in admin/customer order views
 * and appends them to the subscription detail REST response.
 *
 * @package ArraySubsPro\Features\CheckoutBuilder\Services
 * @since 1.0.0
 */

namespace ArraySubsPro\Features\CheckoutBuilder\Services;

defined('ABSPATH') || exit;

/**
 * Display hooks for saved Checkout Builder field values.
 */
class DisplayHooks
{
    /**
     * Enable auto-loading.
     *
     * @var bool
     */
    public static $loadable = true;

    /**
     * Register hooks.
     */
    public function __construct()
    {
        add_action('woocommerce_admin_order_data_after_order_details', [$this, 'renderAdminOrderFields']);
        add_action('woocommerce_order_details_after_order_table', [$this, 'renderCustomerOrderFields']);
        add_filter('arraysubs_subscription_detail_data', [$this, 'appendSubscriptionDetailFields'], 10, 2);
    }

    /**
     * Render custom checkout fields on the admin order screen.
     *
     * @param \WC_Order $order Order object.
     * @return void
     */
    public function renderAdminOrderFields($order): void
    {
        if (! $order instanceof \WC_Order) {
            return;
        }

        $config = $this->getActiveConfig();

        if (empty($config['show_on_order_admin'])) {
            return;
        }

        $rows = $this->getOrderFieldRows($order);

        if (empty($rows)) {
            return;
        }
?>
        <div class="order_data_column arraysubspro-checkout-builder-order-fields">
            <h4><?php esc_html_e('Checkout Builder Fields', 'arraysubspro'); ?></h4>
            <div class="address">
                <?php foreach ($rows as $row) : ?>
                    <p>
                        <strong><?php echo esc_html($row['label']); ?>:</strong>
                        <?php echo esc_html($row['value']); ?>
                    </p>
                <?php endforeach; ?>
            </div>
        </div>
    <?php
    }

    /**
     * Render custom checkout fields on the customer order details view.
     *
     * @param \WC_Order $order Order object.
     * @return void
     */
    public function renderCustomerOrderFields($order): void
    {
        if (! $order instanceof \WC_Order) {
            return;
        }

        $config = $this->getActiveConfig();

        if (empty($config['show_on_order_customer'])) {
            return;
        }

        $rows = $this->getOrderFieldRows($order);

        if (empty($rows)) {
            return;
        }
    ?>
        <section class="woocommerce-order-details arraysubspro-checkout-builder-order-fields">
            <h2 class="woocommerce-order-details__title"><?php esc_html_e('Additional Information', 'arraysubspro'); ?></h2>
            <table class="woocommerce-table woocommerce-table--order-details shop_table order_details">
                <tbody>
                    <?php foreach ($rows as $row) : ?>
                        <tr>
                            <th><?php echo esc_html($row['label']); ?></th>
                            <td><?php echo esc_html($row['value']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </section>
<?php
    }

    /**
     * Append custom checkout fields to the subscription detail REST payload.
     *
     * @param array $data            Subscription detail data.
     * @param int   $subscription_id Subscription ID.
     * @return array
     */
    public function appendSubscriptionDetailFields(array $data, int $subscription_id): array
    {
        $config = $this->getActiveConfig();

        if (empty($config['show_on_subscription_detail'])) {
            return $data;
        }

        $rows = $this->getPostFieldRows($subscription_id);

        if (! empty($rows)) {
            $data['checkout_builder_fields'] = $rows;
        }

        return $data;
    }

    /**
     * Get formatted field rows from an order.
     *
     * @param \WC_Order $order Order object.
     * @return array<int, array<string, string>>
     */
    private function getOrderFieldRows(\WC_Order $order): array
    {
        $rows = [];

        foreach ($this->getConfiguredFieldMap() as $field_key => $field) {
            $value = $order->get_meta($field_key, true);

            if ($this->isDisplayValueEmpty($value)) {
                continue;
            }

            $rows[] = [
                'key'   => $field_key,
                'label' => $field['label'] ?? $field_key,
                'value' => $this->formatDisplayValue($value, $field),
            ];
        }

        return $rows;
    }

    /**
     * Get formatted field rows from a subscription post.
     *
     * @param int $post_id Post ID.
     * @return array<int, array<string, string>>
     */
    private function getPostFieldRows(int $post_id): array
    {
        $rows = [];

        foreach ($this->getConfiguredFieldMap() as $field_key => $field) {
            $value = get_post_meta($post_id, $field_key, true);

            if ($this->isDisplayValueEmpty($value)) {
                continue;
            }

            $rows[] = [
                'key'   => $field_key,
                'label' => $field['label'] ?? $field_key,
                'value' => $this->formatDisplayValue($value, $field),
            ];
        }

        return $rows;
    }

    /**
     * Build a map of configured custom checkout fields.
     *
     * @return array<string, array<string, mixed>>
     */
    private function getConfiguredFieldMap(): array
    {
        $config = $this->getActiveConfig();

        if (empty($config)) {
            return [];
        }

        $field_map = [];

        foreach (MetaHandler::extractCustomFieldsFromConfig($config) as $field) {
            $key = $field['key'] ?? '';

            if ('' === $key) {
                continue;
            }

            if ('upload' === ($field['type'] ?? '') && empty($config['uploads_enabled'])) {
                continue;
            }

            $field_map[$key] = $field;
        }

        return $field_map;
    }

    /**
     * Format a field value for display.
     *
     * @param mixed $value Field value.
     * @param array $field Field config.
     * @return string
     */
    private function formatDisplayValue($value, array $field): string
    {
        $type = $field['type'] ?? 'text';

        if (is_array($value)) {
            if ('upload' === $type) {
                return $this->formatUploadDisplayValue($value);
            }

            if ('date_range' === $type) {
                $start = $value['start'] ?? '';
                $end   = $value['end'] ?? '';

                return trim(implode(' — ', array_filter([$start, $end])));
            }

            $mapped_values = $this->mapOptionLabels($value, $field);

            return implode(', ', array_map('strval', array_filter($mapped_values, static function ($item) {
                return '' !== $item && null !== $item;
            })));
        }

        if (in_array($type, ['checkbox', 'toggle'], true)) {
            return ! empty($value) ? __('Yes', 'arraysubspro') : __('No', 'arraysubspro');
        }

        if (in_array($type, ['select', 'image_select', 'grid_select'], true)) {
            $mapped_values = $this->mapOptionLabels([$value], $field);

            if (! empty($mapped_values[0])) {
                return (string) $mapped_values[0];
            }
        }

        return (string) $value;
    }

    /**
     * Map stored option values back to their configured labels.
     *
     * @param array<int, mixed>          $values Field values.
     * @param array<string, mixed>       $field  Field config.
     * @return array<int, mixed>
     */
    private function mapOptionLabels(array $values, array $field): array
    {
        $options = $field['options'] ?? $field['type_settings']['options'] ?? [];

        if (empty($options) || ! is_array($options)) {
            return $values;
        }

        $option_map = [];

        foreach ($options as $option) {
            if (! is_array($option) || empty($option['value'])) {
                continue;
            }

            $option_map[(string) $option['value']] = $option['label'] ?? $option['value'];
        }

        return array_map(static function ($value) use ($option_map) {
            $string_value = (string) $value;
            return $option_map[$string_value] ?? $string_value;
        }, $values);
    }

    /**
     * Format uploaded file values for order/subscription display.
     *
     * @param array<int, mixed> $files Uploaded files.
     * @return string
     */
    private function formatUploadDisplayValue(array $files): string
    {
        $labels = [];

        foreach ($files as $file) {
            if (is_array($file)) {
                $labels[] = $file['name'] ?? $file['url'] ?? '';
                continue;
            }

            $labels[] = (string) $file;
        }

        return implode(', ', array_filter($labels));
    }

    /**
     * Check whether a saved field value should be treated as empty.
     *
     * @param mixed $value Field value.
     * @return bool
     */
    private function isDisplayValueEmpty($value): bool
    {
        if (is_array($value)) {
            return empty(array_filter($value, static function ($item) {
                return '' !== $item && null !== $item;
            }));
        }

        return '' === $value || null === $value;
    }

    /**
     * Get the active Checkout Builder config.
     *
     * @return array<string, mixed>
     */
    private function getActiveConfig(): array
    {
        $settings = arraysubs_get_settings();
        $config   = $settings['checkout_builder'] ?? [];

        if (empty($config['enabled'])) {
            return [];
        }

        return $config;
    }
}
