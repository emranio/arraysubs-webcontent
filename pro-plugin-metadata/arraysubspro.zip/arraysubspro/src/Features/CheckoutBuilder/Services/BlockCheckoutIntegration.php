<?php

/**
 * Checkout Builder block checkout integration.
 *
 * @package ArraySubsPro\Features\CheckoutBuilder\Services
 */

namespace ArraySubsPro\Features\CheckoutBuilder\Services;

defined('ABSPATH') || exit;

/**
 * Registers Checkout Builder fields with WooCommerce Blocks.
 */
class BlockCheckoutIntegration
{
    /**
     * Enable auto-loading.
     *
     * @var bool
     */
    public static $loadable = true;

    /**
     * Constructor.
     */
    public function __construct()
    {
        add_action('init', [$this, 'registerCheckoutFields'], 20);
    }

    /**
     * Register supported builder inputs for the Checkout block.
     *
     * @return void
     */
    public function registerCheckoutFields(): void
    {
        if (! function_exists('woocommerce_register_additional_checkout_field')) {
            return;
        }

        $config = self::getActiveConfig();
        if (empty($config)) {
            return;
        }

        foreach (MetaHandler::extractCustomFieldsFromConfig($config) as $field) {
            $options = $this->buildCheckoutFieldOptions($field);
            if (empty($options)) {
                continue;
            }

            try {
                woocommerce_register_additional_checkout_field($options);
            } catch (\Throwable $throwable) {
                // Duplicate registration can happen in unusual bootstrap flows; ignore it.
                continue;
            }
        }
    }

    /**
     * Build Woo Blocks field options from a builder field.
     *
     * @param array<string, mixed> $field Builder field config.
     * @return array<string, mixed>
     */
    private function buildCheckoutFieldOptions(array $field): array
    {
        $key = (string) ($field['key'] ?? '');
        if ('' === $key) {
            return [];
        }

        $type = $this->mapBuilderTypeToBlockType((string) ($field['type'] ?? 'text'));
        if ('' === $type) {
            return [];
        }

        $options = [
            'id'                => MetaHandler::getBlockFieldIdForKey($key),
            'label'             => (string) ($field['label'] ?? $key),
            'location'          => 'order',
            'type'              => $type,
            'required'          => empty($field['visibility_rules']) && ! empty($field['is_required']),
            'attributes'        => [
                'data-arraysubs-cb-key' => $key,
            ],
            'sanitize_callback' => static function ($value) use ($field) {
                return MetaHandler::sanitizeFieldValue($field, $value);
            },
        ];

        if ('select' === $type) {
            $choices = $this->getFieldOptions($field);
            if (empty($choices)) {
                return [];
            }

            $options['options'] = array_values(
                array_map(
                    static function ($choice) {
                        return [
                            'value' => (string) ($choice['value'] ?? ''),
                            'label' => (string) ($choice['label'] ?? ''),
                        ];
                    },
                    $choices
                )
            );
        }

        return $options;
    }

    /**
     * Map builder type to supported Woo Blocks field type.
     *
     * @param string $type Builder field type.
     * @return string
     */
    private function mapBuilderTypeToBlockType(string $type): string
    {
        if (in_array($type, ['checkbox', 'toggle'], true)) {
            return 'checkbox';
        }

        if (in_array($type, ['select', 'image_select', 'grid_select'], true)) {
            return 'select';
        }

        if (in_array($type, ['text', 'number', 'email', 'phone', 'textarea', 'date', 'calendar', 'time', 'datetime', 'color_picker'], true)) {
            return 'text';
        }

        return '';
    }

    /**
     * Get options from a builder field.
     *
     * @param array<string, mixed> $field Builder field.
     * @return array<int, array<string, mixed>>
     */
    private function getFieldOptions(array $field): array
    {
        if (! empty($field['options']) && is_array($field['options'])) {
            return $field['options'];
        }

        if (! empty($field['type_settings']['options']) && is_array($field['type_settings']['options'])) {
            return $field['type_settings']['options'];
        }

        return [];
    }

    /**
     * Get the active builder config.
     *
     * @return array<string, mixed>
     */
    private static function getActiveConfig(): array
    {
        $settings = arraysubs_get_settings();
        $config   = $settings['checkout_builder'] ?? [];

        if (empty($config['enabled'])) {
            return [];
        }

        return is_array($config) ? $config : [];
    }
}
