<?php

/**
 * CheckoutBuilder MetaHandler
 *
 * Saves custom checkout field values to orders, copies them to subscriptions,
 * and carries them forward to renewal orders.
 *
 * @package ArraySubsPro\Features\CheckoutBuilder\Services
 * @since 1.0.0
 */

namespace ArraySubsPro\Features\CheckoutBuilder\Services;

defined('ABSPATH') || exit;

/**
 * Handles custom checkout field meta persistence across orders and subscriptions.
 */
class MetaHandler
{

    /**
     * Enable auto-loading.
     *
     * @var bool
     */
    public static $loadable = true;

    /**
     * Constructor.
     */
    public function __construct()
    {
        // Save custom fields to order on classic checkout.
        add_action('woocommerce_checkout_create_order', [$this, 'saveFieldsToOrder'], 20, 2);

        // Save custom fields on Store API / Block checkout.
        add_action('woocommerce_store_api_checkout_order_processed', [$this, 'saveFieldsFromStoreApi'], 20, 1);
        add_action('woocommerce_store_api_checkout_update_order_from_request', [$this, 'saveFieldsFromStoreApiRequest'], 20, 2);

        // Copy custom fields from order to subscription when created.
        add_action('arraysubs_data_created', [$this, 'copyFieldsToSubscription'], 20, 2);

        // Copy custom fields from subscription to renewal order.
        add_action('arraysubs_renewal_invoice_created', [$this, 'copyFieldsToRenewalOrder'], 20, 2);
    }

    /**
     * Save custom checkout fields to the order on classic checkout.
     *
     * @param \WC_Order        $order Order object.
     * @param array<string, mixed> $data  Checkout posted data.
     * @return void
     */
    public function saveFieldsToOrder($order, $data): void
    {
        if (! $order instanceof \WC_Order) {
            return;
        }

        $config = self::getActiveConfig();
        if (empty($config)) {
            return;
        }

        $custom_fields = self::extractCustomFieldsFromConfig($config);
        if (empty($custom_fields)) {
            return;
        }

        foreach ($custom_fields as $field) {
            $key = $field['key'];

            if ('upload' === ($field['type'] ?? '')) {
                $value = $this->handleUploadedField($field);
            } else {
                // phpcs:ignore WordPress.Security.NonceVerification.Missing -- WooCommerce handles nonce.
                $value = isset($_POST[$key]) ? self::sanitizeFieldValue($field, wp_unslash($_POST[$key])) : '';
            }

            if (self::hasMeaningfulValue($value)) {
                $order->update_meta_data($key, $value);
            }
        }

        $order->save_meta_data();
    }

    /**
     * Save custom fields from the Store API (Block checkout).
     *
     * @param int $order_id Order ID.
     * @return void
     */
    public function saveFieldsFromStoreApi($order_id): void
    {
        $order = wc_get_order($order_id);
        if (! $order) {
            return;
        }

        $config = self::getActiveConfig();
        if (empty($config)) {
            return;
        }

        $custom_fields = self::extractCustomFieldsFromConfig($config);
        if (empty($custom_fields)) {
            return;
        }

        // Store API extensions pass data via the order's existing meta at this point.
        // The BlockIntegration class handles registering the schema and pushing initial meta.
        // Here we just ensure all expected fields are present.
        foreach ($custom_fields as $field) {
            $value = $order->get_meta($field['key']);
            if (! self::hasMeaningfulValue($value)) {
                $value = $order->get_meta('_wc_other/' . self::getBlockFieldIdForKey((string) $field['key']));
            }

            if (self::hasMeaningfulValue($value)) {
                $order->update_meta_data(
                    $field['key'],
                    self::sanitizeFieldValue($field, $value)
                );
            }
        }

        $order->save_meta_data();
    }

    /**
     * Save custom fields from the Store API request to ArraySubs meta keys.
     *
     * @param \WC_Order        $order   Order object.
     * @param \WP_REST_Request $request Store API checkout request.
     * @return void
     */
    public function saveFieldsFromStoreApiRequest($order, $request): void
    {
        if (! $order instanceof \WC_Order || ! $request instanceof \WP_REST_Request) {
            return;
        }

        $config = self::getActiveConfig();
        if (empty($config)) {
            return;
        }

        $custom_fields = self::extractCustomFieldsFromConfig($config);
        if (empty($custom_fields)) {
            return;
        }

        $posted_values = (array) ($request->get_param('additional_fields') ?? []);

        foreach ($custom_fields as $field) {
            $key      = (string) ($field['key'] ?? '');
            $block_id = self::getBlockFieldIdForKey($key);

            if ('' === $key || '' === $block_id) {
                continue;
            }

            if (! self::isFieldVisibleForStoreApi($field, $posted_values)) {
                $order->delete_meta_data($key);
                continue;
            }

            $value = array_key_exists($block_id, $posted_values) ? $posted_values[$block_id] : '';
            $value = self::sanitizeFieldValue($field, $value);

            if (self::hasMeaningfulValue($value)) {
                $order->update_meta_data($key, $value);
            } else {
                $order->delete_meta_data($key);
            }
        }
    }

    /**
     * Copy custom checkout fields from the order to the new subscription.
     *
     * @param int             $subscription_id Subscription ID.
     * @param \WP_Post|mixed  $subscription    Subscription post object.
     * @return void
     */
    public function copyFieldsToSubscription(int $subscription_id, $subscription): void
    {
        $config = self::getActiveConfig();
        if (empty($config) || empty($config['copy_to_subscription'])) {
            return;
        }

        $subscription = ($subscription instanceof \WP_Post)
            ? $subscription
            : arraysubs_get_subscription($subscription_id);

        if (! $subscription) {
            return;
        }

        // Get the parent order ID from the subscription.
        $order_id = (int) get_post_meta($subscription_id, '_order_id', true);
        if ($order_id <= 0) {
            return;
        }

        $order = wc_get_order($order_id);
        if (! $order) {
            return;
        }

        self::copyCustomFieldMeta($order, $subscription_id, 'post');
    }

    /**
     * Copy custom checkout fields from the subscription to a renewal order.
     *
     * @param int $subscription_id Subscription ID.
     * @param int $order_id        Renewal order ID.
     * @return void
     */
    public function copyFieldsToRenewalOrder(int $subscription_id, int $order_id): void
    {
        $config = self::getActiveConfig();
        if (empty($config) || empty($config['copy_to_renewal'])) {
            return;
        }

        $order = wc_get_order($order_id);
        if (! $order) {
            return;
        }

        self::copyCustomFieldMeta($subscription_id, $order, 'order');
    }

    /**
     * Copy all _arraysubs_cf_* meta from source to target.
     *
     * @param \WC_Order|int $source      Source (order or subscription ID).
     * @param \WC_Order|int $target      Target (order or subscription ID).
     * @param string        $target_type 'post' for subscription post meta, 'order' for WC order meta.
     * @return void
     */
    private static function copyCustomFieldMeta($source, $target, string $target_type): void
    {
        $prefix = FieldRegistry::META_PREFIX;

        if ($source instanceof \WC_Order) {
            $meta_data = $source->get_meta_data();
            $cf_meta   = [];

            foreach ($meta_data as $meta) {
                $data = $meta->get_data();
                if (isset($data['key']) && 0 === strpos($data['key'], $prefix)) {
                    $cf_meta[$data['key']] = $data['value'];
                }
            }
        } else {
            // Source is a post ID (subscription).
            $all_meta = get_post_meta((int) $source);
            $cf_meta  = [];

            foreach ($all_meta as $key => $values) {
                if (0 === strpos($key, $prefix)) {
                    $cf_meta[$key] = $values[0] ?? '';
                }
            }
        }

        if (empty($cf_meta)) {
            return;
        }

        if ('order' === $target_type && $target instanceof \WC_Order) {
            foreach ($cf_meta as $key => $value) {
                $target->update_meta_data($key, $value);
            }
            $target->save_meta_data();
        } elseif ('post' === $target_type && is_numeric($target)) {
            foreach ($cf_meta as $key => $value) {
                update_post_meta((int) $target, $key, $value);
            }
        }
    }

    /**
     * Get the currently active builder configuration.
     *
     * @return array<string, mixed>
     */
    private static function getActiveConfig(): array
    {
        $settings = arraysubs_get_settings();
        $config   = $settings['checkout_builder'] ?? [];

        if (empty($config['enabled'])) {
            return [];
        }

        return $config;
    }

    /**
     * Extract all custom (non-WC) input fields from the builder config.
     *
     * @param array<string, mixed> $config Builder config.
     * @return array<array<string, mixed>>
     */
    public static function extractCustomFieldsFromConfig(array $config): array
    {
        $mode   = $config['mode'] ?? 'default';
        $fields = [];

        if ('default' === $mode) {
            $sections = $config['default']['sections'] ?? [];
            foreach ($sections as $section) {
                $fields = array_merge($fields, self::collectCustomFields($section['fields'] ?? []));
            }
        } else {
            $steps = $config['multistep']['steps'] ?? [];
            foreach ($steps as $step) {
                $fields = array_merge($fields, self::collectCustomFields($step['fields'] ?? []));
            }
        }

        return $fields;
    }

    /**
     * Recursively collect custom input fields from a field tree.
     *
     * @param array<int, array<string, mixed>> $fields Field tree.
     * @return array<int, array<string, mixed>>
     */
    private static function collectCustomFields(array $fields): array
    {
        $collected = [];

        foreach ($fields as $field) {
            if (! is_array($field)) {
                continue;
            }

            if (self::isCustomInputField($field)) {
                $collected[] = $field;
            }

            if (! empty($field['children']) && is_array($field['children'])) {
                $collected = array_merge($collected, self::collectCustomFields($field['children']));
            }
        }

        return $collected;
    }

    /**
     * Check if a field is a custom input field (not layout, not WC built-in).
     *
     * @param array<string, mixed> $field Field config.
     * @return bool
     */
    private static function isCustomInputField(array $field): bool
    {
        $type = $field['type'] ?? '';

        if (FieldRegistry::isLayoutField($type)) {
            return false;
        }

        return ! empty($field['is_custom']);
    }

    /**
     * Sanitize a field value based on its type.
     *
     * @param array<string, mixed> $field Field config.
     * @param mixed                $value Raw value.
     * @return mixed Sanitized value.
     */
    public static function sanitizeFieldValue(array $field, $value)
    {
        $type = $field['type'] ?? 'text';

        switch ($type) {
            case 'email':
                return sanitize_email($value);

            case 'number':
                return is_numeric($value) ? (float) $value : '';

            case 'textarea':
                return sanitize_textarea_field($value);

            case 'url':
                return esc_url_raw($value);

            case 'checkbox':
            case 'toggle':
                return (bool) $value ? '1' : '0';

            case 'multi_select':
            case 'image_select':
            case 'grid_select':
                if (is_array($value)) {
                    return array_map('sanitize_text_field', $value);
                }
                return sanitize_text_field($value);

            case 'date_range':
                if (is_array($value)) {
                    return [
                        'start' => sanitize_text_field($value['start'] ?? ''),
                        'end'   => sanitize_text_field($value['end'] ?? ''),
                    ];
                }
                return '';

            case 'color_picker':
                return sanitize_hex_color($value) ?: '';

            case 'upload':
                if (is_array($value)) {
                    return array_values(
                        array_filter(
                            array_map(
                                static function ($file) {
                                    if (! is_array($file)) {
                                        return null;
                                    }

                                    return [
                                        'name' => sanitize_text_field($file['name'] ?? ''),
                                        'url'  => esc_url_raw($file['url'] ?? ''),
                                        'type' => sanitize_text_field($file['type'] ?? ''),
                                    ];
                                },
                                $value
                            )
                        )
                    );
                }
                return [];

            default:
                return sanitize_text_field($value);
        }
    }

    /**
     * Handle a classic checkout upload field and return normalized saved data.
     *
     * @param array<string, mixed> $field Field config.
     * @return array<int, array<string, string>>
     */
    private function handleUploadedField(array $field): array
    {
        if (! arraysubs_get_setting('checkout_builder.uploads_enabled', false)) {
            return [];
        }

        $key = $field['key'] ?? '';

        if ('' === $key) {
            return [];
        }

        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Raw file payload is validated and normalized below.
        if (empty($_FILES[$key]) || empty($_FILES[$key]['name'])) {
            return [];
        }

        require_once ABSPATH . 'wp-admin/includes/file.php';

        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Raw file payload is validated and normalized below.
        $files          = $this->normalizeUploadedFiles($_FILES[$key]);
        $allowed_mimes  = $this->getAllowedMimeTypes($field['type_settings']['allowed_types'] ?? []);
        $uploaded_files = [];

        foreach ($files as $file) {
            if (empty($file['name']) || ! empty($file['error'])) {
                continue;
            }

            $upload = wp_handle_upload(
                $file,
                [
                    'test_form' => false,
                    'mimes'     => $allowed_mimes,
                ]
            );

            if (! empty($upload['error']) || empty($upload['url'])) {
                continue;
            }

            $uploaded_files[] = [
                'name' => sanitize_text_field($file['name']),
                'url'  => esc_url_raw($upload['url']),
                'type' => sanitize_text_field($upload['type'] ?? ''),
            ];
        }

        return $uploaded_files;
    }

    /**
     * Normalize a PHP file payload into a flat file list.
     *
     * @param array<string, mixed> $files Raw file payload.
     * @return array<int, array<string, mixed>>
     */
    private function normalizeUploadedFiles(array $files): array
    {
        if (! is_array($files['name'] ?? null)) {
            return [$files];
        }

        $normalized = [];

        foreach (array_keys($files['name']) as $index) {
            $normalized[] = [
                'name'     => $files['name'][$index] ?? '',
                'type'     => $files['type'][$index] ?? '',
                'tmp_name' => $files['tmp_name'][$index] ?? '',
                'error'    => $files['error'][$index] ?? UPLOAD_ERR_NO_FILE,
                'size'     => $files['size'][$index] ?? 0,
            ];
        }

        return $normalized;
    }

    /**
     * Convert allowed upload groups into a WordPress mime map.
     *
     * @param array<int, string> $allowed_types Allowed type groups.
     * @return array<string, string>
     */
    private function getAllowedMimeTypes(array $allowed_types): array
    {
        $group_map = [
            'image' => [
                'jpg|jpeg|jpe' => 'image/jpeg',
                'png'          => 'image/png',
                'gif'          => 'image/gif',
                'webp'         => 'image/webp',
            ],
            'pdf'   => [
                'pdf' => 'application/pdf',
            ],
            'doc'   => [
                'doc'  => 'application/msword',
                'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            ],
        ];

        $mimes = [];

        foreach ($allowed_types as $allowed_type) {
            if (! empty($group_map[$allowed_type])) {
                $mimes = array_merge($mimes, $group_map[$allowed_type]);
            }
        }

        return ! empty($mimes) ? $mimes : get_allowed_mime_types();
    }

    /**
     * Determine whether a saved field value should be persisted.
     *
     * @param mixed $value Field value.
     * @return bool
     */
    public static function hasMeaningfulValue($value): bool
    {
        if (is_array($value)) {
            return ! empty(array_filter($value, static function ($item) {
                if (is_array($item)) {
                    return ! empty(array_filter($item, static function ($nested) {
                        return '' !== $nested && null !== $nested;
                    }));
                }

                return '' !== $item && null !== $item;
            }));
        }

        return '' !== $value && null !== $value;
    }

    /**
     * Build a Woo Blocks additional-field ID for a custom field key.
     *
     * @param string $key Builder field meta key.
     * @return string
     */
    public static function getBlockFieldIdForKey(string $key): string
    {
        $field_id = sanitize_key(ltrim($key, '_'));

        return '' !== $field_id ? 'arraysubs/' . $field_id : '';
    }

    /**
     * Check Store API conditional visibility using posted additional field data.
     *
     * @param array<string, mixed> $field         Builder field.
     * @param array<string, mixed> $posted_values Store API additional_fields.
     * @return bool
     */
    private static function isFieldVisibleForStoreApi(array $field, array $posted_values): bool
    {
        $rules = $field['visibility_rules'] ?? [];
        if (empty($rules) || ! is_array($rules)) {
            return true;
        }

        $results = [];
        foreach ($rules as $rule) {
            if (! is_array($rule)) {
                continue;
            }

            $target_key = (string) ($rule['field'] ?? '');
            $block_id   = self::getBlockFieldIdForKey($target_key);
            $value      = array_key_exists($block_id, $posted_values) ? $posted_values[$block_id] : '';
            $value      = self::normalizeConditionalValue($value);
            $expected   = self::normalizeConditionalValue($rule['value'] ?? '');
            $operator   = (string) ($rule['operator'] ?? 'is');

            switch ($operator) {
                case 'is':
                    $result = ($value === $expected);
                    break;
                case 'is_not':
                    $result = ($value !== $expected);
                    break;
                case 'contains':
                    $result = false !== strpos($value, $expected);
                    break;
                case 'is_empty':
                    $result = '' === $value;
                    break;
                case 'is_not_empty':
                    $result = '' !== $value;
                    break;
                default:
                    $result = true;
                    break;
            }

            $results[] = [
                'result' => $result,
                'logic'  => strtoupper((string) ($rule['logic'] ?? 'AND')),
            ];
        }

        if (empty($results)) {
            return true;
        }

        $visible = $results[0]['result'];

        for ($i = 1, $count = count($results); $i < $count; $i++) {
            $visible = 'OR' === $results[$i]['logic']
                ? $visible || $results[$i]['result']
                : $visible && $results[$i]['result'];
        }

        return $visible;
    }

    /**
     * Normalize values for conditional comparisons.
     *
     * @param mixed $value Raw value.
     * @return string
     */
    private static function normalizeConditionalValue($value): string
    {
        if (is_bool($value)) {
            return $value ? '1' : '';
        }

        if (is_array($value)) {
            return implode(',', array_map('strval', $value));
        }

        return (string) $value;
    }
}
