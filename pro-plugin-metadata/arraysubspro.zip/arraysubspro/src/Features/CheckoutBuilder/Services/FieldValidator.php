<?php

/**
 * CheckoutBuilder FieldValidator
 *
 * Server-side validation for custom checkout fields.
 *
 * @package ArraySubsPro\Features\CheckoutBuilder\Services
 * @since 1.0.0
 */

namespace ArraySubsPro\Features\CheckoutBuilder\Services;

defined('ABSPATH') || exit;

/**
 * Validates custom checkout fields before order creation.
 */
class FieldValidator
{

    /**
     * Enable auto-loading.
     *
     * @var bool
     */
    public static $loadable = true;

    /**
     * Constructor.
     */
    public function __construct()
    {
        add_action('woocommerce_after_checkout_validation', [$this, 'validateCheckoutFields'], 10, 2);
    }

    /**
     * Validate custom checkout fields after WooCommerce checkout validation.
     *
     * @param array     $data   Checkout posted data.
     * @param \WP_Error $errors WP_Error object to add validation errors to.
     * @return void
     */
    public function validateCheckoutFields(array $data, \WP_Error $errors): void
    {
        $settings = arraysubs_get_settings();
        $config   = $settings['checkout_builder'] ?? [];

        if (empty($config) || empty($config['enabled'])) {
            return;
        }

        $custom_fields = MetaHandler::extractCustomFieldsFromConfig($config);

        if (empty($custom_fields)) {
            return;
        }

        foreach ($custom_fields as $field) {
            $this->validateField($field, $errors);
        }
    }

    /**
     * Validate a single field.
     *
     * @param array     $field  Field config.
     * @param \WP_Error $errors Error object.
     * @return void
     */
    private function validateField(array $field, \WP_Error $errors): void
    {
        $key   = $field['key'] ?? '';
        $type  = $field['type'] ?? 'text';
        $label = $field['label'] ?? $key;

        // Check conditional visibility before validating.
        if (! $this->isFieldVisible($field)) {
            return;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- WooCommerce handles nonce.
        $value = isset($_POST[$key]) ? wp_unslash($_POST[$key]) : '';

        // Required field check.
        if (! empty($field['is_required']) && $this->isValueEmpty($value)) {
            $errors->add(
                'validation',
                sprintf(
                    /* translators: %s: Field label */
                    __('%s is a required field.', 'arraysubspro'),
                    '<strong>' . esc_html($label) . '</strong>'
                )
            );
            return;
        }

        // Skip further validation if empty and not required.
        if ($this->isValueEmpty($value)) {
            return;
        }

        // Type-specific validation.
        $this->validateByType($type, $value, $field, $label, $errors);
    }

    /**
     * Run type-specific validation.
     *
     * @param string    $type   Field type.
     * @param mixed     $value  Field value.
     * @param array     $field  Field config.
     * @param string    $label  Field label.
     * @param \WP_Error $errors Error object.
     * @return void
     */
    private function validateByType(string $type, $value, array $field, string $label, \WP_Error $errors): void
    {
        $settings = $field['type_settings'] ?? [];

        switch ($type) {
            case 'email':
                if (! is_email($value)) {
                    $errors->add(
                        'validation',
                        sprintf(
                            /* translators: %s: Field label */
                            __('%s is not a valid email address.', 'arraysubspro'),
                            '<strong>' . esc_html($label) . '</strong>'
                        )
                    );
                }
                break;

            case 'number':
                if (! is_numeric($value)) {
                    $errors->add(
                        'validation',
                        sprintf(
                            /* translators: %s: Field label */
                            __('%s must be a number.', 'arraysubspro'),
                            '<strong>' . esc_html($label) . '</strong>'
                        )
                    );
                } elseif (isset($settings['min']) && (float) $value < (float) $settings['min']) {
                    $errors->add(
                        'validation',
                        sprintf(
                            /* translators: 1: Field label, 2: Minimum value */
                            __('%1$s must be at least %2$s.', 'arraysubspro'),
                            '<strong>' . esc_html($label) . '</strong>',
                            esc_html($settings['min'])
                        )
                    );
                } elseif (isset($settings['max']) && (float) $value > (float) $settings['max']) {
                    $errors->add(
                        'validation',
                        sprintf(
                            /* translators: 1: Field label, 2: Maximum value */
                            __('%1$s must be no more than %2$s.', 'arraysubspro'),
                            '<strong>' . esc_html($label) . '</strong>',
                            esc_html($settings['max'])
                        )
                    );
                }
                break;

            case 'upload':
                $this->validateUpload($field, $label, $errors);
                break;

            case 'phone':
                // Basic phone validation - digits, spaces, dashes, plus, parens.
                $cleaned = preg_replace('/[\s\-\(\)\+]/', '', $value);
                if (! ctype_digit($cleaned) || strlen($cleaned) < 7) {
                    $errors->add(
                        'validation',
                        sprintf(
                            /* translators: %s: Field label */
                            __('%s is not a valid phone number.', 'arraysubspro'),
                            '<strong>' . esc_html($label) . '</strong>'
                        )
                    );
                }
                break;

            case 'date':
            case 'calendar':
                if (! $this->isValidDate($value)) {
                    $errors->add(
                        'validation',
                        sprintf(
                            /* translators: %s: Field label */
                            __('%s is not a valid date.', 'arraysubspro'),
                            '<strong>' . esc_html($label) . '</strong>'
                        )
                    );
                }
                break;

            case 'date_range':
                if (is_array($value)) {
                    $start = $value['start'] ?? '';
                    $end   = $value['end'] ?? '';

                    if ($start && ! $this->isValidDate($start)) {
                        $errors->add('validation', __('Start date is invalid.', 'arraysubspro'));
                    }
                    if ($end && ! $this->isValidDate($end)) {
                        $errors->add('validation', __('End date is invalid.', 'arraysubspro'));
                    }
                    if ($start && $end && strtotime($start) > strtotime($end)) {
                        $errors->add('validation', __('Start date must be before end date.', 'arraysubspro'));
                    }
                }
                break;
        }
    }

    /**
     * Validate file upload field.
     *
     * @param array     $field  Field config.
     * @param string    $label  Field label.
     * @param \WP_Error $errors Error object.
     * @return void
     */
    private function validateUpload(array $field, string $label, \WP_Error $errors): void
    {
        if (! arraysubs_get_setting('checkout_builder.uploads_enabled', false)) {
            return;
        }

        $key      = $field['key'] ?? '';
        $settings = $field['type_settings'] ?? [];

        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- File array is validated below.
        if (empty($_FILES[$key]) || empty($_FILES[$key]['name'])) {
            if (! empty($field['is_required'])) {
                $errors->add(
                    'validation',
                    sprintf(
                        /* translators: %s: Field label */
                        __('%s is a required field.', 'arraysubspro'),
                        '<strong>' . esc_html($label) . '</strong>'
                    )
                );
            }
            return;
        }

        $max_size  = absint($settings['max_file_size'] ?? 5) * 1024 * 1024; // Convert MB to bytes.
        $max_count = absint($settings['max_file_count'] ?? 1);

        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- File metadata, not user text.
        $files = $_FILES[$key];
        $names = is_array($files['name']) ? $files['name'] : [$files['name']];
        $sizes = is_array($files['size']) ? $files['size'] : [$files['size']];

        if (count($names) > $max_count) {
            $errors->add(
                'validation',
                sprintf(
                    /* translators: 1: Field label, 2: Max file count */
                    __('%1$s allows a maximum of %2$d files.', 'arraysubspro'),
                    '<strong>' . esc_html($label) . '</strong>',
                    $max_count
                )
            );
        }

        foreach ($sizes as $size) {
            if ((int) $size > $max_size) {
                $errors->add(
                    'validation',
                    sprintf(
                        /* translators: 1: Field label, 2: Max size in MB */
                        __('%1$s exceeds the maximum file size of %2$d MB.', 'arraysubspro'),
                        '<strong>' . esc_html($label) . '</strong>',
                        absint($settings['max_file_size'] ?? 5)
                    )
                );
                break;
            }
        }
    }

    /**
     * Check whether a field should be visible based on its visibility rules.
     *
     * @param array $field Field config.
     * @return bool
     */
    private function isFieldVisible(array $field): bool
    {
        $rules = $field['visibility_rules'] ?? [];

        if (empty($rules)) {
            return true;
        }

        // Evaluate rules against posted values.
        $results = [];

        foreach ($rules as $rule) {
            $target_key = $rule['field'] ?? '';
            $operator   = $rule['operator'] ?? 'is';

            // phpcs:ignore WordPress.Security.NonceVerification.Missing -- WooCommerce handles nonce.
            $target_value = isset($_POST[$target_key]) ? sanitize_text_field(wp_unslash($_POST[$target_key])) : '';
            $rule_value   = $rule['value'] ?? '';

            $result = false;
            switch ($operator) {
                case 'is':
                    $result = ($target_value === $rule_value);
                    break;
                case 'is_not':
                    $result = ($target_value !== $rule_value);
                    break;
                case 'contains':
                    $result = (false !== strpos($target_value, $rule_value));
                    break;
                case 'is_empty':
                    $result = ('' === $target_value);
                    break;
                case 'is_not_empty':
                    $result = ('' !== $target_value);
                    break;
            }

            $results[] = [
                'result' => $result,
                'logic'  => $rule['logic'] ?? 'AND',
            ];
        }

        // Evaluate combined result.
        if (empty($results)) {
            return true;
        }

        $combined = $results[0]['result'];

        for ($i = 1, $count = count($results); $i < $count; $i++) {
            if ('OR' === $results[$i]['logic']) {
                $combined = $combined || $results[$i]['result'];
            } else {
                $combined = $combined && $results[$i]['result'];
            }
        }

        return $combined;
    }

    /**
     * Check if a value is empty (handles arrays too).
     *
     * @param mixed $value Value to check.
     * @return bool
     */
    private function isValueEmpty($value): bool
    {
        if (is_array($value)) {
            return empty(array_filter($value, static function ($v) {
                return '' !== $v && null !== $v;
            }));
        }

        return '' === $value || null === $value;
    }

    /**
     * Validate a date string (Y-m-d format).
     *
     * @param string $date Date string.
     * @return bool
     */
    private function isValidDate(string $date): bool
    {
        $parsed = date_create_from_format('Y-m-d', $date);
        return $parsed && $parsed->format('Y-m-d') === $date;
    }
}
