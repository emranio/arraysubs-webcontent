<?php

/**
 * CheckoutBuilder Hooks
 *
 * Admin menu registration and asset enqueueing for the Checkout Builder.
 *
 * @package ArraySubsPro\Features\CheckoutBuilder\Services
 * @since 1.0.0
 */

namespace ArraySubsPro\Features\CheckoutBuilder\Services;

defined('ABSPATH') || exit;

use ArraySubs\Supports\Config;

/**
 * Checkout Builder hooks integration.
 */
class Hooks
{

    /**
     * Enable auto-loading.
     *
     * @var bool
     */
    public static $loadable = true;

    /**
     * Constructor.
     */
    public function __construct()
    {
        add_filter('arraysubs_main_admin_menu_items', [$this, 'registerMenuItems']);
        add_filter('arraysubs_sanitize_settings', [$this, 'sanitizeCheckoutBuilderSettings'], 10, 2);
        add_action('admin_enqueue_scripts', [$this, 'enqueueAdminAssets']);
    }

    /**
     * Sanitize Checkout Builder settings saved through the shared core settings API.
     *
     * @param array $sanitized Current sanitized settings.
     * @param array $settings  Raw settings payload.
     * @return array
     */
    public function sanitizeCheckoutBuilderSettings(array $sanitized, array $settings): array
    {
        if (! isset($settings['checkout_builder']) || ! is_array($settings['checkout_builder'])) {
            return $sanitized;
        }

        $checkout_builder = $settings['checkout_builder'];

        $sanitized['checkout_builder'] = array_merge(
            $sanitized['checkout_builder'] ?? [],
            [
                'enabled'                  => ! empty($checkout_builder['enabled']),
                'copy_to_subscription'     => ! empty($checkout_builder['copy_to_subscription']),
                'copy_to_renewal'          => ! empty($checkout_builder['copy_to_renewal']),
                'show_on_order_admin'      => ! empty($checkout_builder['show_on_order_admin']),
                'show_on_order_customer'   => ! empty($checkout_builder['show_on_order_customer']),
                'show_on_subscription_detail' => ! empty($checkout_builder['show_on_subscription_detail']),
                'uploads_enabled'          => ! empty($checkout_builder['uploads_enabled']),
                'uploads_max_size'         => absint($checkout_builder['uploads_max_size'] ?? 5),
            ]
        );

        return $sanitized;
    }

    /**
     * Register Checkout Builder menu items in the core admin menu.
     *
     * Inserts the menu before the Profile Builder item.
     *
     * @param array $items Existing menu items.
     * @return array
     */
    public function registerMenuItems(array $items): array
    {
        $checkout_builder_item = [
            'id'       => 'checkout-builder',
            'title'    => __('Checkout Builder', 'arraysubspro'),
            'icon'     => 'PenTool',
            'children' => [
                [
                    'id'    => 'checkout-builder-editor',
                    'title' => __('Editor', 'arraysubspro'),
                    'path'  => '/checkout-builder',
                ],
                [
                    'id'    => 'checkout-builder-settings',
                    'title' => __('Settings', 'arraysubspro'),
                    'path'  => '/checkout-builder/settings',
                ],
            ],
        ];

        // Find "profile-builder" index and insert before it.
        $profile_builder_index = null;
        foreach ($items as $index => $item) {
            if (isset($item['id']) && 'profile-builder' === $item['id']) {
                $profile_builder_index = $index;
                break;
            }
        }

        if (null !== $profile_builder_index) {
            array_splice($items, $profile_builder_index, 0, [$checkout_builder_item]);
        } else {
            // Fallback: add before settings.
            $settings_index = null;
            foreach ($items as $index => $item) {
                if (isset($item['id']) && 'settings' === $item['id']) {
                    $settings_index = $index;
                    break;
                }
            }

            if (null !== $settings_index) {
                array_splice($items, $settings_index, 0, [$checkout_builder_item]);
            } else {
                $items[] = $checkout_builder_item;
            }
        }

        return $items;
    }

    /**
     * Enqueue admin assets for the Checkout Builder page.
     *
     * Only loads on the core admin page where the React app runs.
     *
     * @param string $hook Current admin page hook.
     * @return void
     */
    public function enqueueAdminAssets(string $hook): void
    {
        if ('toplevel_page_arraysubs-mainadmin' !== $hook) {
            return;
        }

        $asset_file = Config::get('proplugin.public_path') . 'build/admin/checkout-builder.asset.php';
        $asset      = file_exists($asset_file)
            ? require $asset_file
            : ['dependencies' => ['wp-element', 'wp-i18n'], 'version' => ARRAYSUBSPRO_VERSION];

        wp_enqueue_style(
            'arraysubspro-checkout-builder',
            Config::get('proplugin.public_url') . 'build/admin/checkout-builder.css',
            [],
            $asset['version']
        );

        wp_enqueue_script(
            'arraysubspro-checkout-builder',
            Config::get('proplugin.public_url') . 'build/admin/checkout-builder.js',
            $asset['dependencies'],
            $asset['version'],
            true
        );

        wp_set_script_translations(
            'arraysubspro-checkout-builder',
            'arraysubspro',
            Config::get('proplugin.path') . 'languages'
        );
    }
}
