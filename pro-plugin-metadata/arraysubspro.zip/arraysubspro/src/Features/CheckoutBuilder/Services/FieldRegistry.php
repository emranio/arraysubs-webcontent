<?php

/**
 * CheckoutBuilder FieldRegistry
 *
 * Defines all supported checkout field types and their configuration schemas.
 *
 * @package ArraySubsPro\Features\CheckoutBuilder\Services
 * @since 1.0.0
 */

namespace ArraySubsPro\Features\CheckoutBuilder\Services;

defined('ABSPATH') || exit;

/**
 * Registry of all supported checkout field types and their settings.
 */
class FieldRegistry
{

    /**
     * Meta key prefix for custom checkout fields.
     *
     * @var string
     */
    const META_PREFIX = '_arraysubs_cf_';
    const CHECKOUT_COUPON_NOTICES_TYPE = 'checkout_coupon_notices';
    const CHECKOUT_COUPON_NOTICES_KEY  = 'arraysubs_checkout_coupon_notices';
    const ORDER_INFO_PAYMENT_TYPE = 'order_info_payment';
    const ORDER_INFO_PAYMENT_KEY  = 'arraysubs_order_info_payment';
    const ORDER_NOTES_TYPE        = 'order_notes';
    const ORDER_NOTES_KEY         = 'arraysubs_order_notes';

    /**
     * Get all standard field type definitions.
     *
     * @return array<string, array<string, mixed>>
     */
    public static function getFieldTypes(): array
    {
        return [
            // Standard fields.
            'text'         => [
                'label'    => __('Text', 'arraysubspro'),
                'category' => 'standard',
                'icon'     => 'Type',
            ],
            'number'       => [
                'label'    => __('Number', 'arraysubspro'),
                'category' => 'standard',
                'icon'     => 'Hash',
            ],
            'email'        => [
                'label'    => __('Email', 'arraysubspro'),
                'category' => 'standard',
                'icon'     => 'Mail',
            ],
            'phone'        => [
                'label'    => __('Phone', 'arraysubspro'),
                'category' => 'standard',
                'icon'     => 'Phone',
            ],
            'select'       => [
                'label'    => __('Select', 'arraysubspro'),
                'category' => 'standard',
                'icon'     => 'ChevronDown',
            ],
            'multi_select' => [
                'label'    => __('Multi Select', 'arraysubspro'),
                'category' => 'standard',
                'icon'     => 'List',
            ],
            'textarea'     => [
                'label'    => __('Textarea', 'arraysubspro'),
                'category' => 'standard',
                'icon'     => 'AlignLeft',
            ],
            'checkbox'     => [
                'label'    => __('Checkbox', 'arraysubspro'),
                'category' => 'standard',
                'icon'     => 'CheckSquare',
            ],
            'toggle'       => [
                'label'    => __('Toggle', 'arraysubspro'),
                'category' => 'standard',
                'icon'     => 'ToggleLeft',
            ],

            // Advanced fields.
            'upload'          => [
                'label'    => __('File Upload', 'arraysubspro'),
                'category' => 'advanced',
                'icon'     => 'Upload',
            ],
            'image_select'    => [
                'label'    => __('Image Select', 'arraysubspro'),
                'category' => 'advanced',
                'icon'     => 'Image',
            ],
            'grid_select'     => [
                'label'    => __('Grid Select', 'arraysubspro'),
                'category' => 'advanced',
                'icon'     => 'LayoutGrid',
            ],
            'color_picker'    => [
                'label'    => __('Color Picker', 'arraysubspro'),
                'category' => 'advanced',
                'icon'     => 'Palette',
            ],
            'calendar'        => [
                'label'    => __('Calendar', 'arraysubspro'),
                'category' => 'advanced',
                'icon'     => 'Calendar',
            ],
            'date'            => [
                'label'    => __('Date', 'arraysubspro'),
                'category' => 'advanced',
                'icon'     => 'CalendarDays',
            ],
            'datetime'        => [
                'label'    => __('Date & Time', 'arraysubspro'),
                'category' => 'advanced',
                'icon'     => 'Clock',
            ],
            'time'            => [
                'label'    => __('Time', 'arraysubspro'),
                'category' => 'advanced',
                'icon'     => 'Timer',
            ],
            'date_range'      => [
                'label'    => __('Date Range', 'arraysubspro'),
                'category' => 'advanced',
                'icon'     => 'CalendarRange',
            ],
            'product_table'   => [
                'label'    => __('Product Table', 'arraysubspro'),
                'category' => 'layout',
                'icon'     => 'TableProperties',
                'is_input' => false,
            ],

            // Layout fields (non-input).
            'heading'   => [
                'label'    => __('Heading', 'arraysubspro'),
                'category' => 'layout',
                'icon'     => 'Heading',
                'is_input' => false,
            ],
            'section'   => [
                'label'    => __('Section', 'arraysubspro'),
                'category' => 'layout',
                'icon'     => 'Columns',
                'is_input' => false,
            ],
            'paragraph' => [
                'label'    => __('Paragraph', 'arraysubspro'),
                'category' => 'layout',
                'icon'     => 'FileText',
                'is_input' => false,
            ],
            'alert'     => [
                'label'    => __('Alert', 'arraysubspro'),
                'category' => 'layout',
                'icon'     => 'AlertCircle',
                'is_input' => false,
            ],
            self::CHECKOUT_COUPON_NOTICES_TYPE => [
                'label'    => __('Coupon and Notices', 'arraysubspro'),
                'category' => 'layout',
                'icon'     => 'BadgePercent',
                'is_input' => false,
            ],
            self::ORDER_INFO_PAYMENT_TYPE => [
                'label'    => __('Order Info and Payment', 'arraysubspro'),
                'category' => 'layout',
                'icon'     => 'ReceiptText',
                'is_input' => false,
            ],
            'billing_address'  => [
                'label'    => __('Billing Address', 'arraysubspro'),
                'category' => 'layout',
                'icon'     => 'MapPin',
                'is_input' => false,
            ],
            'shipping_address' => [
                'label'    => __('Shipping Address', 'arraysubspro'),
                'category' => 'layout',
                'icon'     => 'Truck',
                'is_input' => false,
            ],
            self::ORDER_NOTES_TYPE => [
                'label'    => __('Order Notes', 'arraysubspro'),
                'category' => 'layout',
                'icon'     => 'StickyNote',
                'is_input' => false,
            ],
        ];
    }

    /**
     * Get WooCommerce locked fields that cannot be removed.
     *
     * @return array<string>
     */
    public static function getLockedFields(): array
    {
        return [
            'billing_email',
            'billing_first_name',
            'billing_last_name',
            'billing_country',
        ];
    }

    /**
     * Check whether a field type is a layout (non-input) type.
     *
     * @param string $type Field type key.
     * @return bool
     */
    public static function isLayoutField(string $type): bool
    {
        $types = self::getFieldTypes();

        if (! isset($types[$type])) {
            return false;
        }

        return isset($types[$type]['is_input']) && false === $types[$type]['is_input'];
    }

    /**
     * Get the default configuration for a new custom field.
     *
     * @param string $type  Field type.
     * @param string $label Field label.
     * @return array<string, mixed>
     */
    public static function getFieldDefaults(string $type, string $label): array
    {
        $key = sanitize_title($label);

        $base = [
            'key'              => self::META_PREFIX . $key,
            'type'             => $type,
            'label'            => $label,
            'placeholder'      => '',
            'is_required'      => false,
            'help_text'        => '',
            'default_value'    => '',
            'column_width'     => 'full',
            'css_class'        => '',
            'visibility_rules' => [],
            'is_custom'        => true,
        ];

        return $base;
    }
}
