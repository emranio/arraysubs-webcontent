<?php

/**
 * CheckoutBuilder Provider
 *
 * @package ArraySubsPro\Features\CheckoutBuilder
 * @since 1.0.0
 */

namespace ArraySubsPro\Features\CheckoutBuilder;

defined('ABSPATH') || exit;

use ArraySubs\Supports\Abstracts\AbstractLoader;

/**
 * Checkout Builder feature entry point.
 *
 * Provides a visual checkout field/step editor for WooCommerce checkout.
 */
class Provider extends AbstractLoader
{

    /**
     * Constructor.
     */
    public function __construct()
    {
        $this->classLoader([
            plugin_dir_path(__FILE__) . 'Services',
            plugin_dir_path(__FILE__) . 'REST',
        ]);
    }
}
