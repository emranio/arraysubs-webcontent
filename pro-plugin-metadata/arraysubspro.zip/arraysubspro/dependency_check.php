<?php

defined('ABSPATH') || exit;

// if function not exists
if (!function_exists('arraysubspro_check_dependency')) {
    function arraysubspro_check_dependency()
    {
        $fails = [];
        $dependencies = [
            // check for php version
            'PHP' => [
                'version' => '8.1',
                'condition' => (version_compare(PHP_VERSION, '8.1', '>='))
            ],
            'WordPress' => [
                'version' => '6.0',
                'condition' => (version_compare(get_bloginfo('version'), '6.0', '>='))
            ],
            // check for ArraySubs
            'ArraySubs' => [
                'version' => '1.0',
                'condition' => (
                    class_exists('ArraySubs') &&
                    defined('ARRAYSUBS_VERSION') &&
                    version_compare(ARRAYSUBS_VERSION, '1.0', '>=')
                )
            ],
            // check for WooCommerce
            'WooCommerce' => [
                'version' => '8.0',
                'condition' => (
                    class_exists('WooCommerce') &&
                    defined('WC_VERSION') &&
                    version_compare(WC_VERSION, '8.0', '>=')
                )
            ],
        ];

        foreach ($dependencies as $dependency => $config) {
            if (!$config['condition']) {
                $fails[] = [
                    'dependency' => $dependency,
                    'required_version' => $config['version'],
                ];
                // $fails[] = sprintf(
                //     /* translators: 1: platform name, 2: platform name, 3: required version */
                //     esc_html__('The %1$s version is not supported or installed. Please upgrade/ install your %2$s to at least %3$s.', 'arraysubspro'),
                //     $dependency,
                //     $dependency,
                //     $config['version']
                // );
            }
        }
        return $fails;
    }
}
