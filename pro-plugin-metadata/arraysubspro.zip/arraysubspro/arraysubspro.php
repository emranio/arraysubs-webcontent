<?php

use ArraySubs\Supports\ActionScheduler;
use ArraySubs\Supports\Config;

defined('ABSPATH') || exit;

/**
 * Plugin Name: ArraySubsPro - Pro Addon for ArraySubs WooCommerce Subscription Plugin
 * Description: Pro Addon for ArraySubs WooCommerce Subscription Plugin - Adds advanced features like analytics
 * Plugin URI: https://arrayhash.com/deals/arraysubs/
 * Author: Emran
 * Version: 1.0.2
 * Author URI: https://arrayhash.com
 * License: GPLv3 or later
 * License URI: https://www.gnu.org/licenses/gpl-3.0.html
 * Requires at least: 6.0
 * Tested up to: 6.9
 * Requires PHP: 8.1
 *
 * Text Domain: arraysubspro
 * Domain Path: /languages
 */


// define version constant 
if (!defined('ARRAYSUBSPRO_VERSION')) {
	define('ARRAYSUBSPRO_VERSION', '1.0.1');
}

// plugin prefix constant
if (!defined('ARRAYSUBSPRO_PREFIX')) {
	define('ARRAYSUBSPRO_PREFIX', 'arraysubspro');
}

// database table prefix constant: wpdb prefix + plugin prefix
if (!defined('ARRAYSUBSPRO_DB_PREFIX')) {
	global $wpdb;
	define('ARRAYSUBSPRO_DB_PREFIX', $wpdb->prefix . ARRAYSUBSPRO_PREFIX . '_');
}


final class ArraySubsPro
{
	protected static $pluginDir;
	protected static $initiated;

	public function __construct()
	{
		// initiate only once
		if (self::$initiated === true) {
			return;
		}
		self::$initiated = true;
		self::$pluginDir = plugin_dir_path(__FILE__);

		add_action('plugins_loaded', [$this, 'initiate'], 9);
		register_activation_hook(__FILE__, [$this, 'activatePlugin']);
		register_deactivation_hook(__FILE__, [$this, 'deactivatePlugin']);
	}

	public static function manageConfig()
	{
		// Add plugin configurations individually
		// src path is added from Boot.php
		Config::add('proplugin.name', 'ArraySubsPro');
		Config::add('proplugin.version', ARRAYSUBSPRO_VERSION);
		Config::add('proplugin.path', trailingslashit(plugin_dir_path(__FILE__)));
		Config::add('proplugin.url', trailingslashit(plugin_dir_url(__FILE__)));
		Config::add('proplugin.public_url', trailingslashit(plugin_dir_url(__FILE__)) . 'public/');
		Config::add('proplugin.public_path', trailingslashit(plugin_dir_path(__FILE__)) . 'public/');
		Config::add('proplugin.resources_url', trailingslashit(plugin_dir_url(__FILE__)) . 'src/resources/');
		Config::add('proplugin.resources_path', trailingslashit(plugin_dir_path(__FILE__)) . 'src/resources/');
		Config::add('proplugin.text_domain', 'arraysubspro');
		Config::add('proplugin.prefix', ARRAYSUBSPRO_PREFIX);
		Config::add('proplugin.file', __FILE__);
		// WordPress related configurations
		Config::add('wp.wp_version', get_bloginfo('version'));
		Config::add('wp.wp_upload_dir', wp_upload_dir());
		// wp-admin dashboard url
		Config::add('wp.wp_admin_url', admin_url());
	}

	public static function loadFunctions()
	{
		// include all files from functions directory: src/functions/*.php
		// could not use autoloader's classmap due to prefixing vendors.
		foreach (glob(self::$pluginDir . 'src/functions/*.php') as $file) {
			include_once $file;
		}
	}

	public function initiate()
	{
		// dependency check
		include_once self::$pluginDir . 'dependency_check.php';
		$fails = arraysubspro_check_dependency();
		if (!empty($fails)) {
			add_action('admin_notices', function () use ($fails) {
?>
				<div class="notice notice-error">
					<h4><?php esc_html_e('ArraySubsPro plugin is not activated due to the following dependency errors:', 'arraysubspro'); ?></h4>
					<ul>
						<?php foreach ($fails as $fail) : ?>
							<li>
								<?php
								printf(
									/* translators: 1: platform name, 2: platform name, 3: required version */
									esc_html__('The %1$s version is not supported or installed. Please upgrade/ install your %2$s to at least %3$s.', 'arraysubspro'),
									esc_html($fail['dependency']),
									esc_html($fail['dependency']),
									esc_html($fail['required_version'])
								);
								?>
							</li>
						<?php endforeach; ?>
					</ul>
				</div>
<?php
			});
			return;
		}

		add_action('arraysubs_before_boot', function () {
			// autoload composer dependencies
			// check if self::$pluginDir . 'vendor-prefixed/' dir exists
			if (is_dir(self::$pluginDir . 'vendor-prefixed/')) {
				require_once self::$pluginDir . 'vendor-prefixed/scoper-autoload.php';
			} else {
				require_once self::$pluginDir . 'vendor/scoper-autoload.php';
			}

			self::loadFunctions();
			self::manageConfig();
			// can be used by other plugins to load before boot
			new \ArraySubsPro\Boot();
		}, 5);
	}


	public function activatePlugin()
	{
		// include all files from activation directory by name asc: self::$pluginDir . 'src/plugin-lifecycle/activate-plugin/*-worker.php'
		foreach (glob(self::$pluginDir . 'src/plugin-lifecycle/activate-plugin/*-worker.php') as $file) {
			include_once $file;
		}
	}

	public function deactivatePlugin()
	{
		$this->unscheduleProGatewayActions();
	}

	/**
	 * Remove Pro-owned gateway maintenance jobs before Pro code unloads.
	 *
	 * @return void
	 */
	private function unscheduleProGatewayActions(): void
	{
		$actions = [
			[
				'hook'  => class_exists(ActionScheduler::class) ? ActionScheduler::HOOK_CLEANUP_WEBHOOK_EVENTS : 'arraysubs_cleanup_webhook_events',
				'group' => class_exists(ActionScheduler::class) ? ActionScheduler::GROUP_GATEWAY : 'arraysubs-gateway',
			],
			[
				'hook'  => class_exists(ActionScheduler::class) ? ActionScheduler::HOOK_GATEWAY_RECONCILE : 'arraysubs_gateway_reconcile',
				'group' => class_exists(ActionScheduler::class) ? ActionScheduler::GROUP_GATEWAY : 'arraysubs-gateway',
			],
		];

		foreach ($actions as $action) {
			if (class_exists(ActionScheduler::class)) {
				ActionScheduler::unscheduleAll($action['hook'], [], $action['group']);
				$this->deleteFailedProGatewayActions($action['hook'], $action['group']);
				continue;
			}

			if (function_exists('as_unschedule_all_actions')) {
				as_unschedule_all_actions($action['hook'], [], $action['group']);
			}

			$this->deleteFailedProGatewayActions($action['hook'], $action['group']);
		}
	}

	/**
	 * Delete failed Pro gateway maintenance rows that would be orphaned while Pro is inactive.
	 *
	 * @param string $hook  Action hook.
	 * @param string $group Action Scheduler group.
	 * @return void
	 */
	private function deleteFailedProGatewayActions(string $hook, string $group): void
	{
		if (
			! function_exists('as_get_scheduled_actions')
			|| ! class_exists('\ActionScheduler')
			|| ! class_exists('\ActionScheduler_Store')
		) {
			return;
		}

		$action_ids = as_get_scheduled_actions(
			[
				'hook'     => $hook,
				'group'    => $group,
				'status'   => \ActionScheduler_Store::STATUS_FAILED,
				'per_page' => -1,
			],
			'ids'
		);

		foreach ($action_ids as $action_id) {
			try {
				\ActionScheduler::store()->delete_action((int) $action_id);
			} catch (\Throwable $exception) {
				// Best-effort cleanup only; deactivation must not fail because of stale queue rows.
			}
		}
	}
}

new  ArraySubsPro();
